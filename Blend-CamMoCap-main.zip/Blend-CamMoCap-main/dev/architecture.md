# Architecture

Three deliverables and one contract between them.

```
   Android phone                      Wi-Fi                    Blender
┌───────────────────┐                                   ┌───────────────────┐
│ :app              │  POSE, 100 Hz, latest-wins UDP →  │ bl/   (needs bpy) │
│  sensors, ARCore  │  ← control, reliable UDP → ←      │  apply, panel,    │
│  Compose UI       │                                   │  record, viewport │
│  take library     │  take upload, TCP 47800 →         │                   │
├───────────────────┤                                   ├───────────────────┤
│ :protocol         │  ← camera frames, TCP 47810       │ core/ (no bpy)    │
│  pure JVM         │                                   │  session, codec,  │
│  codec + frames   │                                   │  filters, takes   │
└───────────────────┘                                   └───────────────────┘
                         spec/ + fixtures/
                    normative for both sides
```

## The two seams that make testing possible

**`blender/core/` imports no `bpy`.** It holds the wire codec, the session and
its sockets, the filters, take parsing, and the viewport stream's socket and
pacing logic. All of it runs under plain desktop `pytest`.

**`android/protocol/` imports nothing from Android.** Same codec, same frame
maths, same fixtures. It runs on the JVM under `:protocol:test`.

Everything that *cannot* be tested that way lives on the other side of the
seam — `blender/bl/` and `android/app/` — and the rule is to keep that side as
thin as it can be. When a decision turns out to be subtle, it moves across.
`CapturePacer` and `CaptureBudget` are both in `core/` for exactly this reason:
they used to be `if` statements inside a `bpy` function, where no test could
reach them, and both were wrong.

## The channels

| What | Transport | Why |
|---|---|---|
| POSE | UDP 47800, ~100 Hz, latest-wins | A late pose is worthless; a queue would turn jitter into lag. Stale and duplicate datagrams are dropped, never replayed. |
| Control (HELLO, PARAMS, RECORD_*, VIEWPORT_CONTROL…) | Same UDP socket, ACK + resend | Deliberate acts must not be lost. |
| Take upload | TCP, same port 47800 | The take you keep is recorded on the phone at full rate and uploaded after the cut, so Wi-Fi glitches only ever hit the live preview. |
| Camera frames | TCP 47810 | Pixels must never queue behind poses, or in front of them. |

Ports search upward if taken (47800–47809, 47810–47819).

`spec/protocol.md` is normative for all of it; `spec/viewport-channel.md` covers
the frame channel. The version byte is 1 and stays 1 — every addition so far has
been an optional key, which is the forward-compatibility rule the spec sets.

## Threading

**Blender.** `bpy` is touched only from the main thread. The add-on registers
one timer (`bl/apply.py`) and everything that touches the scene happens inside
it. Sockets run on their own threads and hand over through plain data. Capture
draws on the timer, then encodes and sends on a worker.

**Android.** `:app` owns the sensors, ARCore and persistence; `:protocol` owns
the socket and the codec and knows nothing about either. Exactly one pose source
*feeds* the session at a time — sensor rotation or ARCore, never both — though
the rotation listener keeps running alongside ARCore in a non-feeding mode,
because rotation must keep tracking while the camera cannot see.

## State that matters

- **Live filtering never touches recorded samples.** Smoothing shapes the
  preview; the bake resamples raw timestamped motion at scene FPS.
- **Pairing begins paused.** Tracking starts when the operator says *Go live*,
  so a reconnect never yanks the camera away from what they were doing.
- **Every take is kept** as a fake-user action. A new take never overwrites an
  old one.
- **Quaternions are Hamilton `(w, x, y, z)`**; coordinates are +X right, +Y up,
  −Z forward. Conversions happen at defined boundaries and are pinned by
  `fixtures/`. See `spec/coordinate-systems.md`.
