# Constraints that will bite you

Each of these was learned by breaking it. They are grouped by what you have to
be touching for them to matter.

## Blender's main thread

**`bpy` is main-thread only, and network work never goes near it.** The add-on
has one timer; everything that reads or writes the scene happens inside it.

**Never call `bpy.ops` from that timer.** `bpy.ops.screen.animation_play` from
the timer crashed Blender natively, repeatably, especially when applying takes
in succession. Playback advances frames by setting `frame_current` instead. The
same applies to any probe: `bpy.ops.view3d.localview` and
`bpy.ops.wm.quit_blender` are on the same list. Lab scripts exit with
`os._exit(0)`.

**A timer callback owns the main thread for as long as it runs.** Sleeping
inside one to "wait for a tick" waits for the thread you are holding. A probe
did exactly that, waiting for the tick to publish a size list, and got an empty
list every time — then silently skipped every resize it thought it was making.

**Installing an add-on does not reload it in a running Blender.** Restart
Blender fully before believing anything about a change.

## The GPU layer

**`gpu` drawing raises under `--background`.** The whole capture path is
therefore invisible to the headless suites; `tools/viewport_lab/in_blender/` is
its only coverage, and those scripts open a real window.

**A timer fires once per event-loop iteration, and that loop runs at the
viewport's redraw rate.** Measured: 30 Hz while the viewport redraws, 64–175 Hz
when nothing does, against the 120 Hz the timer asks for. The stream can never
be faster than the operator's own redraw, however cheap capture becomes.

**Do not count a depsgraph evaluation you triggered yourself as a scene
change.** Reading the evaluated camera forces one, which fires your own change
handler; treating that as "something changed" and then clearing the flag in the
same pass makes the next tick see an unchanged scene while the camera is
visibly moving. It cost exactly half the frame rate — 256 captures against 256
skips, one for one.

**`matrix_world` is derived, not stored.** Write a pose and read the matrix in
the same tick and you get the matrix from before it, indefinitely, if nothing
else forces an evaluation. Use `evaluated_get(depsgraph)`. It is also the only
correct answer for a parented, driven or constrained camera.

**`gpu.types.Buffer` misreports its strides.** `np.asarray` on one reads
transposed, channel-planar memory and produces a well-formed permutation of the
picture — which passes every test that checks sizes and headers. Flatten with
`buffer.dimensions = w * h * channels` and `np.frombuffer` instead.

**Framebuffer readback is bottom-up.** Row 0 is the bottom of the image. An
unflipped frame arrives upside down and, again, passes every structural check.

**A progressive render engine will not draw into an offscreen.**
`draw_view3d` asks once and returns. EEVEE and Workbench answer; Cycles
accumulates over many samples into buffers of its own and hands back the world
background — a flat fill, or pure black once overlays are suppressed. Substitute
a shading mode that draws synchronously; see `drawable_shading`.

**The render's aspect ratio is not its resolution's aspect ratio.** A non-square
`pixel_aspect` stretches the finished image without changing the pixel count. At
1158×798 with a 2:1 pixel aspect the shot is 2.902 wide, not 1.451.

## Sockets

**`SO_REUSEADDR` does not mean on Windows what it means on POSIX.** There it
lets a *second process* bind a port another is already listening on. Both binds
succeed, one process receives everything, and the other advertises a port that
silently swallows every client. Two Blender instances produced exactly that.
Windows needs `SO_EXCLUSIVEADDRUSE`, which fails the second bind loudly.

**Windows reports ICMP errors on UDP sockets.** Sending to a peer that has gone
away raises `ConnectionResetError` from the *next* `recvfrom`, not from the send
that caused it. POSIX does not do this at all, so code written there treats it
as "socket closed" and stops reading — and the host looks connected forever
while hearing nothing. `SIO_UDP_CONNRESET` switches it off.

**A long-lived loop decides whether to exit from its own running flag, never
from an exception.** `except OSError: break` in an accept loop turned one
aborted connection into a dead listener that still advertised its port. The same
defect was in three loops. If the flag is still set, count the error and
continue.

**A listen backlog of 1 is not "one at a time", it is "refuse the second".** A
client whose connect times out leaves a connection queued; the host accepts it
later and waits for a token that never comes, and every retry in that window is
refused, each producing another abandoned connection. It sustains itself until
restart.

## Testing and measurement

**Run the headless suites before believing a host change.** `blender/bl/`
imports `bpy`, so desktop `pytest` cannot reach it at all.
`tools/test-all-blenders.ps1` is the only coverage that layer has, and a broken
`headless_6dof.py` once shipped for a whole session because only the desktop and
Android suites were run.

**A test that passes against the bug is worth nothing.** Two have shipped here.
When you write a regression test, run it against the code you are fixing and
watch it fail first.

**A number saying the pipeline is running says nothing about what is in the
frame.** A Rendered-shading probe measured 16.6 fps and 35 ms captures for an
hour while producing black. Look at the artefact.
