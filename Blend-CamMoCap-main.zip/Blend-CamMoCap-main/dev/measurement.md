# Measurement

Two labs, deliberately separate, because their numbers mean different things.

## Motion Lab — deterministic, and gated

`tools/motion-lab.ps1`, sources in `tools/motion_lab/`.

Replays recorded motion through the real filters and conversion maths and
compares the result against `tools/motion_lab/baselines/*.json`, where each
metric carries a `{value, tol}` pair. Same input, same output, any machine. A
change that moves a gated number either fixes the baseline or is wrong, and the
PR has to say which.

```powershell
./tools/motion-lab.ps1
```

Run it for anything touching quaternions, frames, smoothing or resampling.

## Viewport Lab — wall-clock, and never gated

`tools/viewport_lab/`, with the generated report at
`tools/viewport_lab/viewport-lab-results.md`.

Measures what capture and streaming cost on *this* machine: draw and readback
times, main-thread share, encoder throughput, end-to-end latency. Every figure
depends on the GPU, the driver, the scene and what else is running.

**These numbers must never enter `motion_lab/baselines/`.** A wall-clock figure
inside a `{value, tol}` gate turns the suite into a coin flip on a busy machine.
The report says so at the top, and it stays true.

The raw runs under `tools/viewport_lab/results/` are gitignored — large,
machine-specific and reproducible by re-running. The generated markdown report
is tracked, because the conclusions are what other documents cite.

### The in-Blender probes

`tools/viewport_lab/in_blender/` needs a real window: `gpu` drawing raises under
`--background`. Each script runs unattended and exits itself.

```powershell
$b = "C:\Program Files\Blender Foundation\Blender 4.5\blender.exe"

# Where the main thread actually goes, three windows: connected, live poses,
# streaming. --sweep walks every size x rate; --profiles walks the presets;
# --minimise measures with the window down; --shading RENDERED forces a load.
& $b scene.blend --python tools/viewport_lab/in_blender/main_thread_budget.py -- --out results/budget.json

# Capture split seven ways, plus one-at-a-time variants.
& $b scene.blend --python tools/viewport_lab/in_blender/capture_stall.py -- --out results/split.json

# One frame, written to PNG, with the statistics that separate a render from a
# scramble. --shading and --engine force the awkward cases.
& $b scene.blend --python tools/viewport_lab/in_blender/dump_frame.py -- --out results/frame.png

# One frame per awkward scene condition, on a single contact sheet.
& $b scene.blend --python tools/viewport_lab/in_blender/frame_sweep.py -- --out results/sweep.png
```

## How to not fool yourself

Every wrong number in this project's history came from one of three mistakes,
and each is cheap to avoid once named.

**Measure the operating condition, not a convenient one.** A probe reported a
flat 0.75 ms draw from a scene nobody was moving. Another reported 19.5 ms from
a rolling take against a *paused* host — an interactive host starts paused, so
the poses it was sending moved nothing at all. Both numbers were real; neither
described a viewfinder. Probes now report `camera_travel_deg` per window, and a
window whose camera did not move is not a measurement.

**Establish that it reproduces.** A 12 ms draw was reported, acted on, and never
seen again. Repeat the baseline at the end of the run and quote both.

**Look at the artefact.** Sizes, headers and frame rates all pass while the
picture is a permutation, upside down, or black. `dump_frame.py` exists for this
and prints `adjacent_delta`, which separates a real render (single digits) from
a channel scramble (tens).

## Rendering the phone UI without a phone

Not a lab, but the same principle — look at it rather than reason about it.

```powershell
./tools/render-designs.ps1     # writes .designs/index.html
```

Draws every screen state at four device profiles and four phone rotations, on
the JVM, in seconds. A state absent from `TrayGallery.kt` never gets looked at,
so add one when you add a state.
