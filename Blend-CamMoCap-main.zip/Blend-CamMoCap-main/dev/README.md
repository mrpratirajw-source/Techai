# Developer notes

Four short documents for anyone changing this code. They cover what the source
does not say out loud — the shape of the system, the platform rules that will
bite you, and how the measurement tooling works.

| Document | Read it when |
|---|---|
| [architecture.md](architecture.md) | You are new, or you are about to add something that crosses a module boundary. |
| [constraints.md](constraints.md) | **Before touching the Blender add-on or the sockets.** Every rule in it was learned by breaking it. |
| [measurement.md](measurement.md) | You need a number, or you are about to trust one. |
| [testing.md](testing.md) | You want to know which suite covers what, and which one you can skip. |

Elsewhere:

- [`../CONTRIBUTING.md`](../CONTRIBUTING.md) — ground rules, licensing, how to open a PR.
- [`../QUICKSTART.md`](../QUICKSTART.md) — operational setup: build, install, run, troubleshoot.
- [`../spec/`](../spec/) — normative. The wire protocol, the coordinate
  conventions, and the viewport channel. Behaviour disagreements are settled
  there, not here.
