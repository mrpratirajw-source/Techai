# Testing

Four suites. They cover different layers and none of them is redundant.

```powershell
python -m pytest blender/tests -q            # host core, desktop Python, no bpy
./tools/test-all-blenders.ps1                # the above + headless on 4.5 / 5.0 / 5.1
cd android
./gradlew.bat :protocol:test                 # codec and frame maths, pure JVM
./gradlew.bat :app:testDebugUnitTest         # app logic and the design gallery
```

A change is ready when all four pass. `test-all-blenders.ps1` includes the
desktop pytest run, so it is the one to reach for when you are unsure.

## What each one can and cannot see

| Suite | Covers | Blind to |
|---|---|---|
| `pytest blender/tests` | `blender/core/` — wire codec, session, sockets, filters, takes, viewport pacing and budget | Anything importing `bpy`, which is all of `blender/bl/` |
| `test-all-blenders.ps1` | the above, plus live / record / recenter / 6DOF / pause driven headlessly against real Blender | Anything drawing: `gpu` raises under `--background` |
| `:protocol:test` | codec, frame conversion, take parsing, against the same `fixtures/` the host uses | Anything Android |
| `:app:testDebugUnitTest` | app-side policy, plus the Roborazzi design gallery | The device: sensors, ARCore, the real radio |

Two gaps are structural rather than accidental, and worth knowing:

**`blender/bl/` has no unit tests.** It imports `bpy`. The headless scripts are
its only coverage, which is why "the pytest suite passed" is not a reason to
believe a host change. `headless_6dof.py` once shipped broken for a whole
session on exactly that reasoning.

**The capture path has no automated coverage at all**, because `gpu` drawing
raises headlessly. `tools/viewport_lab/in_blender/` is the only thing that
exercises it, and it needs a real window. Anything in that path that *can* be
decided without `bpy` belongs in `blender/core/` instead — that is why the
capture pacer and the size controller live there.

## Fixtures are frozen

[`fixtures/`](../fixtures/) is cross-platform ground truth, consumed by both the
host and the phone. If a change makes a fixture test fail, the change is wrong.
Adding new cases is welcome; editing an existing one to make code pass is not.

## Writing a regression test

Run it against the unfixed code and **watch it fail** before you fix anything.
Two tests have shipped in this repo that passed against the very bug they were
written for, and both were caught only by trying it. If the failure is awkward
to reproduce, a throwaway script that monkey-patches the old behaviour back and
reruns the test is enough — that is how the capture-pacing tests were checked.

Where a decision is hard to test because it lives behind `bpy` or `gpu`, move
the decision rather than skipping the test.

## Looking at the UI

```powershell
./tools/render-designs.ps1     # writes .designs/index.html
```

Every screen state, four device profiles, four phone rotations, drawn on the JVM
in seconds. Add a case to `TrayGallery.kt` when you add a state, or it will
never be looked at.
