# SPDX-License-Identifier: GPL-3.0-or-later
"""pocketrig Blender extension entry point.

Import-safe on desktop Python: nothing here (or in `core/`) touches bpy.
The bpy-dependent layer lives in `bl/` and is imported lazily so plain
pytest can import this package. Codename and version live in
core/constants.py only.
"""


def register() -> None:
    from . import bl

    bl.register()


def unregister() -> None:
    from . import bl

    bl.unregister()
