# SPDX-License-Identifier: GPL-3.0-or-later
"""The viewport frame server and its codec, on the desktop.

`core/` is bpy-free precisely so this can run under plain pytest. The capture
that feeds it cannot be tested here — `gpu` drawing raises under
`--background` — but everything from "here are some encoded bytes" onward can,
and that is where the rules with teeth live.
"""

from __future__ import annotations

import socket
import threading
import struct
import time

import pytest

from core import protocol as P
from core.constants import (
    MSG_VIEWPORT_CONTROL,
    MSG_VIEWPORT_STAT,
    RELIABLE_TYPES,
    VIEWPORT_MAX_PAYLOAD_GUARD,
)
from core.viewport_stream import (
    AUTH_TIMEOUT_S,
    CaptureBudget,
    drawable_shading,
    CapturePacer,
    ViewportStream,
    camera_sizes,
    pack_rgb,
)

TOKEN = "K3XG9A"


def _client(port: int, token: str = TOKEN) -> socket.socket:
    sock = socket.create_connection(("127.0.0.1", port), timeout=3)
    sock.sendall((token + "\n").encode())
    return sock


def _read_frame(sock: socket.socket):
    """Read one framed frame, the way a conformant receiver must."""
    header = b""
    while len(header) < P.VIEWPORT_HEADER_SIZE:
        chunk = sock.recv(P.VIEWPORT_HEADER_SIZE - len(header))
        assert chunk, "connection closed mid-header"
        header += chunk
    parsed = P.decode_viewport_frame_header(header)
    assert parsed is not None, "header must decode"
    payload = b""
    while len(payload) < parsed.payload_len:
        chunk = sock.recv(parsed.payload_len - len(payload))
        assert chunk, "connection closed mid-payload"
        payload += chunk
    return parsed, payload


@pytest.fixture()
def stream():
    srv = ViewportStream(token_check=lambda t: t == TOKEN)
    port = srv.start()
    assert port is not None, "could not bind a viewport port"
    yield srv, port
    srv.stop()


# ------------------------------------------------------------------- framing

def test_frame_round_trips_header_and_payload(stream):
    srv, port = stream
    sock = _client(port)
    _wait_connected(srv)

    payload = b"\xff\xd8fake-jpeg\xff\xd9"
    assert srv.send_frame(payload, capture_ns=1234567)
    header, body = _read_frame(sock)

    assert body == payload
    assert header.ordinal == 0
    assert header.capture_ns == 1234567
    assert header.codec_name == "jpeg"
    assert header.is_keyframe, "every v1 codec is all-intra"
    sock.close()


def test_the_header_carries_the_size_that_was_actually_produced(stream):
    """A receiver must never have to infer geometry from the negotiated size:
    the operator can resize the viewport with no control message exchanged."""
    srv, port = stream
    sock = _client(port)
    _wait_connected(srv)
    assert srv.send_frame(b"body", capture_ns=1, width=793, height=444)
    header, _ = _read_frame(sock)
    assert (header.width, header.height) == (793, 444)
    sock.close()


def test_ordinal_advances_even_when_no_one_is_connected(stream):
    """A dropped frame still burns its ordinal.

    Without this the receiver cannot tell "the host skipped one" from "the
    network lost one", and the frame-loss figure the whole channel reports
    becomes meaningless.
    """
    srv, port = stream
    assert not srv.send_frame(b"x", capture_ns=1)  # nobody connected: dropped
    assert not srv.send_frame(b"x", capture_ns=2)

    sock = _client(port)
    _wait_connected(srv)
    assert srv.send_frame(b"payload", capture_ns=3)
    header, _ = _read_frame(sock)
    # A fresh connection restarts the count -- ordinals are per-connection.
    assert header.ordinal == 0
    sock.close()


def test_a_second_viewer_replaces_the_first(stream):
    """A phone that reconnects after a Wi-Fi blip must not be locked out by its
    own dead socket."""
    srv, port = stream
    first = _client(port)
    _wait_connected(srv)
    second = _client(port)
    # Waiting for "connected" would return instantly -- the FIRST viewer still
    # is. Wait for the peer to actually become this socket, or the test races
    # the accept loop and sends the frame to the connection being replaced.
    _wait_for_peer(srv, second.getsockname()[1])

    assert srv.send_frame(b"for-the-second", capture_ns=9)
    header, body = _read_frame(second)
    assert body == b"for-the-second"
    first.close()
    second.close()


# --------------------------------------------------------------------- auth

def test_a_wrong_token_gets_no_reply_and_no_stream(stream):
    srv, port = stream
    sock = socket.create_connection(("127.0.0.1", port), timeout=3)
    sock.sendall(b"WRONG1\n")
    time.sleep(0.3)
    assert not srv.connected, "a bad token must not become the viewer"
    sock.close()


def test_a_peer_that_sends_nothing_is_not_a_client(stream):
    srv, _port = stream
    assert not srv.connected


# ------------------------------------------------------------------- sizes

def test_camera_sizes_keep_the_render_aspect():
    """The viewfinder MUST be framed like the render.

    A 16:9 list against a 4:3 render would frame the phone against something the
    camera is not shooting, which for an instrument used to judge framing is a
    correctness bug rather than a cosmetic one.
    """
    for width, height in ((1920, 1080), (1024, 768), (2048, 858), (1080, 1920)):
        source = width / height
        for w, h in camera_sizes(width, height):
            assert abs(w / h - source) / source < 0.02, f"{w}x{h} distorts {source}"


def test_camera_sizes_follow_the_pixel_aspect_not_the_resolution():
    """Pixels are square only by default.

    A non-square `pixel_aspect` stretches the finished image without changing
    the pixel count, so the shape the shot is *seen* in is not the shape of its
    resolution. A frame sweep caught this against Blender's own
    `Camera.view_frame`: at 1158x798 with a 2:1 pixel aspect the camera frame is
    2.902 wide and the advertised list said 1.451, which is the operator judging
    framing against proportions off by a factor of two. Anamorphic and several
    broadcast formats are exactly this.
    """
    for pax, pay, expected in ((1.0, 1.0, 1.451), (2.0, 1.0, 2.902), (1.0, 2.0, 0.726)):
        for w, h in camera_sizes(1158, 798, pax, pay):
            assert abs(w / h - expected) / expected < 0.02, (
                f"{w}x{h} is {w / h:.3f}, but the shot is {expected:.3f} "
                f"at pixel aspect {pax}:{pay}"
            )


def test_camera_sizes_invent_neither_columns_nor_rows():
    """Advertising more pixels than the camera renders invents detail.

    Both axes, not just width: stretching along Y makes the frame taller than
    it is wide, and a height derived from an uncapped width would invent rows
    for the same reason an uncapped width invents columns.
    """
    for pax, pay in ((1.0, 1.0), (2.0, 1.0), (1.0, 2.0), (1.0, 4.0)):
        for w, h in camera_sizes(1158, 798, pax, pay):
            assert w <= 1158 and h <= 798, f"{w}x{h} exceeds the render at {pax}:{pay}"


def test_camera_sizes_never_exceed_the_render():
    """Offering more pixels than the camera renders is inventing detail."""
    for w, h in camera_sizes(800, 600):
        assert w <= 800 and h <= 600


def test_camera_sizes_are_even():
    """Odd dimensions are a portability hazard the moment a chroma-subsampled
    codec joins the list, and cost nothing to avoid."""
    for width, height in ((1920, 1080), (1023, 767), (801, 601)):
        for w, h in camera_sizes(width, height):
            assert w % 2 == 0 and h % 2 == 0, f"{w}x{h} from {width}x{height}"


def test_camera_sizes_survive_a_degenerate_render():
    """A zero-sized render must not divide by zero or return nothing: the host
    still has to advertise something or the phone cannot stream at all."""
    assert camera_sizes(0, 0)
    assert camera_sizes(-1, 10)


# ---------------------------------------------------------------- protocol

def test_viewport_control_is_reliable_and_stat_is_not():
    """Starting a stream is a deliberate act and must not be lost. A statistic
    about a preview is not worth a resend layer."""
    assert MSG_VIEWPORT_CONTROL in RELIABLE_TYPES
    assert MSG_VIEWPORT_STAT not in RELIABLE_TYPES


def test_control_and_stat_round_trip():
    msg = P.decode(
        P.encode_viewport_control(
            1, 2, "camera", codec="jpeg", size=(960, 540), fps=20.0, quality=75
        )
    )
    assert msg is not None and msg.body["size"] == [960, 540]
    assert P.decode(P.encode_viewport_control(1, 2, "off")).body == {"mode": "off"}

    stat = P.decode(P.encode_viewport_stat(3, 4, 1240, 812634, 814188))
    assert stat.body["ordinal"] == 1240


def test_overlays_is_absent_unless_asked_for():
    """viewport-channel.md 5.1.

    Absent means "leave it alone", so a client that has never heard of this
    field must not switch off a preference the operator set. False is a value
    and has to survive as one -- which is exactly the trap `shake_hold_dps`
    fell into, where a falsy setting was dropped and read as unset.
    """
    plain = P.decode(P.encode_viewport_control(1, 2, "camera")).body
    assert "overlays" not in plain

    for wanted in (True, False):
        body = P.decode(
            P.encode_viewport_control(1, 2, "camera", overlays=wanted)
        ).body
        assert body["overlays"] is wanted


def test_a_progressive_engine_does_not_get_to_draw_nothing():
    """The "Rendered makes the stream go black" report, as a rule.

    An offscreen draw is synchronous and happens once. Cycles accumulates a
    viewport render over many samples in buffers of its own, so it returns the
    world background and nothing else -- a flat 63/255 fill, or pure black once
    overlays are suppressed the way a viewfinder wants them. EEVEE and Workbench
    draw when asked and are left alone.
    """
    assert drawable_shading("RENDERED", "CYCLES") == "MATERIAL"
    assert drawable_shading("RENDERED", "BLENDER_EEVEE_NEXT") is None
    assert drawable_shading("RENDERED", "BLENDER_EEVEE") is None
    assert drawable_shading("RENDERED", "BLENDER_WORKBENCH") is None

    # Every other shading mode draws synchronously whatever the engine is, so
    # none of them is any of this function's business.
    for mode in ("SOLID", "MATERIAL", "WIREFRAME"):
        for engine in ("CYCLES", "BLENDER_EEVEE_NEXT", "LUXCORE"):
            assert drawable_shading(mode, engine) is None

    # An engine nobody had heard of when this was written is assumed
    # progressive, because that is the cheap mistake: the wrong shading is a
    # usable viewfinder and a black one is not.
    assert drawable_shading("RENDERED", "LUXCORE") == "MATERIAL"
    assert drawable_shading("RENDERED", "octane") == "MATERIAL"


def test_a_profile_replaces_the_size_rather_than_joining_it():
    """viewport-channel.md 5.1.

    A phone that has handed size selection to the host stops asserting a size,
    and the host reads an absent one as "keep what you have". Sending both would
    reset the controller's choice every time an unrelated setting was touched.
    """
    body = P.decode(
        P.encode_viewport_control(1, 2, "camera", profile="light")
    ).body
    assert body["profile"] == "light"
    assert "size" not in body

    assert "profile" not in P.decode(
        P.encode_viewport_control(1, 2, "camera", size=(960, 540))
    ).body


@pytest.mark.parametrize(
    "mutate,why",
    [
        (lambda h: b"XXXX" + h[4:], "bad magic"),
        (lambda h: h[:4] + b"\x09" + h[5:], "wrong version"),
        (lambda h: h[:5] + b"\x00" + h[6:], "codec 0 is reserved"),
        (lambda h: h[:10], "truncated"),
    ],
)
def test_a_malformed_header_decodes_to_none(mutate, why):
    """None means the reader has lost sync and must close, never resynchronise:
    a desynchronised reader cannot tell a payload byte from a header byte."""
    header = P.encode_viewport_frame_header(7, 99, 1024)
    assert P.decode_viewport_frame_header(mutate(header)) is None, why


def test_an_implausible_length_is_rejected_before_it_is_allocated():
    huge = P.encode_viewport_frame_header(1, 1, VIEWPORT_MAX_PAYLOAD_GUARD + 1)
    assert P.decode_viewport_frame_header(huge) is None


# ----------------------------------------------------------------- helpers

def _wait_connected(srv, timeout: float = 3.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if srv.connected:
            return
        time.sleep(0.01)
    raise AssertionError("viewport client never became the active viewer")


def _wait_for_peer(srv, port: int, timeout: float = 3.0) -> None:
    """Wait until `port` is the ACTIVE viewer, not merely until one exists."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        peer = srv.peer_port()
        if peer == port:
            return
        time.sleep(0.01)
    raise AssertionError(f"peer {port} never became active (saw {srv.peer_port()})")


# --------------------------------------------------------------- pack_rgb
#
# This is the half of the capture path that can be tested at all: everything
# above it needs a GPU context.
#
# Of the two bugs that shipped a scrambled, upside-down picture to the phone,
# these cover ONE. The flip lived here and is pinned below. The other -- reading
# the GPU buffer through np.asarray's reported strides -- lives in the `gpu` call
# `capture_rgb` makes, which cannot run headlessly at all; it is held only by the
# comment there and by looking at a real frame.
#
# Neither was caught by the live check that came before these. That check
# compared the advertised size, the header size and the JPEG's own SOF, found all
# three agreed, and never once looked at a pixel.


def _ramp(width, height):
    """RGBA where every pixel encodes its own (x, y), so a permutation shows."""
    np = pytest.importorskip("numpy")
    a = np.zeros((height, width, 4), dtype=np.uint8)
    a[:, :, 0] = np.arange(width, dtype=np.uint8)[None, :]   # R = x
    a[:, :, 1] = np.arange(height, dtype=np.uint8)[:, None]  # G = y
    a[:, :, 2] = 7                                            # B constant
    a[:, :, 3] = 255                                          # A, to be dropped
    return a


def test_pack_rgb_flips_bottom_up_rows():
    """A framebuffer readback starts at the BOTTOM left.

    Without the flip the phone shows the viewport upside down — which looked, in
    the scrambled frames that hid it, like just more corruption.
    """
    np = pytest.importorskip("numpy")
    src = _ramp(4, 3)
    payload, w, h = pack_rgb(src, 1)
    out = np.frombuffer(payload, dtype=np.uint8).reshape(h, w, 3)

    # Source row 0 is the bottom of the picture, so it must come out last.
    assert out[0, 0, 1] == 2, "top output row must be the last source row"
    assert out[-1, 0, 1] == 0, "bottom output row must be the first source row"


def test_pack_rgb_drops_alpha_and_keeps_pixels_intact():
    np = pytest.importorskip("numpy")
    src = _ramp(5, 4)
    payload, w, h = pack_rgb(src, 1)
    assert (w, h) == (5, 4)
    assert len(payload) == 5 * 4 * 3, "three channels, not four"
    out = np.frombuffer(payload, dtype=np.uint8).reshape(h, w, 3)
    # Every pixel still carries its own coordinates: no transposition, no
    # channel-planar smearing. This is the assertion that fails if the buffer is
    # ever read through np.asarray's reported strides again.
    np.testing.assert_array_equal(out, src[::-1, :, :3])


@pytest.mark.parametrize("width,height", [(1585, 886), (1121, 437), (16, 9), (1, 1)])
def test_pack_rgb_reports_the_size_it_actually_produced(width, height):
    """Dimensions read off the array, never computed.

    `1585 // 2` is 792 but numpy's `[::2]` yields 793, and a receiver told the
    wrong width reshapes garbage. Pinned against numpy rather than against
    hand-written numbers, because an earlier version of this test asserted the
    floor and so locked in the very bug it was meant to catch.
    """
    np = pytest.importorskip("numpy")
    src = _ramp(width, height)
    for step in (1, 2, 3):
        payload, w, h = pack_rgb(src, step)
        assert w == len(np.arange(width)[::step]), f"{width} by {step}"
        assert h == len(np.arange(height)[::step]), f"{height} by {step}"
        assert len(payload) == w * h * 3


def test_pack_rgb_takes_three_channels_and_four_identically():
    """Reading RGB instead of RGBA must change the cost, not the picture.

    The capture asks the framebuffer for three channels now, because the fourth
    was read only to be sliced off and slicing it cost 2.24 ms of a 14.2 ms
    capture. That is only safe if both shapes produce the same bytes, which is
    what this pins -- the last change to this readback path shipped scrambled
    frames to the phone for an afternoon.
    """
    numpy = pytest.importorskip("numpy")
    rgb = numpy.arange(4 * 3 * 3, dtype=numpy.uint8).reshape(4, 3, 3)
    rgba = numpy.dstack([rgb, numpy.full((4, 3), 255, dtype=numpy.uint8)])

    from_three = pack_rgb(rgb, 1)
    from_four = pack_rgb(rgba, 1)
    assert from_three == from_four, "three channels must pack exactly as four did"

    payload, width, height = from_three
    assert (width, height) == (3, 4)
    # And it is still flipped: a readback starts at the bottom left, so the
    # last row in must be the first row out.
    assert payload[:9] == rgb[-1].tobytes()


def test_pack_rgb_flips_at_every_step():
    """The flip must survive decimation: `[::-2]` reverses, `[::2]` does not."""
    np = pytest.importorskip("numpy")
    src = _ramp(8, 7)
    payload, w, h = pack_rgb(src, 2)
    out = np.frombuffer(payload, dtype=np.uint8).reshape(h, w, 3)
    # G carries the source row index; reversed-by-2 from 7 rows starts at 6.
    assert out[0, 0, 1] == 6
    assert out[-1, 0, 1] == 0


# ----------------------------------------------------- exclusive ownership

def test_a_second_stream_cannot_steal_a_bound_port():
    """A port is advertised only when this process genuinely owns it.

    `SO_REUSEADDR` means different things on different platforms. On Windows it
    lets a second process bind a port another is already listening on, so both
    binds succeed, only one receives connections, and the other advertises a
    port that swallows every client — which is exactly what two Blender
    instances produced: `viewport_port` 47810 reported, a listener visible on
    0.0.0.0:47810, and every connection from the phone timing out.

    The fix is `SO_EXCLUSIVEADDRUSE` there, and this is the assertion that says
    so: the second start MUST fail rather than lie.
    """
    first = ViewportStream(token_check=lambda t: True)
    port = first.start()
    assert port is not None
    try:
        second = ViewportStream(token_check=lambda t: True, port=port)
        assert second.start() is None, (
            "a second bind of a held port must fail, not silently succeed"
        )
        second.stop()
    finally:
        first.stop()


def test_a_freed_port_can_be_taken_again():
    """Exclusivity must not become a leak: stopping releases the port.

    Without this the previous test would pass just as well against a listener
    that never let go, which would break every host restart.
    """
    first = ViewportStream(token_check=lambda t: True)
    port = first.start()
    assert port is not None
    first.stop()

    second = ViewportStream(token_check=lambda t: True, port=port)
    try:
        assert second.start() == port, "a released port must be bindable again"
    finally:
        second.stop()


# ------------------------------------------------------- presentation stats

def test_the_round_trip_is_measured_against_our_own_clock(stream):
    """§4: the host stamps, the phone echoes the ordinal, the host subtracts.

    Crossing no clock boundary is the entire reason `ordinal` and `capture_ns`
    are mandatory rather than optional. The phone's own timestamps are in its
    clock domain and are not comparable here.
    """
    srv, port = stream
    sock = _client(port)
    _wait_connected(srv)
    assert srv.send_frame(b"frame-zero", capture_ns=time.perf_counter_ns())
    _read_frame(sock)

    trip = srv.note_presented(0)
    assert trip is not None, "the ordinal we just sent must be measurable"
    assert 0.0 <= trip < 5000.0, f"implausible round trip {trip}"
    sock.close()


def test_an_unknown_ordinal_reports_nothing_rather_than_a_wrong_number(stream):
    """A stale or invented ordinal is not an error and is not a latency."""
    srv, port = stream
    sock = _client(port)
    _wait_connected(srv)
    assert srv.note_presented(999) is None
    assert srv.send_frame(b"x", capture_ns=time.perf_counter_ns())
    _read_frame(sock)
    assert srv.note_presented(0) is not None
    # Consumed: the same frame must not be reported twice.
    assert srv.note_presented(0) is None
    sock.close()


def test_dropped_frames_are_never_waiting_to_be_reported(stream):
    """A frame that was dropped never reaches a screen.

    Stamping on capture rather than on a successful send would leave one pending
    for a round trip that can never arrive, and on a struggling link that is
    most of them.
    """
    srv, _port = stream
    assert not srv.send_frame(b"nobody-connected", capture_ns=1)
    assert srv.note_presented(0) is None


def test_stamps_do_not_outlive_their_connection(stream):
    """Ordinals restart per connection, so a stamp from the old one would be
    matched against a completely different frame."""
    srv, port = stream
    first = _client(port)
    _wait_connected(srv)
    assert srv.send_frame(b"old", capture_ns=time.perf_counter_ns())
    _read_frame(first)
    first.close()

    second = _client(port)
    _wait_for_peer(srv, second.getsockname()[1])
    # Ordinal 0 exists again, but it is a different frame that was never sent.
    assert srv.note_presented(0) is None
    second.close()


def test_a_silent_client_cannot_grow_the_stamp_table(stream):
    """A conformant client need never send VIEWPORT_STAT at all (§5.2), so this
    is bounded rather than trusted."""
    srv, port = stream
    sock = _client(port)
    _wait_connected(srv)
    for _ in range(200):
        srv.send_frame(b"tiny", capture_ns=time.perf_counter_ns())
        _read_frame(sock)
    assert len(srv._stamps) <= 64, "stamp table must stay bounded"
    sock.close()


def test_a_silent_peer_does_not_stall_the_next_client(stream):
    """The outage this channel actually suffered, twice.

    A peer that connects and says nothing holds `AUTH_TIMEOUT_S`. When that ran
    on the accept loop, with a backlog of 1, it stalled every other connection
    for five seconds -- and a phone whose connect timeout is three seconds gives
    up and leaves behind another silent connection, so it sustained itself and
    only a host restart cleared it.

    The assertion is the gap: a good client must be streaming in far less than
    AUTH_TIMEOUT_S while a silent one is still being waited on.
    """
    srv, port = stream
    silent = socket.create_connection(("127.0.0.1", port), timeout=3)
    try:
        started = time.monotonic()
        good = _client(port)
        _wait_connected(srv, timeout=AUTH_TIMEOUT_S - 1.0)
        elapsed = time.monotonic() - started
        assert elapsed < AUTH_TIMEOUT_S - 1.0, (
            f"a good client waited {elapsed:.1f}s behind a silent one"
        )
        assert srv.send_frame(b"payload", capture_ns=1)
        header, body = _read_frame(good)
        assert body == b"payload"
        good.close()
    finally:
        silent.close()


def test_a_burst_of_abandoned_connections_does_not_lock_the_port(stream):
    """The retry storm that followed the stall.

    Each timed-out connect leaves a connection the host has not accepted yet.
    With a backlog of 1 the next attempt was refused outright, which is what
    turned one slow moment into an outage lasting until restart.
    """
    srv, port = stream
    abandoned = [
        socket.create_connection(("127.0.0.1", port), timeout=3)
        for _ in range(4)
    ]
    try:
        good = _client(port)
        _wait_connected(srv, timeout=AUTH_TIMEOUT_S - 1.0)
        assert srv.send_frame(b"through", capture_ns=1)
        _read_frame(good)
        good.close()
    finally:
        for sock in abandoned:
            sock.close()


def test_an_aborted_connection_does_not_kill_the_accept_loop():
    """The outage this channel had, and the reason it never recovered.

    A peer that resets between the TCP handshake and our `accept()` raises
    ConnectionAbortedError there. That is an OSError, and the loop used to treat
    any OSError as "the listener is closed" and exit for good. The kernel then
    kept completing handshakes into the backlog with nobody accepting them, so
    the port still looked open, `nc` connected and received nothing, and every
    real client timed out once the backlog filled.

    Observed on a phone as one good connection, "Software caused connection
    abort", then connect timeouts forever -- including a plain 12-second one --
    against a listener that was plainly still there.

    Driven through a fake listener rather than a real reset, because on loopback
    the accept wins the race and the bug does not reproduce: an earlier version
    of this test passed against the broken code, which makes it worse than none.
    """
    srv = ViewportStream(token_check=lambda t: True)

    class FakeListener:
        """Raises the abort once, then behaves. Records how often it was asked."""

        def __init__(self) -> None:
            self.calls = 0

        def accept(self):
            self.calls += 1
            if self.calls == 1:
                raise ConnectionAbortedError(10053, "software caused connection abort")
            raise socket.timeout()  # nothing more to hand over

    listener = FakeListener()
    srv._sock = listener
    srv._running.set()
    thread = threading.Thread(target=srv._accept_loop, daemon=True)
    thread.start()
    try:
        deadline = time.monotonic() + 2.0
        while listener.calls < 5 and time.monotonic() < deadline:
            time.sleep(0.01)
        assert listener.calls >= 5, (
            f"accept loop stopped after {listener.calls} calls; "
            "an aborted connection must not end it"
        )
        assert srv.accepts_failed == 1
    finally:
        srv._running.clear()
        thread.join(timeout=1.0)


# --------------------------------------------------------------- capture pacing
#
# The stream ran at exactly half the host's event loop rate, by two independent
# routes, for as long as this decision had no tests at all. Measured by
# tools/viewport_lab/in_blender/main_thread_budget.py on a moving camera: 256
# captures against 256 idle skips, one for one. These pin both routes.


class FakeLoop:
    """A Blender event loop, as far as the pacer can tell.

    Models the two things that produce the real behaviour and nothing else: a
    timer callback fires **once per iteration**, and an iteration lasts at
    least one vsync but longer if the work inside it overruns. Measured, that
    is 33.3 ms with the viewport redrawing and 5.6 ms without.
    """

    def __init__(self, pacer, loop_hz=30.0, capture_ms=10.0,
                 camera_moving=True, evaluated_outside_capture=False):
        self.pacer = pacer
        self.interval = 1.0 / loop_hz
        self.capture_s = capture_ms / 1000.0
        self.camera_moving = camera_moving
        # Whether anything other than our own capture evaluates the scene. The
        # sharp case is False: with Blender minimised, or with every redraw
        # coalesced into the evaluation we force ourselves, our capture is the
        # only thing that ever fires the depsgraph handler.
        self.evaluated_outside_capture = evaluated_outside_capture
        self.now = 0.0
        self.frame = 0
        self.captures = []
        self.reasons = []

    def _camera_key(self):
        return (self.frame,) if self.camera_moving else (0,)

    def run(self, seconds):
        end = self.now + seconds
        while self.now < end:
            self.frame += 1
            self.pacer.observe_tick(self.now)
            reason = self.pacer.should_capture(
                self.now, self._camera_key(), busy=False
            )
            self.reasons.append(reason)
            work = 0.0
            if reason == "":
                # capture_camera_rgb calls evaluated_depsgraph_get, which fires
                # the change handler part-way through its own capture.
                self.pacer.note_change()
                self.pacer.note_captured(
                    self.now + self.capture_s, self._camera_key(), self.capture_s
                )
                self.captures.append(self.now)
                work = self.capture_s
            elif self.evaluated_outside_capture:
                self.pacer.note_change()
            self.now += max(self.interval, work)
        return self

    @property
    def fps(self):
        if len(self.captures) < 2:
            return 0.0
        return (len(self.captures) - 1) / (self.captures[-1] - self.captures[0])


def _pacer(fps, **kw):
    return CapturePacer(target_fps=fps, **kw)


def test_a_captures_own_evaluation_is_not_a_scene_change():
    """The bug that halved the frame rate, at unit scale.

    capture_camera_rgb forces a depsgraph evaluation, which fires the handler
    that feeds note_change. Counting that as a change would be harmless; what
    was fatal was the boolean it set being cleared at the end of the same tick,
    so the NEXT opportunity saw "nothing changed" while the camera moved.
    """
    pacer = _pacer(30.0)
    key = (1,)
    assert pacer.should_capture(0.0, key, busy=False) == ""
    pacer.note_change()  # our own evaluated_depsgraph_get, mid-capture
    pacer.note_captured(0.01, key, 0.01)

    # Same camera and nothing else touched the scene: correctly idle.
    assert pacer.should_capture(0.5, key, busy=False) == "idle"
    # Camera moved: MUST capture. This is what the old boolean got wrong.
    assert pacer.should_capture(0.5, (2,), busy=False) == ""


def test_a_moving_camera_captures_every_opportunity_the_loop_offers():
    """30 Hz loop, 30 fps asked for, camera moving: 30, not 15.

    evaluated_outside_capture is False here on purpose -- our own capture is
    then the only thing evaluating the scene, which is the case the boolean
    starved outright rather than merely halving.
    """
    loop = FakeLoop(_pacer(30.0), loop_hz=30.0, capture_ms=5.0).run(3.0)
    assert loop.fps == pytest.approx(30.0, rel=0.05), (
        f"{loop.fps:.1f} fps against a 30 Hz loop; "
        f"{loop.reasons.count('idle')} opportunities lost to idle skips"
    )
    assert loop.reasons.count("idle") == 0


def test_the_operators_redraw_does_not_halve_the_stream():
    """The measurement, reproduced: 256 captures against 256 idle skips.

    This is the case that was actually observed on screen. The operator's
    viewport evaluates the scene on the iterations we do not capture on, so the
    old boolean was set again there and the stream came out at exactly half the
    loop rate rather than starving outright. Same bug as the test above, but
    wearing the disguise it wore in the wild -- and half a frame rate is much
    easier to mistake for a heavy scene than 1 fps is.
    """
    loop = FakeLoop(_pacer(30.0), loop_hz=30.0, capture_ms=5.0,
                    evaluated_outside_capture=True).run(3.0)
    assert loop.fps == pytest.approx(30.0, rel=0.05), (
        f"{loop.fps:.1f} fps against a 30 Hz loop, and half of it would be 15"
    )
    idle = loop.reasons.count("idle")
    assert idle == 0, f"{idle} of {len(loop.reasons)} opportunities lost to idle"


def test_a_rate_the_loop_cannot_divide_averages_out():
    """20 fps against a 33.3 ms loop can only fire at 33.3 or 66.7.

    Alternating between them averages the 20 that was asked for. Rounding every
    deadline up to the later boundary -- which is what a gate with no slack
    does -- silently delivers 15 instead.
    """
    loop = FakeLoop(_pacer(20.0), loop_hz=30.0, capture_ms=5.0).run(3.0)
    assert loop.fps == pytest.approx(20.0, rel=0.08), (
        f"{loop.fps:.1f} fps, asked for 20"
    )


def test_asking_above_the_loop_rate_gets_the_loop_rate_and_blames_the_loop():
    """A phone cannot know the host's redraw rate, so this is not an error.

    It must not read as one either: "capture" would send the operator looking
    for a smaller size, and no size on the phone raises the host's event loop.
    """
    pacer = _pacer(60.0)
    loop = FakeLoop(pacer, loop_hz=30.0, capture_ms=5.0).run(3.0)
    assert loop.fps == pytest.approx(30.0, rel=0.05)
    assert pacer.effective_fps == pytest.approx(30.0, rel=0.05)
    assert pacer.limited_by == "loop"


def test_a_capture_that_does_not_fit_an_iteration_blames_capture():
    """Same shortfall, opposite advice, and the cost is what tells them apart.

    A 60 ms capture on a 33.3 ms loop stretches every iteration it lands in, so
    the loop looks slow -- but here we are why, and a smaller size is the fix.
    """
    pacer = _pacer(30.0)
    FakeLoop(pacer, loop_hz=30.0, capture_ms=60.0).run(3.0)
    assert pacer.limited_by == "capture"


def test_a_parked_scene_idle_skips_but_still_gets_its_keepalive():
    """Nothing changed, so there is nothing to send -- but not forever.

    Change detection cannot see everything that alters the drawn image;
    viewport shading is the standing example. The keepalive bounds how stale
    the phone gets when something slips through.
    """
    pacer = _pacer(30.0, keepalive_s=1.0)
    loop = FakeLoop(
        pacer, loop_hz=30.0, capture_ms=5.0, camera_moving=False
    ).run(6.0)
    assert loop.fps == pytest.approx(1.0, rel=0.25), (
        f"{loop.fps:.2f} fps on a parked rig; the keepalive is 1 s"
    )
    assert pacer.limited_by == "idle", "a parked rig is not a fault"


def test_a_long_stall_resyncs_instead_of_firing_a_burst():
    """The frames are gone; sending four at once does not bring them back."""
    pacer = _pacer(20.0)
    pacer.note_captured(0.0, (1,), 0.005)
    # Two seconds of nothing: a modal operator, a file load, a heavy redraw.
    assert pacer.should_capture(2.0, (2,), busy=False) == ""
    pacer.note_captured(2.0, (2,), 0.005)
    # The next is due a period later, not immediately and not forty deep.
    assert pacer.should_capture(2.0, (3,), busy=False) == "gate"
    assert pacer.should_capture(2.06, (3,), busy=False) == ""


def test_a_busy_encoder_is_not_reported_as_an_idle_scene():
    """Skipping because the last frame is still in flight is its own reason.

    It must not be counted as idle: "idle" is what suppresses the running-slow
    warning, and suppressing it while frames back up hides a real problem.
    """
    pacer = _pacer(30.0)
    pacer.note_captured(0.0, (1,), 0.005)
    assert pacer.should_capture(1.0, (2,), busy=True) == "busy"
    assert pacer.skipped_busy == 1
    assert pacer.skipped_idle == 0
    assert pacer.limited_by != "idle"


# ------------------------------------------------------------ capture budget
#
# Costs below are the measured ones, not invented: on the reference host one
# loop iteration is 33.3 ms and capture is 13-17 ms at 1158x798, 12-13 at
# 960x662 and 9-17 at 640x440. The spread is real and is why the controller
# smooths, dwells, and requires agreement before it moves anything.

SIZES = [[1158, 798], [960, 662], [640, 440]]
INTERVAL = 1.0 / 30.0

#: What each size costs, in seconds. Roughly the measured figures.
MEASURED = {
    (1158, 798): 0.0155,
    (960, 662): 0.0125,
    (640, 440): 0.0095,
}


def _settle(budget, costs, seconds=30.0, step=0.2, start=0.0, jitter=0.0):
    """Run the controller against a machine whose costs are `costs`.

    Feeds it one observation per step, applies whatever it chooses, and returns
    the size it ends on plus every change it made along the way.
    """
    import random

    rng = random.Random(1234)
    size = budget.sizes[budget._index]
    changes = []
    now = start
    while now < start + seconds:
        cost = costs[tuple(size)]
        if jitter:
            cost *= 1.0 + rng.uniform(-jitter, jitter)
        budget.observe(now, size, cost, INTERVAL)
        chosen = budget.choose(now)
        if chosen is not None:
            changes.append((round(now, 1), chosen))
            size = chosen
        now += step
    return tuple(size), changes


def test_balanced_keeps_the_largest_size_when_it_fits():
    """65% of a 33.3 ms iteration is 21.7 ms, and the largest size costs 15.5.

    The whole point of the controller is that it does not move things it has no
    reason to move: a size change is visible on the phone.
    """
    budget = CaptureBudget(SIZES, "balanced")
    final, changes = _settle(budget, MEASURED)
    assert final == (1158, 798)
    assert changes == [], f"nothing to fix, but it changed size: {changes}"


def test_light_steps_down_to_what_fits():
    """35% of 33.3 ms is 11.7 ms, which only the smallest size is under."""
    budget = CaptureBudget(SIZES, "light")
    final, changes = _settle(budget, MEASURED)
    assert final == (640, 440), f"ended on {final} after {changes}"
    # One step at a time, and no more steps than there are sizes.
    assert [c[1] for c in changes] == [(960, 662), (640, 440)]


def test_a_scene_too_heavy_for_any_size_stops_at_the_floor_and_says_so():
    """Backing off is only useful while there is something to back off to.

    Beyond that the honest report is "capture cannot keep up", which the panel
    and the phone already have a way to say. Thrashing between the two smallest
    sizes would be the alternative, and it would make the picture worse while
    telling the operator nothing.
    """
    heavy = {size: 0.090 for size in MEASURED}
    budget = CaptureBudget(SIZES, "balanced")
    final, changes = _settle(budget, heavy)
    assert final == (640, 440)
    assert budget.at_floor, "the smallest size still overruns; that must be said"
    assert len(changes) == 2, f"stepped more than the list allows: {changes}"


def test_it_climbs_back_when_the_scene_gets_lighter():
    """The operator hides a collection and the machine is fast again."""
    budget = CaptureBudget(SIZES, "balanced")
    heavy = {size: 0.030 for size in MEASURED}
    _settle(budget, heavy)
    assert budget.sizes[budget._index] != (1158, 798)
    final, changes = _settle(budget, MEASURED, seconds=60.0, start=100.0)
    assert final == (1158, 798), f"stuck at {final} after {changes}"


def test_a_cost_sitting_on_the_boundary_does_not_oscillate():
    """The failure mode that makes an adaptive control worse than no control.

    A size whose cost lands exactly on the budget must settle, not flip. The
    step-up test asks for half the budget rather than all of it precisely so
    that a size which only just fits is not re-entered the moment it is left.
    """
    boundary = 0.65 * INTERVAL
    costs = {
        (1158, 798): boundary * 1.02,
        (960, 662): boundary * 0.98,
        (640, 440): boundary * 0.40,
    }
    budget = CaptureBudget(SIZES, "balanced")
    final, changes = _settle(budget, costs, seconds=120.0, jitter=0.05)
    assert len(changes) <= 2, f"oscillated: {changes}"
    assert final == (960, 662), f"settled on {final}"


def test_the_first_capture_after_a_resize_does_not_look_like_a_lighter_scene():
    """The oscillation the real host found and this suite did not.

    The first capture at a new size reallocates the offscreen and reads high.
    Taken as the reference for "what does this size cost", it inflates the
    yardstick that decides whether the scene has since got cheaper -- so the
    controller unblocks the size it just left, climbs, overruns, drops back, and
    does it again. Measured on the reference host it cost `light` the entire
    saving it was asked for.

    Every earlier test fed a constant cost, where the first sample and the
    settled one are the same number, so none of them could see it.
    """
    spike = 3.0
    state = {"size": None}

    def costs_with_realloc(size):
        first = state["size"] != size
        state["size"] = size
        return MEASURED[size] * (spike if first else 1.0)

    budget = CaptureBudget(SIZES, "light")
    size = budget.sizes[0]
    changes = []
    now = 0.0
    while now < 90.0:
        budget.observe(now, size, costs_with_realloc(tuple(size)), INTERVAL)
        chosen = budget.choose(now)
        if chosen is not None:
            changes.append((round(now, 1), chosen))
            size = chosen
        now += 1.0 / 30.0

    assert tuple(size) == (640, 440), f"ended on {size} after {changes}"
    assert len(changes) == 2, f"oscillated between sizes: {changes}"


def test_it_will_not_move_twice_inside_the_dwell():
    """Every change reallocates a GPU buffer and re-scales the phone's picture."""
    budget = CaptureBudget(SIZES, "light")
    _final, changes = _settle(budget, MEASURED, seconds=30.0)
    gaps = [b[0] - a[0] for a, b in zip(changes, changes[1:])]
    assert all(gap >= 4.0 for gap in gaps), f"changes too close together: {changes}"


def test_an_unknown_profile_is_balanced_rather_than_an_error():
    """A newer phone naming a profile this host has never heard of must get a
    working stream, not a broken one."""
    assert CaptureBudget(SIZES, "cinematic").profile == "balanced"


def test_it_says_nothing_until_it_has_measured_something():
    """Choosing before the first capture would be choosing from a default,
    which is the reference machine's number wearing a disguise."""
    budget = CaptureBudget(SIZES, "light")
    assert budget.choose(0.0) is None
