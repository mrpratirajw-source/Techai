# SPDX-License-Identifier: GPL-3.0-or-later
"""Quaternion math + take_resample.json conformance + smoothing behavior."""

import json
import math
import random
from pathlib import Path

import pytest

from core import takes

FIXTURES = Path(__file__).resolve().parents[2] / "fixtures"
TAKE = json.loads((FIXTURES / "take_resample.json").read_text(encoding="utf-8"))

SQ2 = math.sqrt(0.5)


def qz(deg: float):
    h = math.radians(deg) / 2.0
    return (math.cos(h), 0.0, 0.0, math.sin(h))


def quat_close(a, b, tol=1e-6):
    """q == -q; compare up to global sign."""
    return all(abs(x - y) <= tol for x, y in zip(a, b)) or all(
        abs(x + y) <= tol for x, y in zip(a, b)
    )


# ----------------------------------------------------------------- unit math


def test_multiply_matches_spec_reference():
    # Worked check from coordinate-systems.md section 3: Rz(-90) applied to
    # q_sensor (0.5, 0.5, -0.5, 0.5) yields (sqrt.5, sqrt.5, 0, 0).
    q_sensor = (0.5, 0.5, -0.5, 0.5)
    q_remap = (SQ2, 0.0, 0.0, -SQ2)
    assert quat_close(takes.multiply(q_sensor, q_remap), (SQ2, SQ2, 0.0, 0.0))


def test_inverse_and_conjugate():
    q = takes.normalize((0.3, -0.4, 0.5, 0.6))
    ident = takes.multiply(q, takes.inverse(q))
    assert quat_close(ident, (1.0, 0.0, 0.0, 0.0))
    assert takes.conjugate(q)[1] == -q[1]


def test_normalize_zero_guard():
    assert takes.normalize((0.0, 0.0, 0.0, 0.0)) == (1.0, 0.0, 0.0, 0.0)


def test_slerp_endpoints_and_midpoint():
    a, b = qz(0.0), qz(90.0)
    assert quat_close(takes.slerp(a, b, 0.0), a)
    assert quat_close(takes.slerp(a, b, 1.0), b)
    assert quat_close(takes.slerp(a, b, 0.5), qz(45.0))


def test_slerp_shortest_path_with_flipped_input():
    a, b = qz(10.0), takes.negate(qz(30.0))
    assert quat_close(takes.slerp(a, b, 0.5), qz(20.0))


def test_slerp_constant_rate_is_exact():
    a, b = qz(0.0), qz(80.0)
    for t in (0.25, 1.0 / 3.0, 0.7):
        assert quat_close(takes.slerp(a, b, t), qz(80.0 * t))


def test_hemisphere_align():
    seq = [qz(0), takes.negate(qz(10)), qz(20), takes.negate(qz(30))]
    aligned = takes.hemisphere_align(seq)
    for prev, cur in zip(aligned, aligned[1:]):
        assert takes.dot(prev, cur) > 0.0
    assert quat_close(aligned[1], qz(10))
    assert quat_close(aligned[3], qz(30))


def test_resample_clamps_outside_sample_range():
    samples = [(int(2e8), qz(10)), (int(4e8), qz(20))]
    out = takes.resample(samples, 0, int(6e8), 10.0)
    assert len(out) == 7  # floor(0.6*10)+1
    assert quat_close(out[0], qz(10))  # before first -> clamp
    assert quat_close(out[-1], qz(20))  # after last -> clamp


def test_resample_empty():
    assert takes.resample([], 0, int(1e9), 24.0) == []


def test_gaussian_smooth_sigma_zero_noop():
    quats = [qz(d) for d in (0, 10, 20)]
    assert takes.gaussian_smooth(quats, 0.0) == quats


# ------------------------------------------------------- fixture conformance


def _fixture_samples():
    return [(s["t_ns"], tuple(s["q"])) for s in TAKE["raw_samples"]]


def test_take_resample_fixture_smoothing_zero():
    frames = takes.bake(
        _fixture_samples(),
        TAKE["start_timestamp_ns"],
        TAKE["end_timestamp_ns"],
        TAKE["fps"],
        smoothing=0.0,
    )
    assert len(frames) == TAKE["expected_frame_count"]
    per_frame_deg = TAKE["expected_frames_rule"]["angle_deg_per_frame"]
    # Global sign must be consistent across the whole take (aligned F-curves).
    sign = 1.0 if takes.dot(frames[0], qz(0.0)) >= 0 else -1.0
    for f, q in enumerate(frames):
        expected = qz(per_frame_deg * f)
        got = tuple(sign * c for c in q)
        assert all(
            abs(a - b) <= 1e-6 for a, b in zip(got, expected)
        ), f"frame {f}: {got} != {expected}"
    for check in TAKE["expected_spot_checks"]:
        assert quat_close(frames[check["frame"]], tuple(check["q"]))


def _angular_speeds(quats):
    """Per-step rotation angle (rad) between consecutive quats."""
    out = []
    for a, b in zip(quats, quats[1:]):
        d = min(1.0, abs(takes.dot(a, b)))
        out.append(2.0 * math.acos(d))
    return out


def test_bake_smoothing_reduces_jitter_preserves_endpoints():
    rng = random.Random(42)
    samples = []
    for i in range(101):  # 1 s at 100 Hz, yaw sweep + jitter
        t_ns = i * 10_000_000
        jitter = rng.uniform(-1.5, 1.5)
        samples.append((t_ns, qz(90.0 * i / 100.0 + jitter)))
    start, end, fps = 0, 1_000_000_000, 24.0
    rough = takes.bake(samples, start, end, fps, smoothing=0.0)
    smooth = takes.bake(samples, start, end, fps, smoothing=0.5)
    assert len(rough) == len(smooth) == 25

    def variance(xs):
        m = sum(xs) / len(xs)
        return sum((x - m) ** 2 for x in xs) / len(xs)

    assert variance(_angular_speeds(smooth)) < 0.5 * variance(_angular_speeds(rough))


def test_bake_smoothing_endpoints_preserved_on_stationary_input():
    # The kernel is renormalized at the boundaries (no phantom zero padding),
    # so a jittery-but-stationary take must keep its endpoints: the smoothed
    # output stays inside the jitter envelope instead of sagging toward
    # identity. (On a moving take the endpoints lag by design — that is the
    # filter delay, not an artifact.)
    rng = random.Random(7)
    samples = [
        (i * 10_000_000, qz(45.0 + rng.uniform(-1.0, 1.0))) for i in range(101)
    ]
    smooth = takes.bake(samples, 0, 1_000_000_000, 24.0, smoothing=0.5)
    for got in (smooth[0], smooth[-1]):
        d = min(1.0, abs(takes.dot(got, qz(45.0))))
        assert math.degrees(2.0 * math.acos(d)) <= 1.0  # within jitter amplitude


def test_bake_empty_samples():
    assert takes.bake([], 0, int(1e9), 24.0, 0.0) == []


# ---- positions (spec 4.1 / coordinate-systems 6) -------------------------


def test_resample_positions_linear_ramp():
    """pos_x = 0.5 * t_seconds, samples every 40 ms over 1 s; at 24 fps each
    frame f must land exactly on 0.5 * f/24 (hand rule, closed form)."""
    samples = [
        (i * 40_000_000, (0.5 * i * 0.04, 0.0, 0.0)) for i in range(26)
    ]
    out = takes.resample_positions(samples, 0, 1_000_000_000, 24.0)
    assert len(out) == 25
    for f, p in enumerate(out):
        assert abs(p[0] - 0.5 * f / 24.0) < 1e-9
        assert p[1] == 0.0 and p[2] == 0.0


def test_resample_positions_clamps_outside_ends():
    samples = [(500_000_000, (1.0, 2.0, 3.0)), (600_000_000, (2.0, 4.0, 6.0))]
    out = takes.resample_positions(samples, 0, 1_000_000_000, 24.0)
    assert len(out) == 25
    assert out[0] == (1.0, 2.0, 3.0)  # before first sample: clamp
    assert out[-1] == (2.0, 4.0, 6.0)  # after last sample: clamp


def test_resample_positions_midpoint():
    samples = [(0, (0.0, 0.0, 0.0)), (1_000_000_000, (1.0, -2.0, 4.0))]
    out = takes.resample_positions(samples, 0, 1_000_000_000, 2.0)
    assert len(out) == 3
    mid = out[1]  # t = 0.5 s
    assert abs(mid[0] - 0.5) < 1e-9
    assert abs(mid[1] + 1.0) < 1e-9
    assert abs(mid[2] - 2.0) < 1e-9


def test_resample_positions_empty_and_degenerate():
    assert takes.resample_positions([], 0, int(1e9), 24.0) == []
    assert takes.resample_positions([(0, (1.0, 1.0, 1.0))], int(1e9), 0, 24.0) == []


def test_bake_positions_smoothing_reduces_jitter_keeps_length():
    rng = random.Random(11)
    samples = [
        (i * 10_000_000, (1.0 + rng.uniform(-0.05, 0.05), 0.0, 0.0))
        for i in range(101)
    ]
    rough = takes.bake_positions(samples, 0, 1_000_000_000, 24.0, smoothing=0.0)
    smooth = takes.bake_positions(samples, 0, 1_000_000_000, 24.0, smoothing=0.5)
    assert len(rough) == len(smooth) == 25

    def variance(xs):
        m = sum(xs) / len(xs)
        return sum((x - m) ** 2 for x in xs) / len(xs)

    assert variance([p[0] for p in smooth]) < 0.5 * variance([p[0] for p in rough])


def test_segmented_positions_match_original_when_every_sample_is_valid():
    samples = [
        (i * 40_000_000, (0.2 * i, -0.1 * i, 0.05 * i)) for i in range(26)
    ]
    for smoothing in (0.0, 0.5):
        expected = takes.bake_positions(
            samples, 0, 1_000_000_000, 24.0, smoothing
        )
        got = takes.bake_segmented_positions(
            samples, 0, 1_000_000_000, 24.0, smoothing
        )
        assert got == expected


def test_segmented_positions_hold_gap_and_reanchor_recovery():
    samples = [
        (0, (0.0, 0.0, 0.0)),
        (1_000_000_000, (1.0, 0.0, 0.0)),
        (2_000_000_000, None),
        # Tracker recovered in a foreign origin. Its first sample must align
        # to the held endpoint; later relative movement is preserved.
        (3_000_000_000, (100.0, 4.0, -2.0)),
        (4_000_000_000, (101.0, 4.0, -2.0)),
    ]
    out = takes.bake_segmented_positions(samples, 0, 4_000_000_000, 1.0)
    assert out == [
        (0.0, 0.0, 0.0),
        (1.0, 0.0, 0.0),
        (1.0, 0.0, 0.0),
        (1.0, 0.0, 0.0),
        (2.0, 0.0, 0.0),
    ]


def test_segmented_positions_do_not_smooth_across_invalid_gap():
    samples = [
        (0, (0.0, 0.0, 0.0)),
        (100_000_000, (0.0, 0.0, 0.0)),
        (200_000_000, (0.0, 0.0, 0.0)),
        (300_000_000, None),
        (400_000_000, (50.0, 0.0, 0.0)),
        (500_000_000, (51.0, 0.0, 0.0)),
        (600_000_000, (52.0, 0.0, 0.0)),
    ]
    out = takes.bake_segmented_positions(samples, 0, 600_000_000, 10.0, 1.0)
    assert out[0] == out[1] == out[2] == out[3] == out[4]
    assert out[-1][0] > out[4][0]


def test_segmented_positions_all_invalid_is_rotation_only():
    assert takes.bake_segmented_positions(
        [(0, None), (1_000_000_000, None)], 0, 1_000_000_000, 24.0
    ) == []
