# SPDX-License-Identifier: GPL-3.0-or-later
"""Live-drive conformance inside `blender --background --python`.

Feeds every fixtures/orientation_cases.json expected_protocol_quat through
the real UDP socket path (the phone-side conversion is not this side's job)
and asserts the scene camera lands on it: quat within 1e-4 and XYZ euler
within 0.01 deg. Timers do not pump in background mode, so apply_tick() is
called directly. q_offset is pinned to identity via the test hook (auto-
recenter-on-connect would otherwise fight the comparison).

Prints HEADLESS_LIVE_PASS and exits 0 on success; exits non-zero on failure.
"""

import json
import math
import sys
import time
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import bpy  # noqa: E402

from _headless_common import (  # noqa: E402
    FIXTURES_DIR,
    FakePhone,
    angle_diff_deg,
    load_addon,
    quat_close,
    wait_for,
)


def main() -> int:
    mod = load_addon()
    from pocketrig.bl import apply as apply_mod
    from pocketrig.bl import state
    from pocketrig.core import constants as C
    from pocketrig.core.session import Server

    scene = bpy.context.scene
    scene.render.fps = 24
    scene.render.fps_base = 1.0
    scene.pocketrig_live_smoothing = 0.0  # compare raw poses, not the smoothed preview

    server = Server(
        port=0,
        get_scene_fps=lambda: state.scene_fps_cache,
        host_version=bpy.app.version_string,
    )
    server.start()
    state.server = server
    state.set_offset_identity_for_test()

    phone = FakePhone(server.port)
    failures = []
    try:
        phone.handshake(server.token)
        cases = json.loads(
            (FIXTURES_DIR / "orientation_cases.json").read_text(encoding="utf-8")
        )["cases"]
        ts_ns = 0
        for case in cases:
            expected_q = tuple(case["expected_protocol_quat"])
            expected_euler = case["expected_blender_euler_xyz_deg"]
            ts_ns += 10_000_000
            sent_seq = phone.pose(ts_ns, expected_q)
            try:
                wait_for(
                    lambda: state.last_seq == sent_seq, pump=apply_mod.apply_tick
                )
            except AssertionError:
                failures.append(f"{case['id']}: pose seq {sent_seq} never applied")
                continue
            cam = scene.camera
            q = cam.rotation_quaternion
            got_q = (q.w, q.x, q.y, q.z)
            if not quat_close(got_q, expected_q, 1e-4):
                failures.append(f"{case['id']}: quat {got_q} != {expected_q}")
            got_euler = [math.degrees(a) for a in q.to_euler("XYZ")]
            for axis, (g, w) in enumerate(zip(got_euler, expected_euler)):
                if angle_diff_deg(g, w) > 0.01:
                    failures.append(
                        f"{case['id']}: euler[{axis}] {g:.4f} != {w} "
                        f"(full: {got_euler})"
                    )
        print(f"checked {len(cases)} orientation cases")

        # ---- Lens (spec 4.5) -------------------------------------------------
        # 0.0 means the sender is not driving focal length, so a lens the
        # operator set in Blender must survive untouched.
        cam = scene.camera
        cam.data.lens = 50.0
        ts_ns += 10_000_000
        seq = phone.pose(ts_ns, (1.0, 0.0, 0.0, 0.0), focal_mm=0.0)
        wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        if abs(cam.data.lens - 50.0) > 1e-4:
            failures.append(f"lens: 0.0 must not drive, got {cam.data.lens}")

        # A driven value lands on the camera data.
        ts_ns += 10_000_000
        seq = phone.pose(ts_ns, (1.0, 0.0, 0.0, 0.0), focal_mm=18.0)
        wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        if abs(cam.data.lens - 18.0) > 1e-3:
            failures.append(f"lens: 18mm not applied, got {cam.data.lens}")

        # ...and tracks a zoom.
        ts_ns += 10_000_000
        seq = phone.pose(ts_ns, (1.0, 0.0, 0.0, 0.0), focal_mm=85.0)
        wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        if abs(cam.data.lens - 85.0) > 1e-3:
            failures.append(f"lens: zoom to 85mm not applied, got {cam.data.lens}")

        # Implausible values are ignored rather than applied: a host must not
        # let a bad number reach the scene, exactly as for a non-finite pose.
        for bad in (-5.0, 0.5, 9000.0, float("nan"), float("inf")):
            ts_ns += 10_000_000
            seq = phone.pose(ts_ns, (1.0, 0.0, 0.0, 0.0), focal_mm=bad)
            wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
            if abs(cam.data.lens - 85.0) > 1e-3:
                failures.append(f"lens: {bad} must be ignored, got {cam.data.lens}")
                break

        # ---- Reporting our lens back to the phone (spec 5.7 lens_mm) ---------
        # Without this the phone's lens control has nothing to open ON, so it
        # asserts a value and merely opening it reframes the operator's shot.
        def latest_params(timeout=1.0):
            """Drain PARAMS; returns the newest body seen, or None."""
            body = None
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                apply_mod.apply_tick()
                phone.pump()
                for msg in phone.inbox:
                    if msg.msg_type == C.MSG_PARAMS:
                        body = msg.body
                        phone.ack(msg.seq)
                phone.inbox.clear()
                if body is not None:
                    return body
            return body

        # While the phone drives the lens, the value is the phone's own: sending
        # it back is a loop, and the change detector would fire on every zoom.
        # Re-establish a *valid* driving pose first: the loop above ends on a
        # rejected value, which by the host's own rule means "not driving", so
        # checking here without this would prove nothing.
        ts_ns += 10_000_000
        seq = phone.pose(ts_ns, (1.0, 0.0, 0.0, 0.0), focal_mm=85.0)
        wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        driving = latest_params(0.3)
        if driving is not None and "lens_mm" in driving:
            failures.append(
                f"lens_mm reported while the phone drives it: {driving['lens_mm']}"
            )

        # Hand the lens back; now the host's own value must be reported.
        cam.data.lens = 50.0
        ts_ns += 10_000_000
        seq = phone.pose(ts_ns, (1.0, 0.0, 0.0, 0.0), focal_mm=0.0)
        wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        released = latest_params()
        if released is None:
            failures.append("no PARAMS after the phone released the lens")
        elif abs(released.get("lens_mm", -1) - 50.0) > 1e-3:
            failures.append(f"lens_mm not reported: {released!r}")

        # An operator turning the lens ring in Blender reaches the phone, so the
        # rail opens on the CURRENT value rather than the connect-time one.
        cam.data.lens = 135.0
        turned = latest_params()
        if turned is None or abs(turned.get("lens_mm", -1) - 135.0) > 1e-3:
            failures.append(f"a host-side lens change did not reach the phone: {turned!r}")

        # An animated lens is suppressed: PARAMS is reliable, and a baked take
        # playing back would put a per-frame value on the retransmit path.
        cam_data = cam.data
        cam_data.animation_data_create()
        cam_data.animation_data.action = bpy.data.actions.new("lens report probe")
        cam_data.lens = 24.0
        animated = latest_params(0.3)
        if animated is not None and "lens_mm" in animated:
            failures.append(
                f"lens_mm reported while the lens is animated: {animated['lens_mm']}"
            )
        cam_data.animation_data.action = None
        print("lens reporting checked")

    finally:
        phone.bye()
        phone.close()
        server.stop()
        state.server = None
        try:
            mod.unregister()
        except Exception:
            traceback.print_exc()

    if failures:
        for f in failures:
            print("FAIL:", f)
        print("HEADLESS_LIVE_FAIL")
        return 1
    print("HEADLESS_LIVE_PASS")
    return 0


if __name__ == "__main__":
    try:
        code = main()
    except Exception:
        traceback.print_exc()
        code = 2
    sys.exit(code)
