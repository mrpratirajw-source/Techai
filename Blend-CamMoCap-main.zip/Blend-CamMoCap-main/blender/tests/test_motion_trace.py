# SPDX-License-Identifier: GPL-3.0-or-later
import json
import math
import sys
from pathlib import Path

import pytest

LAB = Path(__file__).resolve().parents[2] / "tools" / "motion_lab"
sys.path.insert(0, str(LAB))

import trace_report  # noqa: E402
import traces  # noqa: E402


def _write(path: Path, rows):
    path.write_text("\n".join(json.dumps(row) for row in rows) + "\n", encoding="utf-8")


def test_motion_trace_v1_extracts_pose_and_ignores_unknown_events(tmp_path):
    path = tmp_path / "sample.ptrace"
    _write(
        path,
        [
            {"format": traces.TRACE_FORMAT_NAME, "version": 1, "source": "arcore"},
            {"kind": "future_event", "observed_ns": 1, "value": 7},
            {"kind": "marker", "observed_ns": 5, "label": "CLOSE"},
            {
                "kind": "pose", "observed_ns": 12, "source_ns": 10,
                "source": "arcore", "q": [1, 0, 0, 0], "p": [1, 2, 3],
            },
            {
                "kind": "pose", "observed_ns": 22, "source_ns": 20,
                "source": "arcore", "q": [1, 0, 0, 0],
            },
        ],
    )
    header, samples = traces.read_trace(path)
    assert header["format"] == traces.TRACE_FORMAT_NAME
    assert samples == [
        (10, (1.0, 0.0, 0.0, 0.0), (1.0, 2.0, 3.0)),
        (20, (1.0, 0.0, 0.0, 0.0), None),
    ]
    report = trace_report.summarize(path)
    assert report["pose"]["count"] == 2
    assert report["pose"]["with_position"] == 1
    assert report["markers"] == [
        {"observed_ns": 5, "elapsed_s": None, "label": "CLOSE"},
    ]
    assert report["marker_segments"][0]["label"] == "CLOSE"
    assert report["marker_segments"][0]["frames"] == 0
    assert report["unknown_event_kinds"] == ["future_event"]


def test_trace_report_summarizes_cadence_config_and_tracking(tmp_path):
    path = tmp_path / "arcore.ptrace"
    rows = [
        {"format": traces.TRACE_FORMAT_NAME, "version": 1, "source": "arcore"},
        {
            "kind": "arcore_config_inventory", "observed_ns": 0,
            "configs": [
                {
                    "camera_id": "0", "fps_range": [30, 30],
                    "cpu_size": [640, 480], "texture_size": [1920, 1080],
                    "depth_sensor_usage": "DO_NOT_USE",
                    "stereo_camera_usage": "DO_NOT_USE",
                },
                {
                    "camera_id": "0", "fps_range": [60, 60],
                    "cpu_size": [1280, 720], "texture_size": [1280, 720],
                    "depth_sensor_usage": "DO_NOT_USE",
                    "stereo_camera_usage": "DO_NOT_USE",
                },
            ],
        },
        {
            "kind": "arcore_config", "observed_ns": 1, "camera_id": "0",
            "fps_range": [30, 30], "focus_mode": "FIXED",
        },
        {"kind": "tracking", "observed_ns": 2, "frame_ns": 0, "state": "PAUSED", "reason": "NONE"},
    ]
    for index, state in enumerate(("PAUSED", "TRACKING", "TRACKING", "PAUSED")):
        frame_ns = 1_000_000_000 + index * 33_333_333
        rows.append(
            {
                "kind": "arcore_frame", "observed_ns": frame_ns + 2_000_000,
                "frame_ns": frame_ns, "state": state,
                "reason": "NONE" if state == "TRACKING" else "EXCESSIVE_MOTION",
                "af_state": 1 if index == 1 else 2,
                "ae_state": 2,
                "focus_distance_diopters": 0.5 + index * 0.25,
                "exposure_time_ns": 8_000_000 + index * 1_000_000,
                "sensitivity_iso": 100 + index * 20,
            },
        )
        rows.append(
            {
                "kind": "pose", "observed_ns": frame_ns + 3_000_000,
                "source_ns": frame_ns, "source": "arcore", "q": [1, 0, 0, 0],
            },
        )
    _write(path, rows)
    report = trace_report.summarize(path)
    assert report["arcore_config"]["camera_id"] == "0"
    assert report["arcore_config_inventory"]["count"] == 2
    assert report["arcore_config_inventory"]["fps_ranges"] == [[30, 30], [60, 60]]
    assert report["arcore_config_inventory"]["texture_sizes"] == [
        [1280, 720], [1920, 1080],
    ]
    assert report["arcore_frames"]["states"] == {"PAUSED": 2, "TRACKING": 2}
    assert report["arcore_frames"]["failure_reasons"] == {
        "EXCESSIVE_MOTION": 2,
        "NONE": 2,
    }
    assert report["arcore_frames"]["rate_hz"] == pytest.approx(30.0, rel=1e-6)
    assert report["arcore_frames"]["unique_rate_hz"] == pytest.approx(30.0, rel=1e-6)
    assert report["arcore_frames"]["observation_age_median_ms"] == pytest.approx(2.0)
    assert report["arcore_frames"]["state_durations_s"] == pytest.approx(
        {"PAUSED": 1 / 30, "TRACKING": 2 / 30}, rel=1e-6,
    )
    metadata = report["camera_metadata"]
    assert metadata["coverage"] == pytest.approx(1.0)
    assert metadata["autofocus"]["states"] == {
        "PASSIVE_FOCUSED": 3, "PASSIVE_SCAN": 1,
    }
    assert metadata["autofocus"]["transitions"] == 2
    assert metadata["focus_value_changes"] == 3
    assert metadata["focus_step_diopters"]["median"] == pytest.approx(0.25)
    assert metadata["exposure_time_ms"]["median"] == pytest.approx(9.5)
    assert metadata["sensitivity_iso"]["max"] == pytest.approx(160)


def test_trace_report_compares_raw_and_anchor_relative_steps(tmp_path):
    path = tmp_path / "anchor.ptrace"
    rows = [{"format": traces.TRACE_FORMAT_NAME, "version": 1, "source": "arcore"}]
    # A synthetic world correction translates and rotates raw camera+anchor
    # equally. The anchor-relative camera remains unchanged.
    rows.extend(
        [
            {
                "kind": "arcore_frame", "observed_ns": 1, "frame_ns": 1,
                "state": "TRACKING", "reason": "NONE", "pose_mode": "anchor_relative",
                "anchor_generation": 1, "anchor_state": "TRACKING",
                "display_q": [1, 0, 0, 0], "display_p": [1, 0, 0],
                "anchor_q": [1, 0, 0, 0], "anchor_p": [0, 0, 0],
                "relative_display_q": [1, 0, 0, 0], "relative_display_p": [1, 0, 0],
            },
            {
                "kind": "arcore_frame", "observed_ns": 2, "frame_ns": 2,
                "state": "TRACKING", "reason": "NONE", "pose_mode": "anchor_relative",
                "anchor_generation": 1, "anchor_state": "TRACKING",
                "display_q": [0.70710678, 0, 0, 0.70710678], "display_p": [5, 1, 0],
                "anchor_q": [0.70710678, 0, 0, 0.70710678], "anchor_p": [5, 0, 0],
                "relative_display_q": [1, 0, 0, 0], "relative_display_p": [1, 0, 0],
            },
        ],
    )
    _write(path, rows)
    report = trace_report.summarize(path)
    anchor = report["anchor"]
    assert anchor["pose_modes"] == {"anchor_relative": 2}
    assert anchor["states"] == {"TRACKING": 2}
    assert anchor["generations"] == [1]
    assert anchor["relative_coverage"] == pytest.approx(1.0)
    assert anchor["position_step_m"]["raw"]["max"] > 4.0
    assert anchor["position_step_m"]["relative"]["max"] == pytest.approx(0.0)
    assert anchor["rotation_step_degrees"]["raw"]["max"] == pytest.approx(90.0)
    assert anchor["rotation_step_degrees"]["relative"]["max"] == pytest.approx(0.0)
    assert anchor["endpoint_delta"]["raw"]["position_m"] == pytest.approx(math.sqrt(17))
    assert anchor["endpoint_delta"]["raw"]["rotation_degrees"] == pytest.approx(90.0)
    assert anchor["endpoint_delta"]["relative"]["position_m"] == pytest.approx(0.0)
    assert anchor["endpoint_delta"]["relative"]["rotation_degrees"] == pytest.approx(0.0)


def test_trace_report_correlates_raw_pose_steps_with_focus_changes(tmp_path):
    path = tmp_path / "focus.ptrace"
    rows = [{"format": traces.TRACE_FORMAT_NAME, "version": 1, "source": "arcore"}]
    rows.extend(
        [
            {
                "kind": "arcore_frame", "observed_ns": 1, "frame_ns": 1,
                "state": "TRACKING", "reason": "NONE", "pose_mode": "raw",
                "display_q": [1, 0, 0, 0], "display_p": [0, 0, 0],
                "af_state": 2, "focus_distance_diopters": 1.0,
            },
            {
                "kind": "arcore_frame", "observed_ns": 2, "frame_ns": 2,
                "state": "TRACKING", "reason": "NONE", "pose_mode": "raw",
                "display_q": [1, 0, 0, 0], "display_p": [0.1, 0, 0],
                "af_state": 1, "focus_distance_diopters": 2.0,
            },
            {
                "kind": "arcore_frame", "observed_ns": 3, "frame_ns": 3,
                "state": "TRACKING", "reason": "NONE", "pose_mode": "raw",
                "display_q": [1, 0, 0, 0], "display_p": [0.11, 0, 0],
                "af_state": 1, "focus_distance_diopters": 2.0,
            },
        ],
    )
    _write(path, rows)

    report = trace_report.summarize(path)
    assert report["anchor"]["position_step_m"]["raw"]["count"] == 2
    focus = report["camera_metadata"]["motion_by_focus"]
    assert focus["focus_changing_intervals"] == 1
    assert focus["focus_stable_intervals"] == 1
    assert focus["position_step_m"]["focus_changing"]["max"] == pytest.approx(0.1)
    assert focus["position_step_m"]["focus_stable"]["max"] == pytest.approx(0.01)


def test_trace_report_segments_markers_after_settle_window(tmp_path):
    path = tmp_path / "segments.ptrace"
    rows = [
        {"format": traces.TRACE_FORMAT_NAME, "version": 1, "source": "arcore", "started_ns": 0},
        {"kind": "marker", "observed_ns": 0, "label": "ROOM"},
        {"kind": "marker", "observed_ns": 4_000_000_000, "label": "CLOSE"},
    ]
    for index, observed_ns in enumerate((1_000_000_000, 2_000_000_000, 3_000_000_000)):
        rows.append(
            {
                "kind": "arcore_frame", "observed_ns": observed_ns,
                "frame_ns": observed_ns, "state": "TRACKING", "reason": "NONE",
                "display_q": [1, 0, 0, 0], "display_p": [index * 0.01, 0, 0],
                "af_state": 0, "focus_distance_diopters": 1.0,
            },
        )
    rows.append(
        {
            "kind": "arcore_frame", "observed_ns": 6_000_000_000,
            "frame_ns": 6_000_000_000, "state": "TRACKING", "reason": "NONE",
            "display_q": [1, 0, 0, 0], "display_p": [1, 0, 0],
            "af_state": 2, "focus_distance_diopters": 3.0,
        },
    )
    _write(path, rows)

    report = trace_report.summarize(path)
    room, close = report["marker_segments"]
    assert room["label"] == "ROOM"
    assert room["frames"] == 2  # the 1 s transition frame is excluded
    assert room["position_step_m"]["max"] == pytest.approx(0.01)
    assert close["label"] == "CLOSE"
    assert close["frames"] == 1
    assert close["focus_distance_diopters"]["median"] == pytest.approx(3.0)


def test_trace_report_compares_first_and_last_minute(tmp_path):
    path = tmp_path / "thermal.ptrace"
    rows = [{"format": traces.TRACE_FORMAT_NAME, "version": 1, "source": "arcore"}]
    for index in range(13):
        frame_ns = index * 10_000_000_000
        age_ns = 1_000_000 if index <= 6 else 5_000_000
        rows.append(
            {
                "kind": "arcore_frame", "observed_ns": frame_ns + age_ns,
                "frame_ns": frame_ns, "state": "TRACKING", "reason": "NONE",
                "display_q": [1, 0, 0, 0], "display_p": [index * 0.01, 0, 0],
                "exposure_time_ns": 8_000_000 + index * 1_000_000,
                "sensitivity_iso": 100 + index,
            },
        )
    _write(path, rows)

    windows = trace_report.summarize(path)["time_windows"]
    assert windows["window_s"] == pytest.approx(60.0)
    assert windows["trace_span_s"] == pytest.approx(120.004)
    assert windows["windows_overlap"] is False
    assert windows["first"]["count"] == 6  # frame_ns=0 is intentionally invalid
    assert windows["last"]["count"] == 6
    assert windows["first"]["observation_age_p95_ms"] == pytest.approx(1.0)
    assert windows["last"]["observation_age_p95_ms"] == pytest.approx(5.0)
    assert windows["last"]["exposure_time_ms"]["max"] == pytest.approx(20.0)


def test_trace_report_summarizes_independent_imu_samples(tmp_path):
    path = tmp_path / "imu.ptrace"
    rows = [
        {"format": traces.TRACE_FORMAT_NAME, "version": 1, "source": "arcore"},
        {
            "kind": "imu", "observed_ns": 1_001_000_000,
            "sensor_ns": 1_000_000_000, "sensor": "gyroscope",
            "v": [1.0, 0.0, 0.0], "accuracy": 3,
        },
        {
            "kind": "imu", "observed_ns": 1_011_000_000,
            "sensor_ns": 1_010_000_000, "sensor": "gyroscope",
            "v": [0.0, 0.0, 0.0], "accuracy": 3,
        },
        {
            "kind": "imu", "observed_ns": 1_002_000_000,
            "sensor_ns": 1_000_000_000, "sensor": "accelerometer",
            "v": [0.0, 0.0, 9.80665], "accuracy": 2,
        },
        {
            "kind": "imu", "observed_ns": 1_012_000_000,
            "sensor_ns": 1_010_000_000, "sensor": "accelerometer",
            "v": [0.0, 0.0], "accuracy": 2,
        },
    ]
    _write(path, rows)

    report = trace_report.summarize(path)
    assert report["unknown_event_kinds"] == []
    assert report["imu"]["rows"] == 4
    gyro = report["imu"]["sensors"]["gyroscope"]
    assert gyro["valid_samples"] == 2
    assert gyro["rate_hz"] == pytest.approx(100.0)
    assert gyro["magnitude_rad_s"]["max"] == pytest.approx(1.0)
    assert gyro["magnitude_deg_s"]["max"] == pytest.approx(57.2957795)
    assert gyro["observation_age_ms"]["median"] == pytest.approx(1.0)
    accel = report["imu"]["sensors"]["accelerometer"]
    assert accel["valid_samples"] == 1
    assert accel["malformed_samples"] == 1
    assert accel["magnitude_m_s2"]["max"] == pytest.approx(9.80665)
    assert accel["gravity_residual_m_s2"]["max"] == pytest.approx(0.0)


def test_trace_report_aligns_imu_to_arcore_frame_intervals(tmp_path):
    path = tmp_path / "aligned.ptrace"
    rows = [{"format": traces.TRACE_FORMAT_NAME, "version": 1, "source": "arcore"}]
    rows.extend(
        [
            {"kind": "marker", "observed_ns": 1_050_000_000, "label": "MOVE"},
            {"kind": "marker", "observed_ns": 1_150_000_000, "label": "STOP"},
        ],
    )
    for index, frame_ns in enumerate((1_000_000_000, 1_100_000_000, 1_200_000_000)):
        rows.append(
            {
                "kind": "arcore_frame", "observed_ns": frame_ns + 50_000_000,
                "frame_ns": frame_ns, "state": "TRACKING", "reason": "NONE",
                "display_q": [1, 0, 0, 0], "display_p": [index * index * 0.01, 0, 0],
            },
        )
    for sensor_ns, gyro, accel in (
        (1_050_000_000, 0.1, 9.80665),
        (1_090_000_000, 0.2, 9.90665),
        (1_150_000_000, 0.3, 10.00665),
        (1_190_000_000, 0.4, 10.20665),
    ):
        rows.extend(
            [
                {
                    "kind": "imu", "observed_ns": sensor_ns + 1_000_000,
                    "sensor_ns": sensor_ns, "sensor": "gyroscope",
                    "v": [gyro, 0, 0], "accuracy": 3,
                },
                {
                    "kind": "imu", "observed_ns": sensor_ns + 1_000_000,
                    "sensor_ns": sensor_ns, "sensor": "accelerometer",
                    "v": [0, 0, accel], "accuracy": 3,
                },
            ],
        )
    _write(path, rows)

    aligned = trace_report.summarize(path)["arcore_imu_alignment"]
    assert aligned["intervals"] == 2
    assert aligned["fully_covered_intervals"] == 2
    assert aligned["coverage"] == pytest.approx(1.0)
    assert aligned["activity_window_ms"] == pytest.approx(200.0)
    assert aligned["position_speed_m_s"]["max"] == pytest.approx(0.3)
    assert aligned["gyro_peak_degrees_s"]["max"] == pytest.approx(math.degrees(0.4))
    assert aligned["correlations"]["position_speed_vs_gyro_peak"] == pytest.approx(1.0)
    biggest = aligned["largest_position_intervals"][0]
    assert biggest["frame_ns"] == 1_200_000_000
    assert biggest["gyro_samples"] == 2
    assert biggest["accelerometer_samples"] == 2
    assert biggest["accelerometer_delta_peak_m_s2"] == pytest.approx(0.2)
    assert biggest["gyro_activity_rms_degrees_s"] == pytest.approx(
        math.degrees(math.sqrt((0.1 ** 2 + 0.2 ** 2 + 0.3 ** 2 + 0.4 ** 2) / 4)),
    )
    assert biggest["accelerometer_activity_rms_m_s2"] == pytest.approx(
        math.sqrt((0.1 ** 2 + 0.1 ** 2 + 0.2 ** 2) / 3),
    )
    pre, move, stop = aligned["marker_segments"]
    assert pre["label"] == "PRE"
    assert pre["intervals"] == 0
    assert move["label"] == "MOVE"
    assert move["intervals"] == 1
    assert move["position_speed_m_s"]["max"] == pytest.approx(0.1)
    assert stop["label"] == "STOP"
    assert stop["intervals"] == 1
    assert stop["position_speed_m_s"]["max"] == pytest.approx(0.3)


@pytest.mark.parametrize(
    "field,value",
    [
        ("q", [float("nan"), 0, 0, 0]),
        ("q", [1, 0, 0]),
        ("p", [float("inf"), 0, 0]),
        ("p", [0, 0]),
    ],
)
def test_motion_trace_rejects_bad_numeric_vectors(tmp_path, field, value):
    path = tmp_path / "bad.ptrace"
    row = {
        "kind": "pose", "observed_ns": 2, "source_ns": 1,
        "source": "arcore", "q": [1, 0, 0, 0], "p": [0, 0, 0],
    }
    row[field] = value
    _write(path, [{"format": traces.TRACE_FORMAT_NAME, "version": 1}, row])
    with pytest.raises(ValueError):
        traces.read_trace(path)
