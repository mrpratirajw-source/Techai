# SPDX-License-Identifier: GPL-3.0-or-later
"""Host motion thresholds must equal fixtures/motion_gates.json.

`shake_hold_dps` in particular is used by BOTH peers: the host holds 6DOF
position above it, and the phone shows its "position held" cue from the same
computation at the same threshold. That agreement was previously maintained by
a comment in each language saying the other one must match. The fixture is the
record; these tests and the Kotlin `MotionGatesTest` make it binding.

Importing bl/apply.py needs bpy, so the host constants are read from source
rather than imported. That keeps this a desktop test, and it is the constant's
definition that must match the fixture, not a runtime value.
"""

from __future__ import annotations

import ast
import json
from pathlib import Path

import pytest

from conftest import BLENDER_DIR, FIXTURES_DIR

GATES = json.loads((FIXTURES_DIR / "motion_gates.json").read_text(encoding="utf-8"))
BY_ID = {gate["id"]: gate for gate in GATES["gates"]}

HOST_GATES = [
    ("shake_hold_dps", "SHAKE_HOLD_DPS"),
    ("rot_teleport_dps", "ROT_TELEPORT_DPS"),
    ("teleport_mps", "TELEPORT_MPS"),
    ("pos_gap_ns", "POS_GAP_NS"),
]


def _module_constants(path: Path) -> dict:
    """Top-level `NAME = <number>` assignments, without importing (needs bpy)."""
    tree = ast.parse(path.read_text(encoding="utf-8"))
    out = {}
    for node in tree.body:
        if not isinstance(node, ast.Assign):
            continue
        try:
            value = ast.literal_eval(node.value)
        except ValueError:
            continue
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            continue
        for target in node.targets:
            if isinstance(target, ast.Name):
                out[target.id] = value
    return out


APPLY_CONSTANTS = _module_constants(BLENDER_DIR / "bl" / "apply.py")


@pytest.mark.parametrize("gate_id,constant", HOST_GATES, ids=[g for g, _ in HOST_GATES])
def test_host_constant_matches_fixture(gate_id, constant):
    assert constant in APPLY_CONSTANTS, f"{constant} is no longer defined in bl/apply.py"
    assert APPLY_CONSTANTS[constant] == BY_ID[gate_id]["value"]


def test_every_host_gate_in_the_fixture_is_checked():
    """A gate marked used_by host must be pinned above, or adding one to the
    fixture would silently prove nothing."""
    declared = {
        gate["id"] for gate in GATES["gates"] if "host" in gate["used_by"]
    }
    assert declared == {gate_id for gate_id, _ in HOST_GATES}


def test_shake_gate_is_marked_as_shared():
    """If this stops being shared, the phone's cue no longer has to agree and
    the Kotlin-side assertion should be reconsidered rather than quietly kept."""
    assert set(BY_ID["shake_hold_dps"]["used_by"]) == {"host", "phone"}


def test_shake_gate_sits_between_a_pan_and_the_relocalization_guard():
    """The ordering is the whole design: hold position while shaking, but treat
    only genuinely impossible speeds as a tracker relocalizing."""
    assert BY_ID["shake_hold_dps"]["value"] < BY_ID["rot_teleport_dps"]["value"]
    assert BY_ID["shake_hold_dps"]["value"] > 90.0  # a deliberate pan
