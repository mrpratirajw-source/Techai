# SPDX-License-Identifier: GPL-3.0-or-later
"""Codec conformance: exact hex vectors, round-trips, forward-compat, rejects."""

import json
import struct
from pathlib import Path

import pytest

from core import constants as C
from core import protocol as P

FIXTURES = Path(__file__).resolve().parents[2] / "fixtures"
VECTORS = json.loads((FIXTURES / "packet_vectors.json").read_text(encoding="utf-8"))


def f32(x: float) -> float:
    """Round-trip a double through f32 (what the wire carries)."""
    return struct.unpack("<f", struct.pack("<f", x))[0]


def _encode_binary(entry: dict) -> bytes:
    t = entry["msg_type"]
    if t == C.MSG_POSE:
        pos = entry.get("pos_xyz")
        return P.encode_pose(
            entry["seq"],
            entry["timestamp_ns"],
            tuple(entry["quat_wxyz"]),
            flags=entry["flags"],
            focal_length_mm=entry["reserved_f"],
            pos=tuple(pos) if pos is not None else None,
        )
    if t == C.MSG_ACK:
        return P.encode_ack(entry["seq"], entry["timestamp_ns"], entry["acked_seq"])
    if t == C.MSG_BYE:
        return P.encode_bye(entry["seq"], entry["timestamp_ns"])
    if t == C.MSG_PING:
        return P.encode_ping(entry["seq"], entry["timestamp_ns"])
    raise AssertionError(f"unhandled binary msg_type {t}")


@pytest.mark.parametrize("entry", VECTORS["binary"], ids=lambda e: e["id"])
def test_binary_exact_encoding(entry):
    assert _encode_binary(entry).hex().lower() == entry["hex"].lower()


@pytest.mark.parametrize("entry", VECTORS["binary"], ids=lambda e: e["id"])
def test_binary_decode_fields(entry):
    msg = P.decode(bytes.fromhex(entry["hex"]))
    assert msg is not None
    assert msg.msg_type == entry["msg_type"]
    assert msg.seq == entry["seq"]
    assert msg.timestamp_ns == entry["timestamp_ns"]
    if entry["msg_type"] == C.MSG_POSE:
        for got, want in zip(msg.quat, entry["quat_wxyz"]):
            assert got == f32(want)
        assert msg.focal_length_mm == f32(entry["reserved_f"])
        assert msg.flags == entry["flags"]
        pos = entry.get("pos_xyz")
        if pos is None:
            assert msg.pos is None
        else:
            assert msg.pos == tuple(f32(v) for v in pos)
    if entry["msg_type"] == C.MSG_ACK:
        assert msg.acked_seq == entry["acked_seq"]


@pytest.mark.parametrize("entry", VECTORS["json_messages"], ids=lambda e: e["id"])
def test_json_messages(entry):
    data = P.encode_json(
        entry["msg_type"], entry["seq"], entry["timestamp_ns"], entry["body"]
    )
    if "expected_header_hex" in entry:
        assert data[:16].hex().lower() == entry["expected_header_hex"].lower()
    msg = P.decode(data)
    assert isinstance(msg, P.JsonMsg)
    assert msg.msg_type == entry["msg_type"]
    assert msg.seq == entry["seq"]
    assert msg.timestamp_ns == entry["timestamp_ns"]
    assert msg.body == entry["body"]  # semantic compare; key order irrelevant


def test_roundtrip_every_message_type():
    quat = (0.5, 0.5, -0.5, -0.5)
    cases = [
        P.encode_pose(1, 2, quat, flags=1),
        P.encode_ack(2, 3, acked_seq=1),
        P.encode_bye(3, 4),
        P.encode_ping(4, 5),
        P.encode_hello(5, 6, "Pixel", "0.1.0", "K3XG9A"),
        P.encode_welcome(6, 7, "HOST", "blender", "4.5.0", "0.1.0", 24.0),
        P.encode_pong(7, 8, t1=55, t2=66),
        P.encode_error(8, 9, "bad_token", "nope"),
        P.encode_record_start(9, 10, 111),
        P.encode_record_stop(10, 11, 999, 512),
        P.encode_record_baked(11, 12, 240, 24.0, 500, 512),
        P.encode_recenter(12, 13),
        P.encode_params(13, 14, 0.3, 0.15, 2.5, layout="portrait"),
        P.encode_pause(14, 15, True),
        P.encode_seek(15, 16),
        P.encode_seek(16, 17, frame=120),
        P.encode_take_list_request(17, 18),
        P.encode_take_list(18, 19, [{"id": "t.take", "name": "n", "duration_s": 1.0,
                                     "source": "sensor", "samples": 3, "sent": False}]),
        P.encode_take_pull(19, 20, "t.take"),
        P.encode_frame_reset(20, 21, "source"),
    ]
    expected_types = [
        C.MSG_POSE, C.MSG_ACK, C.MSG_BYE, C.MSG_PING, C.MSG_HELLO, C.MSG_WELCOME,
        C.MSG_PONG, C.MSG_ERROR, C.MSG_RECORD_START, C.MSG_RECORD_STOP,
        C.MSG_RECORD_BAKED, C.MSG_RECENTER, C.MSG_PARAMS, C.MSG_PAUSE,
        C.MSG_SEEK, C.MSG_SEEK, C.MSG_TAKE_LIST, C.MSG_TAKE_LIST, C.MSG_TAKE_PULL,
        C.MSG_FRAME_RESET,
    ]
    for data, want_type in zip(cases, expected_types):
        msg = P.decode(data)
        assert msg is not None, f"type 0x{want_type:02x} failed to decode"
        assert msg.msg_type == want_type
    pose = P.decode(cases[0])
    assert pose.quat == tuple(f32(v) for v in quat)
    params = P.decode(cases[12])
    assert params.body["move_scale"] == 2.5
    assert params.body["layout"] == "portrait"
    assert P.decode(cases[13]).body == {"paused": True}
    assert P.decode(cases[14]).body == {"to": "start"}
    assert P.decode(cases[15]).body == {"frame": 120}
    assert P.decode(cases[16]).body == {}  # take-list request
    take_list = P.decode(cases[17])
    assert take_list.body["takes"][0]["name"] == "n"
    assert P.decode(cases[18]).body == {"id": "t.take"}
    assert P.decode(cases[19]).body == {"reason": "source"}


def test_record_transaction_ids_are_optional_and_round_trip():
    take_id = "9c6a5f91-d70a-46dc-a604-d255cd13fc55"
    start = P.decode(P.encode_record_start(1, 2, 3, take_id=take_id))
    stop = P.decode(
        P.encode_record_stop(2, 3, 4, 5, offline=True, take_id=take_id)
    )
    baked = P.decode(
        P.encode_record_baked(3, 4, 24, 24.0, 10, 10, "offline", take_id)
    )
    assert start.body["take_id"] == take_id
    assert stop.body["take_id"] == take_id
    assert baked.body["take_id"] == take_id
    assert "take_id" not in P.decode(P.encode_record_start(4, 5, 6)).body


def test_pose_forward_compat_extra_bytes():
    base = bytes.fromhex(VECTORS["binary"][0]["hex"])
    msg = P.decode(base + b"\xde\xad\xbe\xef" * 3)  # 12 junk bytes appended
    assert isinstance(msg, P.PoseMsg)
    assert msg.quat == (1.0, 0.0, 0.0, 0.0)
    assert msg.seq == 1
    # No position_valid flag -> the 12 appended bytes are junk, not a position.
    assert msg.pos is None


def test_pose_6dof_roundtrip_sets_flag():
    data = P.encode_pose(5, 6, (1.0, 0.0, 0.0, 0.0), pos=(0.5, -0.25, 1.5))
    assert len(data) == P.POSE_6DOF_SIZE
    msg = P.decode(data)
    assert msg.pos == (0.5, -0.25, 1.5)
    assert msg.flags & C.FLAG_HAS_POSITION


def test_pose_encode_without_pos_clears_stale_flag():
    # A caller passing FLAG_HAS_POSITION but no pos would violate spec 4.1;
    # the encoder must not let that packet exist.
    data = P.encode_pose(5, 6, (1.0, 0.0, 0.0, 0.0), flags=C.FLAG_HAS_POSITION)
    assert len(data) == P.POSE_SIZE
    msg = P.decode(data)
    assert msg.pos is None
    assert not msg.flags & C.FLAG_HAS_POSITION


def test_pose_tracking_quality_fields_are_append_only_and_decoded():
    flags = (
        C.FLAG_HAS_POSITION
        | (C.TRACKING_DEGRADED << C.FLAG_QUALITY_SHIFT)
        | (C.ISSUE_INSUFFICIENT_FEATURES << C.FLAG_ISSUE_SHIFT)
    )
    data = P.encode_pose(
        5, 6, (1.0, 0.0, 0.0, 0.0), flags=flags, pos=(1.0, 2.0, 3.0)
    )
    msg = P.decode(data)
    assert msg.flags == flags
    assert P.tracking_quality(msg.flags) == "degraded"
    assert P.tracking_issue(msg.flags) == "insufficient_features"
    assert msg.pos == (1.0, 2.0, 3.0)


def test_zero_quality_bits_remain_backward_compatible_unknown():
    assert P.tracking_quality(0) == "unknown"
    assert P.tracking_issue(0) == "none"


def test_pose_position_flag_without_bytes_yields_no_position():
    # Hostile/buggy sender: 40-byte packet with bit 1 set. Must not crash,
    # must not invent a position.
    data = bytearray(P.encode_pose(5, 6, (1.0, 0.0, 0.0, 0.0)))
    data[36] |= C.FLAG_HAS_POSITION
    msg = P.decode(bytes(data))
    assert isinstance(msg, P.PoseMsg)
    assert msg.pos is None


def test_bad_magic_rejected():
    data = bytearray(P.encode_ping(1, 2))
    data[0] = 0x51
    assert P.decode(bytes(data)) is None


def test_bad_version_rejected():
    data = bytearray(P.encode_ping(1, 2))
    data[2] = 2
    assert P.decode(bytes(data)) is None


def test_unknown_msg_type_ignored():
    data = bytearray(P.encode_ping(1, 2))
    data[3] = 0x7E
    assert P.decode(bytes(data)) is None


def test_truncated_rejected():
    assert P.decode(b"PR") is None
    assert P.decode(P.encode_pose(1, 2, (1, 0, 0, 0))[:30]) is None
    assert P.decode(P.encode_ack(1, 2, 3)[:18]) is None


def test_invalid_json_rejected():
    data = P.encode_header(C.MSG_HELLO, 1, 2) + b"{not json"
    assert P.decode(data) is None


def test_empty_json_body_tolerated():
    msg = P.decode(P.encode_header(C.MSG_RECENTER, 1, 2))
    assert isinstance(msg, P.JsonMsg)
    assert msg.body == {}


def test_params_carries_the_shake_threshold_including_zero():
    """spec 5.7 shake_hold_dps.

    Zero means the operator switched the shake-hold off. It has to reach the
    phone as 0.0 rather than being dropped as falsy: absent means "unchanged",
    which is the opposite of off, and the phone would keep holding.
    """
    for gate in (0.0, 500.0, 1200.0):
        msg = P.decode(P.encode_params(1, 2, 0.3, 0.15, 1.0, shake_hold_dps=gate))
        assert msg is not None
        assert msg.body["shake_hold_dps"] == gate

    # Omitted stays omitted, so a host that does not mirror it says nothing
    # rather than asserting a default over whatever the phone already had.
    msg = P.decode(P.encode_params(1, 2, 0.3, 0.15, 1.0))
    assert msg is not None
    assert "shake_hold_dps" not in msg.body


def test_params_carries_the_measured_viewport_ceiling():
    """viewport-channel.md 5.3.

    Host -> phone only, and optional in the strong sense: a host that has not
    measured its loop yet MUST say nothing rather than guess. The phone treats
    absence as "unchanged", so a fabricated default here would put a wrong
    ceiling on its Refresh control and leave it there.
    """
    msg = P.decode(P.encode_params(1, 2, 0.3, 0.15, 1.0, viewport_max_fps=30))
    assert msg is not None
    assert msg.body["viewport_max_fps"] == 30.0

    msg = P.decode(P.encode_params(1, 2, 0.3, 0.15, 1.0))
    assert msg is not None
    assert "viewport_max_fps" not in msg.body
