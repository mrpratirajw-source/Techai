# SPDX-License-Identifier: GPL-3.0-or-later
"""Start-paused conformance inside `blender --background --python`.

A real UI session starts a fresh connection PAUSED — the camera is NOT driven
until the operator goes live. Background mode auto-lives instead (so the other
suites can drive immediately), so this test flips the `_is_interactive` seam on
to exercise the real interactive path and proves:

  - on connect the host is paused, and a pose does NOT move the camera;
  - a phone Go-live (PAUSE false) clears paused, and poses then drive the camera.

This is the exact behaviour a user sees as "it should start paused". Prints
HEADLESS_PAUSE_PASS and exits 0 on success; non-zero on failure.
"""

import sys
import time
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import bpy  # noqa: E402
from mathutils import Vector  # noqa: E402

from _headless_common import (  # noqa: E402
    FakePhone,
    load_addon,
    wait_for,
)

Q_POSE = (0.70710678, 0.70710678, 0.0, 0.0)


def main() -> int:
    mod = load_addon()
    from pocketrig.bl import apply as apply_mod
    from pocketrig.bl import state
    from pocketrig.core import protocol as P
    from pocketrig.core.session import Server

    scene = bpy.context.scene
    scene.render.fps = 24
    scene.render.fps_base = 1.0
    scene.pocketrig_live_smoothing = 0.0

    cam_data = bpy.data.cameras.new("PocketRig Cam")
    cam = bpy.data.objects.new("PocketRig Cam", cam_data)
    scene.collection.objects.link(cam)
    scene.camera = cam
    cam.rotation_mode = "QUATERNION"
    cam.location = Vector((1.0, 2.0, 3.0))
    home = cam.location.copy()

    # Exercise the interactive (UI) start-paused path, not the headless
    # auto-live path the other suites rely on.
    apply_mod._is_interactive = lambda: True

    server = Server(
        port=0,
        get_scene_fps=lambda: state.scene_fps_cache,
        host_version=bpy.app.version_string,
    )
    server.start()
    state.server = server

    phone = FakePhone(server.port)
    failures = []
    ts = 0

    def pump(n=4):
        for _ in range(n):
            apply_mod.apply_tick()

    try:
        phone.handshake(server.token)
        # The first tick that sees the new HELLO must start PAUSED.
        wait_for(
            lambda: state.seen_hello_count == server.hello_count,
            pump=apply_mod.apply_tick,
        )
        if not state.paused:
            failures.append("connect did not start paused")

        # A pose while paused must NOT drive the camera.
        ts += 10_000_000
        phone.pose(ts, Q_POSE, pos=(9.0, 9.0, 9.0))
        wait_for(
            lambda: server.latest_pose is not None and server.latest_pose[1] == ts,
            pump=apply_mod.apply_tick,
        )
        pump(6)
        if (cam.location - home).length > 1e-6:
            failures.append(f"paused connect drove the camera to {tuple(cam.location)}")

        # Go live (phone PAUSE false): paused clears and poses drive again.
        phone.send_reliable(
            P.encode_pause(phone.next_seq(), time.monotonic_ns(), False),
            pump=apply_mod.apply_tick,
        )
        pump(4)
        if state.paused:
            failures.append("go-live did not clear paused")
        # First pose anchors (soft resume: no jump), the second displaces it.
        # Space them 200 ms / 0.2 m apart (1 m/s) so neither the position-gap
        # re-anchor guard (> 250 ms) nor the teleport guard (> ~5 m/s) fires.
        for p in ((0.0, 0.0, 0.0), (0.2, 0.0, 0.0)):
            ts += 200_000_000
            phone.pose(ts, Q_POSE, pos=p)
            wait_for(
                lambda: server.latest_pose[1] == ts, pump=apply_mod.apply_tick
            )
            pump(4)
        if (cam.location - home).length < 1e-6:
            failures.append("after go-live the camera never moved")
        print("checked start-paused + go-live")

        # A heartbeat/reconnect HELLO must re-sync controls without applying
        # the fresh-pairing start-paused policy again.
        hello_before = server.hello_count
        pairing_before = server.pairing_count
        reconnect_loc = cam.location.copy()
        reconnect_rot = cam.rotation_quaternion.copy()
        phone.handshake(server.token)
        wait_for(
            lambda: server.hello_count > hello_before,
            pump=apply_mod.apply_tick,
        )
        pump(4)
        if server.pairing_count != pairing_before:
            failures.append("reconnect was misclassified as a fresh pairing")
        if state.paused:
            failures.append("reconnect unexpectedly paused live tracking")
        # Simulate a restarted source with a completely different world
        # reference. Its first pose must be adopted without a visible jump.
        ts += 200_000_000
        phone.pose(ts, (1.0, 0.0, 0.0, 0.0), pos=(50.0, -40.0, 30.0))
        wait_for(
            lambda: server.latest_pose[1] == ts,
            pump=apply_mod.apply_tick,
        )
        pump(4)
        if (cam.location - reconnect_loc).length > 1e-6:
            failures.append("first reconnect pose jumped camera position")
        if cam.rotation_quaternion.rotation_difference(reconnect_rot).angle > 1e-6:
            failures.append("first reconnect pose jumped camera rotation")
        print("checked reconnect preserves live state")
    finally:
        phone.bye()
        phone.close()
        server.stop()
        state.server = None
        try:
            mod.unregister()
        except Exception:
            traceback.print_exc()

    if failures:
        for f in failures:
            print("FAIL:", f)
        print("HEADLESS_PAUSE_FAIL")
        return 1
    print("HEADLESS_PAUSE_PASS")
    return 0


if __name__ == "__main__":
    try:
        code = main()
    except Exception:
        traceback.print_exc()
        code = 2
    sys.exit(code)
