# SPDX-License-Identifier: GPL-3.0-or-later
"""Record/bake conformance inside `blender --background --python`.

Drives fixtures/take_resample.json through the REAL socket path: HELLO, a few
POSEs before RECORD_START (rolling-buffer splice), remaining POSEs,
RECORD_STOP — then pumps apply_tick() until the bake lands and validates:
25 keyframes on all four rotation_quaternion channels, every keyed value
matching the closed-form rule (cos(1.875 f deg), 0, 0, sin(1.875 f deg))
within 1e-4 up to one global sign, and RECORD_BAKED reporting scene fps 24.

Prints HEADLESS_RECORD_PASS and exits 0 on success; non-zero on failure.
"""

import json
import math
import sys
import time
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import bpy  # noqa: E402

from _headless_common import (  # noqa: E402
    FIXTURES_DIR,
    FakePhone,
    load_addon,
    wait_for,
)


def _all_fcurves(owner):
    """F-curves for `owner`'s action, slot-aware.

    From Blender 4.4 one Action can carry channels for several IDs in separate
    slots, and the legacy flat `action.fcurves` view then reports another slot's
    curves. Match the owner's own slot first.
    """
    ad = owner.animation_data
    action = ad.action if ad is not None else None
    if action is None:
        return []
    slot = getattr(ad, "action_slot", None)
    fcs = []
    for layer in getattr(action, "layers", []):
        for strip in layer.strips:
            for bag in getattr(strip, "channelbags", []):
                if slot is not None and getattr(bag, "slot", None) != slot:
                    continue
                fcs.extend(bag.fcurves)
    if not fcs:
        fcs = list(getattr(action, "fcurves", None) or [])
    return fcs


def rotation_fcurves(action):
    """rotation_quaternion F-curves across legacy and slotted-action APIs."""
    fcurves = getattr(action, "fcurves", None)
    if fcurves:
        found = [fc for fc in fcurves if fc.data_path == "rotation_quaternion"]
        if found:
            return found
    found = []
    for layer in getattr(action, "layers", []):
        for strip in layer.strips:
            for bag in strip.channelbags:
                found.extend(
                    fc for fc in bag.fcurves if fc.data_path == "rotation_quaternion"
                )
    return found


def main() -> int:
    mod = load_addon()
    from pocketrig.bl import apply as apply_mod
    from pocketrig.bl import state
    from pocketrig.core import constants as C
    from pocketrig.core.session import Server

    take = json.loads(
        (FIXTURES_DIR / "take_resample.json").read_text(encoding="utf-8")
    )
    samples = [(s["t_ns"], tuple(s["q"])) for s in take["raw_samples"]]

    scene = bpy.context.scene
    scene.render.fps = 24  # determinism: the fixture is authored for 24 fps
    scene.render.fps_base = 1.0
    scene.frame_current = 1
    scene.pocketrig_record_smoothing = 0.0  # fixture expects exact slerp resampling

    server = Server(
        port=0,
        get_scene_fps=lambda: state.scene_fps_cache,
        host_version=bpy.app.version_string,
    )
    server.start()
    state.server = server
    state.set_offset_identity_for_test()

    phone = FakePhone(server.port)
    failures = []
    try:
        phone.handshake(server.token)
        P = phone.P

        # Splice path: first three samples go out BEFORE record_start and must
        # be recovered from the server's rolling buffer.
        for t_ns, q in samples[:3]:
            phone.pose(t_ns, q)
        wait_for(
            lambda: server.latest_pose is not None
            and server.latest_pose[1] == samples[2][0]
        )
        phone.send_reliable(
            P.encode_record_start(
                phone.next_seq(), time.monotonic_ns(), take["start_timestamp_ns"]
            )
        )
        wait_for(lambda: server.recording)
        apply_mod.apply_tick()  # observe the recording edge -> pins frame 1
        # Play-during-record regression: the playhead rolls during the take;
        # the bake must still land at the record-START frame.
        scene.frame_current = 50
        for t_ns, q in samples[3:]:
            phone.pose(t_ns, q)
        wait_for(
            lambda: server.latest_pose is not None
            and server.latest_pose[1] == samples[-1][0]
        )
        phone.send_reliable(
            P.encode_record_stop(
                phone.next_seq(),
                time.monotonic_ns(),
                take["end_timestamp_ns"],
                len(samples),
            )
        )

        # Pump the main-thread tick until the bake result reaches the phone.
        baked = phone.wait_msg(C.MSG_RECORD_BAKED, pump=apply_mod.apply_tick)
        phone.ack(baked.seq)
        expected_frames = take["expected_frame_count"]
        if baked.body.get("frames") != expected_frames:
            failures.append(f"RECORD_BAKED frames {baked.body} != {expected_frames}")
        if baked.body.get("fps") != 24.0:  # scene fps must be what was baked
            failures.append(f"RECORD_BAKED fps {baked.body.get('fps')} != 24.0")
        if baked.body.get("received") != len(samples):
            failures.append(f"RECORD_BAKED received != {len(samples)}: {baked.body}")
        if baked.body.get("sent") != len(samples):
            failures.append(f"RECORD_BAKED sent != {len(samples)}: {baked.body}")

        cam = scene.camera
        fcurves = rotation_fcurves(cam.animation_data.action)
        if len(fcurves) != 4:
            failures.append(f"expected 4 rotation_quaternion fcurves, got {len(fcurves)}")
        else:
            fcurves.sort(key=lambda fc: fc.array_index)
            for fc in fcurves:
                if len(fc.keyframe_points) != expected_frames:
                    failures.append(
                        f"channel {fc.array_index}: {len(fc.keyframe_points)} "
                        f"keyframes != {expected_frames}"
                    )
            if not failures:
                # Keyed values, all 25 frames, one global sign for the take.
                per_frame = take["expected_frames_rule"]["angle_deg_per_frame"]
                keyed = []
                for f in range(expected_frames):
                    frame_no = 1 + f
                    vals = []
                    for fc in fcurves:
                        kp = fc.keyframe_points[f]
                        if abs(kp.co[0] - frame_no) > 1e-6:
                            failures.append(
                                f"channel {fc.array_index} key {f} at frame "
                                f"{kp.co[0]} != {frame_no}"
                            )
                        vals.append(kp.co[1])
                    keyed.append(vals)
                sign = 1.0 if keyed[0][0] >= 0.0 else -1.0
                for f, vals in enumerate(keyed):
                    half = math.radians(per_frame * f) / 2.0
                    expected = (math.cos(half), 0.0, 0.0, math.sin(half))
                    got = [sign * v for v in vals]
                    if any(abs(g - w) > 1e-4 for g, w in zip(got, expected)):
                        failures.append(f"frame {f}: keyed {got} != {expected}")
        print(f"baked report: {baked.body}")

        # --- Take 2: consecutive takes must never destroy take 1 (A5). ---
        phone.inbox.clear()  # forget take 1's RECORD_BAKED so wait_msg finds take 2's
        OFF = 10_000_000_000
        for t_ns, q in samples[:3]:
            phone.pose(t_ns + OFF, q)
        wait_for(
            lambda: server.latest_pose is not None
            and server.latest_pose[1] == samples[2][0] + OFF
        )
        phone.send_reliable(
            P.encode_record_start(
                phone.next_seq(), time.monotonic_ns(), take["start_timestamp_ns"] + OFF
            )
        )
        wait_for(lambda: server.recording)
        apply_mod.apply_tick()
        for t_ns, q in samples[3:]:
            phone.pose(t_ns + OFF, q)
        wait_for(lambda: server.latest_pose[1] == samples[-1][0] + OFF)
        phone.send_reliable(
            P.encode_record_stop(
                phone.next_seq(),
                time.monotonic_ns(),
                take["end_timestamp_ns"] + OFF,
                len(samples),
            )
        )
        baked2 = phone.wait_msg(C.MSG_RECORD_BAKED, pump=apply_mod.apply_tick)
        phone.ack(baked2.seq)
        if baked2.body.get("frames") != expected_frames:
            failures.append(f"take 2 frames {baked2.body} != {expected_frames}")
        take_actions = sorted(
            a.name for a in bpy.data.actions if a.name.startswith("pocketrig Take")
        )
        if take_actions != ["pocketrig Take 01", "pocketrig Take 02"]:
            failures.append(f"expected two stashed takes, got {take_actions}")
        else:
            t1 = bpy.data.actions["pocketrig Take 01"]
            t1_fcs = rotation_fcurves(t1)
            if len(t1_fcs) != 4 or any(
                len(fc.keyframe_points) != expected_frames for fc in t1_fcs
            ):
                failures.append("take 1 was damaged by recording take 2")
        print("take 2 baked; take 1 intact")

        # ---- A zoom performed during the take survives into it (spec 4.5) ----
        # Lens keyframes live on the camera DATA block. From Blender 4.4 a single
        # Action can hold channels for several IDs in separate slots, so leaving
        # keyframe_insert to choose files the lens into the OBJECT's action --
        # where the flat curve view returns the object's rotation curves and the
        # lens curve is silently unreachable. The bake gives it its own action.
        cam_data = cam.data
        cam_data.lens = 50.0
        zoom_n = 25
        zoom_start = samples[-1][0] + 5_000_000_000  # well clear of the earlier takes
        phone.send_reliable(
            P.encode_record_start(phone.next_seq(), time.monotonic_ns(), zoom_start),
            pump=apply_mod.apply_tick,
        )
        for i in range(zoom_n):
            mm = 18.0 + i * (67.0 / (zoom_n - 1))  # 18 -> 85 mm
            phone.pose(zoom_start + i * 10_000_000, (1.0, 0.0, 0.0, 0.0), focal_mm=mm)
        zoom_end = zoom_start + (zoom_n - 1) * 10_000_000
        phone.send_reliable(
            P.encode_record_stop(
                phone.next_seq(), time.monotonic_ns(), zoom_end, zoom_n,
            ),
            pump=apply_mod.apply_tick,
        )
        lens_fcs = []
        try:
            wait_for(
                lambda: [
                    fc for fc in _all_fcurves(cam_data) if fc.data_path == "lens"
                ],
                pump=apply_mod.apply_tick,
            )
            lens_fcs = [
                fc for fc in _all_fcurves(cam_data) if fc.data_path == "lens"
            ]
        except AssertionError:
            failures.append("a recorded zoom produced no lens curve")
        if len(lens_fcs) > 1:
            failures.append(f"expected one lens fcurve, got {len(lens_fcs)}")
        elif lens_fcs:
            keys = lens_fcs[0].keyframe_points
            # The frame grid does not land on the last sample: 25 samples at 10 ms
            # is 240 ms, and at 24 fps the final frame sits at 208.3 ms. Compare
            # every key against the zoom's own linear rule rather than assuming
            # the endpoints coincide.
            span_ns = float((zoom_n - 1) * 10_000_000)
            frame_count = int((span_ns / 1e9) * 24.0 + 1e-9) + 1
            expected = [
                18.0 + (min(i * 1e9 / 24.0, span_ns) / span_ns) * 67.0
                for i in range(frame_count)
            ]
            if len(keys) != frame_count:
                failures.append(
                    f"lens curve has {len(keys)} keys, expected {frame_count}"
                )
            else:
                for i, (k, want) in enumerate(zip(keys, expected)):
                    if abs(k.co[1] - want) > 0.05:
                        failures.append(f"lens key {i}: {k.co[1]:.3f} != {want:.3f}")
                        break
                values = [k.co[1] for k in keys]
                if values != sorted(values):
                    failures.append("a monotonic zoom did not bake monotonically")
        print("recorded zoom checked")

        # A take shot at a FIXED lens must not keep playing the previous take's
        # zoom: the bake has to clear lens animation whether or not it has any of
        # its own.
        fixed_start = zoom_end + 5_000_000_000
        phone.send_reliable(
            P.encode_record_start(phone.next_seq(), time.monotonic_ns(), fixed_start),
            pump=apply_mod.apply_tick,
        )
        for i in range(10):
            phone.pose(fixed_start + i * 10_000_000, (1.0, 0.0, 0.0, 0.0))
        phone.send_reliable(
            P.encode_record_stop(
                phone.next_seq(), time.monotonic_ns(),
                fixed_start + 9 * 10_000_000, 10,
            ),
            pump=apply_mod.apply_tick,
        )
        for _ in range(60):
            apply_mod.apply_tick()
        still_animated = [
            fc for fc in _all_fcurves(cam_data) if fc.data_path == "lens"
        ]
        if still_animated:
            failures.append(
                "a fixed-lens take still plays the previous take's zoom"
            )
        print("fixed-lens take checked")

        # The baker must clear lens animation on its OWN, not only because record
        # start happens to stash first: Apply and .take import reach bake_and_insert
        # without a record edge. Exercise the baker directly.
        from pocketrig.bl import record as record_mod
        from pocketrig.core import takes as core_takes

        zoomed = [
            core_takes.RowSample(i * 10_000_000, (1.0, 0.0, 0.0, 0.0), None, 20.0 + i)
            for i in range(25)
        ]
        record_mod.bake_and_insert(zoomed, 0, 24 * 10_000_000, review=True, name="lens A")
        if not [fc for fc in _all_fcurves(cam_data) if fc.data_path == "lens"]:
            failures.append("direct bake of a zoom produced no lens curve")
        flat = [
            core_takes.RowSample(i * 10_000_000, (1.0, 0.0, 0.0, 0.0), None, None)
            for i in range(25)
        ]
        record_mod.bake_and_insert(flat, 0, 24 * 10_000_000, review=True, name="lens B")
        if [fc for fc in _all_fcurves(cam_data) if fc.data_path == "lens"]:
            failures.append(
                "the baker left a previous take's zoom driving the lens"
            )
        print("baker lens handover checked")

        # ---- The same zoom through the OFFLINE UPLOAD (spec 5.10) ----
        # This is the path the phone takes by default: rows are written to the
        # phone during the shoot and uploaded losslessly afterwards. It reaches
        # the baker through parse_row rather than the live pose buffer, and it
        # had no coverage at all -- which is how a recorded zoom shipped that was
        # correct live and absent from every uploaded take.
        for fc in list(_all_fcurves(cam_data)):
            if fc.data_path == "lens":
                cam_data.animation_data.action = None
                break
        cam_data.lens = 50.0
        up_n = 25
        up_rows = [
            {
                "t": i * 10_000_000,
                "q": [1.0, 0.0, 0.0, 0.0],
                "f": 18.0 + i * (67.0 / (up_n - 1)),
            }
            for i in range(up_n)
        ]
        reply = phone.upload_take(
            up_rows, server.token, name="uploaded zoom", pump=apply_mod.apply_tick,
        )
        if not reply.startswith(b"ok"):
            failures.append(f"offline upload refused: {reply!r}")
        up_fcs = []
        try:
            wait_for(
                lambda: [
                    fc for fc in _all_fcurves(cam_data) if fc.data_path == "lens"
                ],
                pump=apply_mod.apply_tick,
            )
            up_fcs = [fc for fc in _all_fcurves(cam_data) if fc.data_path == "lens"]
        except AssertionError:
            failures.append("an uploaded take's zoom produced no lens curve")
        if up_fcs:
            up_keys = [k.co[1] for k in up_fcs[0].keyframe_points]
            # As above, the 24 fps grid does not land on the last sample, so
            # check every key against the zoom's linear rule rather than
            # expecting the final key to reach 85 mm.
            up_span_ns = float((up_n - 1) * 10_000_000)
            up_frames = int((up_span_ns / 1e9) * 24.0 + 1e-9) + 1
            up_expected = [
                18.0 + (min(i * 1e9 / 24.0, up_span_ns) / up_span_ns) * 67.0
                for i in range(up_frames)
            ]
            if len(up_keys) != up_frames:
                failures.append(
                    f"uploaded zoom baked {len(up_keys)} lens keys, want {up_frames}"
                )
            else:
                for i, (got, want) in enumerate(zip(up_keys, up_expected)):
                    if abs(got - want) > 0.05:
                        failures.append(
                            f"uploaded lens key {i}: {got:.3f} != {want:.3f}"
                        )
                        break
                if up_keys != sorted(up_keys):
                    failures.append("uploaded zoom did not bake monotonically")
        print("uploaded zoom checked")
    finally:
        phone.bye()
        phone.close()
        server.stop()
        state.server = None
        try:
            mod.unregister()
        except Exception:
            traceback.print_exc()

    if failures:
        for f in failures:
            print("FAIL:", f)
        print("HEADLESS_RECORD_FAIL")
        return 1
    print("HEADLESS_RECORD_PASS")
    return 0


if __name__ == "__main__":
    try:
        code = main()
    except Exception:
        traceback.print_exc()
        code = 2
    sys.exit(code)
