# SPDX-License-Identifier: GPL-3.0-or-later
"""Q0.2 deterministic multi-clock simulator and candidate-gate tests."""

import math
import sys
from pathlib import Path

LAB = Path(__file__).resolve().parents[2] / "tools" / "motion_lab"
sys.path.insert(0, str(LAB))

import quality_suite  # noqa: E402
import simulator  # noqa: E402
from presentation import LatestPosePresenter, run_scenario  # noqa: E402


def test_default_scenarios_are_byte_deterministic():
    first = simulator.default_scenarios()
    second = simulator.default_scenarios()
    assert [scenario.fingerprint for scenario in first] == [
        scenario.fingerprint for scenario in second
    ]
    assert len({scenario.fingerprint for scenario in first}) == len(first)


def test_source_send_arrival_and_presentation_clocks_are_separate():
    scenario = next(
        item for item in simulator.default_scenarios() if item.name == "mixed_loop"
    )
    assert 250 < len(scenario.source) < 270  # ~30 Hz for 8.5 seconds
    assert 800 < len(scenario.packets) < 860  # ~100 Hz, minus deterministic loss
    assert 1050 < len(scenario.presentation_ns) < 1100  # 120 Hz + tail
    assert len({packet.frame.index for packet in scenario.packets}) < len(scenario.packets)
    arrival_order = sorted(scenario.packets, key=lambda packet: packet.arrival_ns)
    assert any(b.seq < a.seq for a, b in zip(arrival_order, arrival_order[1:]))


def test_thermal_scenario_really_degrades_source_cadence():
    scenario = next(
        item
        for item in simulator.default_scenarios()
        if item.name == "degraded_relocalization"
    )
    counts = [0, 0, 0]
    for frame in scenario.source:
        counts[min(2, int(frame.source_ns / (4 * simulator.NS)))] += 1
    assert 235 <= counts[0] <= 245
    assert 115 <= counts[1] <= 125
    assert 55 <= counts[2] <= 65


def test_quality_metrics_are_finite_and_baseline_is_stable():
    scenarios, metrics = quality_suite.run_suite()
    assert len(metrics) >= 25
    assert all(math.isfinite(value) for value in metrics.values())
    payload = quality_suite.baseline_payload(scenarios, metrics)
    assert quality_suite.check_baseline(payload) == []


def test_over_smoothed_presenter_fails_responsiveness_gates():
    _scenarios, baseline = quality_suite.run_suite()
    _scenarios, slow = quality_suite.run_suite(smoothing=1.0)
    failures = quality_suite.compare_candidate(baseline, slow)
    assert any("phase_lag" in failure or "settling" in failure for failure in failures)


def test_unguarded_presenter_fails_continuity_gates():
    _scenarios, baseline = quality_suite.run_suite()
    _scenarios, unsafe = quality_suite.run_suite(guards=False)
    failures = quality_suite.compare_candidate(baseline, unsafe)
    assert any("continuity/degraded" in failure for failure in failures)


def test_relocalization_guard_reduces_the_world_frame_jump():
    scenario = next(
        item
        for item in simulator.default_scenarios()
        if item.name == "degraded_relocalization"
    )
    guarded = run_scenario(scenario, LatestPosePresenter(0.30, guards=True))
    unsafe = run_scenario(scenario, LatestPosePresenter(0.30, guards=False))

    def max_step(frames):
        return max(
            simulator.vlength(simulator.vsub(b.output.p, a.output.p))
            for a, b in zip(frames, frames[1:])
        )

    assert max_step(guarded) < 0.03
    assert max_step(unsafe) > 0.25


def test_every_candidate_receives_identical_frozen_inputs():
    scenario = simulator.default_scenarios()[0]
    before = scenario.fingerprint
    run_scenario(scenario, LatestPosePresenter(0.0))
    run_scenario(scenario, LatestPosePresenter(1.0))
    assert scenario.fingerprint == before
