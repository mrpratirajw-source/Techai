# SPDX-License-Identifier: GPL-3.0-or-later
"""Take-row validation at the ingest boundary (spec 5.10) and the NaN-safety of
the shared interpolation helpers.

A take row arrives from a TCP upload, a phone push, or a `.take` file. All three
go through `takes.parse_row`, because a non-finite quaternion that reaches the
baker becomes NaN in `cam.rotation_quaternion` keyframes and propagates through
the dependency graph. Losing one take to a loud error is correct; corrupting a
scene is not.
"""

from __future__ import annotations

import math

import pytest

from core import filters, takes


def _row(**over):
    row = {"t": 1_000_000, "q": [1.0, 0.0, 0.0, 0.0]}
    row.update(over)
    return row


# ------------------------------------------------------------------ good rows


def test_minimal_rotation_row():
    assert takes.parse_row(_row()) == (1_000_000, (1.0, 0.0, 0.0, 0.0), None, None)


def test_row_with_position():
    ts, q, pos, _focal = takes.parse_row(_row(p=[1.0, -2.0, 0.5]))
    assert (ts, q) == (1_000_000, (1.0, 0.0, 0.0, 0.0))
    assert pos == (1.0, -2.0, 0.5)


def test_non_unit_quaternion_is_accepted_and_normalized_later():
    """The wire allows drift; only a zero-magnitude quaternion is meaningless."""
    _ts, q, _pos, _focal = takes.parse_row(_row(q=[2.0, 0.0, 0.0, 0.0]))
    assert takes.normalize(q) == (1.0, 0.0, 0.0, 0.0)


@pytest.mark.parametrize("quality", [None, "unknown", "good"])
def test_position_survives_valid_quality(quality):
    _ts, _q, pos, _focal = takes.parse_row(_row(p=[1.0, 2.0, 3.0], quality=quality))
    assert pos == (1.0, 2.0, 3.0)


@pytest.mark.parametrize(
    "quality", ["warming", "degraded", "lost", "recovering"]
)
def test_quality_marked_row_drops_position_but_keeps_rotation(quality):
    """Spec 5.10: raw `p` may be retained as evidence but is not valid
    translation. Rotation stays usable throughout."""
    ts, q, pos, _focal = takes.parse_row(_row(p=[9.0, 9.0, 9.0], quality=quality))
    assert (ts, q) == (1_000_000, (1.0, 0.0, 0.0, 0.0))
    assert pos is None


def test_focal_length_is_read_when_present():
    sample = takes.parse_row(_row(f=35.0))
    assert sample.focal_mm == 35.0


def test_focal_length_is_absent_when_the_sender_was_not_driving_the_lens():
    assert takes.parse_row(_row()).focal_mm is None


@pytest.mark.parametrize("bad", [0.0, -18.0, "35", [], True])
def test_bad_focal_length_is_rejected(bad):
    # A take that cannot say what lens it was shot on must fail loudly rather
    # than bake a nonsense focal length onto the camera.
    with pytest.raises(ValueError):
        takes.parse_row(_row(f=bad))


@pytest.mark.parametrize("value", [float("nan"), float("inf")])
def test_non_finite_focal_length_is_rejected(value):
    with pytest.raises(ValueError):
        takes.parse_row(_row(f=value))


# --------------------------------------------------------------- focal baking


def test_bake_focal_resamples_a_zoom():
    # 1 s of zoom from 18 to 58 mm at 100 Hz, baked at 25 fps.
    samples = [(i * 10_000_000, 18.0 + i * 0.4) for i in range(101)]
    out = takes.bake_focal(samples, 0, 100 * 10_000_000, 25.0)
    assert len(out) == 26
    assert out[0] == pytest.approx(18.0, abs=1e-6)
    assert out[-1] == pytest.approx(58.0, abs=1e-6)
    assert out == sorted(out), "a monotonic zoom must bake monotonically"


def test_bake_focal_is_empty_when_no_row_carries_one():
    samples = [(i * 10_000_000, None) for i in range(50)]
    assert takes.bake_focal(samples, 0, 49 * 10_000_000, 24.0) == []


def test_bake_focal_holds_the_first_known_value_across_earlier_frames():
    # The sender started driving the lens partway through: hold rather than
    # invent a zoom from nothing.
    samples = [(i * 10_000_000, None if i < 50 else 85.0) for i in range(100)]
    out = takes.bake_focal(samples, 0, 99 * 10_000_000, 24.0)
    assert out and all(v == pytest.approx(85.0) for v in out)


# ------------------------------------------------------------------- bad rows


@pytest.mark.parametrize(
    "bad",
    [
        pytest.param({"q": [1.0, 0.0, 0.0, 0.0]}, id="missing-t"),
        pytest.param(_row(t=None), id="null-t"),
        pytest.param(_row(t="soon"), id="string-t"),
        pytest.param({"t": 0}, id="missing-q"),
        pytest.param(_row(q="abc"), id="string-q-of-len-3"),
        pytest.param(_row(q=[1.0, 0.0]), id="two-element-q"),
        pytest.param(_row(q=[1.0, 0.0, 0.0, 0.0, 0.0]), id="five-element-q"),
        pytest.param(_row(q=[0.0, 0.0, 0.0, 0.0]), id="zero-magnitude-q"),
        pytest.param(_row(q=[None, 0.0, 0.0, 0.0]), id="null-in-q"),
        pytest.param(_row(q=["1", 0.0, 0.0, 0.0]), id="stringly-typed-q"),
        pytest.param(_row(p=[1.0, 2.0]), id="two-element-p"),
        pytest.param(_row(p="xyz"), id="string-p"),
        pytest.param(_row(quality=7), id="numeric-quality"),
        pytest.param([1, 2, 3], id="row-is-a-list"),
        pytest.param("nope", id="row-is-a-string"),
    ],
)
def test_malformed_rows_are_rejected(bad):
    with pytest.raises(ValueError):
        takes.parse_row(bad)


@pytest.mark.parametrize("value", [float("nan"), float("inf"), float("-inf")])
def test_non_finite_values_are_rejected_everywhere(value):
    with pytest.raises(ValueError):
        takes.parse_row(_row(q=[value, 0.0, 0.0, 0.0]))
    with pytest.raises(ValueError):
        takes.parse_row(_row(p=[value, 0.0, 0.0]))
    with pytest.raises(ValueError):
        takes.parse_row(_row(t=value))


def test_bool_is_not_a_number():
    """bool subclasses int, so True would otherwise pass as 1.0."""
    with pytest.raises(ValueError):
        takes.parse_row(_row(q=[True, False, False, False]))


# ----------------------------------------------- NaN safety of shared helpers
# Defence in depth: parse_row is the gate, but neither interpolator may raise
# or emit NaN if a non-finite value ever reaches it by another route.


def test_normalize_rejects_non_finite():
    assert takes.normalize((float("nan"),) * 4) == (1.0, 0.0, 0.0, 0.0)
    assert takes.normalize((float("inf"), 0.0, 0.0, 0.0)) == (1.0, 0.0, 0.0, 0.0)
    assert takes.normalize((0.0, 0.0, 0.0, 0.0)) == (1.0, 0.0, 0.0, 0.0)


@pytest.mark.parametrize("module", [takes, filters], ids=["takes", "filters"])
def test_slerp_does_not_raise_on_nan(module):
    """Guard ordering: `min(1.0, NaN)` is 1.0, so a NaN dot used to skip the
    near-parallel branch and then divide by sin(acos(1.0)) == 0."""
    nan = float("nan")
    out = module.slerp((nan, nan, nan, nan), (1.0, 0.0, 0.0, 0.0), 0.5)
    assert all(math.isfinite(c) for c in out)
    out = module.slerp((1.0, 0.0, 0.0, 0.0), (nan, nan, nan, nan), 0.5)
    assert all(math.isfinite(c) for c in out)


def test_slerp_still_interpolates_normally():
    """The NaN guard must not disturb ordinary interpolation."""
    a = (1.0, 0.0, 0.0, 0.0)
    b = takes.normalize((math.cos(math.pi / 4), 0.0, 0.0, math.sin(math.pi / 4)))
    mid = takes.slerp(a, b, 0.5)
    expected = takes.normalize(
        (math.cos(math.pi / 8), 0.0, 0.0, math.sin(math.pi / 8))
    )
    for got, want in zip(mid, expected):
        assert got == pytest.approx(want, abs=1e-9)


def test_bake_never_emits_non_finite_keyframes():
    """The end-to-end property that matters: whatever survives validation, no
    baked keyframe component may be NaN or infinite."""
    good = (1.0, 0.0, 0.0, 0.0)
    samples = [(i * 10_000_000, good) for i in range(200)]
    for smoothing in (0.0, 0.15, 1.0):
        out = takes.bake(samples, 0, 199 * 10_000_000, 24.0, smoothing)
        assert out
        assert all(math.isfinite(c) for q in out for c in q)
