# SPDX-License-Identifier: GPL-3.0-or-later
"""Gate the Motion Lab's tier-1 feel metrics in the normal desktop test run.

If this fails, a change moved filter lag / jitter attenuation / stepping
outside the committed tolerance bands in tools/motion_lab/baselines/.
That is sometimes intentional (a deliberate retune): verify the numbers with
`python tools/motion_lab/run_lab.py`, then commit new baselines via
`--update-baselines` so the change is explicit in the diff — never widen a
band to make a test pass.
"""

import sys
from pathlib import Path

LAB = Path(__file__).resolve().parents[2] / "tools" / "motion_lab"
sys.path.insert(0, str(LAB))

import run_lab  # noqa: E402


def test_tier1_metrics_within_baselines():
    failures = run_lab.check_tier1()
    assert not failures, "Motion Lab regression:\n" + "\n".join(failures)
