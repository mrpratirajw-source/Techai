# SPDX-License-Identifier: GPL-3.0-or-later
"""6DOF conformance inside `blender --background --python`.

Exercises every host rule of spec/coordinate-systems.md section 6 over the
real UDP path: connect-holds-home, displacement composition
(cam_loc = t_offset + s * R(q_offset) * p), no-jump on movement-scale change,
tracking-loss hold + no-jump re-anchor on recovery, 6DOF re-center snap-back,
and a recorded take producing location F-curves alongside rotation.

Prints HEADLESS_6DOF_PASS and exits 0 on success; non-zero on failure.
"""

import math
import sys
import time
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import bpy  # noqa: E402
from mathutils import Euler, Quaternion, Vector  # noqa: E402

from _headless_common import (  # noqa: E402
    FakePhone,
    load_addon,
    quat_close,
    wait_for,
)

HOME_EULER_DEG = (65.0, 0.0, 40.0)
HOME_LOC = (1.0, -2.0, 3.0)
Q_POSE = (0.70710678, 0.70710678, 0.0, 0.0)  # constant orientation throughout
P0 = (0.5, -0.25, 1.5)


def vec_close(got, want, tol=1e-4):
    return all(abs(g - w) <= tol for g, w in zip(got, want))


def _fcurves(action, data_path):
    """F-curves for a data_path across both the flat (4.5) and slotted (5.x)
    action APIs, sorted by array_index."""
    fcs = [fc for fc in (getattr(action, "fcurves", None) or []) if fc.data_path == data_path]
    if not fcs:
        for layer in getattr(action, "layers", []):
            for strip in layer.strips:
                for bag in strip.channelbags:
                    fcs.extend(fc for fc in bag.fcurves if fc.data_path == data_path)
    return sorted(fcs, key=lambda fc: fc.array_index)


def _first_key(action, data_path):
    """The first keyframe's value across a data_path's channels, or None if the
    channels are missing / unkeyed."""
    fcs = _fcurves(action, data_path)
    if not fcs or any(len(fc.keyframe_points) == 0 for fc in fcs):
        return None
    return [fc.keyframe_points[0].co[1] for fc in fcs]


def main() -> int:
    mod = load_addon()
    from pocketrig.bl import apply as apply_mod
    from pocketrig.bl import state
    from pocketrig.core import constants as C
    from pocketrig.core import protocol as P
    from pocketrig.core.session import Server

    scene = bpy.context.scene
    scene.render.fps = 24
    scene.render.fps_base = 1.0
    scene.frame_current = 1
    scene.pocketrig_live_smoothing = 0.0
    scene.pocketrig_record_smoothing = 0.0
    scene.pocketrig_move_scale = 1.0

    cam_data = bpy.data.cameras.new("PocketRig Cam")
    cam = bpy.data.objects.new("PocketRig Cam", cam_data)
    scene.collection.objects.link(cam)
    scene.camera = cam
    cam.rotation_mode = "QUATERNION"
    home_q = Euler([math.radians(a) for a in HOME_EULER_DEG], "XYZ").to_quaternion()
    cam.rotation_quaternion = home_q
    cam.location = Vector(HOME_LOC)

    server = Server(
        port=0,
        get_scene_fps=lambda: state.scene_fps_cache,
        host_version=bpy.app.version_string,
    )
    server.start()
    state.server = server

    phone = FakePhone(server.port)
    failures = []
    ts = 0

    def send_and_apply(quat, pos, dt_ns=10_000_000):
        # Displacement steps use dt_ns=50ms so implied speeds stay handheld-
        # plausible (< 10 m/s) — the teleport guard is meant to reject faster.
        nonlocal ts
        ts += dt_ns
        seq = phone.pose(ts, quat, pos=pos)
        wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        return ts

    try:
        phone.handshake(server.token)

        # 1. Connect with a 6DOF pose -> camera holds home placement exactly.
        send_and_apply(Q_POSE, P0)
        if not vec_close(cam.location, HOME_LOC):
            failures.append(f"connect: location {tuple(cam.location)} != home {HOME_LOC}")
        if not quat_close(tuple(cam.rotation_quaternion), tuple(home_q), 1e-4):
            failures.append("connect: rotation did not hold home")
        q_off = state.q_offset.copy()

        # 2. Displacement: moving the phone by D must move the camera by
        #    s * R(q_offset) * D (spec 6 composition), with s = 1.
        d1 = Vector((0.2, 0.3, -0.1))
        send_and_apply(Q_POSE, tuple(Vector(P0) + d1), dt_ns=100_000_000)
        want = Vector(HOME_LOC) + (q_off @ d1)
        if not vec_close(cam.location, want):
            failures.append(f"move: {tuple(cam.location)} != {tuple(want)}")

        # 3. Scale change must not jump: same phone pose, new scale -> same spot.
        before = cam.location.copy()
        scene.pocketrig_move_scale = 2.0
        send_and_apply(Q_POSE, tuple(Vector(P0) + d1))
        if not vec_close(cam.location, before):
            failures.append(f"scale change jumped: {tuple(cam.location)} != {tuple(before)}")
        # ...and subsequent displacement is doubled.
        d2 = Vector((-0.1, 0.05, 0.2))
        send_and_apply(Q_POSE, tuple(Vector(P0) + d1 + d2), dt_ns=100_000_000)
        want = before + 2.0 * (q_off @ d2)
        if not vec_close(cam.location, want):
            failures.append(f"scaled move: {tuple(cam.location)} != {tuple(want)}")

        # 4. Tracking loss: rotation-only pose -> location holds; recovery at a
        #    wildly different position -> still no jump (re-anchor rule).
        held = cam.location.copy()
        send_and_apply(Q_POSE, None)
        if not vec_close(cam.location, held):
            failures.append("tracking loss moved the camera")
        send_and_apply(Q_POSE, (10.0, 10.0, 10.0))
        if not vec_close(cam.location, held):
            failures.append(f"recovery jumped: {tuple(cam.location)} != {tuple(held)}")
        # ...and motion resumes relative to the recovered origin, scaled.
        d3 = Vector((0.1, 0.0, 0.0))
        send_and_apply(Q_POSE, tuple(Vector((10.0, 10.0, 10.0)) + d3), dt_ns=50_000_000)
        want = held + 2.0 * (q_off @ d3)
        if not vec_close(cam.location, want):
            failures.append(f"post-recovery move: {tuple(cam.location)} != {tuple(want)}")

        # 5. Re-center: camera snaps back to the full home placement. The
        #    offset is captured against the latest pose, so the confirming
        #    pose repeats the last position (as a still-held phone would).
        p_last = tuple(Vector((10.0, 10.0, 10.0)) + d3)
        phone.send_reliable(
            P.encode_recenter(phone.next_seq(), time.monotonic_ns()),
            pump=apply_mod.apply_tick,
        )
        send_and_apply(Q_POSE, p_last)
        for _ in range(5):
            apply_mod.apply_tick()
        if not vec_close(cam.location, HOME_LOC):
            failures.append(f"recenter: location {tuple(cam.location)} != home {HOME_LOC}")
        if not quat_close(tuple(cam.rotation_quaternion), tuple(home_q), 1e-4):
            failures.append("recenter: rotation did not snap home")
        q_off = state.q_offset.copy()

        # 6. Record a linear 6DOF move -> location F-curves alongside rotation.
        scene.pocketrig_move_scale = 1.0
        a = Vector((10.0, 10.0, 10.0))
        b = a + Vector((0.6, -0.3, 0.24))
        send_and_apply(Q_POSE, tuple(a), dt_ns=50_000_000)  # re-anchors scale 1.0
        cam_at_a = cam.location.copy()
        start_ns = ts + 10_000_000
        phone.send_reliable(
            P.encode_record_start(phone.next_seq(), time.monotonic_ns(), start_ns),
            pump=apply_mod.apply_tick,
        )
        n = 25  # 250 ms at 10 ms steps -> floor(0.24s * 24fps) + 1 = 6 frames
        for i in range(n):
            u = i / (n - 1)
            send_and_apply(Q_POSE, tuple(a.lerp(b, u)))
            if i == 0 and not vec_close(cam.location, cam_at_a):
                # Record start drops the anchor; the first in-take pose must
                # re-anchor at the camera's current spot — zero motion.
                failures.append(
                    f"record-start fresh anchor moved the camera: {tuple(cam.location)}"
                )
        end_ns = ts
        phone.send_reliable(
            P.encode_record_stop(phone.next_seq(), time.monotonic_ns(), end_ns, n),
            pump=apply_mod.apply_tick,
        )
        baked = phone.wait_msg(C.MSG_RECORD_BAKED, pump=apply_mod.apply_tick)
        phone.ack(baked.seq)
        expected_frames = int((end_ns - start_ns) * 24 / 1e9) + 1
        if baked.body.get("frames") != expected_frames:
            failures.append(f"baked frames {baked.body} != {expected_frames}")

        action = cam.animation_data.action
        fcurves = getattr(action, "fcurves", None) or []
        loc_fc = sorted(
            (fc for fc in fcurves if fc.data_path == "location"),
            key=lambda fc: fc.array_index,
        )
        if not loc_fc:  # slotted-actions API (Blender 5.x layered actions)
            loc_fc = []
            for layer in getattr(action, "layers", []):
                for strip in layer.strips:
                    for bag in strip.channelbags:
                        loc_fc.extend(
                            fc for fc in bag.fcurves if fc.data_path == "location"
                        )
            loc_fc.sort(key=lambda fc: fc.array_index)
        if len(loc_fc) != 3:
            failures.append(f"expected 3 location fcurves, got {len(loc_fc)}")
        else:
            for fc in loc_fc:
                if len(fc.keyframe_points) != expected_frames:
                    failures.append(
                        f"location[{fc.array_index}]: {len(fc.keyframe_points)} "
                        f"keys != {expected_frames}"
                    )
            if not failures:
                # Take is linear in protocol space, so keyed locations are
                # cam_at_a + R(q_offset) * (lerp(a,b,t_f) - a), s = 1.
                dur_ns = end_ns - start_ns
                for f in range(expected_frames):
                    t_ns = start_ns + f * 1e9 / 24.0
                    u = (t_ns - start_ns) / dur_ns
                    want = cam_at_a + (q_off @ ((b - a) * u))
                    got = [fc.keyframe_points[f].co[1] for fc in loc_fc]
                    if not vec_close(got, want, 5e-3):
                        failures.append(f"frame {f}: location {got} != {tuple(want)}")
        # 7. THE landscape-rotation bug, at the wire level: a sender that keeps
        #    repeating a stale positional pose with a FROZEN timestamp (fresh
        #    seqs) during tracking loss, then resumes at a shifted origin.
        #    The ts-gap host guard (coordinate-systems.md section 6) must
        #    re-anchor instead of jumping.
        p_stale = tuple(b)
        send_and_apply(Q_POSE, p_stale)  # fresh baseline
        held = cam.location.copy()
        for _ in range(5):  # frozen ts, advancing seq — poseLoop's repeat shape
            seq = phone.pose(ts, Q_POSE, pos=p_stale)
            wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        if not vec_close(cam.location, held):
            failures.append(f"stale repeat moved camera: {tuple(cam.location)}")
        ts += 2_000_000_000  # tracker was gone 2 s; origin relocated far away
        seq = phone.pose(ts, Q_POSE, pos=(50.0, -50.0, 5.0))
        wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        if not vec_close(cam.location, held):
            failures.append(f"frozen-ts recovery jumped: {tuple(cam.location)}")
        # ...and relative motion still works after the re-anchor.
        d4 = Vector((0.0, 0.2, 0.0))
        send_and_apply(Q_POSE, tuple(Vector((50.0, -50.0, 5.0)) + d4), dt_ns=100_000_000)
        want = held + (q_off @ d4)  # applied_move_scale is 1.0 here
        if not vec_close(cam.location, want):
            failures.append(f"post-gap move: {tuple(cam.location)} != {tuple(want)}")

        # 8. Pure ts-jump (true silence variant): >250 ms gap in the stream's
        #    own timestamps -> re-anchor, no movement on that pose.
        held = cam.location.copy()
        ts += 300_000_000
        seq = phone.pose(ts, Q_POSE, pos=(51.0, -50.0, 5.0))
        wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        if not vec_close(cam.location, held):
            failures.append(f"ts-gap pose jumped: {tuple(cam.location)}")

        # 9. Teleport guard: normal cadence but an impossible displacement
        #    (5 m in 33 ms = 150 m/s) — relocalization, not motion.
        held = cam.location.copy()
        ts += 33_000_000
        seq = phone.pose(ts, Q_POSE, pos=(56.0, -50.0, 5.0))
        wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        if not vec_close(cam.location, held):
            failures.append(f"teleport jumped: {tuple(cam.location)}")
        d5 = Vector((0.05, 0.0, 0.0))  # plausible move resumes normally
        send_and_apply(Q_POSE, tuple(Vector((56.0, -50.0, 5.0)) + d5), dt_ns=50_000_000)
        want = held + (q_off @ d5)
        if not vec_close(cam.location, want):
            failures.append(f"post-teleport move: {tuple(cam.location)} != {tuple(want)}")

        # 10. Rotational teleport (loop closure): the tracker's world rotates
        #     120 deg between frames — implied ~3600 deg/s, no wrist does that.
        #     The displayed orientation must hold (offset re-expressed) and the
        #     position must not move either (R(q_offset) changed -> re-anchor).
        shown_before = cam.rotation_quaternion.copy()
        held = cam.location.copy()
        p_hold = (56.05, -50.0, 5.0)
        q_flip = (
            Quaternion((0.0, 0.0, 1.0), math.radians(120.0)) @ Quaternion(Q_POSE)
        ).normalized()
        ts += 33_000_000
        seq = phone.pose(ts, tuple(q_flip), pos=p_hold)
        wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        if not quat_close(tuple(cam.rotation_quaternion), tuple(shown_before), 1e-3):
            failures.append(
                f"rotation teleport changed the view: {tuple(cam.rotation_quaternion)}"
            )
        if not vec_close(cam.location, held):
            failures.append(f"rotation teleport moved the camera: {tuple(cam.location)}")
        # ...and small rotations keep tracking against the new reference.
        q_off2 = state.q_offset.copy()
        q_next = (
            Quaternion((0.0, 0.0, 1.0), math.radians(2.0)) @ q_flip
        ).normalized()
        ts += 33_000_000
        seq = phone.pose(ts, tuple(q_next), pos=p_hold)
        wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        want_q = q_off2 @ q_next
        if not quat_close(tuple(cam.rotation_quaternion), tuple(want_q), 1e-3):
            failures.append("post-rotation-teleport tracking broken")

        # 11. PARAMS mirror (spec 5.7): a phone slider change lands on the
        #     scene props without an echo; a Blender-side change pushes to the
        #     phone as one PARAMS message.
        # First drain + ACK the pushes triggered by this test's own earlier
        # move_scale changes so their reliable resends stop before the
        # no-echo window below.
        drain_until = time.monotonic() + 1.0
        while time.monotonic() < drain_until:
            phone.pump()
            for m in phone.inbox:
                if m.msg_type == C.MSG_PARAMS:
                    phone.ack(m.seq)
            apply_mod.apply_tick()
            time.sleep(0.02)
        phone.inbox.clear()
        phone.send_reliable(
            P.encode_params(phone.next_seq(), time.monotonic_ns(), 0.42, 0.21, 4.0),
            pump=apply_mod.apply_tick,
        )
        wait_for(
            lambda: abs(scene.pocketrig_live_smoothing - 0.42) < 1e-6,
            pump=apply_mod.apply_tick,
        )
        if abs(scene.pocketrig_record_smoothing - 0.21) > 1e-6:
            failures.append("params: record smoothing not applied")
        if abs(scene.pocketrig_move_scale - 4.0) > 1e-6:
            failures.append("params: move scale not applied")
        phone.inbox.clear()
        for _ in range(5):  # settle: no echo may arrive for the phone's change
            apply_mod.apply_tick()
        phone.pump()
        if any(m.msg_type == C.MSG_PARAMS for m in phone.inbox):
            failures.append("params: host echoed a phone-driven change")
        scene.pocketrig_move_scale = 6.5  # Blender-side change -> push
        msg = phone.wait_msg(C.MSG_PARAMS, pump=apply_mod.apply_tick)
        phone.ack(msg.seq)
        if abs(msg.body.get("move_scale", 0.0) - 6.5) > 1e-6:
            failures.append(f"params push wrong: {msg.body}")
        # restore for any later cases
        scene.pocketrig_live_smoothing = 0.0
        scene.pocketrig_move_scale = 1.0
        for _ in range(3):
            apply_mod.apply_tick()

        # 12. PAUSE + soft resume (spec 5.8): freeze the drive, move the phone
        #     far away while paused, resume -> camera continues from where it
        #     is (no jump), and subsequent motion tracks relative again.
        send_and_apply(Q_POSE, p_hold, dt_ns=50_000_000)  # baseline (rot guard
        # absorbs the params-case orientation delta on this pose)
        held = cam.location.copy()
        phone.send_reliable(
            P.encode_pause(phone.next_seq(), time.monotonic_ns(), True),
            pump=apply_mod.apply_tick,
        )
        wait_for(lambda: state.paused, pump=apply_mod.apply_tick)
        ts += 50_000_000
        phone.pose(ts, Q_POSE, pos=(60.0, -48.0, 6.0))  # ignored while paused
        for _ in range(10):
            apply_mod.apply_tick()
            time.sleep(0.005)
        if not vec_close(cam.location, held):
            failures.append(f"paused drive still moved: {tuple(cam.location)}")
        phone.send_reliable(
            P.encode_pause(phone.next_seq(), time.monotonic_ns(), False),
            pump=apply_mod.apply_tick,
        )
        wait_for(lambda: not state.paused, pump=apply_mod.apply_tick)
        send_and_apply(Q_POSE, (60.0, -48.0, 6.0), dt_ns=50_000_000)
        if not vec_close(cam.location, held):
            failures.append(f"soft resume jumped: {tuple(cam.location)}")
        d6 = Vector((0.1, 0.0, 0.0))
        send_and_apply(Q_POSE, tuple(Vector((60.0, -48.0, 6.0)) + d6), dt_ns=50_000_000)
        want = held + state.applied_move_scale * (state.q_offset @ d6)
        if not vec_close(cam.location, want):
            failures.append(f"post-resume move: {tuple(cam.location)} != {tuple(want)}")

        # 13. Pause -> MANUAL reframe in Blender -> Go live: the camera stays
        #     at the new framing, motion tracks relative from it, and the new
        #     framing becomes the re-center HOME (spec 5.8).
        phone.send_reliable(
            P.encode_pause(phone.next_seq(), time.monotonic_ns(), True),
            pump=apply_mod.apply_tick,
        )
        wait_for(lambda: state.paused, pump=apply_mod.apply_tick)
        new_home_q = Euler(
            [math.radians(a) for a in (80.0, 0.0, -30.0)], "XYZ"
        ).to_quaternion()
        cam.rotation_quaternion = new_home_q  # the operator reframes by hand
        cam.location = Vector((7.0, 7.0, 7.0))
        phone.send_reliable(
            P.encode_pause(phone.next_seq(), time.monotonic_ns(), False),
            pump=apply_mod.apply_tick,
        )
        wait_for(lambda: not state.paused, pump=apply_mod.apply_tick)
        p_now = tuple(Vector((60.0, -48.0, 6.0)) + d6)  # phone hasn't moved
        send_and_apply(Q_POSE, p_now, dt_ns=50_000_000)
        if not vec_close(cam.location, (7.0, 7.0, 7.0)):
            failures.append(f"manual reframe lost on resume: {tuple(cam.location)}")
        if not quat_close(tuple(cam.rotation_quaternion), tuple(new_home_q), 1e-3):
            failures.append("manual reframe rotation lost on resume")
        d7 = Vector((0.0, 0.1, 0.0))
        send_and_apply(Q_POSE, tuple(Vector(p_now) + d7), dt_ns=50_000_000)
        want = Vector((7.0, 7.0, 7.0)) + state.applied_move_scale * (state.q_offset @ d7)
        if not vec_close(cam.location, want):
            failures.append(f"post-reframe move: {tuple(cam.location)} != {tuple(want)}")
        # ...and Re-center now returns to the ADOPTED framing, not the old one.
        phone.send_reliable(
            P.encode_recenter(phone.next_seq(), time.monotonic_ns()),
            pump=apply_mod.apply_tick,
        )
        send_and_apply(Q_POSE, tuple(Vector(p_now) + d7), dt_ns=50_000_000)
        for _ in range(5):
            apply_mod.apply_tick()
        if not vec_close(cam.location, (7.0, 7.0, 7.0)):
            failures.append(f"recenter ignored adopted home: {tuple(cam.location)}")
        if not quat_close(tuple(cam.rotation_quaternion), tuple(new_home_q), 1e-3):
            failures.append("recenter ignored adopted home rotation")

        # 14. Forgetting Go-live: Record while paused MUST equal Go-live +
        #     Record — the take starts from the camera's CURRENT framing,
        #     never a stale-offset composition (the "camera flew away" bug).
        phone.send_reliable(
            P.encode_pause(phone.next_seq(), time.monotonic_ns(), True),
            pump=apply_mod.apply_tick,
        )
        wait_for(lambda: state.paused, pump=apply_mod.apply_tick)
        q14 = Euler(
            [math.radians(a) for a in (10.0, 0.0, 120.0)], "XYZ"
        ).to_quaternion()
        cam.rotation_quaternion = q14  # reviewing/scrubbing left it here
        cam.location = Vector((9.0, -9.0, 2.0))
        start14 = ts + 10_000_000
        phone.send_reliable(
            P.encode_record_start(phone.next_seq(), time.monotonic_ns(), start14),
            pump=apply_mod.apply_tick,
        )
        wait_for(lambda: server.recording, pump=apply_mod.apply_tick)
        apply_mod.apply_tick()  # record edge: implies resume
        p14 = tuple(Vector(p_now) + d7)  # the phone never moved meanwhile
        ts = start14
        seq = phone.pose(ts, Q_POSE, pos=p14)
        wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        if not vec_close(cam.location, (9.0, -9.0, 2.0)):
            failures.append(f"record-from-pause flew away: {tuple(cam.location)}")
        if not quat_close(tuple(cam.rotation_quaternion), tuple(q14), 1e-3):
            failures.append("record-from-pause lost the framing (rotation)")
        d8 = Vector((0.05, 0.0, 0.0))
        send_and_apply(Q_POSE, tuple(Vector(p14) + d8), dt_ns=50_000_000)
        want = Vector((9.0, -9.0, 2.0)) + state.applied_move_scale * (
            state.q_offset @ d8
        )
        if not vec_close(cam.location, want):
            failures.append(f"in-take move after implied resume: {tuple(cam.location)}")
        phone.send_reliable(
            P.encode_record_stop(phone.next_seq(), time.monotonic_ns(), ts, 2),
            pump=apply_mod.apply_tick,
        )
        phone.inbox.clear()  # earlier RECORD_BAKED would satisfy wait_msg
        baked14 = phone.wait_msg(C.MSG_RECORD_BAKED, pump=apply_mod.apply_tick)
        phone.ack(baked14.seq)
        if baked14.body.get("frames", 0) < 1:
            failures.append(f"record-from-pause take failed to bake: {baked14.body}")

        # 15. SEEK + PARAMS: the phone's retake button moves the playhead
        #     (spec 5.9). Layout is now phone-LOCAL — a layout request must NOT
        #     touch the render aspect (decoupled); take_source still mirrors into
        #     the scene, proving PARAMS otherwise still applies (spec 5.7).
        scene.frame_current = 33
        phone.send_reliable(
            P.encode_seek(phone.next_seq(), time.monotonic_ns()),
            pump=apply_mod.apply_tick,
        )
        wait_for(
            lambda: scene.frame_current == scene.frame_start,
            pump=apply_mod.apply_tick,
        )
        rx, ry = scene.render.resolution_x, scene.render.resolution_y
        phone.send_reliable(
            P.encode_params(
                phone.next_seq(), time.monotonic_ns(), 0.0, 0.0, 1.0,
                layout="portrait", take_source="live",
            ),
            pump=apply_mod.apply_tick,
        )
        wait_for(
            lambda: str(getattr(scene, "pocketrig_take_source", "")) == "live",
            pump=apply_mod.apply_tick,
        )
        if (scene.render.resolution_x, scene.render.resolution_y) != (rx, ry):
            failures.append("layout must no longer swap the render resolution")

        # 16. Apply a take (upload while not recording), then go live: the take
        #     ATTACHES to the camera (so it is visible/scrubbable), and going
        #     live DETACHES it so the live drive is never fought (spec 5.11).
        import json as _json
        import socket as _socket

        conn = _socket.create_connection(("127.0.0.1", server.take_port), timeout=3.0)
        try:
            hdr = {
                "format": "pocketrig-take", "version": 0, "token": server.token,
                "name": "Applied", "start_ns": 0, "end_ns": 20_000_000,
                "sample_count": 3, "source": "sensor",
            }
            payload = _json.dumps(hdr) + "\n"
            for t in (0, 10_000_000, 20_000_000):
                payload += _json.dumps({"t": t, "q": list(Q_POSE)}) + "\n"
            conn.sendall(payload.encode("utf-8"))
            conn.settimeout(3.0)
            if conn.recv(16).strip() != b"ok":
                failures.append("apply upload not acked")
        finally:
            conn.close()
        wait_for(
            lambda: scene.camera.animation_data is not None
            and scene.camera.animation_data.action is not None,
            pump=apply_mod.apply_tick,
        )
        if scene.camera.animation_data.action is None:
            failures.append("applied take did not attach to the camera")
        apply_mod._go_live(scene)
        if (
            scene.camera.animation_data is not None
            and scene.camera.animation_data.action is not None
        ):
            failures.append("go-live did not detach the applied take")

        # 17. Shake-hold: fast rotation (~800 deg/s, above the 300 shake gate
        #     but below the 1200 relocalization guard) with a DRIFTING position
        #     must HOLD the camera position — ARCore's dead-reckoning drift is
        #     never applied — then resume cleanly when the motion calms.
        send_and_apply(Q_POSE, (70.0, 70.0, 70.0), dt_ns=100_000_000)  # settle
        base_loc = cam.location.copy()
        drift = Vector((70.0, 70.0, 70.0))
        qz = Quaternion(Q_POSE)
        for i in range(1, 8):  # 8 deg per 10 ms = 800 deg/s
            qz = (
                Quaternion((0.0, 0.0, 1.0), math.radians(8.0 * i))
                @ Quaternion(Q_POSE)
            ).normalized()
            drift += Vector((0.1, 0.0, 0.0))  # position "drifting" during blur
            ts += 10_000_000
            seq = phone.pose(ts, tuple(qz), pos=tuple(drift))
            wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        if not vec_close(cam.location, base_loc, 1e-3):
            failures.append(
                f"shake drifted the camera: {tuple(cam.location)} != {tuple(base_loc)}"
            )
        # Calm again (same orientation -> ~0 deg/s): re-anchor at current spot.
        #
        # The gate reads a SMOOTHED speed on purpose: one pose interval is far
        # too short a window to tell a shake from noise, and measuring a single
        # interval is what made the hold fire during slow deliberate moves. The
        # cost of that is a short tail -- the average decays 25% per sample, so
        # ~800 deg/s needs three calm samples to fall back under the 300 gate.
        # That lag is the feature and must not be "fixed" by sharpening the
        # filter; what this pins is that the hold nonetheless releases PROMPTLY,
        # within a handful of samples (~40 ms at the 100 Hz pose rate), and
        # re-anchors where the camera stands so no drift is ever applied.
        CALM_SAMPLES = 4
        for _ in range(CALM_SAMPLES):
            send_and_apply(tuple(qz), tuple(drift), dt_ns=100_000_000)
        held = cam.location.copy()
        d = Vector((0.05, 0.0, 0.0))
        send_and_apply(tuple(qz), tuple(drift + d), dt_ns=100_000_000)
        want = held + state.applied_move_scale * (state.q_offset @ d)
        if not vec_close(cam.location, want, 5e-3):
            failures.append(
                f"hold did not release within {CALM_SAMPLES} calm samples: "
                f"{tuple(cam.location)} != {tuple(want)}"
            )

        # 17y. A single step above the relocalization guard must not feed the
        #      shake average. That guard's whole definition is "no wrist produces
        #      this, so the reference changed rather than the camera moving", and
        #      a reference change is not motion. The phone turning past a
        #      shot-orientation quadrant emits exactly such a step (a quarter turn
        #      in one pose interval), and it used to leave the average parked well
        #      above the gate, holding position afterwards because the operator
        #      had rotated the phone.
        send_and_apply(tuple(qz), tuple(drift), dt_ns=100_000_000)  # settle
        q_seam = (
            Quaternion((0.0, 0.0, 1.0), math.radians(90.0)) @ Quaternion(qz)
        ).normalized()
        ts += 10_000_000  # 90 deg in 10 ms = 9000 deg/s: a relabelling
        seq = phone.pose(ts, tuple(q_seam), pos=tuple(drift))
        wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        send_and_apply(tuple(q_seam), tuple(drift), dt_ns=100_000_000)  # re-anchor
        seam_base = cam.location.copy()
        d_seam = Vector((0.05, 0.0, 0.0))
        send_and_apply(tuple(q_seam), tuple(drift + d_seam), dt_ns=100_000_000)
        want_seam = seam_base + state.applied_move_scale * (
            state.q_offset @ d_seam
        )
        if not vec_close(cam.location, want_seam, 5e-3):
            failures.append(
                "a reference seam left the shake gate holding: "
                f"{tuple(cam.location)} != {tuple(want_seam)}"
            )
        qz = q_seam  # subsequent cases continue from the new orientation

        # 17z. Shake-hold OFF (spec 5.7 shake_hold_dps = 0): the same shake must
        #      now drive position straight through. The gate trades an invented
        #      drift against a real reframe being mistaken for a shake, and which
        #      of those costs more is the operator's call, so "off" has to mean
        #      off rather than "a very high threshold".
        scene.pocketrig_shake_hold_dps = 0.0
        for _ in range(3):
            apply_mod.apply_tick()
        send_and_apply(tuple(qz), tuple(drift), dt_ns=100_000_000)  # settle/anchor
        off_base = cam.location.copy()
        # 0.02 m per 10 ms is 2 m/s: real handheld speed, comfortably under the
        # 5 m/s teleport guard, which would otherwise re-anchor and mask this.
        d_off = Vector((0.02, 0.0, 0.0))
        steps = 8
        for i in range(1, steps + 1):  # shaking hard AND translating
            qz_off = (
                Quaternion((0.0, 0.0, 1.0), math.radians(8.0 * i)) @ Quaternion(qz)
            ).normalized()
            ts += 10_000_000
            seq = phone.pose(ts, tuple(qz_off), pos=tuple(drift + d_off * i))
            wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        # Assert the FULL translation arrived, not merely that something moved.
        # The smoothed speed needs a few samples to climb past the gate, so with
        # the hold enabled the first samples are applied and only the later ones
        # are dropped -- "the camera moved at all" passes in both worlds and
        # proves nothing.
        want_off = off_base + state.applied_move_scale * (
            state.q_offset @ (d_off * steps)
        )
        if not vec_close(cam.location, want_off, 5e-3):
            failures.append(
                "shake hold off did not follow the whole move: "
                f"{tuple(cam.location)} != {tuple(want_off)}"
            )
        scene.pocketrig_shake_hold_dps = apply_mod.SHAKE_HOLD_DPS  # restore
        for _ in range(3):
            apply_mod.apply_tick()

        # 17a. A shake immediately before Go Live must not hold the resumed
        #      camera. The smoothed speed is derived from the previous pose, and
        #      every re-anchor deliberately forgets the pose history -- so the
        #      average has to be forgotten with it. It was not, and a stale value
        #      above the gate kept HOLDING position at the exact moment the
        #      operator had asked the camera to start following again. Same
        #      applies to Record-from-pause and FRAME_RESET, which share the
        #      re-anchor path.
        for i in range(1, 9):  # shake hard, then stop dead
            ts += 10_000_000
            seq = phone.pose(
                ts,
                tuple(
                    (
                        Quaternion((0.0, 0.0, 1.0), math.radians(8.0 * i))
                        @ Quaternion(qz)
                    ).normalized()
                ),
                pos=tuple(drift),
            )
            wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        q_shaken = state.last_pose_quat.copy()
        phone.send_reliable(
            P.encode_pause(phone.next_seq(), time.monotonic_ns(), True),
            pump=apply_mod.apply_tick,
        )
        wait_for(lambda: state.paused, pump=apply_mod.apply_tick)
        phone.send_reliable(
            P.encode_pause(phone.next_seq(), time.monotonic_ns(), False),
            pump=apply_mod.apply_tick,
        )
        wait_for(lambda: not state.paused, pump=apply_mod.apply_tick)
        send_and_apply(tuple(q_shaken), tuple(drift), dt_ns=100_000_000)  # re-anchor
        resumed = cam.location.copy()
        d_resume = Vector((0.05, 0.0, 0.0))
        send_and_apply(tuple(q_shaken), tuple(drift + d_resume), dt_ns=100_000_000)
        want = resumed + state.applied_move_scale * (state.q_offset @ d_resume)
        if not vec_close(cam.location, want, 5e-3):
            failures.append(
                f"go-live after a shake stayed held: {tuple(cam.location)} != {tuple(want)}"
            )

        # 17b. The rotational relocalization guard must survive a run of
        #      position-invalid poses. Position loss has a safety net (the
        #      anchor is dropped, so recovery re-anchors and cannot jump);
        #      ORIENTATION has none — q_offset is untouched while position is
        #      invalid, so only this guard stands between a relocalized
        #      tracker and a visible snap. Angular speed is therefore measured
        #      against the last POSE, not the last positional pose: measuring
        #      from the latter let the divisor grow across the invalid run, so
        #      a 90 deg step read as ~150 deg/s instead of ~9000 and slipped
        #      under the 1200 deg/s guard.
        send_and_apply(tuple(qz), tuple(drift), dt_ns=100_000_000)  # settle
        q_before = cam.rotation_quaternion.copy()
        loc_before = cam.location.copy()
        for _ in range(6):  # ~600 ms with no valid position
            ts += 100_000_000
            seq = phone.pose(ts, tuple(qz))
            wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        if not quat_close(tuple(cam.rotation_quaternion), tuple(q_before), 1e-4):
            failures.append("position-invalid run rotated the camera")
        # Recovery 10 ms later, relocalized: 90 deg of orientation in one step
        # (~9000 deg/s, no wrist does this) plus a shifted position origin.
        relocalized = (
            Quaternion((0.0, 1.0, 0.0), math.radians(90.0)) @ Quaternion(tuple(qz))
        ).normalized()
        send_and_apply(tuple(relocalized), (500.0, -500.0, 500.0), dt_ns=10_000_000)
        if not quat_close(tuple(cam.rotation_quaternion), tuple(q_before), 1e-3):
            failures.append(
                "relocalization after a position-invalid run snapped the camera: "
                f"{tuple(cam.rotation_quaternion)} != {tuple(q_before)}"
            )
        if not vec_close(cam.location, loc_before, 1e-3):
            failures.append(
                f"relocalization recovery moved the camera: {tuple(cam.location)}"
            )
        # The re-expressed offset must still track normally afterwards.
        step = Quaternion((0.0, 0.0, 1.0), math.radians(5.0))
        after = (step @ Quaternion(tuple(relocalized))).normalized()
        send_and_apply(tuple(after), (500.0, -500.0, 500.0), dt_ns=100_000_000)
        if quat_close(tuple(cam.rotation_quaternion), tuple(q_before), 1e-3):
            failures.append("camera stopped tracking rotation after relocalization")

        # 17c. The rotational relocalization guard must stay active while
        #      position is WITHHELD. A visual tracker hands over a rotated
        #      world reference exactly during the recovery dwell after a loss,
        #      when a correct sender is reporting RECOVERING and sending no
        #      position. Gating the guard on `pos is not None` switched it off
        #      for that whole window, so the one discontinuity it exists to
        #      catch was the one it could never see: the camera snapped to a
        #      relocalized orientation. Device evidence: ARCore's orientation
        #      returned 0.93 s before position was restored.
        send_and_apply(tuple(qz), tuple(drift), dt_ns=100_000_000)  # settle 6DOF
        q_hold = cam.rotation_quaternion.copy()
        loc_hold = cam.location.copy()
        quality_lost = (C.TRACKING_LOST << C.FLAG_QUALITY_SHIFT) | (
            C.ISSUE_INSUFFICIENT_LIGHT << C.FLAG_ISSUE_SHIFT
        )
        quality_recovering = (C.TRACKING_RECOVERING << C.FLAG_QUALITY_SHIFT) | (
            C.ISSUE_NONE << C.FLAG_ISSUE_SHIFT
        )
        # Tracking lost: the phone holds its last orientation and sends no
        # position, exactly as SixDofFeed does. The camera must not move.
        for _ in range(6):
            ts += 100_000_000
            seq = phone.pose(ts, tuple(qz), flags=quality_lost)
            wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        if not quat_close(tuple(cam.rotation_quaternion), tuple(q_hold), 1e-4):
            failures.append("held rotation-only run rotated the camera")
        if not vec_close(cam.location, loc_hold, 1e-4):
            failures.append("held rotation-only run moved the camera")
        # Orientation returns from a RELOCALIZED reference while position is
        # still withheld: 90 deg in one 10 ms step (~9000 deg/s).
        relocalized_rot = (
            Quaternion((0.0, 1.0, 0.0), math.radians(90.0)) @ Quaternion(tuple(qz))
        ).normalized()
        ts += 10_000_000
        seq = phone.pose(ts, tuple(relocalized_rot), flags=quality_recovering)
        wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        if not quat_close(tuple(cam.rotation_quaternion), tuple(q_hold), 1e-3):
            failures.append(
                "relocalized orientation snapped the camera while position was "
                f"withheld: {tuple(cam.rotation_quaternion)} != {tuple(q_hold)}"
            )
        # ...and normal rotation tracking still works through the re-expressed
        # offset afterwards.
        resumed = (
            Quaternion((0.0, 0.0, 1.0), math.radians(6.0))
            @ Quaternion(tuple(relocalized_rot))
        ).normalized()
        ts += 100_000_000
        seq = phone.pose(ts, tuple(resumed), flags=quality_recovering)
        wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        if quat_close(tuple(cam.rotation_quaternion), tuple(q_hold), 1e-3):
            failures.append("camera stopped tracking rotation after relocalization")

        # 17d. The same guard must protect the OTHER switch direction:
        #      ARCore -> sensor, where the incoming poses are rotation-only with
        #      no quality field. Gating the guard on "is this a visual source"
        #      left this direction unprotected, which is why the device symptom
        #      was asymmetric: toggling 6DOF on held, toggling it off snapped.
        #      Measured source-frame disagreement was 90 deg in one session and
        #      176 deg in another, always about world up.
        quality_good = (C.TRACKING_GOOD << C.FLAG_QUALITY_SHIFT)
        base_rot = Quaternion(tuple(resumed))
        settle_p = (12.0, -3.0, 4.0)
        for _ in range(3):  # settle as a 6DOF sender: quality GOOD, position valid
            ts += 100_000_000
            seq = phone.pose(ts, tuple(base_rot), flags=quality_good, pos=settle_p)
            wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        rot_only_hold = cam.rotation_quaternion.copy()
        # 6DOF off: the next pose is rotation-only with no quality field, and it
        # carries the whole frame difference in one step. 90 deg in 10 ms is
        # ~9000 deg/s, far past anything a wrist can do.
        switched = (
            Quaternion((0.0, 0.0, 1.0), math.radians(90.0)) @ base_rot
        ).normalized()
        ts += 10_000_000
        seq = phone.pose(ts, tuple(switched))
        wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        if not quat_close(tuple(cam.rotation_quaternion), tuple(rot_only_hold), 1e-3):
            failures.append(
                "rotation-only source switch snapped the camera: "
                f"{tuple(cam.rotation_quaternion)} != {tuple(rot_only_hold)}"
            )
        # Ordinary rotation still tracks afterwards through the new offset.
        nudged = (
            Quaternion((0.0, 0.0, 1.0), math.radians(4.0)) @ switched
        ).normalized()
        ts += 100_000_000
        seq = phone.pose(ts, tuple(nudged))
        wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        if quat_close(tuple(cam.rotation_quaternion), tuple(rot_only_hold), 1e-3):
            failures.append("rotation-only tracking stopped after the switch")

        # 18. A phone display/source/world boundary keeps raw q+p together.
        #     FRAME_RESET rebases Blender against the first new-frame pose:
        #     no jump, correct subsequent translation axes, and Home unchanged.
        frame_hold_loc = cam.location.copy()
        frame_hold_q = cam.rotation_quaternion.copy()
        old_home_loc = state.home_loc.copy()
        old_home_q = state.home_quat.copy()
        phone.send_reliable(
            P.encode_frame_reset(phone.next_seq(), time.monotonic_ns(), "source"),
            pump=apply_mod.apply_tick,
        )
        q_frame = Euler(
            [math.radians(a) for a in (-35.0, 65.0, 140.0)], "XYZ"
        ).to_quaternion()
        p_frame = Vector((-80.0, 45.0, 12.0))
        send_and_apply(tuple(q_frame), tuple(p_frame), dt_ns=50_000_000)
        if not vec_close(cam.location, frame_hold_loc, 1e-3):
            failures.append(f"frame reset moved location: {tuple(cam.location)}")
        if not quat_close(tuple(cam.rotation_quaternion), tuple(frame_hold_q), 1e-3):
            failures.append("frame reset moved rotation")
        if not vec_close(state.home_loc, old_home_loc, 1e-6):
            failures.append("frame reset changed Home location")
        if not quat_close(tuple(state.home_quat), tuple(old_home_q), 1e-6):
            failures.append("frame reset changed Home rotation")
        frame_delta = Vector((0.08, -0.03, 0.02))
        send_and_apply(
            tuple(q_frame), tuple(p_frame + frame_delta), dt_ns=50_000_000
        )
        frame_want = frame_hold_loc + state.applied_move_scale * (
            state.q_offset @ frame_delta
        )
        if not vec_close(cam.location, frame_want, 5e-3):
            failures.append(
                f"post-frame-reset move wrong: {tuple(cam.location)} != {tuple(frame_want)}"
            )

        # 19. Apply a FOREIGN take (samples ~100 m from origin, in a tracking
        #     frame unrelated to the live offsets): it must RE-ANCHOR to the
        #     camera's current pose — frame 0 lands exactly where the camera is
        #     and the motion plays relative from there (spec 5.11 / §6). Pre-fix
        #     the stale live offset flung frame 0 ~100 m away ("flies to a
        #     random place"). Apply itself must freeze live driving; tests used
        #     to pre-pause here and therefore missed the real UI race.
        apply_mod._detach_camera_action(scene)
        cam.location = Vector((2.0, -1.0, 0.5))
        cam.rotation_quaternion = Quaternion((1.0, 0.0, 0.0, 0.0))
        anchor_loc = cam.location.copy()
        anchor_rot = cam.rotation_quaternion.copy()
        # Applying while paused must snapshot the CURRENT scene setting, not
        # the scale most recently adopted by the live driver. Those differ in
        # real use when the operator adjusts scale while reviewing a take.
        scene.pocketrig_move_scale = 3.0
        state.applied_move_scale = 0.5
        state.paused = False
        apply_mod._begin_take_apply(scene, "Foreign", "foreign.take")
        if not state.paused:
            failures.append("Apply did not pause live tracking immediately")
        if not vec_close(cam.location, anchor_loc, 1e-6):
            failures.append("Apply changed camera location before upload")
        if not quat_close(tuple(cam.rotation_quaternion), tuple(anchor_rot), 1e-6):
            failures.append("Apply changed camera rotation before upload")
        if abs((state.apply_move_scale or 0.0) - 3.0) > 1e-9:
            failures.append(
                f"Apply did not freeze current position scale: {state.apply_move_scale}"
            )
        conn = _socket.create_connection(("127.0.0.1", server.take_port), timeout=3.0)
        try:
            n = 21  # 200 ms @ 10 ms -> a few frames at 24 fps
            hdr = {
                "format": "pocketrig-take", "version": 0, "token": server.token,
                "name": "Foreign", "start_ns": 0, "end_ns": 200_000_000,
                "sample_count": n, "source": "offline",
            }
            payload = _json.dumps(hdr) + "\n"
            for i in range(n):
                px = 100.0 + 2.0 * (i / (n - 1))  # 100 -> 102 m from origin
                payload += _json.dumps(
                    {"t": i * 10_000_000, "q": list(Q_POSE), "p": [px, 0.0, 0.0]}
                ) + "\n"
            conn.sendall(payload.encode("utf-8"))
            conn.settimeout(3.0)
            if conn.recv(16).strip() != b"ok":
                failures.append("foreign apply upload not acked")
        finally:
            conn.close()
        wait_for(
            lambda: scene.camera.animation_data is not None
            and scene.camera.animation_data.action is not None
            and _first_key(scene.camera.animation_data.action, "location") is not None,
            pump=apply_mod.apply_tick,
        )
        applied = scene.camera.animation_data.action
        loc0 = _first_key(applied, "location")
        rot0 = _first_key(applied, "rotation_quaternion")
        if loc0 is None or not vec_close(loc0, anchor_loc, 1e-3):
            failures.append(
                f"apply flew the camera away: frame0 loc {loc0} != anchor {tuple(anchor_loc)}"
            )
        if rot0 is None or not quat_close(rot0, tuple(anchor_rot), 1e-3):
            failures.append(
                f"apply reoriented the camera: frame0 rot {rot0} != anchor {tuple(anchor_rot)}"
            )
        # ...and the take uses the frozen 3x scale, despite the deliberately
        # stale 0.5x live-driver scale above.
        loc_fc = _fcurves(applied, "location")
        if loc_fc and len(loc_fc[0].keyframe_points) > 1:
            last = [fc.keyframe_points[-1].co[1] for fc in loc_fc]
            keyed_seconds = (
                loc_fc[0].keyframe_points[-1].co[0]
                - loc_fc[0].keyframe_points[0].co[0]
            ) / (scene.render.fps / scene.render.fps_base)
            # The synthetic take moves +X at 10 m/s. Bake samples on scene
            # frame times, so a 200 ms take at 24 fps ends on 166.7 ms rather
            # than including the raw endpoint.
            keyed_delta = Vector((10.0 * keyed_seconds, 0.0, 0.0))
            take_offset = anchor_rot @ Quaternion(Q_POSE).inverted()
            expected_last = anchor_loc + 3.0 * (take_offset @ keyed_delta)
            if not vec_close(last, expected_last, 1e-3):
                failures.append(
                    f"applied take ignored current position scale: {last} != "
                    f"{tuple(expected_last)}"
                )
        # Go Live detaches the action without exposing stale object transforms.
        shown_loc = cam.location.copy()
        shown_rot = cam.rotation_quaternion.copy()
        apply_mod._go_live(scene)
        if cam.animation_data is not None and cam.animation_data.action is not None:
            failures.append("Go Live left the applied action attached")
        if not vec_close(cam.location, shown_loc, 1e-6):
            failures.append("Go Live jumped location while detaching applied take")
        if not quat_close(tuple(cam.rotation_quaternion), tuple(shown_rot), 1e-6):
            failures.append("Go Live jumped rotation while detaching applied take")
        scene.pocketrig_move_scale = 1.0
        state.applied_move_scale = 1.0

        # 20. Quality gap while recording: live display holds through the gap
        #     and re-anchors a shifted recovered origin, while the baked action
        #     still starts from the immutable record-start camera mapping.
        state.paused = True  # matches interactive post-apply/review state
        start20 = ts + 10_000_000
        start20_loc = cam.location.copy()
        start20_rot = cam.rotation_quaternion.copy()
        phone.send_reliable(
            P.encode_record_start(phone.next_seq(), time.monotonic_ns(), start20),
            pump=apply_mod.apply_tick,
        )
        wait_for(lambda: server.recording, pump=apply_mod.apply_tick)
        apply_mod.apply_tick()
        p20 = Vector((5.0, -3.0, 1.0))
        ts = start20
        send_and_apply(Q_POSE, tuple(p20), dt_ns=10_000_000)
        held20 = cam.location.copy()
        send_and_apply(Q_POSE, None, dt_ns=100_000_000)
        if not vec_close(cam.location, held20, 1e-6):
            failures.append("quality gap moved camera during recording")
        recovered20 = Vector((105.0, 20.0, -8.0))
        send_and_apply(Q_POSE, tuple(recovered20), dt_ns=400_000_000)
        if not vec_close(cam.location, held20, 1e-3):
            failures.append("quality recovery jumped camera during recording")
        delta20 = Vector((0.1, 0.0, 0.0))
        send_and_apply(Q_POSE, tuple(recovered20 + delta20), dt_ns=100_000_000)
        phone.send_reliable(
            P.encode_record_stop(phone.next_seq(), time.monotonic_ns(), ts, 4),
            pump=apply_mod.apply_tick,
        )
        phone.inbox.clear()
        baked20 = phone.wait_msg(C.MSG_RECORD_BAKED, pump=apply_mod.apply_tick)
        phone.ack(baked20.seq)
        action20 = cam.animation_data.action if cam.animation_data else None
        loc20 = _first_key(action20, "location") if action20 is not None else None
        rot20 = (
            _first_key(action20, "rotation_quaternion")
            if action20 is not None
            else None
        )
        if loc20 is None or not vec_close(loc20, start20_loc, 1e-3):
            failures.append(
                f"quality-gap bake lost record-start mapping: {loc20} != {tuple(start20_loc)}"
            )
        if rot20 is None or not quat_close(rot20, tuple(start20_rot), 1e-3):
            failures.append("quality-gap bake lost record-start rotation")

        print(f"checked 6dof drive/scale/loss/recenter/record/guards/params/pause/apply/shake/foreign-apply/quality-gap; baked {baked.body}")
    finally:
        phone.bye()
        phone.close()
        server.stop()
        state.server = None
        try:
            mod.unregister()
        except Exception:
            traceback.print_exc()

    if failures:
        for f in failures:
            print("FAIL:", f)
        print("HEADLESS_6DOF_FAIL")
        return 1
    print("HEADLESS_6DOF_PASS")
    return 0


if __name__ == "__main__":
    try:
        code = main()
    except Exception:
        traceback.print_exc()
        code = 2
    sys.exit(code)
