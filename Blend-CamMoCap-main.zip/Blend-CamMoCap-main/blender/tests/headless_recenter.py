# SPDX-License-Identifier: GPL-3.0-or-later
"""Re-center conformance inside `blender --background --python`.

Regression test for the snap-to-home Re-center behaviour: on connect the
camera's home framing is captured; after the phone "moves" the camera away,
a RECENTER message must snap the camera back to that home framing (not
re-zero in place). Drives the real UDP socket path end-to-end; apply_tick()
is pumped directly because timers do not fire in background mode.

Prints HEADLESS_RECENTER_PASS and exits 0 on success; non-zero on failure.
"""

import math
import sys
import time
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import bpy  # noqa: E402
from mathutils import Euler, Quaternion  # noqa: E402

from _headless_common import (  # noqa: E402
    FakePhone,
    load_addon,
    quat_close,
    wait_for,
)

# A distinctive, non-identity home framing so "snapped back" is unambiguous.
HOME_EULER_DEG = (65.0, 0.0, 40.0)
# Two different phone orientations: the neutral held at connect, then a moved one.
Q_POSE_CONNECT = (0.70710678, 0.70710678, 0.0, 0.0)          # upright, north
Q_POSE_MOVED = (0.5, 0.5, -0.5, -0.5)                        # panned/tilted away


def _quat_tuple(q):
    return (q.w, q.x, q.y, q.z)


def main() -> int:
    mod = load_addon()
    from pocketrig.bl import apply as apply_mod
    from pocketrig.bl import state
    from pocketrig.core import constants as C
    from pocketrig.core import protocol as P
    from pocketrig.core.session import Server

    scene = bpy.context.scene
    scene.render.fps = 24
    scene.render.fps_base = 1.0
    scene.pocketrig_live_smoothing = 0.0  # isolate re-center from the live filter

    # Give the scene a camera with a known HOME orientation before connecting.
    cam_data = bpy.data.cameras.new("PocketRig Cam")
    cam = bpy.data.objects.new("PocketRig Cam", cam_data)
    scene.collection.objects.link(cam)
    scene.camera = cam
    cam.rotation_mode = "QUATERNION"
    home_q = Euler([math.radians(a) for a in HOME_EULER_DEG], "XYZ").to_quaternion()
    cam.rotation_quaternion = home_q

    server = Server(
        port=0,
        get_scene_fps=lambda: state.scene_fps_cache,
        host_version=bpy.app.version_string,
    )
    server.start()
    state.server = server
    # NOTE: auto-recenter left ENABLED (unlike headless_live) — that is the
    # feature under test.

    phone = FakePhone(server.port)
    failures = []
    try:
        phone.handshake(server.token)

        # 1. First pose at connect -> auto-recenter captures home; camera holds it.
        seq = phone.pose(10_000_000, Q_POSE_CONNECT)
        wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        got = _quat_tuple(scene.camera.rotation_quaternion)
        if not quat_close(got, _quat_tuple(home_q), 1e-4):
            failures.append(f"connect: camera {got} != home {_quat_tuple(home_q)}")
        if state.home_quat is None or not quat_close(
            _quat_tuple(state.home_quat), _quat_tuple(home_q), 1e-4
        ):
            failures.append("connect: state.home_quat not captured at home")

        # 2. Phone "moves" -> camera must leave the home framing.
        seq = phone.pose(20_000_000, Q_POSE_MOVED)
        wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        moved = _quat_tuple(scene.camera.rotation_quaternion)
        if quat_close(moved, _quat_tuple(home_q), 1e-2):
            failures.append(f"moved: camera did not leave home ({moved})")

        # 3. RECENTER over the wire, then a fresh pose -> camera snaps back home.
        phone.send_reliable(
            P.encode_recenter(phone.next_seq(), time.monotonic_ns()),
            pump=apply_mod.apply_tick,
        )
        seq = phone.pose(30_000_000, Q_POSE_MOVED)
        wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        # pump a couple extra ticks so the recenter request is serviced
        for _ in range(5):
            apply_mod.apply_tick()
        snapped = _quat_tuple(scene.camera.rotation_quaternion)
        if not quat_close(snapped, _quat_tuple(home_q), 1e-4):
            failures.append(
                f"recenter: camera {snapped} did not snap back to home "
                f"{_quat_tuple(home_q)}"
            )
        print("checked connect-home / move-away / recenter-snap-back")
    finally:
        phone.bye()
        phone.close()
        server.stop()
        state.server = None
        try:
            mod.unregister()
        except Exception:
            traceback.print_exc()

    if failures:
        for f in failures:
            print("FAIL:", f)
        print("HEADLESS_RECENTER_FAIL")
        return 1
    print("HEADLESS_RECENTER_PASS")
    return 0


if __name__ == "__main__":
    try:
        code = main()
    except Exception:
        traceback.print_exc()
        code = 2
    sys.exit(code)
