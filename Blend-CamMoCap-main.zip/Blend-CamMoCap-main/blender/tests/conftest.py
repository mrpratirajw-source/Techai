# SPDX-License-Identifier: GPL-3.0-or-later
"""Make `import core.*` work under desktop pytest (no Blender)."""

import sys
from pathlib import Path

BLENDER_DIR = Path(__file__).resolve().parents[1]
FIXTURES_DIR = BLENDER_DIR.parent / "fixtures"

if str(BLENDER_DIR) not in sys.path:
    sys.path.insert(0, str(BLENDER_DIR))
