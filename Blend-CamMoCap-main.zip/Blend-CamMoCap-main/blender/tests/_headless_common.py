# SPDX-License-Identifier: GPL-3.0-or-later
"""Shared bootstrap for the `blender --background --python` conformance
scripts: loads blender/ as the package "pocketrig" from source, registers it,
and provides a protocol-correct in-process fake phone client built on the
SAME core.protocol module the add-on uses (single codec source of truth)."""

from __future__ import annotations

import importlib.util
import socket
import sys
import time
from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent
BLENDER_DIR = TESTS_DIR.parent
REPO_DIR = BLENDER_DIR.parent
FIXTURES_DIR = REPO_DIR / "fixtures"

DEADLINE = 5.0


def load_addon():
    """Import blender/ as package "pocketrig" and register() it."""
    if "pocketrig" in sys.modules:
        return sys.modules["pocketrig"]
    spec = importlib.util.spec_from_file_location(
        "pocketrig",
        str(BLENDER_DIR / "__init__.py"),
        submodule_search_locations=[str(BLENDER_DIR)],
    )
    mod = importlib.util.module_from_spec(spec)
    sys.modules["pocketrig"] = mod
    spec.loader.exec_module(mod)
    mod.register()
    return mod


def wait_for(predicate, timeout=DEADLINE, interval=0.002, pump=None):
    """Poll `predicate` until truthy; optionally call `pump` (e.g. apply_tick)
    each iteration. Raises on deadline — no bare sleeps anywhere."""
    end = time.monotonic() + timeout
    started = time.monotonic()
    while time.monotonic() < end:
        if pump is not None:
            pump()
        result = predicate()
        if result:
            return result
        time.sleep(interval)
    # Naming the condition, because a bare "deadline" message is why an
    # intermittent failure here is unactionable: it says nothing about WHICH
    # condition, how long it really waited, or whether it was close.
    try:
        import inspect

        what = inspect.getsource(predicate).strip()
    except (OSError, TypeError, ImportError):
        what = getattr(predicate, "__qualname__", repr(predicate))
    raise AssertionError(
        f"condition not met within {timeout}s "
        f"(waited {time.monotonic() - started:.2f}s): {what}"
    )


def quat_close(got, want, tol):
    """q and -q are the same rotation; compare up to global sign."""
    return all(abs(g - w) <= tol for g, w in zip(got, want)) or all(
        abs(g + w) <= tol for g, w in zip(got, want)
    )


def angle_diff_deg(a: float, b: float) -> float:
    return abs(((a - b) + 180.0) % 360.0 - 180.0)


class FakePhone:
    """Loopback client speaking real protocol v1 through the server socket."""

    def __init__(self, server_port: int):
        from pocketrig.core import protocol as P

        self.P = P
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("127.0.0.1", 0))
        self.sock.settimeout(0.05)
        self.server = ("127.0.0.1", server_port)
        self.seq = 0
        self.inbox = []

    def close(self):
        self.sock.close()

    def next_seq(self) -> int:
        self.seq += 1
        return self.seq

    def send_raw(self, data: bytes) -> None:
        self.sock.sendto(data, self.server)

    def pump(self) -> None:
        while True:
            try:
                data, _ = self.sock.recvfrom(65535)
            except (socket.timeout, OSError):
                return
            msg = self.P.decode(data)
            if msg is not None:
                self.inbox.append(msg)

    def wait_msg(self, msg_type: int, timeout=DEADLINE, pump=None):
        def find():
            self.pump()
            for m in self.inbox:
                if m.msg_type == msg_type:
                    return m
            return None

        return wait_for(find, timeout, pump=pump)

    def ack(self, acked_seq: int) -> None:
        self.send_raw(
            self.P.encode_ack(self.next_seq(), time.monotonic_ns(), acked_seq)
        )

    def send_reliable(self, data: bytes, timeout=DEADLINE, pump=None) -> None:
        """Send + resend every 200 ms until the server ACKs it."""
        msg_seq = self.P.decode(data).seq
        self.send_raw(data)
        next_resend = time.monotonic() + 0.2

        def acked():
            self.pump()
            return any(
                m.msg_type == 0x30 and m.acked_seq == msg_seq for m in self.inbox
            )

        end = time.monotonic() + timeout
        while time.monotonic() < end:
            if pump is not None:
                pump()
            if acked():
                return
            if time.monotonic() >= next_resend:
                self.send_raw(data)
                next_resend = time.monotonic() + 0.2
            time.sleep(0.002)
        raise AssertionError("reliable send never ACKed")

    def pose(self, ts_ns: int, quat, flags=0, pos=None, focal_mm=0.0) -> int:
        seq = self.next_seq()
        self.send_raw(
            self.P.encode_pose(
                seq, ts_ns, quat, flags=flags, focal_length_mm=focal_mm, pos=pos,
            ),
        )
        return seq

    def handshake(self, token: str, device_name="HeadlessPhone"):
        from pocketrig.core import constants as C

        self.send_reliable(
            self.P.encode_hello(
                self.next_seq(), time.monotonic_ns(), device_name, "0.1.0", token
            )
        )
        welcome = self.wait_msg(C.MSG_WELCOME)
        self.ack(welcome.seq)
        return welcome

    def upload_take(
        self, rows, token, source="offline", name=None, take_id=None, pump=None,
    ):
        """
        Offline-take TCP upload on the same port (spec 5.10).

        This is the phone's *default* path -- an offline take is written to the
        phone and uploaded losslessly -- so anything the live stream can carry
        has to be checked here too, not only through record_start/record_stop.

        `rows` are dicts already in wire form. Returns the server's reply.
        """
        import json

        start_ns = rows[0]["t"]
        end_ns = rows[-1]["t"]
        header = {
            "format": "pocketrig-take",
            "version": 0,
            "token": token,
            "start_ns": start_ns,
            "end_ns": end_ns,
            "sample_count": len(rows),
            "source": source,
        }
        if name is not None:
            header["name"] = name
        if take_id is not None:
            header["take_id"] = take_id
        buf = json.dumps(header) + "\n"
        for row in rows:
            buf += json.dumps(row) + "\n"

        # The server accepts the connection from its own thread, but the bake it
        # queues is drained by the apply timer, so keep pumping while we wait.
        conn = socket.create_connection(self.server, timeout=DEADLINE)
        try:
            conn.sendall(buf.encode("utf-8"))
            conn.settimeout(0.05)
            deadline = time.monotonic() + DEADLINE
            reply = b""
            while time.monotonic() < deadline:
                if pump is not None:
                    pump()
                try:
                    chunk = conn.recv(64)
                except socket.timeout:
                    continue
                if not chunk:
                    break
                reply += chunk
                if reply.endswith(b"\n"):
                    break
            return reply
        finally:
            conn.close()

    def bye(self) -> None:
        try:
            self.send_raw(self.P.encode_bye(self.next_seq(), time.monotonic_ns()))
        except OSError:
            pass
