# SPDX-License-Identifier: GPL-3.0-or-later
"""Server behavior driven by a real UDP client socket. No Blender, no sleeps
without deadlines: every wait polls a condition with a hard timeout.
"""

import socket
import inspect
import time

import pytest

from core import constants as C
from core import protocol as P
from core.session import Server

DEADLINE = 5.0


def wait_for(predicate, timeout=DEADLINE, interval=0.005):
    """Poll until truthy, or fail with enough context to act on.

    The message matters more than it looks. This raised a bare "condition not
    met within deadline" for every caller, so an intermittent failure in CI or
    in a full-suite run left nothing to work from: not which condition, not how
    long it actually waited, not whether it was close. Chasing one cost a day
    and ended in a guess. The source line of the predicate is almost always
    enough to name the race outright.
    """
    end = time.monotonic() + timeout
    started = time.monotonic()
    while time.monotonic() < end:
        result = predicate()
        if result:
            return result
        time.sleep(interval)
    raise AssertionError(
        f"condition not met within {timeout}s "
        f"(waited {time.monotonic() - started:.2f}s): {_describe(predicate)}"
    )


def _describe(predicate) -> str:
    """The predicate's source line, or its name if that is all there is."""
    try:
        return inspect.getsource(predicate).strip()
    except (OSError, TypeError):
        return getattr(predicate, "__qualname__", repr(predicate))


class FakePhone:
    """Minimal protocol-correct client for driving the server in tests."""

    def __init__(self, server_port: int):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("127.0.0.1", 0))
        self.sock.settimeout(0.05)
        self.server = ("127.0.0.1", server_port)
        self.seq = 0
        self.inbox = []  # decoded messages, in arrival order

    def close(self):
        self.sock.close()

    def next_seq(self) -> int:
        self.seq += 1
        return self.seq

    def send_raw(self, data: bytes) -> None:
        self.sock.sendto(data, self.server)

    def pump(self) -> None:
        """Drain any waiting datagrams into the inbox."""
        while True:
            try:
                data, _ = self.sock.recvfrom(65535)
            except (socket.timeout, OSError):
                return
            msg = P.decode(data)
            if msg is not None:
                self.inbox.append(msg)

    def wait_msg(self, msg_type: int, timeout=DEADLINE):
        def find():
            self.pump()
            for m in self.inbox:
                if m.msg_type == msg_type:
                    return m
            return None

        return wait_for(find, timeout)

    def count_msgs(self, msg_type: int) -> int:
        self.pump()
        return sum(1 for m in self.inbox if m.msg_type == msg_type)

    def hello(self, token: str, device_name="TestPhone") -> bytes:
        data = P.encode_hello(
            self.next_seq(), time.monotonic_ns(), device_name, "0.1.0", token
        )
        self.send_raw(data)
        return data

    def ack(self, acked_seq: int) -> None:
        self.send_raw(P.encode_ack(self.next_seq(), time.monotonic_ns(), acked_seq))

    def pose(self, ts_ns: int, quat, flags=0, seq=None, pos=None) -> None:
        if seq is None:
            seq = self.next_seq()
        self.send_raw(P.encode_pose(seq, ts_ns, quat, flags=flags, pos=pos))

    def upload_take(
        self, samples, start_ns, end_ns, token, source="sensor", take_id=None,
    ):
        """Offline-take TCP upload (spec 5.10): header line + JSONL rows."""
        import json as _json
        import socket as _socket

        conn = _socket.create_connection(self.server, timeout=3.0)
        try:
            header = {
                "format": "pocketrig-take",
                "version": 0,
                "token": token,
                "start_ns": start_ns,
                "end_ns": end_ns,
                "sample_count": len(samples),
                "source": source,
            }
            if take_id is not None:
                header["take_id"] = take_id
            buf = _json.dumps(header) + "\n"
            for sample in samples:
                t_ns, quat, pos = sample[:3]
                row = {"t": t_ns, "q": list(quat)}
                if pos is not None:
                    row["p"] = list(pos)
                if len(sample) > 3:
                    row.update(sample[3])
                buf += _json.dumps(row) + "\n"
            conn.sendall(buf.encode("utf-8"))
            conn.settimeout(3.0)
            return conn.recv(16)  # "ok\n" on success
        finally:
            conn.close()

    def handshake(self, token: str):
        """HELLO -> ACK+WELCOME -> ACK the WELCOME. Returns the WELCOME."""
        self.hello(token)
        welcome = self.wait_msg(C.MSG_WELCOME)
        self.ack(welcome.seq)
        return welcome


@pytest.fixture
def server():
    srv = Server(port=0, get_scene_fps=lambda: 24.0, host_version="test")
    srv.start()
    yield srv
    srv.stop()


@pytest.fixture
def phone(server):
    ph = FakePhone(server.port)
    yield ph
    ph.close()


def test_handshake(server, phone):
    hello_data = phone.hello(server.token)
    hello_seq = P.decode(hello_data).seq
    ack = phone.wait_msg(C.MSG_ACK)
    assert ack.acked_seq == hello_seq
    welcome = phone.wait_msg(C.MSG_WELCOME)
    assert welcome.body["protocol_version"] == 1
    assert welcome.body["scene_fps"] == 24.0
    assert welcome.body["host_app"] == "blender"
    assert welcome.body["host_version"] == "test"
    phone.ack(welcome.seq)
    wait_for(lambda: server.is_client_connected)
    assert server.client_name == "TestPhone"
    assert server.hello_count == 1
    assert server.pairing_count == 1


def test_wrong_token_gets_bad_token_error(server, phone):
    phone.hello("AAAAAA" if server.token != "AAAAAA" else "BBBBBB")
    err = phone.wait_msg(C.MSG_ERROR)
    assert err.body["code"] == "bad_token"
    phone.ack(err.seq)
    assert not server.is_client_connected


def test_invalid_format_token_bad_token(server, phone):
    phone.hello("nope")  # wrong length + lowercase
    err = phone.wait_msg(C.MSG_ERROR)
    assert err.body["code"] == "bad_token"
    phone.ack(err.seq)


def test_second_client_valid_format_token_gets_busy(server, phone):
    phone.handshake(server.token)
    wait_for(lambda: server.is_client_connected)
    other = FakePhone(server.port)
    try:
        bad = "AAAAAA" if server.token != "AAAAAA" else "BBBBBB"
        other.hello(bad)
        err = other.wait_msg(C.MSG_ERROR)
        assert err.body["code"] == "busy"
        other.ack(err.seq)
    finally:
        other.close()


def test_reconnect_same_token_new_addr_readopts_silently(server, phone):
    phone.handshake(server.token)
    wait_for(lambda: server.is_client_connected)
    roamed = FakePhone(server.port)  # new source port = new address
    try:
        roamed.handshake(server.token)
        wait_for(lambda: server.hello_count == 2)
        assert server.pairing_count == 1
        assert not any(m.msg_type == C.MSG_ERROR for m in roamed.inbox)
        # POSE from the new address is accepted (seq space reset on re-HELLO).
        roamed.pose(1000, (1.0, 0.0, 0.0, 0.0), seq=1)
        wait_for(lambda: server.latest_pose is not None)
    finally:
        roamed.close()


def test_bye_then_new_hello_is_a_fresh_pairing(server, phone):
    phone.handshake(server.token)
    assert server.pairing_count == 1
    phone.send_raw(P.encode_bye(phone.next_seq(), time.monotonic_ns()))
    wait_for(lambda: not server.is_client_connected)

    replacement = FakePhone(server.port)
    try:
        replacement.handshake(server.token)
        wait_for(lambda: server.pairing_count == 2)
        assert server.hello_count == 2
    finally:
        replacement.close()


def test_restart_same_udp_address_and_seq_gets_welcome(server, phone):
    """A restarted app may reuse the same source port and reset seq to 1.
    Its new HELLO timestamp makes it a fresh datagram, not an old retry."""
    phone.handshake(server.token)
    phone.send_raw(P.encode_bye(phone.next_seq(), time.monotonic_ns()))
    wait_for(lambda: not server.is_client_connected)
    phone.inbox.clear()
    phone.seq = 0  # simulate app restart on the same UDP socket/address
    phone.hello(server.token)
    welcome = phone.wait_msg(C.MSG_WELCOME)
    phone.ack(welcome.seq)
    wait_for(lambda: server.pairing_count == 2)
    assert server.is_client_connected


def test_wrong_protocol_version_unsupported(server, phone):
    data = P.encode_json(
        C.MSG_HELLO,
        phone.next_seq(),
        time.monotonic_ns(),
        {"device_name": "X", "app_version": "9", "protocol_version": 2,
         "token": server.token},
    )
    phone.send_raw(data)
    err = phone.wait_msg(C.MSG_ERROR)
    assert err.body["code"] == "version_unsupported"
    phone.ack(err.seq)


def test_pose_updates_latest_and_stale_seq_dropped(server, phone):
    phone.handshake(server.token)
    phone.pose(100, (1.0, 0.0, 0.0, 0.0), seq=5)
    wait_for(lambda: server.latest_pose is not None and server.latest_pose[0] == 5)
    seq, ts, quat, flags, pos, _focal = server.latest_pose
    assert (seq, ts, flags) == (5, 100, 0)
    assert quat == (1.0, 0.0, 0.0, 0.0)
    assert pos is None  # rotation-only sender
    # Stale/duplicate seq must be dropped (latest-wins).
    phone.pose(200, (0.0, 1.0, 0.0, 0.0), seq=4)
    phone.pose(300, (0.0, 0.0, 1.0, 0.0), seq=5)
    # Force a round-trip so the stale packets have surely been handled.
    phone.pose(400, (0.0, 0.0, 0.0, 1.0), seq=6)
    wait_for(lambda: server.latest_pose[0] == 6)
    assert server.pose_count == 2  # seq 5 and 6 only


def test_pose_ignored_before_handshake(server, phone):
    phone.pose(100, (1.0, 0.0, 0.0, 0.0), seq=1)
    time.sleep(0.1)  # give the server a chance to (wrongly) accept it
    assert server.latest_pose is None


def test_pose_with_extra_bytes_accepted(server, phone):
    phone.handshake(server.token)
    data = P.encode_pose(1, 777, (1.0, 0.0, 0.0, 0.0)) + b"\x00" * 12
    phone.send_raw(data)
    wait_for(lambda: server.latest_pose is not None)
    assert server.latest_pose[1] == 777


def test_pose_6dof_position_carried_through(server, phone):
    """A 6DOF POSE's position must reach latest_pose AND the record buffer,
    and rotation-only poses in the same take must carry None (spec 4.1)."""
    phone.handshake(server.token)
    ident = (1.0, 0.0, 0.0, 0.0)
    phone.pose(1_000, ident, pos=(0.5, -0.25, 1.5))
    wait_for(lambda: server.latest_pose is not None and server.latest_pose[1] == 1_000)
    assert server.latest_pose[4] == (0.5, -0.25, 1.5)
    assert server.latest_pose[3] & C.FLAG_HAS_POSITION

    start = P.encode_record_start(phone.next_seq(), time.monotonic_ns(), 500)
    phone.send_raw(start)
    wait_for(lambda: server.recording)
    phone.pose(2_000, ident, pos=(1.0, 0.0, 0.0))
    phone.pose(3_000, ident)  # tracking lost mid-take: rotation-only sample
    wait_for(lambda: server.latest_pose[1] == 3_000)
    assert server.latest_pose[4] is None
    stop = P.encode_record_stop(phone.next_seq(), time.monotonic_ns(), 4_000, 3)
    phone.send_raw(stop)
    req = wait_for(server.take_bake_request)
    assert [(s[0], s[2]) for s in req.samples] == [
        (1_000, (0.5, -0.25, 1.5)),
        (2_000, (1.0, 0.0, 0.0)),
        (3_000, None),
    ]


def test_params_both_directions(server, phone):
    """Spec 5.7: a phone PARAMS lands as a host request; send_params reaches
    the phone as a reliable PARAMS message."""
    phone.handshake(server.token)
    phone.send_raw(
        P.encode_params(phone.next_seq(), time.monotonic_ns(), 0.5, 0.2, 3.0)
    )
    req = wait_for(server.take_params_request)
    assert req == {"live_smoothing": 0.5, "record_smoothing": 0.2, "move_scale": 3.0}
    assert server.take_params_request() is None  # consumed once

    server.send_params(0.4, 0.1, 7.5)
    msg = phone.wait_msg(C.MSG_PARAMS)
    phone.ack(msg.seq)
    assert msg.body == {"live_smoothing": 0.4, "record_smoothing": 0.1, "move_scale": 7.5}
    assert "lens_mm" not in msg.body  # omitted unless the host reports one


def test_params_carries_host_lens(server, phone):
    """Spec 5.7 lens_mm: host -> phone only, so the phone's lens control can open
    ON the operator's lens instead of asserting one and reframing the shot."""
    phone.handshake(server.token)

    server.send_params(0.4, 0.1, 1.0, lens_mm=52.5)
    msg = phone.wait_msg(C.MSG_PARAMS)
    phone.ack(msg.seq)
    assert msg.body["lens_mm"] == 52.5

    # The reverse direction is not a thing: a phone-sent lens_mm is an unknown
    # key the host applies nothing from (it drives the lens on POSE, spec 4.5).
    phone.send_raw(
        P.encode_params(phone.next_seq(), time.monotonic_ns(), 0.5, 0.2, 3.0)
    )
    req = wait_for(server.take_params_request)
    assert "lens_mm" not in req


def test_params_ignored_from_stranger(server, phone):
    """PARAMS from an address that never completed HELLO must not apply."""
    phone.send_raw(
        P.encode_params(phone.next_seq(), time.monotonic_ns(), 0.9, 0.9, 9.0)
    )
    time.sleep(0.1)
    assert server.take_params_request() is None


def test_pause_both_directions(server, phone):
    """Spec 5.8: phone PAUSE lands as a host request; send_paused reaches the
    phone; junk 'paused' values are ignored."""
    phone.handshake(server.token)
    phone.send_raw(P.encode_pause(phone.next_seq(), time.monotonic_ns(), True))
    assert wait_for(server.take_pause_request) is True
    assert server.take_pause_request() is None  # consumed once

    server.send_paused(False)
    msg = phone.wait_msg(C.MSG_PAUSE)
    phone.ack(msg.seq)
    assert msg.body == {"paused": False}

    # Hostile: non-bool paused never surfaces as a request.
    data = P.encode_json(
        C.MSG_PAUSE, phone.next_seq(), time.monotonic_ns(), {"paused": "yes"}
    )
    phone.send_raw(data)
    time.sleep(0.1)
    assert server.take_pause_request() is None


def test_seek_request_and_recording_gate(server, phone):
    """Spec 5.9: SEEK surfaces as a request; ignored while recording."""
    phone.handshake(server.token)
    phone.send_raw(P.encode_seek(phone.next_seq(), time.monotonic_ns()))
    assert wait_for(server.take_seek_request) == {"to": "start"}
    assert server.take_seek_request() is None  # consumed once

    phone.send_raw(
        P.encode_record_start(phone.next_seq(), time.monotonic_ns(), 1_000)
    )
    wait_for(lambda: server.recording)
    phone.send_raw(P.encode_seek(phone.next_seq(), time.monotonic_ns(), frame=5))
    time.sleep(0.1)
    assert server.take_seek_request() is None  # MUST ignore while recording


def test_offline_take_upload_beats_live(server, phone):
    """Spec 5.10: a stop with offline=true holds the live samples as fallback
    and bakes the uploaded lossless take instead — the whole point of M2."""
    assert server.take_port is not None  # TCP listener bound
    phone.handshake(server.token)
    ident = (1.0, 0.0, 0.0, 0.0)
    phone.send_raw(
        P.encode_record_start(phone.next_seq(), time.monotonic_ns(), 1_000)
    )
    wait_for(lambda: server.recording)
    # A lossy live stream: only 2 poses survived the "network".
    phone.pose(1_000, ident)
    phone.pose(9_000, ident)
    wait_for(lambda: server.latest_pose is not None and server.latest_pose[1] == 9_000)
    phone.send_raw(
        P.encode_record_stop(
            phone.next_seq(), time.monotonic_ns(), 9_000, 2, offline=True
        )
    )
    wait_for(lambda: not server.recording)
    # The phone uploads the FULL-rate lossless take (10 samples) after the cut.
    dense = [(1_000 + i * 800, ident, None) for i in range(10)]
    resp = phone.upload_take(dense, 1_000, 9_000, token=server.token)
    assert resp.strip() == b"ok"
    req = wait_for(server.take_bake_request)
    assert len(req.samples) == 10  # baked the uploaded take, not the 2 live poses
    assert req.start_ns == 1_000 and req.end_ns == 9_000
    assert req.source == "offline"  # RECORD_BAKED will report it to the phone


def test_offline_take_quality_markers_invalidate_position_for_bake(server, phone):
    """Raw p remains transferable, but non-GOOD rows become explicit gaps in
    the conservative bake request."""
    phone.handshake(server.token)
    ident = (1.0, 0.0, 0.0, 0.0)
    samples = [
        (1_000, ident, (0.0, 0.0, 0.0), {"quality": "good"}),
        (
            2_000,
            ident,
            (99.0, 0.0, 0.0),
            {"quality": "degraded", "issue": "excessive_motion"},
        ),
        (3_000, ident, (100.0, 0.0, 0.0), {"quality": "recovering"}),
        (4_000, ident, (101.0, 0.0, 0.0), {"quality": "good"}),
    ]
    assert phone.upload_take(samples, 1_000, 4_000, server.token).strip() == b"ok"
    req = wait_for(server.take_bake_request)
    assert [sample[2] for sample in req.samples] == [
        (0.0, 0.0, 0.0), None, None, (101.0, 0.0, 0.0)
    ]


def test_take_library_list_and_pull(server, phone):
    """Spec 5.11: host requests the phone's take list, caches the response, and
    can ask to pull a specific take."""
    phone.handshake(server.token)
    rev0, takes0 = server.get_take_list()
    assert takes0 == []

    server.request_take_list()
    req = phone.wait_msg(C.MSG_TAKE_LIST)  # host -> phone request
    phone.ack(req.seq)
    assert req.body == {}

    takes = [{"id": "t1.take", "name": "Pan A", "duration_s": 3.0,
              "source": "arcore", "samples": 90, "position_samples": 84,
              "sent": False}]
    phone.send_raw(P.encode_take_list(phone.next_seq(), time.monotonic_ns(), takes))
    wait_for(lambda: server.get_take_list()[0] != rev0)
    _, got = server.get_take_list()
    assert got[0]["name"] == "Pan A"
    assert got[0]["position_samples"] == 84

    server.request_take_pull("t1.take")
    pull = phone.wait_msg(C.MSG_TAKE_PULL)
    phone.ack(pull.seq)
    assert pull.body == {"id": "t1.take"}


def test_upload_names_the_baked_take(server, phone):
    """A pulled/pushed upload carries the take's name (spec 5.11) into the
    bake request so the host can name the action after it."""
    phone.handshake(server.token)
    ident = (1.0, 0.0, 0.0, 0.0)
    take = [(1_000 + i * 500, ident, None) for i in range(4)]
    # Upload with a name in the header (the phone adds it for library takes).
    import json as _json
    import socket as _socket
    conn = _socket.create_connection(phone.server, timeout=3.0)
    try:
        header = {"format": "pocketrig-take", "version": 0, "token": server.token,
                  "name": "Rooftop", "id": "t.take", "start_ns": 1_000,
                  "end_ns": 2_500, "sample_count": len(take), "source": "sensor"}
        buf = _json.dumps(header) + "\n"
        for t_ns, q, _p in take:
            buf += _json.dumps({"t": t_ns, "q": list(q)}) + "\n"
        conn.sendall(buf.encode("utf-8"))
        assert conn.recv(16).strip() == b"ok"
    finally:
        conn.close()
    req = wait_for(server.take_bake_request)
    assert req.name == "Rooftop"
    assert req.review is True  # not recording -> applied to the camera


def test_standalone_upload_applies_to_camera(server, phone):
    """A take moved while NOT recording (Blender pull / phone push) applies to
    the camera: it bakes with review so "import a take" is visibly shown."""
    phone.handshake(server.token)
    assert not server.recording
    ident = (1.0, 0.0, 0.0, 0.0)
    dense = [(1_000 + i * 500, ident, None) for i in range(6)]
    resp = phone.upload_take(dense, 1_000, 3_500, token=server.token)
    assert resp.strip() == b"ok"
    req = wait_for(server.take_bake_request)
    assert len(req.samples) == 6
    assert req.source == "offline"
    assert req.review is True  # applied + shown on the camera


def test_multiple_standalone_uploads_all_bake(server, phone):
    """Auto-upload of several saved takes at once: each bakes (a queue, not a
    single slot that later uploads would clobber)."""
    phone.handshake(server.token)
    ident = (1.0, 0.0, 0.0, 0.0)
    for k in range(3):
        take = [(k * 100_000 + i * 500, ident, None) for i in range(4)]
        assert phone.upload_take(take, k * 100_000, k * 100_000 + 1_500,
                                 token=server.token).strip() == b"ok"
    baked = []
    for _ in range(3):
        baked.append(wait_for(server.take_bake_request))
    assert len(baked) == 3
    assert all(len(b.samples) == 4 and b.review is True for b in baked)
    assert server.take_bake_request() is None  # queue drained


def test_offline_take_upload_before_stop_races_ok(server, phone):
    """The upload may arrive BEFORE the RECORD_STOP; the two still marry."""
    phone.handshake(server.token)
    ident = (1.0, 0.0, 0.0, 0.0)
    phone.send_raw(
        P.encode_record_start(phone.next_seq(), time.monotonic_ns(), 1_000)
    )
    wait_for(lambda: server.recording)
    dense = [(1_000 + i * 500, ident, None) for i in range(6)]
    phone.upload_take(dense, 1_000, 4_000, token=server.token)
    # Nothing baked yet — no stop.
    assert server.take_bake_request() is None
    phone.send_raw(
        P.encode_record_stop(
            phone.next_seq(), time.monotonic_ns(), 4_000, 6, offline=True
        )
    )
    req = wait_for(server.take_bake_request)
    assert len(req.samples) == 6


def test_transaction_id_matches_upload_before_stop(server, phone):
    """An early TCP upload is held and married only to its named record
    transaction; the identity survives into RECORD_BAKED metadata."""
    phone.handshake(server.token)
    ident = (1.0, 0.0, 0.0, 0.0)
    take_id = "7f114f1d-82de-4c52-b6aa-a2dc2bbc48d1"
    phone.send_raw(
        P.encode_record_start(
            phone.next_seq(), time.monotonic_ns(), 1_000, take_id=take_id,
        )
    )
    wait_for(lambda: server.recording)
    dense = [(1_000 + i * 500, ident, None) for i in range(6)]
    assert phone.upload_take(
        dense, 1_000, 3_500, server.token, take_id=take_id,
    ).strip() == b"ok"
    assert server.take_bake_request() is None
    phone.send_raw(
        P.encode_record_stop(
            phone.next_seq(), time.monotonic_ns(), 3_500, 6,
            offline=True, take_id=take_id,
        )
    )
    req = wait_for(server.take_bake_request)
    assert req.take_id == take_id
    assert req.source == "offline"


def test_wrong_transaction_upload_cannot_attach_or_apply_mid_record(server, phone):
    """A delayed/foreign modern upload must neither finish the active take
    nor become a standalone camera apply while recording."""
    phone.handshake(server.token)
    ident = (1.0, 0.0, 0.0, 0.0)
    active = "11111111-1111-4111-8111-111111111111"
    phone.send_raw(
        P.encode_record_start(
            phone.next_seq(), time.monotonic_ns(), 1_000, take_id=active,
        )
    )
    wait_for(lambda: server.recording)
    wrong = [(1_000, ident, None), (2_000, ident, None)]
    response = phone.upload_take(
        wrong, 1_000, 2_000, server.token,
        take_id="22222222-2222-4222-8222-222222222222",
    )
    assert response == b""
    assert server.recording
    assert server.take_bake_request() is None

    phone.send_raw(
        P.encode_record_stop(
            phone.next_seq(), time.monotonic_ns(), 2_000, 0,
            offline=False, take_id=active,
        )
    )
    req = wait_for(server.take_bake_request)
    assert req.take_id == active


def test_offline_wrong_token_upload_is_dropped(server, phone):
    """A take with a bad token is refused; the live fallback bakes instead."""
    srv = Server(port=0, get_scene_fps=lambda: 24.0, host_version="t", take_timeout=0.4)
    srv.start()
    ph = FakePhone(srv.port)
    try:
        ph.handshake(srv.token)
        ident = (1.0, 0.0, 0.0, 0.0)
        ph.send_raw(P.encode_record_start(ph.next_seq(), time.monotonic_ns(), 1_000))
        wait_for(lambda: srv.recording)
        ph.pose(1_000, ident)
        ph.pose(2_000, ident)
        wait_for(lambda: srv.latest_pose is not None and srv.latest_pose[1] == 2_000)
        ph.send_raw(
            P.encode_record_stop(ph.next_seq(), time.monotonic_ns(), 2_000, 2, offline=True)
        )
        dense = [(1_000 + i * 300, ident, None) for i in range(8)]
        ph.upload_take(dense, 1_000, 2_000, token="WRONG9")  # refused
        req = wait_for(srv.take_bake_request, timeout=3.0)
        assert [s[0] for s in req.samples] == [1_000, 2_000]  # live fallback baked
    finally:
        ph.close()
        srv.stop()


def test_offline_fallback_when_no_upload():
    """Offline stop but the upload never arrives: the live fallback bakes at
    the timeout — a take is never lost."""
    srv = Server(port=0, get_scene_fps=lambda: 24.0, host_version="t", take_timeout=0.3)
    srv.start()
    ph = FakePhone(srv.port)
    try:
        ph.handshake(srv.token)
        ident = (1.0, 0.0, 0.0, 0.0)
        ph.send_raw(P.encode_record_start(ph.next_seq(), time.monotonic_ns(), 1_000))
        wait_for(lambda: srv.recording)
        ph.pose(1_000, ident)
        ph.pose(2_000, ident)
        wait_for(lambda: srv.latest_pose is not None and srv.latest_pose[1] == 2_000)
        ph.send_raw(
            P.encode_record_stop(ph.next_seq(), time.monotonic_ns(), 2_000, 2, offline=True)
        )
        req = wait_for(srv.take_bake_request, timeout=3.0)
        assert [s[0] for s in req.samples] == [1_000, 2_000]
        assert req.source == "live"  # the fallback reports itself honestly
    finally:
        ph.close()
        srv.stop()


def test_request_stop_from_host_asks_the_phone(server, phone):
    """Spec 5.4: the host asks the phone to end the take; the phone's reply
    drives the normal stop + (offline) upload."""
    phone.handshake(server.token)
    phone.send_raw(
        P.encode_record_start(phone.next_seq(), time.monotonic_ns(), 1_000)
    )
    wait_for(lambda: server.recording)
    server.request_stop_from_host()
    stop = phone.wait_msg(C.MSG_RECORD_STOP)  # host -> phone RECORD_STOP
    phone.ack(stop.seq)
    assert "end_timestamp_ns" in stop.body
    # The phone answers with its own stop -> the take bakes, recording ends.
    phone.pose(1_000, (1.0, 0.0, 0.0, 0.0))
    phone.pose(1_500, (1.0, 0.0, 0.0, 0.0))
    wait_for(lambda: server.latest_pose is not None and server.latest_pose[1] == 1_500)
    phone.send_raw(
        P.encode_record_stop(phone.next_seq(), time.monotonic_ns(), 1_500, 2)
    )
    req = wait_for(server.take_bake_request)
    assert not server.recording
    assert req.end_ns == 1_500


def test_welcome_advertises_take_port(server, phone):
    welcome = phone.handshake(server.token)
    assert welcome.body.get("take_port") == server.port


def test_host_can_end_the_take(server, phone):
    """spec 5.5: the host may end a take itself (scene end frame = cut)."""
    phone.handshake(server.token)
    ident = (1.0, 0.0, 0.0, 0.0)
    phone.send_raw(
        P.encode_record_start(phone.next_seq(), time.monotonic_ns(), 1_000)
    )
    wait_for(lambda: server.recording)
    phone.pose(1_000, ident)
    phone.pose(2_000, ident)
    wait_for(lambda: server.latest_pose is not None and server.latest_pose[1] == 2_000)
    server.stop_recording_from_host()
    assert not server.recording
    req = wait_for(server.take_bake_request)
    assert [s[0] for s in req.samples] == [1_000, 2_000]
    assert req.start_ns == 1_000 and req.end_ns == 2_000
    assert req.sample_count == 2  # host never saw the phone's count: received
    # Idempotent: a second host stop with no recording does nothing.
    server.stop_recording_from_host()
    assert server.take_bake_request() is None


def test_ping_pong_echo(server, phone):
    phone.handshake(server.token)
    t1 = 123456789
    phone.send_raw(P.encode_ping(phone.next_seq(), t1))
    pong = phone.wait_msg(C.MSG_PONG)
    assert pong.body["t1"] == t1
    assert pong.body["t2"] > 0


def test_record_flow_with_rolling_buffer_splice(server, phone):
    phone.handshake(server.token)
    ident = (1.0, 0.0, 0.0, 0.0)
    # Samples sent BEFORE record_start whose timestamps are inside the window:
    phone.pose(1_000, ident)
    phone.pose(2_000, ident)
    phone.pose(3_000, ident)
    wait_for(lambda: server.latest_pose is not None and server.latest_pose[1] == 3_000)
    # Window starts at 1_500: sample at 1_000 is out, 2_000/3_000 are in.
    start_data = P.encode_record_start(phone.next_seq(), time.monotonic_ns(), 1_500)
    phone.send_raw(start_data)
    start_seq = P.decode(start_data).seq
    wait_for(lambda: phone.count_msgs(C.MSG_ACK) >= 2)  # HELLO ack + this one
    wait_for(lambda: server.recording)
    phone.pose(4_000, ident)
    phone.pose(5_000, ident)
    phone.pose(9_999, ident)  # will fall outside [start, end] at stop time
    wait_for(lambda: server.latest_pose[1] == 9_999)
    stop_data = P.encode_record_stop(phone.next_seq(), time.monotonic_ns(), 6_000, 4)
    phone.send_raw(stop_data)
    req = wait_for(server.take_bake_request)
    assert not server.recording
    assert req.start_ns == 1_500 and req.end_ns == 6_000
    assert req.sample_count == 4
    assert [s[0] for s in req.samples] == [2_000, 3_000, 4_000, 5_000]
    # Both reliable messages were ACKed.
    phone.pump()
    acked = {m.acked_seq for m in phone.inbox if m.msg_type == C.MSG_ACK}
    assert start_seq in acked


def test_recenter_sets_flag_once_but_acked_twice(server, phone):
    phone.handshake(server.token)
    data = P.encode_recenter(phone.next_seq(), time.monotonic_ns())
    msg_seq = P.decode(data).seq
    phone.send_raw(data)

    def got_first_ack():
        phone.pump()
        return any(
            m.msg_type == C.MSG_ACK and m.acked_seq == msg_seq for m in phone.inbox
        )

    wait_for(got_first_ack)
    assert server.take_recenter_request() is True
    # Duplicate datagram: ACKed again, but NOT processed again.
    phone.send_raw(data)

    def got_two_acks():
        phone.pump()
        return (
            sum(
                1
                for m in phone.inbox
                if m.msg_type == C.MSG_ACK and m.acked_seq == msg_seq
            )
            >= 2
        )

    wait_for(got_two_acks)
    assert server.take_recenter_request() is False


def test_recenter_ignored_while_recording(server, phone):
    phone.handshake(server.token)
    phone.pose(1_000, (1.0, 0.0, 0.0, 0.0))
    wait_for(lambda: server.latest_pose is not None)
    phone.send_raw(P.encode_record_start(phone.next_seq(), time.monotonic_ns(), 0))
    wait_for(lambda: server.recording)
    data = P.encode_recenter(phone.next_seq(), time.monotonic_ns())
    msg_seq = P.decode(data).seq
    phone.send_raw(data)

    def acked():
        phone.pump()
        return any(
            m.msg_type == C.MSG_ACK and m.acked_seq == msg_seq for m in phone.inbox
        )

    wait_for(acked)
    assert server.take_recenter_request() is False


def test_frame_reset_sets_internal_rebase_once(server, phone):
    phone.handshake(server.token)
    data = P.encode_frame_reset(phone.next_seq(), time.monotonic_ns(), "source")
    phone.send_raw(data)
    assert wait_for(server.take_frame_reset_request) is True
    assert server.take_frame_reset_request() is False

    # A duplicate reliable datagram is ACKed but cannot trigger another rebase.
    phone.send_raw(data)
    time.sleep(0.1)
    assert server.take_frame_reset_request() is False


def test_frame_reset_ignored_while_recording(server, phone):
    phone.handshake(server.token)
    phone.pose(1_000, (1.0, 0.0, 0.0, 0.0), pos=(0.0, 0.0, 0.0))
    wait_for(lambda: server.latest_pose is not None)
    phone.send_raw(P.encode_record_start(phone.next_seq(), time.monotonic_ns(), 0))
    wait_for(lambda: server.recording)
    phone.send_raw(P.encode_frame_reset(phone.next_seq(), time.monotonic_ns(), "display"))
    time.sleep(0.1)
    assert server.take_frame_reset_request() is False


def test_notify_baked_reaches_client(server, phone):
    phone.handshake(server.token)
    wait_for(lambda: server.is_client_connected)
    server.notify_baked(25, 24.0, received=11, sent=11, source="offline")
    baked = phone.wait_msg(C.MSG_RECORD_BAKED)
    assert baked.body == {
        "frames": 25, "fps": 24.0, "received": 11, "sent": 11, "source": "offline",
    }
    phone.ack(baked.seq)


def test_bye_clears_client(server, phone):
    phone.handshake(server.token)
    wait_for(lambda: server.is_client_connected)
    data = P.encode_bye(phone.next_seq(), time.monotonic_ns())
    bye_seq = P.decode(data).seq
    phone.send_raw(data)

    def acked():
        phone.pump()
        return any(
            m.msg_type == C.MSG_ACK and m.acked_seq == bye_seq for m in phone.inbox
        )

    wait_for(acked)
    wait_for(lambda: not server.is_client_connected)
    assert server.client_name is None


def test_malformed_packets_never_kill_the_thread(server, phone):
    for junk in (b"", b"x", b"PR\x01", b"\x00" * 64, b"PR\x01\x01" + b"\xff" * 5):
        phone.send_raw(junk)
    phone.handshake(server.token)  # server still alive and functional
    assert server.malformed_count >= 1


def test_welcome_resent_until_acked(server, phone):
    phone.hello(server.token)
    first = phone.wait_msg(C.MSG_WELCOME)
    # Do not ACK; the reliable layer must resend the identical datagram.
    wait_for(lambda: phone.count_msgs(C.MSG_WELCOME) >= 2, timeout=2.0)
    phone.pump()
    welcomes = [m for m in phone.inbox if m.msg_type == C.MSG_WELCOME]
    assert all(m.seq == first.seq for m in welcomes)
    phone.ack(first.seq)


def test_port_range_binding():
    a = Server(get_scene_fps=lambda: 24.0)
    try:
        a.start()
    except OSError:
        pytest.skip("default port range unavailable on this machine")
    try:
        assert C.DEFAULT_PORT <= a.port <= C.PORT_RANGE_END
        b = Server(get_scene_fps=lambda: 24.0)
        b.start()
        try:
            assert C.DEFAULT_PORT <= b.port <= C.PORT_RANGE_END
            assert b.port != a.port
        finally:
            b.stop()
    finally:
        a.stop()


def test_token_format(server):
    assert len(server.token) == C.TOKEN_LENGTH
    assert all(c in C.TOKEN_ALPHABET for c in server.token)


def test_refused_record_start_is_answered_not_dropped(server, phone):
    """The reliability layer ACKs every reliable datagram before dispatch, so a
    silently dropped RECORD_START is indistinguishable from an accepted one and
    the phone waits out its finalization timeout believing it is recording."""
    phone.handshake(server.token)
    wait_for(lambda: server.is_client_connected)
    phone.send_raw(
        P.encode_record_start(
            phone.next_seq(), time.monotonic_ns(), 1_000, take_id="take-a"
        )
    )
    wait_for(lambda: server.recording)

    phone.send_raw(
        P.encode_record_start(
            phone.next_seq(), time.monotonic_ns(), 2_000, take_id="take-b"
        )
    )
    err = phone.wait_msg(C.MSG_ERROR)
    assert err.body["code"] == "record_rejected"
    phone.ack(err.seq)
    # The original take is untouched by the refusal.
    assert server.recording


def test_fresh_pairing_ends_an_orphaned_take(server, phone):
    """A phone that vanishes mid-recording must not leave the host recording
    forever, or the next phone's first Record is refused. Only a FRESH pairing
    does this; test_reconnect_preserves_an_in_flight_take pins the other side."""
    phone.handshake(server.token)
    wait_for(lambda: server.is_client_connected)
    phone.send_raw(
        P.encode_record_start(
            phone.next_seq(), time.monotonic_ns(), 1_000, take_id="orphan"
        )
    )
    wait_for(lambda: server.recording)
    for i in range(4):
        phone.pose(1_000 + i * 10_000_000, (1.0, 0.0, 0.0, 0.0))
    wait_for(lambda: server.pose_count >= 4)

    # A different address after the liveness window is a fresh pairing.
    server._last_rx = time.monotonic() - C.CLIENT_GONE_TIMEOUT - 1.0
    newcomer = FakePhone(server.port)
    try:
        newcomer.handshake(server.token)
        wait_for(lambda: not server.recording)
        assert server.pairing_count == 2
        # The orphaned samples were baked, not discarded.
        req = wait_for(server.take_bake_request)
        assert req.take_id == "orphan"
        assert req.samples

        # And the new phone can start its own take immediately.
        newcomer.send_raw(
            P.encode_record_start(
                newcomer.next_seq(), time.monotonic_ns(), 5_000, take_id="fresh"
            )
        )
        wait_for(lambda: server.recording)
    finally:
        newcomer.close()


def test_reconnect_preserves_an_in_flight_take(server, phone):
    """Spec 8: a reconnect resumes the session and MUST NOT act like a fresh
    pairing. The orphaned-take cleanup must not fire here — a Wi-Fi blip during
    a take may not end the take."""
    phone.handshake(server.token)
    wait_for(lambda: server.is_client_connected)
    phone.send_raw(
        P.encode_record_start(
            phone.next_seq(), time.monotonic_ns(), 1_000, take_id="keep-me"
        )
    )
    wait_for(lambda: server.recording)

    # Same token from a new address, inside the liveness window: a reconnect.
    roamed = FakePhone(server.port)
    try:
        roamed.handshake(server.token)
        wait_for(lambda: server.hello_count == 2)
        assert server.pairing_count == 1  # not a fresh pairing
        assert server.recording  # the take survives the roam
        assert server.take_bake_request() is None  # and was not force-baked
    finally:
        roamed.close()


def test_a_bounced_datagram_does_not_deafen_the_host(server, phone):
    """A phone that goes away must not kill the receive loop.

    On Windows, sending to a host that is no longer listening makes the OS raise
    ConnectionResetError from the NEXT recvfrom on that socket -- not from the
    send. It is an OSError, and the loop used to treat any OSError as "the
    socket was closed by stop()" and exit. Blender then stayed connected in the
    UI and never heard another pose until the server was restarted.

    POSIX does not report ICMP errors on an unconnected UDP socket at all, so
    this test passes there for free. It still belongs in the shared suite: it
    pins the contract that only stop() ends the loop, on every platform.
    """
    phone.handshake(server.token)
    ident = (1.0, 0.0, 0.0, 0.0)
    phone.pose(1_000, ident)
    wait_for(lambda: server.latest_pose is not None)

    # Make the host talk to somewhere nothing is listening. On Windows the ICMP
    # unreachable comes back and poisons the next read.
    import socket as _socket

    dead = _socket.socket(_socket.AF_INET, _socket.SOCK_DGRAM)
    dead.bind(("127.0.0.1", 0))
    dead_addr = dead.getsockname()
    dead.close()
    for _ in range(3):
        server._send(b"\x00" * 8, dead_addr)
        time.sleep(0.05)

    # The loop must still be alive and still listening.
    phone.pose(2_000, ident)
    wait_for(lambda: server.latest_pose is not None and server.latest_pose[1] == 2_000)


def test_an_aborted_upload_does_not_kill_the_take_listener(server):
    """The take listener must outlive one bad connection.

    A phone that resets between the TCP handshake and our accept() raises
    ConnectionAbortedError there -- an OSError -- and the loop used to treat any
    OSError as "the listener is closed" and exit. The port stays open, so nothing
    looks wrong, and every offline take from then on silently fails to upload.
    That loses the lossless recording, not a preview.

    Same shape as the bug that killed the viewport accept loop and the UDP recv
    loop. Driven through a fake listener rather than a real reset, because on
    loopback the accept wins the race and a real one does not reproduce.
    """
    import socket as _socket
    import threading as _threading

    class FakeListener:
        def __init__(self) -> None:
            self.calls = 0

        def accept(self):
            self.calls += 1
            if self.calls == 1:
                raise ConnectionAbortedError(10053, "software caused connection abort")
            raise _socket.timeout()

    listener = FakeListener()
    server._tcp = listener
    thread = _threading.Thread(target=server._take_loop, daemon=True)
    thread.start()
    try:
        deadline = time.monotonic() + 2.0
        while listener.calls < 5 and time.monotonic() < deadline:
            time.sleep(0.01)
        assert listener.calls >= 5, (
            f"take listener stopped after {listener.calls} calls; "
            "an aborted upload must not end it"
        )
        assert server.take_accepts_failed == 1
    finally:
        server._running.clear()
        thread.join(timeout=1.0)
