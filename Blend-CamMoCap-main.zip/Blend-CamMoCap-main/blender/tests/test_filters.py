# SPDX-License-Identifier: GPL-3.0-or-later
"""Unit tests for the live One-Euro quaternion filter (core/filters.py).
Pure desktop Python — no bpy."""

import math

from core import filters
from core.filters import OneEuroQuat


def _angle_between(a, b):
    d = min(1.0, abs(sum(x * y for x, y in zip(a, b))))
    return 2.0 * math.acos(d)


def _rot_z(deg):
    h = math.radians(deg) / 2.0
    return (math.cos(h), 0.0, 0.0, math.sin(h))


# ---- slerp --------------------------------------------------------------

def test_slerp_endpoints():
    a, b = _rot_z(0), _rot_z(90)
    assert filters.slerp(a, b, 0.0) == a
    assert all(abs(x - y) < 1e-9 for x, y in zip(filters.slerp(a, b, 1.0), b))


def test_slerp_midpoint_is_half_angle():
    a, b = _rot_z(0), _rot_z(90)
    mid = filters.slerp(a, b, 0.5)
    assert math.degrees(_angle_between(a, mid)) == \
        __import__("pytest").approx(45.0, abs=1e-4)


def test_slerp_takes_shortest_path_across_sign_flip():
    a = _rot_z(0)
    b = tuple(-x for x in _rot_z(20))  # same rotation as +20deg, opposite sign
    mid = filters.slerp(a, b, 0.5)
    # shortest arc is 10deg, not 170deg
    assert math.degrees(_angle_between(a, mid)) < 15.0


# ---- filter behaviour ---------------------------------------------------

def _same(a, b, tol=1e-9):
    return all(abs(x - y) < tol for x, y in zip(a, b))


def test_first_sample_passes_through():
    f = OneEuroQuat(*_mc())
    q = _rot_z(37)
    assert _same(f.update(q, 0), q)  # unit-normalized passthrough (to 1 ULP)


def test_reset_makes_next_sample_passthrough():
    f = OneEuroQuat(*_mc())
    f.update(_rot_z(0), 0)
    f.update(_rot_z(30), 10_000_000)
    f.reset()
    q = _rot_z(80)
    assert _same(f.update(q, 20_000_000), q)  # verbatim (to 1 ULP) right after reset


def test_reduces_jitter_on_a_still_pose():
    """A stationary orientation + noise should come out calmer than it went in."""
    mc, beta = filters.live_filter_params(0.5)
    f = OneEuroQuat(mc, beta)
    base = 30.0
    rng = _lcg(1234)
    t = 0
    in_dev, out_dev = [], []
    f.update(_rot_z(base), t)
    for _ in range(300):
        t += 10_000_000  # 100 Hz
        noise = (next(rng) - 0.5) * 6.0  # +/-3 deg jitter
        raw = _rot_z(base + noise)
        out = f.update(raw, t)
        in_dev.append(abs(noise))
        out_dev.append(math.degrees(_angle_between(_rot_z(base), out)))
    # settle: ignore the first handful of samples
    assert _mean(out_dev[20:]) < 0.5 * _mean(in_dev[20:])


def test_tracks_fast_motion_without_large_lag():
    """Adaptive cutoff: a steady fast pan should not lag far behind."""
    mc, beta = filters.live_filter_params(0.5)
    f = OneEuroQuat(mc, beta)
    t = 0
    f.update(_rot_z(0), t)
    last_out = None
    deg = 0.0
    for _ in range(120):  # ~1.2 s of 90 deg/s pan at 100 Hz
        t += 10_000_000
        deg += 0.9
        last_out = f.update(_rot_z(deg), t)
    lag_deg = math.degrees(_angle_between(_rot_z(deg), last_out))
    assert lag_deg < 12.0  # keeps up; not a molasses low-pass


def test_params_more_smoothing_lowers_cutoff():
    c_lo, _ = filters.live_filter_params(0.1)
    c_hi, _ = filters.live_filter_params(0.9)
    assert c_hi < c_lo  # higher slider = heavier smoothing = lower cutoff
    assert filters.live_filter_params(0.0)[0] > filters.live_filter_params(1.0)[0]


# ---- tiny helpers (no numpy/pytest-deps beyond approx) ------------------

def _mc():
    return filters.live_filter_params(0.3)


def _mean(xs):
    return sum(xs) / len(xs)


def _lcg(seed):
    x = seed
    while True:
        x = (1103515245 * x + 12345) & 0x7FFFFFFF
        yield x / 0x7FFFFFFF


# ---- position filter (OneEuroVec3) --------------------------------------


def test_vec_first_sample_passes_through():
    f = filters.OneEuroVec3(*filters.live_pos_filter_params(0.3))
    assert f.update((1.0, -2.0, 3.0), 0) == (1.0, -2.0, 3.0)


def test_vec_reset_makes_next_sample_passthrough():
    f = filters.OneEuroVec3(*filters.live_pos_filter_params(0.3))
    f.update((0.0, 0.0, 0.0), 0)
    f.update((1.0, 0.0, 0.0), 10_000_000)
    f.reset()
    assert f.update((5.0, 5.0, 5.0), 20_000_000) == (5.0, 5.0, 5.0)


def test_vec_reduces_jitter_on_still_position():
    mc, beta = filters.live_pos_filter_params(0.5)
    f = filters.OneEuroVec3(mc, beta)
    rng = _lcg(99)
    t = 0
    in_dev, out_dev = [], []
    f.update((1.0, 0.0, 0.0), t)
    for _ in range(300):
        t += 33_000_000  # ~30 Hz, ARCore cadence
        noise = (next(rng) - 0.5) * 0.01  # +/-5 mm jitter
        out = f.update((1.0 + noise, 0.0, 0.0), t)
        in_dev.append(abs(noise))
        out_dev.append(abs(out[0] - 1.0))
    assert _mean(out_dev[20:]) < 0.5 * _mean(in_dev[20:])


def test_vec_tracks_fast_motion_without_large_lag():
    mc, beta = filters.live_pos_filter_params(0.5)
    f = filters.OneEuroVec3(mc, beta)
    t = 0
    x = 0.0
    f.update((0.0, 0.0, 0.0), t)
    out = (0.0, 0.0, 0.0)
    for _ in range(60):  # 2 s of 1 m/s travel at 30 Hz
        t += 33_000_000
        x += 0.033
        out = f.update((x, 0.0, 0.0), t)
    assert abs(out[0] - x) < 0.06  # lags under 60 ms of travel at 1 m/s
