# SPDX-License-Identifier: GPL-3.0-or-later
"""bpy-touching layer: runtime state, tick applier, bake, UI. Only ever
imported inside Blender (lazily, from the package root register())."""

from . import panel, qr_ui, state


def register() -> None:
    panel.register()


def unregister() -> None:
    if state.server is not None:
        try:
            state.server.stop()
        finally:
            state.server = None
    qr_ui.cleanup()
    panel.unregister()
    state.reset()
