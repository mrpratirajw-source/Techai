# SPDX-License-Identifier: GPL-3.0-or-later
"""Viewport capture: pixels out of Blender and onto the stream.

The bl half of the viewport channel. `core/viewport_stream.py` owns the socket
and is desktop-testable; this needs a GPU context and Blender's main thread, so
it lives here and **cannot be covered by the headless suites** — `gpu` drawing
raises under `--background`. `tools/viewport_lab/` is the only thing that
exercises it for real.

There was a second path here, reading the framebuffer Blender had already drawn.
It was three times cheaper and it was deleted, because cost was never the
deciding axis: it streamed whatever the operator happened to be looking at, so
they could not open another editor or switch windows without wrecking the phone's
picture, and it showed nothing useful whenever the camera was not the active
view. It also inherited the region framebuffer's premultiplied alpha, which
turned every object black. A viewfinder that depends on the operator not using
Blender is not a viewfinder.

**Draw the camera offscreen, from the tick.** 2.5-5 ms of the main thread with
the viewport idle, 32-40 ms with the phone live and the camera moving. Verified
to keep producing frames with the Blender window minimised, which is the whole
point -- and incidentally the cheapest case, since nothing else is drawing.

**The rate is not ours to set.** A `bpy.app.timers` callback fires once per
event-loop iteration, and that loop is locked to the viewport's redraw rate
whenever the viewport redraws: measured at 30 Hz against the 120 Hz
`apply.TICK_INTERVAL` asks for, and 175 Hz with nothing redrawing. So the
requested frame rate is a ceiling under a ceiling, and `core.CapturePacer`
exists to pace against the real one instead of pretending. It is in core/
because `gpu` drawing raises under `--background`, so anything left in this file
cannot be tested -- and the two bugs that halved the stream both lived here.

**Never convert the buffer naively.** `gpu.types.Buffer` is not C-contiguous:
`bytes(buf)` costs 17.2 ms at 720p and `np.asarray(buf).tobytes()` 9.6 ms,
against 0.1 ms for a contiguous array of the same size. `np.asarray` is also
plainly **wrong** here, not merely slow — see `capture_camera_rgb`.

**Capture on the main thread, encode and send off it.** The GPU context is only
valid here, but a blocked `sendall` costs whatever the link is doing and has no
business inside Blender's tick.
"""

from __future__ import annotations

import threading
import time
from typing import Any, Dict, Optional, Tuple

import bpy
import gpu

from ..core import viewport_stream

#: Requested rate when the phone does not say. 30 rather than the 20 it used to
#: be, because 20 turned out not to be the cheaper option it looked like.
#:
#: Measured across every advertised size, asking for 20 costs the same share of
#: Blender's main thread as asking for 30 and returns a third fewer frames --
#: 49.7% against 50.4% at 1158x798. Captures spaced further apart each cost
#: more, so the saving the lower rate promises is mostly given back. What does
#: save the PC is a smaller frame: 31.8% at 640x440 against 50.4%, at the same
#: 30 fps.
DEFAULT_FPS = 30.0


def camera_key(scene) -> Optional[Tuple]:
    """What the tick writes to the camera, before anything has evaluated it.

    Deliberately the **raw** datablock, which is the exact opposite of what the
    draw needs. `capture_camera_rgb` must read `evaluated_get` or it renders a
    stale pose; this must read the raw values, because they change the instant a
    pose is applied and waiting for an evaluation to notice motion is precisely
    what coupled the stream to the operator's redraw and halved its rate.

    Lens rides along because it changes the framing without moving anything, and
    is the one non-transform change an operator makes while watching the phone.
    Parented, driven and constrained cameras are not in any of these numbers --
    that is what the depsgraph counter is still for.
    """
    camera = scene.camera if scene is not None else None
    if camera is None:
        return None
    data = getattr(camera, "data", None)
    return (
        tuple(camera.location),
        tuple(camera.rotation_quaternion),
        tuple(camera.rotation_euler),
        getattr(data, "lens", 0.0),
    )


def encoder_available() -> Tuple[bool, str]:
    """Is there a JPEG encoder? Returns (available, human-readable reason).

    Lazy, like `qr_ui`'s segno import, and for the same reason: a bundled native
    wheel is absent on any platform upstream does not build for. There is no
    cp313 macOS x86_64 simplejpeg, so Blender 5.1 on an Intel Mac lands here.
    The stream reports itself unavailable instead of failing at register time.
    """
    try:
        import simplejpeg  # noqa: F401
    except ImportError as exc:
        return False, f"no JPEG encoder for this build ({exc})"
    return True, "simplejpeg"


def find_view3d() -> Optional[Tuple[Any, Any, Any]]:
    """The first 3D viewport as (area, region, space), or None."""
    wm = bpy.context.window_manager
    if wm is None:
        return None
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type != "VIEW_3D":
                continue
            for region in area.regions:
                if region.type == "WINDOW":
                    return area, region, area.spaces.active
    return None


def capture_camera_rgb(offscreen, scene, space, region, width, height,
                       overlays: bool = False):
    """Draw the SCENE CAMERA offscreen and read it back as packed RGB.

    This is what a viewfinder actually needs. The deleted framebuffer path
    streamed whatever the operator happened to be looking at, so they could not
    open another editor or switch windows without wrecking the phone's picture,
    and it showed nothing useful when the camera was not the active view.

    **Verified to work from a timer with Blender minimised**, 12 ticks out of 12,
    which is the whole requirement: no viewport redraw is involved, so the stream
    survives the operator being somewhere else entirely.

    Costs 2.5-5 ms against a static viewport and 32-40 ms with the phone live
    and the camera moving, both at 1158x798 on a 229k-triangle scene. Where the
    difference goes has not been split under a correct load: the probe that
    reported draw 19.5 / readback 9.6 / pack 2.7 was measuring a rolling take
    against a paused host, so its numbers describe a timeline advancing rather
    than a camera turning.

    Whatever it is, it is worth chasing: the operator's own redraw of the same
    scene costs **0.95 ms**, so 40 ms for one offscreen draw of it is a 40x gap.

    Resolution matters here in a way it does not elsewhere, and non-linearly. A
    capture that fits inside one event-loop iteration is nearly free, because
    the loop spends that iteration waiting on vsync anyway; one that overruns
    stretches every iteration it lands in. Measured, 640x440 captures in 32.1 ms
    against a 33.3 ms iteration and 1158x798 in 38.6 ms -- on opposite sides of
    the only boundary that matters.

    `do_color_management=True` because the phone displays these bytes directly;
    without it the picture comes out visibly dark.

    [overlays] defaults to False, and that is a correctness choice rather than a
    performance one -- measured, the overlay pass costs nothing. `draw_view3d`
    borrows a real 3D view's settings, so whatever the operator has switched on
    lands in the phone's picture: on one real scene the 3D cursor, the
    relationship lines and the grid covered 1.72% of the frame. A viewfinder is
    for judging framing, and those are not in the shot. The operator can ask for
    them back (viewport-channel.md 5.1) because some of them -- the floor grid
    especially -- do help place a camera.
    """
    import numpy as np

    camera = scene.camera
    if camera is None:
        return None
    depsgraph = bpy.context.evaluated_depsgraph_get()
    # The EVALUATED camera, never the raw datablock.
    #
    # `matrix_world` is derived, not stored: the tick writes `cam.location` and
    # `cam.rotation_quaternion` and Blender recomputes the matrix when the
    # depsgraph next evaluates. Reading it off the raw object in the same tick
    # returns the matrix from BEFORE the pose was applied -- and with nothing
    # else forcing an evaluation it can stay stale indefinitely, which is
    # exactly what made the phone show a frozen picture while the Blender
    # camera was visibly moving.
    #
    # It is also the only correct answer when the camera is parented, driven or
    # constrained, since none of that is in the raw transform at all.
    camera_eval = camera.evaluated_get(depsgraph)
    # Borrowed and put back, because it is the operator's viewport and they are
    # still using it. Written only when it differs from what they already have,
    # so an operator who works with overlays off never sees a property of theirs
    # touched at all -- and the restore is in a finally, because leaving someone
    # else's overlays switched off is a worse bug than any frame we might drop.
    overlay = space.overlay
    restore = overlay.show_overlays if overlay.show_overlays != overlays else None
    if restore is not None:
        overlay.show_overlays = overlays
    # Same borrow-and-return, for the same reason: a progressive engine draws
    # nothing into a one-shot offscreen, so Rendered has to become something
    # that does. See `drawable_shading` for why this is the engine's prefix
    # rather than a list of names.
    shading = space.shading
    substitute = viewport_stream.drawable_shading(
        shading.type, scene.render.engine
    )
    restore_shading = shading.type if substitute else None
    if substitute:
        shading.type = substitute
    try:
        offscreen.draw_view3d(
            scene,
            bpy.context.view_layer,
            space,
            region,
            camera_eval.matrix_world.inverted(),
            camera_eval.calc_matrix_camera(depsgraph, x=width, y=height),
            do_color_management=True,
        )
    finally:
        if restore_shading is not None:
            shading.type = restore_shading
        if restore is not None:
            overlay.show_overlays = restore
    with offscreen.bind():
        framebuffer = gpu.state.active_framebuffer_get()
        # THREE channels, not four. Alpha here is a solid 255 -- an offscreen
        # draw composites against the world background rather than leaving the
        # premultiplied holes that turned every object black on the deleted
        # framebuffer path -- so the fourth channel was read only to be sliced
        # off again, and slicing it off cost 2.24 ms of the 14.2 ms capture.
        #
        # It does not make the readback itself cheaper: measured, `read_color`
        # takes the same time for three channels as for four, so the GPU is
        # converting rather than moving less. The saving is entirely in what
        # numpy no longer has to do afterwards.
        buffer = framebuffer.read_color(0, 0, width, height, 3, 0, "UBYTE")
        # Same flattening rule as capture_rgb: never let np.asarray read a
        # gpu.types.Buffer through its own reported strides.
        buffer.dimensions = width * height * 3
        rgb = np.frombuffer(buffer, dtype=np.uint8).reshape(height, width, 3)
        # Copied because the Buffer's memory does not outlive the bind block.
        rgb = rgb.copy()
    return viewport_stream.pack_rgb(rgb, 1)


class CameraCapture:
    """Streams the scene camera, driven by the add-on's own tick.

    The counterpart to `ViewportCapture`, and the one that makes this a
    viewfinder rather than screen sharing. It never touches a draw handler, so
    its cadence is ours and it keeps producing frames while the operator is in
    the shader editor, in another window, or in another application entirely --
    verified with Blender minimised.

    Encoding and sending stay on the worker thread, exactly as the other path
    does, because a blocked `sendall` must never sit inside Blender's tick.
    """

    def __init__(self, stream: viewport_stream.ViewportStream) -> None:
        self._stream = stream
        self._worker: Optional[threading.Thread] = None
        self._running = threading.Event()
        self._lock = threading.Lock()
        self._slot: Optional[Tuple[bytes, int, int, int]] = None
        self._wake = threading.Event()
        self._offscreen = None
        self._offscreen_size: Optional[Tuple[int, int]] = None

        self._handler = None
        self._was_connected = False

        self.width = 960
        self.height = 540
        self.quality = 75
        #: Whether the operator's overlays are drawn into the phone's picture.
        #: Off by default: a viewfinder shows the shot, and the 3D cursor is not
        #: in it.
        self.overlays = False
        #: None means the phone is choosing the size. Otherwise the host is, and
        #: `_budget` is what does the choosing.
        self.profile: Optional[str] = None
        self._budget: Optional[viewport_stream.CaptureBudget] = None
        #: Everything about whether this tick draws lives here, in core/, where
        #: it can be tested -- `gpu` drawing raises under `--background`, so the
        #: half of this class that matters most had no coverage at all until it
        #: moved. Both of the bugs that halved the frame rate were in it.
        self._pacer = viewport_stream.CapturePacer(target_fps=DEFAULT_FPS)

        self.frames_captured = 0
        self.encode_ms = 0.0
        self.last_error: Optional[str] = None

    @property
    def active(self) -> bool:
        return self._running.is_set()

    @property
    def target_fps(self) -> float:
        return self._pacer.target_fps

    @property
    def limited_by(self) -> Optional[str]:
        """`idle`, `loop`, `capture`, or None. See `CapturePacer.limited_by`."""
        return self._pacer.limited_by

    @property
    def achieved_fps(self) -> float:
        """Frames actually captured per second, over a short window."""
        return self._pacer.achieved_fps

    @property
    def loop_fps(self) -> float:
        """How often Blender's event loop offers this tick a chance, per second.

        The stream's real ceiling, and it belongs to Blender rather than to us: a
        timer callback fires once per loop iteration, and the iteration is the
        viewport's redraw. Measured, 30 Hz while the viewport redraws against
        the 120 Hz `apply.TICK_INTERVAL` asks for -- and 175 Hz when the
        operator is not looking at a moving scene, which is why the stream is
        fastest exactly when Blender is minimised.
        """
        return self._pacer.loop_fps

    @property
    def effective_fps(self) -> float:
        """The rate being aimed at, after the loop has had its say."""
        return self._pacer.effective_fps

    @property
    def capture_ms(self) -> float:
        """Mean capture cost over the last few frames, not the newest one."""
        return self._pacer.capture_ms

    @property
    def frames_skipped_busy(self) -> int:
        return self._pacer.skipped_busy

    @property
    def frames_skipped_idle(self) -> int:
        return self._pacer.skipped_idle

    def start(self, width: int, height: int, quality: int = 75,
              fps: float = DEFAULT_FPS, overlays: bool = False,
              profile: Optional[str] = None, sizes=None) -> bool:
        ok, _reason = encoder_available()
        if not ok:
            return False
        self.width = max(16, int(width))
        self.height = max(16, int(height))
        self.quality = int(quality)
        self.overlays = bool(overlays)
        # Rebuilt only when the choice actually changes, because the budget
        # carries everything it has learned about this scene and throwing that
        # away on every control message would leave it permanently ignorant.
        if profile != self.profile or (profile and self._budget is None):
            self.profile = profile
            self._budget = (
                viewport_stream.CaptureBudget(sizes or [], profile)
                if profile else None
            )
        self._pacer.target_fps = float(fps)
        if self._running.is_set():
            return True  # already running; new settings simply take effect
        self._running.set()
        self._pacer.note_change()  # nothing drawn yet, so the first tick draws
        self._install_handler()
        self._worker = threading.Thread(
            target=self._encode_loop, name="pocketrig-camera-encode", daemon=True
        )
        self._worker.start()
        return True

    def stop(self) -> None:
        self._running.clear()
        self._remove_handler()
        self._wake.set()
        if self._worker is not None:
            self._worker.join(timeout=2.0)
            self._worker = None
        with self._lock:
            self._slot = None
        self._pacer = viewport_stream.CapturePacer(target_fps=self.target_fps)
        self._free_offscreen()

    def stats(self) -> Dict[str, Any]:
        return {
            "active": self.active,
            "mode": "camera",
            "frames_captured": self.frames_captured,
            "frames_skipped_busy": self.frames_skipped_busy,
            "frames_skipped_idle": self.frames_skipped_idle,
            "achieved_fps": round(self.achieved_fps, 1),
            "requested_fps": round(self.target_fps, 1),
            # What the host can actually offer, measured rather than assumed.
            # The phone has no way to know it: it is the operator's viewport
            # redraw rate, and it moves with what they are doing.
            "loop_fps": round(self.loop_fps, 1),
            "effective_fps": round(self.effective_fps, 1),
            "limited_by": self.limited_by,
            "capture_ms": round(self.capture_ms, 2),
            "encode_ms": round(self.encode_ms, 2),
            "size": [self.width, self.height],
            "quality": self.quality,
            "overlays": self.overlays,
            "profile": self.profile,
            # Only meaningful under a profile: the smallest size still overruns
            # an iteration, so there is nothing left for the host to give up.
            "at_floor": bool(self._budget.at_floor) if self._budget else False,
            "error": self.last_error,
        }

    # ----------------------------------------------------------------- tick

    def tick(self) -> None:
        """One capture opportunity. Called from the add-on tick, main thread.

        Must never raise: this runs inside the same timer that drives the pose
        path, and an exception here would take the whole session down over a
        preview.
        """
        if not self._running.is_set():
            return
        try:
            connected = self._stream.connected
            if not connected:
                self._was_connected = False
                return
            now = time.perf_counter()
            # Counted before any decision, and even on the ticks that skip:
            # this measures the LOOP, which is the ceiling on everything below.
            self._pacer.observe_tick(now)

            if not self._was_connected:
                # A fresh viewer needs a picture immediately, not on the next
                # scene change -- which on a parked rig might be minutes away.
                self._pacer.note_change()
            self._was_connected = True

            with self._lock:
                busy = self._slot is not None
            scene = bpy.context.scene
            key = camera_key(scene)
            if self._pacer.should_capture(now, key, busy):
                return

            found = find_view3d()
            if found is None:
                # draw_view3d borrows settings from a real 3D view. With every
                # one closed there is nothing to borrow, so the stream pauses
                # rather than guessing.
                return
            _area, region, space = found

            started = time.perf_counter()
            captured = capture_camera_rgb(
                self._ensure_offscreen(), scene, space, region,
                self.width, self.height, self.overlays,
            )
            if captured is None:
                self.last_error = "no scene camera"
                return
            payload, width, height = captured
            elapsed = time.perf_counter() - started
            # AFTER the capture, never before. capture_camera_rgb calls
            # evaluated_depsgraph_get, which fires our own change handler
            # part-way through; snapshotting here absorbs that instead of
            # letting it look like a scene change we still owe a frame for.
            # `now` rather than the post-capture clock, so the deadline stays
            # anchored to the schedule and does not drift by the capture cost.
            self._pacer.note_captured(now, key, elapsed)
            self._steer(now, elapsed)
            self.frames_captured += 1
            self.last_error = None

            with self._lock:
                self._slot = (payload, width, height, time.perf_counter_ns())
            self._wake.set()
        except Exception as exc:  # noqa: BLE001
            self.last_error = f"{type(exc).__name__}: {exc}"

    def _steer(self, now: float, elapsed: float) -> None:
        """Let the budget see what that capture cost, and move if it says so.

        Called from the tick, on the main thread, immediately after a capture.
        The size takes effect on the next one: `_ensure_offscreen` reallocates
        when it sees a size it does not have, and the frame header carries the
        size actually produced, so a receiver never has to be told separately.
        """
        if self._budget is None:
            return
        loop = self._pacer.loop_fps
        if loop <= 0:
            return
        self._budget.observe(now, (self.width, self.height), elapsed, 1.0 / loop)
        chosen = self._budget.choose(now)
        if chosen is not None:
            self.width, self.height = chosen

    # ------------------------------------------------------- change tracking

    def _on_depsgraph_update(self, scene, depsgraph=None) -> None:
        """The scene was evaluated. Must be trivial and must not raise.

        This fires on every depsgraph evaluation, which is often, so it does the
        least possible: bump a counter. The pacer decides what to do about it --
        and a counter rather than a flag is what lets it tell an evaluation that
        happened before a capture from one that happened after, including the
        evaluation the capture forced itself.
        """
        self._pacer.note_change()

    def _install_handler(self) -> None:
        """Attach the change listener for as long as we are streaming.

        Tied to the capture's lifetime rather than registered at add-on load, so
        nothing at all runs on this path when the feature is off. Deliberately
        NOT @persistent: a file load should drop it, and the session that comes
        back attaches a fresh one.
        """
        if self._handler is not None:
            return
        try:
            handlers = bpy.app.handlers.depsgraph_update_post
            self._handler = self._on_depsgraph_update
            handlers.append(self._handler)
        except Exception as exc:  # noqa: BLE001
            # Losing change detection is survivable -- the keepalive below still
            # produces frames -- so this must never take the stream down with it.
            self._handler = None
            self.last_error = f"depsgraph handler: {type(exc).__name__}: {exc}"

    def _remove_handler(self) -> None:
        if self._handler is None:
            return
        try:
            bpy.app.handlers.depsgraph_update_post.remove(self._handler)
        except (ValueError, AttributeError):
            pass  # already gone, e.g. a file load cleared it
        self._handler = None

    # --------------------------------------------------------------- helpers

    def _ensure_offscreen(self):
        """One GPUOffScreen, reused. Allocating per frame is pure waste."""
        size = (self.width, self.height)
        if self._offscreen is not None and self._offscreen_size == size:
            return self._offscreen
        self._free_offscreen()
        self._offscreen = gpu.types.GPUOffScreen(self.width, self.height)
        self._offscreen_size = size
        return self._offscreen

    def _free_offscreen(self) -> None:
        if self._offscreen is not None:
            try:
                self._offscreen.free()
            except Exception:  # noqa: BLE001 - already gone is fine
                pass
        self._offscreen = None
        self._offscreen_size = None

    def _encode_loop(self) -> None:
        import simplejpeg
        import numpy as np

        while self._running.is_set():
            self._wake.wait(timeout=0.25)
            self._wake.clear()
            with self._lock:
                frame, self._slot = self._slot, None
            if frame is None:
                continue
            payload, width, height, capture_ns = frame
            try:
                started = time.perf_counter()
                array = np.frombuffer(payload, dtype=np.uint8).reshape(
                    height, width, 3
                )
                encoded = simplejpeg.encode_jpeg(
                    array, quality=self.quality, colorspace="RGB"
                )
                self.encode_ms = (time.perf_counter() - started) * 1000.0
                self._stream.send_frame(encoded, capture_ns, width, height)
            except Exception as exc:  # noqa: BLE001 - a bad frame is not fatal
                self.last_error = f"encode: {type(exc).__name__}: {exc}"
