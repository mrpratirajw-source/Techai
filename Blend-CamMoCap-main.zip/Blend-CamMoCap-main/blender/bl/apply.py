# SPDX-License-Identifier: GPL-3.0-or-later
"""One tick of main-thread work: pose -> camera, recenter, bake dispatch.

apply_tick() is a plain function returning None so `blender --background`
tests (where bpy.app.timers never pump) can drive it directly in a loop.
_timer_callback() is the thin wrapper actually registered with
bpy.app.timers in interactive sessions.
"""

from __future__ import annotations

import math
import time
import traceback
from typing import Optional

import bpy
from mathutils import Quaternion, Vector

from ..core import filters, protocol
from . import record, state, viewport
from ..core import viewport_stream

CAMERA_NAME = "PocketRig Cam"
TICK_INTERVAL = 1.0 / 120.0

# Section-6 host guards (spec/coordinate-systems.md): a gap in the position
# stream's own timestamps, or an implied speed no hand can produce, means the
# tracker restarted or relocalized — re-anchor instead of applying the jump.
# Real handheld translation tops out near 3 m/s; whip pans near 700 deg/s.
POS_GAP_NS = 250_000_000  # 250 ms
TELEPORT_MPS = 5.0
ROT_TELEPORT_DPS = 1200.0
# DEFAULT angular speed above which the phone is being shaken/whipped hard
# enough that the camera motion-blurs and ARCore's visual-inertial position
# dead-reckons into a clean constant-velocity drift — so HOLD position (rotation
# keeps tracking) and re-anchor when it calms.
#
# The live value is scene.pocketrig_shake_hold_dps, mirrored to the phone over
# PARAMS (spec 5.7), and 0 turns the gate off. This is a setting rather than a
# constant because no single number is right: the gate has to sit above every
# legitimate fast reframe and below a real shake, and those overlap. It was 500,
# lowered to 300 to catch shakes that a one-interval measurement under-reported,
# and 300 then fired on ordinary framing moves — 300 dps is a 90-degree turn in
# 0.3 s. Smoothing fixed the noise half of the measurement and left the ceiling
# too low, so the default returns to 500 and the choice becomes the operator's.
#
# This default MUST match the phone's SHAKE_HOLD_DPS (SessionClient), and the
# mirrored value MUST reach it, or the "position held" cue stops describing what
# happens here. Pinned by fixtures/motion_gates.json on both sides.
SHAKE_HOLD_DPS = 500.0

# Above the relocalization guard the shake gate could never fire first, so a
# larger setting is indistinguishable from that guard's threshold (spec 5.7).
SHAKE_HOLD_MAX_DPS = ROT_TELEPORT_DPS

# Weight of each new sample in the smoothed angular speed used by the shake gate.
# MUST match the phone's SessionClient.SHAKE_SMOOTHING.
SHAKE_SMOOTHING = 0.25

# Below this a pose interval is noise amplification, not a measurement.
MIN_SHAKE_DT_NS = 2_000_000

# Lens (spec 4.5). 0.0 means the sender is not driving focal length, so a lens
# set in Blender is left alone. Values outside a plausible photographic range are
# ignored rather than applied, for the same reason a non-finite quaternion is
# dropped: a host must not let a bad number reach the scene.
LENS_MIN_MM = 1.0
LENS_MAX_MM = 5000.0


def _driven_lens_mm(value: float) -> Optional[float]:
    """The focal length to apply, or None when the sender is not driving it."""
    try:
        mm = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(mm) or mm <= 0.0:
        # 0.0 is the documented "not driving the lens" value (spec 4.5). The
        # range check below would also reject it; both are kept because they say
        # different things -- this one is protocol semantics, that one is
        # plausibility -- and they only happen to overlap at zero.
        return None
    if not (LENS_MIN_MM <= mm <= LENS_MAX_MM):
        return None
    return mm


#: The fastest rate this host will accept being asked for, advertised in
#: WELCOME and used as the clamp on the measured ceiling. A viewfinder answers
#: "where is the camera pointing"; past 30 the extra frames buy nothing and the
#: main thread they cost belongs to the operator.
VIEWPORT_MAX_FPS = 30

#: How far the measured loop rate must move before it is republished.
#:
#: PARAMS is diffed and resent on any change, and the loop rate jitters by a
#: frame either way, so publishing the raw number would put a reliable datagram
#: on the wire every tick. Three frames is coarser than the jitter and finer
#: than any difference the operator would act on.
_VIEWPORT_FPS_HYSTERESIS = 3.0


def _reportable_viewport_max_fps() -> Optional[float]:
    """The stream rate this host has measured itself reaching, or None.

    Only meaningful while the stream is actually working. A parked rig leaves
    the event loop free-running -- 64-175 Hz measured, against 30 Hz once the
    camera moves and the viewport starts redrawing -- so sampling then would
    publish a ceiling several times higher than anything the phone will ever
    see. The last figure from an active period is kept instead, which is a far
    better estimate of the next one than the idle rate is.
    """
    capture = state.camera_capture
    if capture is None or not capture.active:
        state.viewport_max_fps_published = None
        return None
    # Clamped to what we will actually accept being asked for. Minimised, this
    # host measures 64 -- true, and useless to say on a control that stops at
    # 30: a ceiling above the top of the dial reads as a fault in the dial.
    ceiling = min(capture.loop_fps, VIEWPORT_MAX_FPS)
    if ceiling > 0 and capture.limited_by != "idle":
        previous = state.viewport_max_fps_published
        if previous is None or abs(ceiling - previous) >= _VIEWPORT_FPS_HYSTERESIS:
            state.viewport_max_fps_published = round(ceiling)
    return state.viewport_max_fps_published


def _reportable_lens_mm(scene, srv) -> Optional[float]:
    """
    Our current focal length to mirror to the phone, or None to omit it.

    The phone's lens rail has to open ON the operator's lens rather than assert
    one of its own -- otherwise merely opening the control reframes the shot,
    which is the very thing spec 4.5's "0.0 means not driving" rule exists to
    prevent. It cannot do that without being told, so PARAMS carries it (5.7).

    Two cases are deliberately NOT reported:

    - **The phone is driving the lens.** The value came from the phone; sending
      it back is redundant, and the change detector would fire on every zoom.
    - **The lens is animated.** A baked take driving the camera, or scrubbing
      the timeline, changes `lens` every frame. PARAMS is reliable, so mirroring
      that would put a per-frame value on the retransmit path -- and an animated
      lens is not a value the phone could meaningfully adopt anyway.
    """
    live = srv.latest_pose
    if live is not None and _driven_lens_mm(live.focal_length_mm) is not None:
        return None
    cam = scene.camera
    cam_data = getattr(cam, "data", None)
    if cam_data is None or not hasattr(cam_data, "lens"):
        return None
    anim = getattr(cam_data, "animation_data", None)
    if getattr(anim, "action", None) is not None:
        return None
    try:
        mm = float(cam_data.lens)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(mm):
        return None
    # Rounded so float noise in the camera data cannot trip the change detector
    # into resending PARAMS forever.
    return round(mm, 3)


def _is_interactive() -> bool:
    """True in a real Blender UI session, False under `blender --background`.
    A single seam so a headless test can exercise the interactive start-paused
    path (which the normal background tests skip on purpose)."""
    return not bpy.app.background


def _ensure_camera(scene) -> bpy.types.Object:
    """scene.camera if set, else create/adopt "PocketRig Cam" and make it the
    scene camera. Forces quaternion rotation mode while driving."""
    cam = scene.camera
    if cam is None:
        cam = bpy.data.objects.get(CAMERA_NAME)
        if cam is None:
            cam_data = bpy.data.cameras.new(CAMERA_NAME)
            cam = bpy.data.objects.new(CAMERA_NAME, cam_data)
            scene.collection.objects.link(cam)
            cam.location = (0.0, 0.0, 0.0)
        scene.camera = cam
    if cam.rotation_mode != "QUATERNION":
        cam.rotation_mode = "QUATERNION"
    return cam


def apply_tick() -> None:
    """Read latest pose, drive the camera, service recenter/bake requests."""
    srv = state.server
    if srv is None:
        return
    scene = bpy.context.scene
    if scene is None:
        return
    state.scene_fps_cache = scene.render.fps / scene.render.fps_base

    # Timeline playback (recording roll / take review): advance the playhead
    # ourselves from wall-clock. Done first so the auto-stop / review-stop
    # checks below act on the up-to-date frame.
    advanced_frame = _advance_playback(scene)

    # Every HELLO epoch re-syncs controls/library. Only a genuinely fresh
    # pairing applies start-paused/auto-home behavior; a transient reconnect
    # must preserve the operator's current live state.
    hello_count = srv.hello_count
    hello_changed = hello_count != state.seen_hello_count
    if hello_changed:
        state.seen_hello_count = hello_count
        state.ever_connected = True
        state.synced_params = None  # pairing/reconnect: push full PARAMS sync
        state.sent_paused = None  # ...and the authoritative pause state
        srv.request_take_list()  # spec 5.11: ask for the phone's library

    pairing_count = srv.pairing_count
    pairing_changed = pairing_count != state.seen_pairing_count
    if pairing_changed:
        state.seen_pairing_count = pairing_count
        if not _is_interactive():
            # Headless conformance: keep the old auto-live-on-connect so the
            # test suites drive the camera immediately.
            if state.auto_recenter_enabled:
                state.pending_auto_recenter = True
        elif not srv.recording:
            # Interactive: start PAUSED so the camera is not fighting the user.
            # "Start tracking" (the phone's Go-live, or the panel button) goes
            # live and captures the current framing as home. This is what makes
            # applying a take, then tracking, then applying another, coherent.
            # sent_paused=None above forces this state to the phone this tick;
            # the phone also defaults to paused on a fresh connect so it never
            # flashes "live" before the push lands. Skipped mid-recording so a
            # reconnect blip during a take never freezes the live preview.
            state.paused = True
    elif (
        hello_changed
        and not srv.recording
        and not state.paused
        and not state.reviewing
    ):
        # Reconnect while live: the phone process/source may have restarted
        # its yaw/world reference. Preserve the visible camera on the first
        # resumed pose without changing the user's deliberate Home framing.
        state.pending_frame_rebase = True

    # PARAMS mirror (spec 5.7): phone slider changes apply to the scene props
    # (host authoritative, no echo back); local prop changes push to the
    # phone. Applied BEFORE this tick reads the props, so it takes effect now.
    params_req = srv.take_params_request()
    if params_req is not None:
        v = _fnum(params_req.get("live_smoothing"))
        if v is not None:
            scene.pocketrig_live_smoothing = max(0.0, min(1.0, v))
        v = _fnum(params_req.get("record_smoothing"))
        if v is not None:
            scene.pocketrig_record_smoothing = max(0.0, min(1.0, v))
        v = _fnum(params_req.get("move_scale"))
        if v is not None:
            scene.pocketrig_move_scale = max(0.001, min(100.0, v))
        # NOTE: the phone's portrait/landscape control is now phone-LOCAL (it
        # just rotates the phone's own screen). The host no longer swaps its
        # render resolution to match — the render aspect is the user's to set in
        # Blender. `layout` is accepted-and-ignored for wire compatibility.
        want_src = params_req.get("take_source")
        if want_src in ("offline", "live"):
            scene.pocketrig_take_source = want_src
        v = _fnum(params_req.get("shake_hold_dps"))
        if v is not None:
            scene.pocketrig_shake_hold_dps = max(0.0, min(SHAKE_HOLD_MAX_DPS, v))

    recording = srv.recording

    # FRAME_RESET is an internal pose-reference boundary, not user Re-center.
    # The phone gates POSE output until this reliable control is acknowledged,
    # so the next fresh raw pose can be adopted atomically. Paused/review state
    # already rebases through Go Live; recording freezes the frame by contract.
    if srv.take_frame_reset_request() and not recording:
        if not state.paused and not state.reviewing:
            state.pending_frame_rebase = True

    # Auto-stop: the scene's end frame cuts the take (the timeline IS the
    # shot). Wrap detection covers frame-dropped playback skipping past the
    # end. The stop is REQUESTED through the phone so the offline-take upload
    # happens (spec 5.4); the session falls back to a live-buffer stop if the
    # phone never answers. Headless keeps phone-controlled stops only.
    if recording and state.was_recording and not bpy.app.background:
        f = scene.frame_current
        at_end = f >= scene.frame_end or (
            state.record_prev_frame is not None and f < state.record_prev_frame
        )
        if at_end and not state.host_stop_requested:
            state.host_stop_requested = True
            srv.request_stop_from_host()
            _set_playback(False)  # don't visibly loop while the stop lands
        elif not at_end:
            state.record_prev_frame = f

    if recording and not state.was_recording:
        # Recording just started: pin the bake frame (the playhead is about to
        # roll), detach any previous take BEFORE the timeline plays (an
        # attached action would be evaluated by the animation system and fight
        # the live stream — the camera would fly to old keyframes), then roll.
        if state.reviewing or state.paused:
            # Record straight out of pause/review MUST equal Go-live + Record:
            # the take starts from the camera's CURRENT framing. Without this,
            # the first pose composed with a stale q_offset and the camera
            # flew to an arbitrary orientation — unguarded, because the
            # teleport guards are frozen during recording.
            state.pending_soft_resume = True
        state.reviewing = False  # a new take always goes live
        state.paused = False
        if not bpy.app.background and scene.frame_current >= scene.frame_end:
            # Starting at the end would cut instantly — a take from the end
            # of the scene means "from the top".
            scene.frame_set(scene.frame_start)
        state.record_frame_start = scene.frame_current
        state.record_prev_frame = scene.frame_current
        state.host_stop_requested = False
        state.record_q_offset = None
        state.record_loc_offset = None
        state.record_move_scale = None
        record_cam = _ensure_camera(scene)
        state.record_camera_quat = record_cam.rotation_quaternion.copy()
        state.record_camera_loc = record_cam.location.copy()
        record.stash_existing_take(record_cam)
        record.stash_existing_lens_take(record_cam)
        # The take starts from a coherent reference: drop the position anchor
        # (the next positional pose re-anchors at the camera's CURRENT
        # location — zero visible motion by construction) and reset the live
        # filters. Any drift or pending tracker glitch accumulated before the
        # take is absorbed HERE, instead of surfacing as a mid-take jump once
        # the offsets freeze. This is "re-center before recording" made
        # automatic, without snapping the camera anywhere.
        state.loc_offset = None
        state.live_pos_filter.reset()
        state.live_filter.reset()
        state.disp_quat = None
        _set_playback(True)
    elif not recording and state.was_recording:
        _set_playback(False)
        state.host_stop_requested = False
    state.was_recording = recording

    recenter = srv.take_recenter_request() or state.manual_recenter
    state.manual_recenter = False
    if recording:
        recenter = False  # offset is frozen during a take (guard, session too)

    # SEEK (spec 5.9): the phone moves the playhead — the retake button.
    # Ignored while recording (session gates too); pause/review unaffected,
    # so a paused operator can scrub from the phone.
    seek_req = srv.take_seek_request()
    if seek_req is not None and not recording:
        target = (
            scene.frame_start
            if seek_req.get("to") == "start"
            else _fnum(seek_req.get("frame"))
        )
        if target is not None:
            scene.frame_set(
                max(scene.frame_start, min(scene.frame_end, int(target)))
            )

    # Manual pause (spec 5.8). A refused request (recording) gets the actual
    # state pushed back so the phone's button never lies.
    pause_req = srv.take_pause_request()
    if pause_req is True and not recording and not state.paused:
        state.paused = True
        if state.reviewing:
            state.reviewing = False
            _set_playback(False)
    elif pause_req is False and (state.paused or state.reviewing):
        _go_live(scene)  # detach any applied take, continue from HERE

    # Showing a take / paused: the live drive is off so the take can be
    # watched and scrubbed without the phone fighting the animation system.
    # Re-center goes live snapping HOME (falls through to the recenter branch);
    # a take's own playback stops at its last frame, then holds for scrubbing.
    if (state.reviewing or state.paused) and recenter:
        _detach_camera_action(scene)  # stop driving from the take
        state.reviewing = False
        state.paused = False
        _set_playback(False)
    elif state.reviewing and (
        state.review_stop_frame is not None
        and scene.frame_current >= state.review_stop_frame
    ):
        _set_playback(False)

    live_s = float(getattr(scene, "pocketrig_live_smoothing", 0.0))
    move_scale = float(getattr(scene, "pocketrig_move_scale", 1.0))
    record_s = float(getattr(scene, "pocketrig_record_smoothing", 0.0))
    # 0 disables the shake-hold gate entirely (spec 5.7). Clamped here rather
    # than trusted, because it also arrives from the phone.
    shake_hold = max(
        0.0,
        min(
            SHAKE_HOLD_MAX_DPS,
            float(getattr(scene, "pocketrig_shake_hold_dps", SHAKE_HOLD_DPS)),
        ),
    )

    # Layout is intentionally NOT mirrored anymore (it's phone-local now, and
    # the render aspect is the user's to set) — the host neither derives it from
    # the render resolution nor pushes it to the phone.
    take_src = str(getattr(scene, "pocketrig_take_source", "offline"))
    host_lens = _reportable_lens_mm(scene, srv)
    viewport_ceiling = _reportable_viewport_max_fps()
    cur_params = (
        round(live_s, 4), round(record_s, 4), round(move_scale, 4), take_src,
        host_lens, round(shake_hold, 3), viewport_ceiling,
    )
    if params_req is not None:
        state.synced_params = cur_params  # phone asked for this: no echo
    elif state.synced_params != cur_params and srv.is_client_connected:
        srv.send_params(
            *cur_params[:3], layout=None, take_source=take_src, lens_mm=host_lens,
            shake_hold_dps=shake_hold, viewport_max_fps=viewport_ceiling,
        )
        state.synced_params = cur_params

    # Pause-state mirror: push on local change; correct the phone if its
    # request was refused; never echo an honored request.
    paused_now = state.paused or state.reviewing
    if pause_req is not None:
        if paused_now != pause_req and srv.is_client_connected:
            srv.send_paused(paused_now)
        state.sent_paused = paused_now
    elif state.sent_paused != paused_now and srv.is_client_connected:
        srv.send_paused(paused_now)
        state.sent_paused = paused_now

    # phone-driven changes: redraw the panel
    changed = (
        advanced_frame
        or params_req is not None
        or pause_req is not None
        or seek_req is not None
    )
    pose = srv.latest_pose
    # A pose crossing the UNKNOWN/known quality boundary means the phone
    # switched pose source: only rotation-only senders report UNKNOWN. The two
    # sources sit in unrelated world frames, so that crossing is the one moment
    # a large rotation step means "reference changed", not "the operator moved".
    source_regime_changed = False
    if pose is not None:
        quality = protocol.tracking_quality(pose[3])
        issue = protocol.tracking_issue(pose[3])
        source_regime_changed = (quality == "unknown") != (
            state.tracking_quality == "unknown"
        )
        if quality != state.tracking_quality or issue != state.tracking_issue:
            state.tracking_quality = quality
            state.tracking_issue = issue
            changed = True
    if pose is not None and not (state.reviewing or state.paused):
        seq, ts, quat, _flags, pos = pose[:5]
        q_new: Optional[Quaternion] = None
        if seq != state.last_seq:
            q_new = Quaternion(quat).normalized()
            if state.last_pose_quat is not None and state.last_pose_quat.dot(q_new) < 0:
                q_new.negate()
        q_raw = q_new if q_new is not None else state.last_pose_quat
        if q_raw is not None:
            cam = _ensure_camera(scene)
            if (recenter or state.pending_auto_recenter) and not recording:
                # coordinate-systems.md section 5. On connect (auto-recenter) the
                # camera's pre-driving orientation IS the home framing; capture it
                # once. Manual Re-center then snaps the camera back to that home
                # (a visible, useful reset) rather than re-zeroing in place, which
                # is a near-no-op when the phone is held still at the tap. Use the
                # RAW pose for an exact neutral and reset the live filter so the
                # snap is crisp before it starts easing again.
                if state.pending_auto_recenter or state.home_quat is None:
                    state.home_quat = cam.rotation_quaternion.normalized()
                    state.home_loc = cam.location.copy()
                state.q_offset = state.home_quat @ q_raw.inverted()
                state.live_filter.reset()
                state.live_pos_filter.reset()
                state.disp_quat = None
                state.pending_auto_recenter = False
                # 6DOF (coordinate-systems.md section 6): re-center also snaps
                # the camera back to its home placement. Rotation-only sessions
                # (loc_offset never anchored) leave the location untouched, so
                # a manually placed camera stays where the user put it.
                if pos is not None:
                    state.loc_offset = state.home_loc - move_scale * (
                        state.q_offset @ Vector(pos)
                    )
                    state.applied_move_scale = move_scale
                    cam.location = state.home_loc.copy()
                    state.last_pos = Vector(pos)
                    state.last_pos_ts = ts
                elif state.loc_offset is not None:
                    cam.location = state.home_loc.copy()
                    state.loc_offset = None  # re-anchor when tracking returns
                state.pending_soft_resume = False  # recenter supersedes
                state.pending_frame_rebase = False
                changed = True
            # Lens (spec 4.5). Driven only while the phone says so, and written
            # only on change: the timer runs at 120 Hz and re-assigning an equal
            # value would dirty the dependency graph for nothing. Field of view
            # follows from the scene camera's own sensor size, which stays the
            # operator's, exactly as render aspect does.
            lens_mm = _driven_lens_mm(pose.focal_length_mm)
            if lens_mm is not None and state.last_focal_mm != lens_mm:
                cam_data = getattr(cam, "data", None)
                if cam_data is not None and hasattr(cam_data, "lens"):
                    cam_data.lens = lens_mm
                    state.last_focal_mm = lens_mm
                    changed = True

            if state.q_offset is None:
                state.q_offset = Quaternion()  # identity until first recenter

            # The first fresh pose of every take is mapped explicitly onto the
            # camera transform captured at the record edge. This is a no-op in
            # coherent live tracking, but it also covers an attached Action,
            # packet loss before the first pose, and stale hidden object data.
            if (
                recording
                and state.record_q_offset is None
                and q_new is not None
                and (state.pending_soft_resume or _is_interactive())
            ):
                from_pause = state.pending_soft_resume
                q_shown = (
                    state.record_camera_quat.copy()
                    if state.record_camera_quat is not None
                    else cam.rotation_quaternion.normalized()
                )
                state.q_offset = q_shown @ q_new.inverted()
                state.record_q_offset = state.q_offset.copy()
                state.live_filter.reset()
                state.disp_quat = None
                state.loc_offset = None
                state.live_pos_filter.reset()
                state.last_pose_quat = None
                state.last_pose_ts = None
                state.last_pos = None
                state.last_pos_ts = None
                state.pending_soft_resume = False
                if from_pause:
                    state.home_quat = q_shown.copy()
                    if state.record_camera_loc is not None:
                        state.home_loc = state.record_camera_loc.copy()

            # Soft resume (spec 5.8): un-pausing continues from wherever the
            # camera is — re-express both offsets against the current pose,
            # exactly the teleport-guard recovery math. The camera's transform
            # includes any MANUAL reframing done while paused, and adopting a
            # framing via Go-live is the most deliberate choice an operator
            # makes: it becomes the new HOME, so Re-center returns to the
            # framing you chose, not the connect-time accident.
            if state.pending_soft_resume and q_new is not None:
                state.pending_soft_resume = False
                q_shown = cam.rotation_quaternion.normalized()
                state.q_offset = q_shown @ q_new.inverted()
                state.home_quat = q_shown.copy()
                state.home_loc = cam.location.copy()
                state.live_filter.reset()
                state.disp_quat = None
                state.loc_offset = None
                state.live_pos_filter.reset()
                # Never compare samples from two different raw frames: doing
                # so would immediately trip teleport/shake guards and could
                # overwrite the just-established coherent rebase.
                state.last_pose_quat = None
                state.last_pose_ts = None
                state.last_pos = None
                state.last_pos_ts = None

            # Internal frame rebase: source/display/resume transitions preserve
            # the visible rigid camera transform, but unlike Go Live they MUST
            # NOT redefine Home. Raw quaternion and position remain in one
            # coherent phone frame; only Blender's two left offsets change.
            if state.pending_frame_rebase and q_new is not None:
                state.pending_frame_rebase = False
                q_shown = cam.rotation_quaternion.normalized()
                state.q_offset = q_shown @ q_new.inverted()
                state.live_filter.reset()
                state.disp_quat = None
                state.loc_offset = None
                state.live_pos_filter.reset()
                state.last_pose_quat = None
                state.last_pose_ts = None
                state.last_pos = None
                state.last_pos_ts = None

            # Angular speed between the previous and current pose (deg/s),
            # computed BEFORE last_pose_quat is overwritten. Drives both the
            # rotational teleport guard and the shake-hold position gate.
            # Measured against last_pose_TS, which advances on every pose. Using
            # last_pos_ts here meant that through a run of position-invalid poses
            # the divisor kept growing while the numerator stayed a single pose
            # step, so the reported speed decayed toward zero and both guards
            # went quiet on the first recovered poses — precisely when a
            # relocalizing tracker is most likely to hand us a jump.
            ang_dps = 0.0
            if q_new is not None and (
                state.last_pose_quat is None or state.last_pose_ts is None
            ):
                # The smoothed speed is derived from the previous pose, so it
                # cannot outlive it. Every re-anchor (soft resume, frame rebase,
                # record start) deliberately forgets the pose history, and this
                # average used to survive that: a genuine shake before tapping Go
                # Live or Record left a stale value above the gate, and the host
                # went on HOLDING position at the exact moment the operator had
                # asked the camera to start following. `ang_dps` never had the
                # bug because it is a local that is recomputed from nothing each
                # tick; making the average expire the same way is what keeps the
                # two consistent. This can only ever make the gate LESS eager --
                # it restarts the average at zero, so the hold has to be earned
                # again from real motion.
                state.shake_dps = 0.0
            elif (
                q_new is not None
                and state.last_pose_quat is not None
                and state.last_pose_ts is not None
            ):
                dt_ns = ts - state.last_pose_ts
                # A floor on dt: the measure is an angle DIVIDED by it, so two
                # poses a few hundred microseconds apart turn a fraction of a
                # degree of noise into thousands of degrees per second.
                if dt_ns >= MIN_SHAKE_DT_NS:
                    d = min(1.0, abs(state.last_pose_quat.dot(q_new)))
                    ang_dps = math.degrees(2.0 * math.acos(d)) / (dt_ns / 1e9)
                    # Smoothed copy for the shake gate ONLY. One pose interval is
                    # far too short a window to tell a shake from noise, which is
                    # why the hold was firing during slow deliberate moves. The
                    # raw figure above stays as it is: the teleport guard is
                    # hunting the single-frame spike this average suppresses.
                    # MUST match the phone's SHAKE_SMOOTHING (SessionClient), or
                    # the "position held" cue stops describing what happens here.
                    #
                    # A sample above the relocalization guard is excluded, because
                    # that guard's own definition is "no wrist produces this, so
                    # the reference changed rather than the camera moving" -- and
                    # feeding a reference change into a MOTION average is a
                    # category error. The phone turning past a shot-orientation
                    # quadrant emits exactly such a step (a quarter turn in one
                    # pose interval, thousands of deg/s), and it used to leave the
                    # average parked above the gate afterwards, holding position
                    # because the operator had rotated the phone. Skipped rather
                    # than reset: the device may well still be moving, and the
                    # evidence from before the seam is still good.
                    if ang_dps <= ROT_TELEPORT_DPS:
                        state.shake_dps += SHAKE_SMOOTHING * (
                            ang_dps - state.shake_dps
                        )

            # Rotational teleport guard (6DOF only — the sensor path is fusion-
            # continuous): a visual tracker relocalizing can rotate its world
            # between frames. An implied angular speed no wrist produces means
            # correction, not motion: re-express the offset against the new
            # reference so the DISPLAYED orientation holds, and re-anchor
            # position (R(q_offset) changed). The record-start mapping is
            # snapshotted separately, so display recovery stays safe mid-take.
            #
            # Fires for a visual sender, and for either direction of a
            # pose-source switch.
            #
            # A switch is identified by the pose crossing the quality boundary:
            # rotation-only senders report UNKNOWN, 6DOF senders do not, so
            # UNKNOWN <-> known is exactly "the source changed". That matters
            # because gating on the pose being visual left ARCore -> sensor
            # unprotected (the arriving poses are rotation-only), which is the
            # asymmetry behind "toggling on holds, toggling off snaps".
            #
            # Measured source-frame disagreement: 90 deg in one session, 176 deg
            # in another, always about world up. Delivered in one pose interval
            # that is thousands of deg/s.
            #
            # A blanket guard with no gate at all is NOT correct here: the
            # conformance suites pin camera == q_offset (x) q_protocol against
            # deliberately discontinuous fixture poses, and suppressing
            # discontinuities destroys that contract. The gate keeps the guard
            # to the cases where a discontinuity means a changed reference.
            # A visual sender: it carries position, or it reports a quality field
            # (a v1.1 peer sends position without quality bits, so accept either).
            visual_source = pos is not None or state.tracking_quality != "unknown"
            if (
                q_new is not None
                and ang_dps > ROT_TELEPORT_DPS
                and (visual_source or source_regime_changed)
            ):
                q_shown = state.q_offset @ (
                    state.disp_quat
                    if state.disp_quat is not None
                    else state.last_pose_quat
                )
                state.q_offset = q_shown @ q_new.inverted()
                state.live_filter.reset()
                state.disp_quat = None
                state.loc_offset = None
                state.live_pos_filter.reset()

            # Live smoothing is display-only (the recorded take stays raw). Update
            # the filter on each fresh pose; slider 0 = passthrough.
            if q_new is not None:
                if live_s > 0.0:
                    state.live_filter.min_cutoff, state.live_filter.beta = (
                        filters.live_filter_params(live_s)
                    )
                    fq = state.live_filter.update(
                        (q_new.w, q_new.x, q_new.y, q_new.z), ts
                    )
                    state.disp_quat = Quaternion(fq)
                else:
                    state.live_filter.reset()
                    state.disp_quat = q_new
                state.last_seq = seq
                state.last_pose_quat = q_new
                state.last_pose_ts = ts

            q_disp = state.disp_quat if state.disp_quat is not None else q_raw
            # While a soft resume is pending, the camera holds the operator's
            # (possibly manual) framing untouched: writing the stale composed
            # pose here would clobber it one tick before the re-anchor reads it.
            if (
                (q_new is not None or changed)
                and not state.pending_soft_resume
                and not state.pending_frame_rebase
            ):
                cam.rotation_quaternion = state.q_offset @ q_disp
                changed = True

            # Position drive (coordinate-systems.md section 6). Display
            # anchoring remains active while recording; immutable record-start
            # offsets below keep the final bake in its original framing.
            if (
                pos is not None
                and q_new is not None
                and shake_hold > 0.0
                and state.shake_dps > shake_hold
            ):
                # Shake-hold gate: an aggressive shake blurs the camera and
                # ARCore's position dead-reckons into a clean drift. While the
                # angular speed says "shaking", HOLD the camera's position
                # (rotation still tracks, above) and drop the anchor so the
                # next calm pose re-anchors at the camera's CURRENT spot — the
                # drifted positions are never applied, so no drift is visible.
                state.loc_offset = None
                state.live_pos_filter.reset()
                state.last_pos = Vector(pos)
                state.last_pos_ts = ts
            elif pos is not None and q_new is not None:
                p_raw = Vector(pos)
                if state.loc_offset is not None and state.last_pos_ts is not None:
                    dt_ns = ts - state.last_pos_ts
                    if dt_ns > POS_GAP_NS:
                        state.loc_offset = None  # stream gap: tracker restarted
                        state.live_pos_filter.reset()
                    elif dt_ns > 0 and state.last_pos is not None:
                        speed = (p_raw - state.last_pos).length / (dt_ns / 1e9)
                        if speed > TELEPORT_MPS:
                            state.loc_offset = None  # relocalization teleport
                            state.live_pos_filter.reset()
                # Live smoothing on the RAW position (display only, pre-scale,
                # same slider as rotation): ARCore's ~30 Hz cadence and noise
                # floor never reach the camera, and movement scale amplifies
                # motion, not noise.
                if live_s > 0.0:
                    (
                        state.live_pos_filter.min_cutoff,
                        state.live_pos_filter.beta,
                    ) = filters.live_pos_filter_params(live_s)
                    p_use = Vector(
                        state.live_pos_filter.update((p_raw.x, p_raw.y, p_raw.z), ts)
                    )
                else:
                    state.live_pos_filter.reset()
                    p_use = p_raw
                p = state.q_offset @ p_use
                if state.loc_offset is None or (
                    move_scale != state.applied_move_scale and not recording
                ):
                    # First position, recovery after tracking loss/teleport, or
                    # a scale change: anchor so the camera does not jump.
                    anchor_loc = (
                        state.record_camera_loc
                        if recording
                        and state.record_loc_offset is None
                        and state.record_camera_loc is not None
                        else cam.location
                    )
                    state.loc_offset = anchor_loc - move_scale * p
                    state.applied_move_scale = move_scale
                cam.location = state.loc_offset + state.applied_move_scale * p
                state.last_pos = p_raw  # guards compare tracker truth, unfiltered
                state.last_pos_ts = ts
                changed = True
            elif pos is None and q_new is not None:
                # Tracking lost: hold location now, re-anchor on recovery.
                state.loc_offset = None
                state.live_pos_filter.reset()

            if recording and q_new is not None:
                if state.record_q_offset is None:
                    state.record_q_offset = state.q_offset.copy()
                if (
                    pos is not None
                    and state.loc_offset is not None
                    and state.record_loc_offset is None
                ):
                    state.record_loc_offset = state.loc_offset.copy()
                    state.record_move_scale = state.applied_move_scale

    _service_viewport(scene, srv)

    # Take library (spec 5.11): mirror the phone's list into the scene
    # collection for the UIList, but only when it actually changed.
    rev, takes = srv.get_take_list()
    if rev != state.take_list_rev:
        state.take_list_rev = rev
        _sync_take_collection(scene, takes)
        changed = True

    # A pull that never arrives must not leave every control disabled forever.
    # Stay paused (the user explicitly asked to inspect a take), but release the
    # transaction and explain what happened in the panel.
    if (
        state.applying_started_at is not None
        and time.monotonic() - state.applying_started_at >= 12.0
    ):
        _clear_take_apply("Take did not arrive — retry Apply")
        changed = True

    req = srv.take_bake_request()
    if req is not None:
        # Standalone/library takes are Apply operations.  Pause BEFORE baking,
        # stop any previous review, and freeze the exact visible transform. A
        # Blender-side pull already did this at button press; a phone-side Apply
        # reaches here after its reliable PAUSE and reuses the same path.
        if req.reanchor and state.apply_anchor_quat is None:
            _begin_take_apply(scene, req.name)
        anchor_quat = state.apply_anchor_quat if req.reanchor else None
        anchor_loc = state.apply_anchor_loc if req.reanchor else None
        apply_move_scale = state.apply_move_scale if req.reanchor else None
        bake_move_scale = (
            apply_move_scale
            if apply_move_scale is not None
            else state.record_move_scale
            if state.record_move_scale is not None
            else state.applied_move_scale
        )
        try:
            frames, fps, frame0 = record.bake_and_insert(
                req.samples, req.start_ns, req.end_ns, review=req.review, name=req.name,
                reanchor=req.reanchor, anchor_quat=anchor_quat, anchor_loc=anchor_loc,
                move_scale_override=apply_move_scale,
            )
        except Exception as exc:  # keep the timer alive; surface a recoverable error
            traceback.print_exc()
            if req.reanchor:
                _clear_take_apply(f"Could not apply take: {exc}")
                state.paused = True
            srv.notify_error("apply_failed" if req.reanchor else "bake_failed", str(exc))
            changed = True
            frames = 0
            fps = state.scene_fps_cache
            frame0 = scene.frame_current
        has_position = any(s.pos is not None for s in req.samples)
        if frames <= 0:
            if req.reanchor and state.apply_error is None:
                _clear_take_apply("Take contained no usable motion")
            srv.notify_error(
                "apply_failed" if req.reanchor else "bake_failed",
                "Take contained no usable motion",
            )
            changed = True
            if changed:
                _tag_view3d_redraw()
            return
        srv.notify_baked(
            frames, fps, received=len(req.samples), sent=req.sample_count,
            source=req.source, take_id=req.take_id,
        )
        if req.review:
            # A just-recorded or applied take shows on the camera: pause live,
            # jump to the take's start, play it back once, then hold for
            # scrubbing. "Start tracking" (phone Go-live / panel) resumes live
            # and detaches the take; the next Record does too.
            _finish_take_review(
                scene, frames, frame0, req.name, req.source, has_position,
                bake_move_scale,
            )
        # A take baked with review=False (e.g. an offline take arriving during
        # a live recording) becomes a named action without disturbing the live
        # drive; bake_and_insert already detached it and restored the pose.
        if req.reanchor:
            _clear_take_apply()
        changed = True

    if changed:
        _tag_view3d_redraw()


def _service_viewport(scene, srv) -> None:
    """One tick of viewport channel work, on the main thread.

    Everything here has to be on this thread: only it may ask Blender how large
    a region is, add or remove a draw handler, or drive a GPU draw.

    One mode: **camera** draws the scene camera into an offscreen buffer, from
    right here, tick by tick. Independent of what the operator is looking at, so
    they can work in another editor or another application entirely and the
    phone keeps showing the shot.
    """
    if srv.viewport_port is None:
        return

    # Real resolutions carrying the render's aspect, because an offscreen draw
    # can produce any size and barely cares which (viewport-channel.md section 3).
    render = scene.render
    # The pixels the render will actually produce, and the shape they are seen
    # in. Percentage first, because advertising more pixels than the camera
    # renders invents detail; pixel aspect second, because the finished image is
    # stretched by it and a viewfinder that is not shows the wrong proportions.
    percent = max(1, int(render.resolution_percentage)) / 100.0
    camera_sizes = viewport_stream.camera_sizes(
        int(render.resolution_x * percent),
        int(render.resolution_y * percent),
        render.pixel_aspect_x,
        render.pixel_aspect_y,
    )
    if camera_sizes != state.viewport_sizes_published:
        available, reason = viewport.encoder_available()
        srv.viewport_modes = ["camera"] if available else []
        srv.viewport_video = {
            "codecs": ["jpeg"] if available else [],
            "camera_sizes": camera_sizes,
            "max_fps": VIEWPORT_MAX_FPS,
        }
        state.viewport_sizes_published = camera_sizes
        if not available:
            state.viewport_error = reason

    request = srv.take_viewport_request()
    if request is not None:
        _apply_viewport_request(srv, request, camera_sizes)

    # The camera path has no draw handler to fire it, which is exactly why it
    # keeps working while Blender is minimised. It runs on this tick instead.
    if state.camera_capture is not None:
        state.camera_capture.tick()


def _apply_viewport_request(srv, request, camera_sizes) -> None:
    """Start, reconfigure or stop the stream (viewport-channel.md section 5.1)."""
    mode = str(request.get("mode", "off"))
    if mode == "off":
        _stop_viewport_capture()
        return
    if mode != "camera":
        # Named rather than ignored. A client asking for a mode this host does
        # not have should be told so, not left watching a stream that never
        # starts -- which is what silence looks like from the phone.
        srv.notify_error("viewport_unsupported", f"unsupported mode {mode!r}")
        return

    available, reason = viewport.encoder_available()
    if not available:
        state.viewport_error = reason
        srv.notify_error("viewport_unsupported", reason)
        return

    size = request.get("size")
    want = None
    if isinstance(size, list) and len(size) == 2:
        try:
            want = [int(size[0]), int(size[1])]
        except (TypeError, ValueError):
            want = None
    if want is not None and want not in camera_sizes:
        srv.notify_error("viewport_unsupported", f"size {size} was not advertised")
        return

    # A profile hands size selection to the host, which is the only party that
    # can see what a capture costs here. An unknown name is not an error: the
    # controller falls back to `balanced` rather than refusing a stream, because
    # a newer phone naming a profile this host has not heard of should still get
    # a picture (viewport-channel.md 5.1).
    profile = request.get("profile")
    profile = str(profile) if profile else None
    if want is None:
        # Absent means unchanged. A phone under a profile deliberately stops
        # sending a size -- the host owns it now -- so re-reading the largest
        # here would undo the controller's choice every time the operator
        # touched Quality.
        running = state.camera_capture
        if running is not None and running.active:
            want = [running.width, running.height]
        else:
            # Nothing running: start from the largest and let it settle down if
            # it must. Starting small and climbing would show a soft picture
            # first and then sharpen it, which reads as the stream struggling.
            want = camera_sizes[0] if camera_sizes else [960, 540]

    if state.camera_capture is None:
        state.camera_capture = viewport.CameraCapture(srv.viewport)
    # Absent means unchanged, not "off": a client that has never heard of this
    # field must not silently switch a preference the operator set.
    overlays = request.get("overlays")
    started = state.camera_capture.start(
        width=want[0],
        height=want[1],
        quality=int(request.get("quality", 75)),
        fps=float(request.get("fps", viewport.DEFAULT_FPS)),
        overlays=(
            bool(overlays) if overlays is not None
            else state.camera_capture.overlays
        ),
        profile=profile,
        sizes=camera_sizes,
    )
    if not started:
        srv.notify_error("viewport_unsupported", "camera capture could not start")


def _stop_viewport_capture() -> None:
    """Stop the stream. Safe when it is already idle."""
    if state.camera_capture is not None:
        state.camera_capture.stop()


def _fnum(v) -> Optional[float]:
    """JSON value -> float, None for junk (hostile input never raises)."""
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _sync_take_collection(scene, takes) -> None:
    """Rebuild scene.pocketrig_takes from the phone's reported library."""
    coll = getattr(scene, "pocketrig_takes", None)
    if coll is None:
        return
    coll.clear()
    for t in takes:
        item = coll.add()
        item.take_id = str(t.get("id", ""))
        item.take_name = str(t.get("name", "")) or item.take_id
        try:
            item.duration_s = float(t.get("duration_s", 0.0))
        except (TypeError, ValueError):
            item.duration_s = 0.0
        item.source = str(t.get("source", ""))
        try:
            item.samples = int(t.get("samples", 0))
        except (TypeError, ValueError):
            item.samples = 0
        try:
            item.position_samples = int(t.get("position_samples", -1))
        except (TypeError, ValueError):
            item.position_samples = -1
        item.sent = bool(t.get("sent", False))
    idx = getattr(scene, "pocketrig_takes_index", 0)
    scene.pocketrig_takes_index = min(idx, max(0, len(coll) - 1))


def _detach_camera_action(scene) -> None:
    """Stop driving the camera from its baked take (the take stays a fake-user
    data-block). Leaves the camera on the take's current-frame pose so a soft
    resume can continue from there without a jump."""
    cam = scene.camera
    if cam is not None:
        # Lens animation is a separate action on the camera DATA block; detaching
        # only the object action would leave a previous take's zoom still driving.
        record.detach_lens_take(cam)
    ad = cam.animation_data if cam is not None else None
    if ad is not None and ad.action is not None:
        # Detaching changes dependency-graph evaluation immediately and can
        # expose stale underlying object properties. Preserve the evaluated
        # transform explicitly so Go Live / repeated Apply never jumps.
        shown_loc = cam.location.copy()
        shown_rot = cam.rotation_quaternion.copy()
        ad.action = None
        cam.location = shown_loc
        cam.rotation_quaternion = shown_rot


def _begin_take_apply(scene, name: Optional[str] = None, take_id: Optional[str] = None) -> None:
    """Freeze the current camera framing and enter the Apply transaction.

    Called immediately by the Blender pull button, or on the first main-thread
    tick that receives a phone-pushed take. Live poses are ignored from this
    point; the frozen transform becomes frame zero of the applied take.
    """
    _set_playback(False)
    _detach_camera_action(scene)
    cam = _ensure_camera(scene)
    state.reviewing = False
    state.review_stop_frame = None
    state.paused = True
    state.pending_soft_resume = False
    state.applying_take_name = name or "take"
    state.applying_take_id = take_id
    state.applying_started_at = time.monotonic()
    state.apply_anchor_quat = cam.rotation_quaternion.copy()
    state.apply_anchor_loc = cam.location.copy()
    state.apply_move_scale = float(getattr(scene, "pocketrig_move_scale", 1.0))
    state.apply_error = None
    state.sent_paused = None


def _clear_take_apply(error: Optional[str] = None) -> None:
    state.applying_take_name = None
    state.applying_take_id = None
    state.applying_started_at = None
    state.apply_anchor_quat = None
    state.apply_anchor_loc = None
    state.apply_move_scale = None
    state.apply_error = error


def _finish_take_review(
    scene,
    frames: int,
    frame0: int,
    name: Optional[str],
    source: str,
    has_position: bool,
    move_scale: Optional[float] = None,
) -> None:
    """Attach/show a successful bake and enter the single review state."""
    state.last_bake_source = source
    state.last_take_name = name
    state.last_take_has_position = has_position
    state.last_take_move_scale = move_scale if has_position else None
    if bpy.app.background:
        return
    state.paused = True
    state.reviewing = True
    state.review_stop_frame = frame0 + frames - 1
    scene.frame_set(frame0)
    _set_playback(True)


def _go_live(scene) -> None:
    """Leave paused / showing-a-take and resume live tracking, continuing from
    the camera's current framing. Detaches any applied take so the animation
    system never fights the live drive."""
    _detach_camera_action(scene)
    state.reviewing = False
    state.paused = False
    state.pending_soft_resume = True
    _set_playback(False)


def _set_playback(active: bool) -> None:
    """Start/stop timeline playback. We do NOT call bpy.ops.screen.animation_play
    /animation_cancel: those manage a wmTimer, and toggling them from inside a
    bpy.app.timers callback null-dereferenced Blender's window/screen context and
    hard-crashed (EXCEPTION_ACCESS_VIOLATION in ED_screen_animation_play), most
    reliably when a take was applied twice. Instead _advance_playback() steps
    scene.frame_current from wall-clock in this same timer — fully in our control,
    crash-proof, and it stops exactly where we want. No-op headless (tests drive
    frames themselves)."""
    if bpy.app.background:
        return
    if active:
        if not state.playing:
            state.playing = True
            state.play_wall0 = time.monotonic()
            state.play_frame0 = bpy.context.scene.frame_current
    else:
        state.playing = False
        state.play_wall0 = None
        state.play_frame0 = None


def _advance_playback(scene) -> bool:
    """Move the playhead to match real-time playback while state.playing. Returns
    True if the frame changed (so the caller redraws). Clamped to the scene end;
    the auto-stop / review-stop logic decides when to actually stop."""
    if not state.playing or state.play_wall0 is None or bpy.app.background:
        return False
    fps = state.scene_fps_cache or 24.0
    elapsed = time.monotonic() - state.play_wall0
    frame = state.play_frame0 + int(round(elapsed * fps))
    if frame > scene.frame_end:
        frame = scene.frame_end
    if frame != scene.frame_current:
        scene.frame_set(frame)
        return True
    return False


def _tag_view3d_redraw() -> None:
    wm = bpy.context.window_manager
    if wm is None:
        return
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _timer_callback() -> Optional[float]:
    """Registered with bpy.app.timers; self-unregisters when the session
    stops. Never lets an exception kill the timer."""
    if state.server is None:
        return None
    try:
        apply_tick()
    except Exception:
        traceback.print_exc()
    return TICK_INTERVAL
