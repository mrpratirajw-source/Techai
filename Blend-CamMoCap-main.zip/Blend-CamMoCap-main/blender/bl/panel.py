# SPDX-License-Identifier: GPL-3.0-or-later
"""Operators + N-panel UI."""

from __future__ import annotations

import time

import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)

from ..core import takes as core_takes
from ..core import viewport_stream
from ..core.session import Server
from . import apply as apply_mod
from . import qr_ui, record, state, viewport


def _tracking_status_line():
    """One concise, actionable line for the phone's latest quality state."""
    quality = state.tracking_quality
    issue = state.tracking_issue
    if quality == "unknown":
        return None
    if quality == "good":
        return "6DOF tracking", "CHECKMARK"
    if quality == "warming":
        return "Finding position...", "TIME"
    if quality == "recovering":
        return "Recovering position...", "FILE_REFRESH"
    guidance = {
        "insufficient_features": "Point at a textured area",
        "insufficient_light": "More light needed",
        "excessive_motion": "Slow down — position held",
        "camera_unavailable": "Phone camera unavailable",
        "bad_state": "Tracking unavailable",
    }.get(issue, "Position held")
    return guidance, "ERROR"


class POCKETRIG_take_item(bpy.types.PropertyGroup):
    """One take in the phone's library (spec 5.11), mirrored for the UIList."""

    take_id: StringProperty()
    take_name: StringProperty()
    duration_s: FloatProperty()
    source: StringProperty()
    samples: IntProperty()
    position_samples: IntProperty(default=-1)
    sent: BoolProperty()


class POCKETRIG_UL_takes(bpy.types.UIList):
    """The phone's take library: name, length, source, delivered-state, with a
    name search."""

    def draw_item(self, context, layout, data, item, icon, active_data, active_prop):
        row = layout.row(align=True)
        row.label(
            text=item.take_name or item.take_id,
            icon="CHECKMARK" if item.sent else "RADIOBUT_OFF",
        )
        sub = row.row()
        sub.alignment = "RIGHT"
        sub.label(text=f"{item.duration_s:.1f}s")
        sub.label(text="6DOF" if item.position_samples > 0 else "Rotation")

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        search = getattr(context.scene, "pocketrig_take_search", "").lower()
        flt = []
        for it in items:
            visible = (not search) or search in (it.take_name or "").lower()
            flt.append(self.bitflag_filter_item if visible else 0)
        return flt, []

_HINT_AFTER_SECONDS = 15.0


class POCKETRIG_OT_connect(bpy.types.Operator):
    """Start the phone session: bind the UDP port and show the pairing QR"""

    bl_idname = "pocketrig.connect"
    bl_label = "Connect Phone"

    def execute(self, context):
        if state.server is not None:
            return {"CANCELLED"}
        state.reset()
        scene = context.scene
        state.scene_fps_cache = scene.render.fps / scene.render.fps_base
        server = Server(
            get_scene_fps=lambda: state.scene_fps_cache,
            host_version=bpy.app.version_string,
        )
        try:
            # Bind happens here, on the button click, so the OS firewall
            # prompt appears with user-action context.
            server.start()
        except OSError as exc:
            self.report({"ERROR"}, f"Could not bind UDP port: {exc}")
            return {"CANCELLED"}
        state.server = server
        state.server_started_at = time.monotonic()
        qr_ui.refresh(server)
        if not bpy.app.background:
            bpy.app.timers.register(apply_mod._timer_callback, first_interval=0.0)
        return {"FINISHED"}


class POCKETRIG_OT_disconnect(bpy.types.Operator):
    """Stop the phone session"""

    bl_idname = "pocketrig.disconnect"
    bl_label = "Disconnect"

    def execute(self, context):
        server = state.server
        if server is None:
            return {"CANCELLED"}
        state.server = None  # timer self-unregisters on its next tick
        server.stop()
        qr_ui.cleanup()
        state.reset()
        return {"FINISHED"}


class POCKETRIG_OT_pause(bpy.types.Operator):
    """Pause the live camera drive; resuming continues from the current
    framing (Re-center instead snaps back to home)"""

    bl_idname = "pocketrig.pause"
    bl_label = "Pause tracking"

    @classmethod
    def poll(cls, context):
        return state.server is not None and not (
            (state.server.busy if state.server else False)
            or state.applying_take_name is not None
        )

    def execute(self, context):
        if state.paused or state.reviewing:
            apply_mod._go_live(context.scene)  # detach any take, continue live
        else:
            state.paused = True
        return {"FINISHED"}


class POCKETRIG_OT_import_take(bpy.types.Operator):
    """Bake a .take file (an offline recording, spec 5.10) onto the camera —
    the same bake path a live take uses, so a file records identically"""

    bl_idname = "pocketrig.import_take"
    bl_label = "Import Take (.take)"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.take", options={"HIDDEN"})

    @classmethod
    def poll(cls, context):
        return state.server is None or (
            not state.server.busy and state.applying_take_name is None
        )

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        import json

        try:
            with open(self.filepath, "r", encoding="utf-8") as fh:
                lines = [ln for ln in (raw.strip() for raw in fh) if ln]
            if not lines:
                self.report({"ERROR"}, "Empty file")
                return {"CANCELLED"}
            header = json.loads(lines[0])
            if header.get("format") != "pocketrig-take":
                self.report({"ERROR"}, "Not a pocketrig .take file")
                return {"CANCELLED"}
            if len(lines) - 1 > core_takes.MAX_TAKE_ROWS:
                self.report({"ERROR"}, "Take is too large to import")
                return {"CANCELLED"}
            # Same validator as the network path: a corrupt row fails the import
            # with the line number instead of baking a non-finite transform.
            samples = []
            for number, ln in enumerate(lines[1:], start=2):
                try:
                    samples.append(core_takes.parse_row(json.loads(ln)))
                except (ValueError, json.JSONDecodeError) as exc:
                    self.report({"ERROR"}, f"Take is corrupt at line {number}: {exc}")
                    return {"CANCELLED"}
            if not samples:
                self.report({"ERROR"}, "Take has no samples")
                return {"CANCELLED"}
        except Exception as exc:  # noqa: BLE001 - report any parse failure
            self.report({"ERROR"}, f"Could not read take: {exc}")
            return {"CANCELLED"}

        start_ns = header.get("start_ns", samples[0][0])
        end_ns = header.get("end_ns", samples[-1][0])
        # A file may have been recorded under any phone tracking origin. Match
        # phone-library Apply: frame zero maps to the camera's current pose.
        take_name = header.get("name") if isinstance(header.get("name"), str) else None
        apply_mod._begin_take_apply(context.scene, take_name or "imported take")
        try:
            frames, fps, frame0 = record.bake_and_insert(
                samples, start_ns, end_ns, reanchor=True, name=take_name,
                anchor_quat=state.apply_anchor_quat,
                anchor_loc=state.apply_anchor_loc,
                move_scale_override=state.apply_move_scale,
            )
        except Exception as exc:  # noqa: BLE001 - recover UI state and report
            apply_mod._clear_take_apply(f"Could not apply take: {exc}")
            self.report({"ERROR"}, f"Could not apply take: {exc}")
            return {"CANCELLED"}
        has_position = any(s.pos is not None for s in samples)
        if frames > 0:
            apply_mod._finish_take_review(
                context.scene, frames, frame0, take_name, "offline", has_position,
                state.apply_move_scale,
            )
            apply_mod._clear_take_apply()
        else:
            apply_mod._clear_take_apply("Take contained no usable motion")
            self.report({"ERROR"}, "Take contained no usable motion")
            return {"CANCELLED"}
        self.report({"INFO"}, f"Baked {frames} frames @ {fps:g} fps")
        return {"FINISHED"}


class POCKETRIG_OT_refresh_takes(bpy.types.Operator):
    """Ask the phone for its current take library"""

    bl_idname = "pocketrig.refresh_takes"
    bl_label = "Refresh takes"

    @classmethod
    def poll(cls, context):
        return state.server is not None and (
            state.server.is_client_connected if state.server else False
        )

    def execute(self, context):
        state.server.request_take_list()
        return {"FINISHED"}


class POCKETRIG_OT_pull_take(bpy.types.Operator):
    """Download the selected take from the phone and bake it onto the camera"""

    bl_idname = "pocketrig.pull_take"
    bl_label = "Import selected"

    @classmethod
    def poll(cls, context):
        scene = context.scene
        srv = state.server
        return (
            srv is not None
            and srv.is_client_connected
            and not srv.busy  # can't apply while record/finalize is in flight
            and state.applying_take_name is None
            and 0 <= scene.pocketrig_takes_index < len(scene.pocketrig_takes)
        )

    def execute(self, context):
        scene = context.scene
        item = scene.pocketrig_takes[scene.pocketrig_takes_index]
        apply_mod._begin_take_apply(scene, item.take_name, item.take_id)
        state.server.request_take_pull(item.take_id)
        self.report({"INFO"}, f"Applying '{item.take_name}' from phone…")
        return {"FINISHED"}


class POCKETRIG_OT_recenter(bpy.types.Operator):
    """Re-capture the offset: the camera keeps its current framing and phone
    motion becomes relative to it"""

    bl_idname = "pocketrig.recenter"
    bl_label = "Re-center"

    @classmethod
    def poll(cls, context):
        return state.server is not None and not (
            (state.server.busy if state.server else False)
            or state.applying_take_name is not None
        )

    def execute(self, context):
        state.manual_recenter = True
        return {"FINISHED"}


class POCKETRIG_PT_panel(bpy.types.Panel):
    bl_label = "pocketrig"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "pocketrig"

    def draw(self, context):
        layout = self.layout
        server = state.server
        if server is None:
            col = layout.column()
            col.scale_y = 2.0
            col.operator("pocketrig.connect", icon="CAMERA_DATA")
            col.scale_y = 1.0
            layout.operator("pocketrig.import_take", icon="IMPORT")
            return

        icon_id = qr_ui.get_icon_id()
        if icon_id:
            layout.template_icon(icon_value=icon_id, scale=8.0)
        addr_text, code_text = qr_ui.get_pairing_text(server)
        box = layout.box()
        box.label(text=addr_text)
        box.label(text=code_text)

        if server.recording:
            row = layout.row()
            row.alert = True
            row.label(text="REC", icon="RECORD_ON")
        elif server.finalizing:
            layout.label(text="Finalizing take…", icon="TIME")
        elif state.applying_take_name is not None:
            layout.label(
                text=f"Applying: {state.applying_take_name}", icon="IMPORT"
            )
            layout.label(text="Live tracking paused — waiting for take")
            if state.apply_move_scale is not None:
                layout.label(text=f"Position scale: {state.apply_move_scale:g}x (locked)")
        elif state.apply_error:
            layout.label(text=state.apply_error, icon="ERROR")
        elif state.reviewing:
            col = layout.column(align=True)
            name = state.last_take_name or "take"
            col.label(text=f"Showing: {name}", icon="PLAY")
            col.label(
                text="6DOF (rotation + position)"
                if state.last_take_has_position else "Rotation only"
            )
            if state.last_take_move_scale is not None:
                col.label(text=f"Position scale: {state.last_take_move_scale:g}x")
            col.label(text="Scrub the timeline. Start tracking to go live")
        elif state.paused:
            col = layout.column(align=True)
            col.label(text="Paused — camera not tracking", icon="PAUSE")
            col.label(text="Start tracking to follow the phone")

        if server.is_client_connected:
            age = server.last_packet_age or 0.0
            if age < 1.0:
                status, icon = f"Connected: {server.client_name}", "CHECKMARK"
            else:
                status, icon = (
                    f"Connected: {server.client_name} ({age:.0f}s silent)",
                    "ERROR",
                )
            layout.label(text=status, icon=icon)
            tracking = _tracking_status_line()
            if tracking is not None:
                layout.label(text=tracking[0], icon=tracking[1])
        else:
            layout.label(text="Waiting for phone...", icon="TIME")
            started = state.server_started_at
            if (
                not state.ever_connected
                and started is not None
                and time.monotonic() - started > _HINT_AFTER_SECONDS
            ):
                hint = layout.column(align=True)
                hint.label(text="Phone can't connect?", icon="QUESTION")
                hint.label(text="Check firewall / same Wi-Fi")

        layout.operator("pocketrig.recenter", icon="ORIENTATION_GIMBAL")
        if state.reviewing:
            layout.operator("pocketrig.pause", text="Go live", icon="PLAY")
        elif state.paused:
            layout.operator("pocketrig.pause", text="Start tracking", icon="PLAY")
        else:
            layout.operator("pocketrig.pause", text="Pause tracking", icon="PAUSE")
        smooth = layout.column(align=True)
        smooth.prop(context.scene, "pocketrig_live_smoothing", slider=True)
        smooth.prop(context.scene, "pocketrig_record_smoothing", slider=True)
        scale_row = smooth.row(align=True)
        controls_busy = server.busy or state.applying_take_name is not None
        scale_row.enabled = not controls_busy
        scale_row.prop(context.scene, "pocketrig_move_scale", slider=True)
        shake_row = smooth.row(align=True)
        shake_row.enabled = not controls_busy
        shake_row.prop(
            context.scene, "pocketrig_shake_hold_dps",
            text="Shake hold (0 = off)", slider=True,
        )

        src_row = layout.row(align=True)
        src_row.enabled = not controls_busy
        src_row.prop(context.scene, "pocketrig_take_source", expand=True)

        # Take library (spec 5.11): browse the phone's takes, search, and pull
        # any of them on demand.
        if server.is_client_connected:
            box = layout.box()
            head = box.row(align=True)
            head.label(text="Phone takes", icon="SEQUENCE")
            head.operator("pocketrig.refresh_takes", text="", icon="FILE_REFRESH")
            takes = context.scene.pocketrig_takes
            if len(takes):
                box.prop(
                    context.scene, "pocketrig_take_search", text="", icon="VIEWZOOM"
                )
                box.template_list(
                    "POCKETRIG_UL_takes", "", context.scene, "pocketrig_takes",
                    context.scene, "pocketrig_takes_index", rows=4,
                )
                apply_row = box.row()
                apply_row.enabled = not server.busy and state.applying_take_name is None
                apply_row.operator(
                    "pocketrig.pull_take", text="Apply to camera", icon="IMPORT"
                )
            else:
                box.label(text="No takes on phone (or tap refresh)", icon="INFO")

        # Viewport stream (spec/viewport-channel.md). Status only: the phone
        # starts and stops it, because it is the thing that has to decode and
        # display the frames and only it knows whether it can.
        if server.viewport_port is not None:
            box = layout.box()
            box.label(text="Camera to phone", icon="SEQ_PREVIEW")
            stats = server.viewport.stats()
            capture = state.camera_capture
            if state.viewport_error:
                box.label(text=state.viewport_error, icon="ERROR")
            elif capture is not None and capture.active:
                drop = stats.get("drop_pct", 0.0)
                got = capture.achieved_fps
                want = capture.target_fps
                # Achieved against requested, always both. The requested rate
                # does not bind -- capture shares this thread with the viewport's
                # own redraw -- and a preview running at a third of its setting
                # with nothing saying so reads as a fault in the phone.
                limited = capture.limited_by
                if limited == "idle":
                    # Nothing has changed, so there is nothing to send. Saying
                    # "1 of 20 fps" against a parked rig reads as a fault.
                    box.label(text=f"Streaming, idle ({got:.1f} fps)", icon="CHECKMARK")
                elif limited == "loop":
                    # Not a fault and not fixable from the phone: a timer fires
                    # once per event-loop iteration, and that loop runs at the
                    # viewport's redraw rate. Naming the number stops the
                    # operator hunting for a setting that would change it.
                    loop = capture.loop_fps
                    box.label(
                        text=f"Streaming {got:.1f} of {want:.0f} fps", icon="INFO"
                    )
                    box.label(
                        text=f"this viewport redraws at {loop:.0f} fps",
                        icon="INFO",
                    )
                elif limited == "capture":
                    box.label(
                        text=f"Streaming {got:.1f} of {want:.0f} fps", icon="ERROR"
                    )
                    # Only said when capture really is the reason. A capture
                    # that does not fit one loop iteration stretches every
                    # iteration it lands in, and a smaller size is the fix --
                    # which is exactly why this must not be printed against a
                    # host whose loop is simply slow.
                    box.label(text="capture too slow for the set rate", icon="INFO")
                else:
                    box.label(
                        text=f"Streaming {got:.1f} of {want:.0f} fps", icon="CHECKMARK"
                    )
                found = viewport.find_view3d()
                if found is not None:
                    substitute = viewport_stream.drawable_shading(
                        found[2].shading.type, context.scene.render.engine
                    )
                    if substitute:
                        # Said here because this is where the operator is when
                        # they switch shading and the phone stops matching it.
                        # Without the line the picture simply looks wrong.
                        box.label(
                            text=f"{context.scene.render.engine.title()} cannot draw "
                                 "to the phone; showing Material",
                            icon="INFO",
                        )
                row = box.row(align=True)
                row.label(text=f"capture {capture.capture_ms:.1f} ms")
                row.label(text=f"encode {capture.encode_ms:.1f} ms")
                trip = server.viewport_latency_ms
                if trip is not None:
                    # Capture to on-screen, measured against our own clock at
                    # both ends, so it needs no synchronisation with the phone.
                    box.label(text=f"{trip:.0f} ms to the phone screen")
                if drop:
                    # Drops are the link failing to keep up, not a bug. Naming
                    # the number stops it being read as stutter of unknown cause.
                    box.label(text=f"{drop:g}% dropped (link)", icon="INFO")
            elif stats.get("connected"):
                box.label(text="Phone connected, not streaming", icon="PAUSE")
            else:
                box.label(text="Start from the phone", icon="INFO")

        layout.operator("pocketrig.import_take", text="Import .take file", icon="IMPORT")
        row = layout.row()
        row.scale_y = 0.9
        row.operator("pocketrig.disconnect", icon="X")


_CLASSES = (
    POCKETRIG_take_item,
    POCKETRIG_UL_takes,
    POCKETRIG_OT_connect,
    POCKETRIG_OT_disconnect,
    POCKETRIG_OT_import_take,
    POCKETRIG_OT_refresh_takes,
    POCKETRIG_OT_pull_take,
    POCKETRIG_OT_pause,
    POCKETRIG_OT_recenter,
    POCKETRIG_PT_panel,
)


def register() -> None:
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.pocketrig_live_smoothing = FloatProperty(
        name="Live smoothing",
        description="Smooths the live preview camera (0 = raw, most responsive). "
        "Adapts to motion, so fast moves stay snappy. Does not affect recordings",
        min=0.0,
        max=1.0,
        default=0.30,
    )
    bpy.types.Scene.pocketrig_record_smoothing = FloatProperty(
        name="Recording smoothing",
        description="Smooths the baked keyframes when you record (0 = raw). "
        "Independent of live smoothing; the raw take is kept so you can re-bake",
        min=0.0,
        max=1.0,
        default=0.15,
    )
    bpy.types.Scene.pocketrig_move_scale = FloatProperty(
        name="Position scale",
        description="Scales translation only; rotation is unchanged. Used "
        "for live 6DOF, recordings, and applied 6DOF takes. 1 = life-size; "
        "try 5-10 for desk motion or large scenes. The value is frozen when "
        "Record or Apply begins, and changing it never makes the camera jump",
        min=0.001,
        max=100.0,
        soft_min=0.1,
        soft_max=25.0,
        default=1.0,
    )
    bpy.types.Scene.pocketrig_shake_hold_dps = FloatProperty(
        name="Shake hold",
        description="Hold the camera's position while the phone rotates faster "
        "than this (deg/s). A visual tracker cannot see during a hard shake and "
        "invents translation, so holding is safer than following it; rotation "
        "keeps tracking either way. Set to 0 to switch the hold off entirely. "
        "Lower catches more shakes but starts firing on fast reframes - 300 is "
        "a 90-degree turn in a third of a second, which is a framing move",
        min=0.0,
        max=1200.0,
        soft_min=0.0,
        soft_max=1200.0,
        default=500.0,
    )
    bpy.types.Scene.pocketrig_take_source = EnumProperty(
        name="Take from",
        description="What a finished take is baked from. Offline: the phone's "
        "lossless full-rate local recording, uploaded after you stop - Wi-Fi "
        "glitches only ever hit the live preview, never the take. Live: the "
        "streamed poses (fallback / no upload)",
        items=[
            ("offline", "Offline (lossless)", "Bake the phone's local recording"),
            ("live", "Live stream", "Bake the streamed poses (fallback)"),
        ],
        default="offline",
    )
    bpy.types.Scene.pocketrig_takes = CollectionProperty(type=POCKETRIG_take_item)
    bpy.types.Scene.pocketrig_takes_index = IntProperty(default=0)
    bpy.types.Scene.pocketrig_take_search = StringProperty(
        name="Search", description="Filter takes by name", default=""
    )


def unregister() -> None:
    for prop in (
        "pocketrig_live_smoothing",
        "pocketrig_record_smoothing",
        "pocketrig_move_scale",
        "pocketrig_shake_hold_dps",
        "pocketrig_take_source",
        "pocketrig_takes",
        "pocketrig_takes_index",
        "pocketrig_take_search",
    ):
        if hasattr(bpy.types.Scene, prop):
            delattr(bpy.types.Scene, prop)
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
