# SPDX-License-Identifier: GPL-3.0-or-later
"""Bake a finished take into rotation_quaternion (and, for 6DOF takes,
location) keyframes."""

from __future__ import annotations

from typing import List, Optional, Sequence, Tuple

import bpy
from mathutils import Quaternion, Vector

from ..core import takes
from . import state

Vec3 = Tuple[float, float, float]

TAKE_PREFIX = "pocketrig Take"


def _next_take_name() -> str:
    n = 1
    while f"{TAKE_PREFIX} {n:02d}" in bpy.data.actions:
        n += 1
    return f"{TAKE_PREFIX} {n:02d}"


def _unique_action_name(base: str) -> str:
    """A collision-free action name from a user's take name (§5.11)."""
    base = base.strip() or _next_take_name()
    if base not in bpy.data.actions:
        return base
    n = 2
    while f"{base} ({n})" in bpy.data.actions:
        n += 1
    return f"{base} ({n})"


def _action_fcurves(owner, data_path: str) -> List:
    """F-curves for `data_path` on `owner`'s action, sorted by array_index.

    `owner` is any ID with animation_data: the camera OBJECT for transform
    channels, the camera DATA for lens.

    Covers both the flat `action.fcurves` API (Blender 4.5) and the layered
    slot/strip/channel-bag API (5.x).
    """
    ad = owner.animation_data
    action = ad.action if ad is not None else None
    if action is None:
        return []
    # Prefer the channel bag belonging to THIS owner's slot. From Blender 4.4 a
    # single Action can carry channels for several IDs in separate slots, and the
    # legacy flat `action.fcurves` view then reports another slot's curves --
    # which is how a camera-data lens curve became invisible while the object's
    # rotation curves were returned in its place.
    slot = getattr(ad, "action_slot", None)
    fcurves: List = []
    for layer in getattr(action, "layers", []):
        for strip in layer.strips:
            for bag in getattr(strip, "channelbags", []):
                if slot is not None and getattr(bag, "slot", None) != slot:
                    continue
                fcurves.extend(fc for fc in bag.fcurves if fc.data_path == data_path)
    if not fcurves:
        # Pre-4.4 actions have no layers at all.
        fcurves = [
            fc
            for fc in (getattr(action, "fcurves", None) or [])
            if fc.data_path == data_path
        ]
    return sorted(fcurves, key=lambda fc: fc.array_index)


def _fill_curves(owner, data_path: str, frame0: int, rows: Sequence) -> None:
    """Write one keyframe per row onto every channel of `data_path`, in bulk.

    `rows` are composed values (Quaternion or Vector); row i lands on frame
    frame0 + i. The curves must already exist with their first keyframe — see
    the caller — so this only grows and fills them.

    Values are written straight into the keyframe array with foreach_set rather
    than through keyframe_insert, which is two RNA round trips per frame and
    re-sorts the whole curve each time. Interpolation is copied from that first
    keyframe so the user's preference still applies; handles are recomputed by
    fc.update(). Every frame is keyed, so evaluation at integer frames does not
    depend on the handle shape anyway.
    """
    count = len(rows)
    if count <= 0:
        return
    for fc in _action_fcurves(owner, data_path):
        points = fc.keyframe_points
        existing = len(points)
        if existing == 0:
            continue  # nothing to copy interpolation from; caller seeds it
        interpolation = [0] * existing
        points.foreach_get("interpolation", interpolation)
        if count > existing:
            points.add(count - existing)
        index = fc.array_index
        flat = [0.0] * (count * 2)
        for i, row in enumerate(rows):
            flat[i * 2] = float(frame0 + i)
            flat[i * 2 + 1] = row[index]
        points.foreach_set("co", flat)
        points.foreach_set("interpolation", [interpolation[0]] * count)
        fc.update()


LENS_SUFFIX = " Lens"


def _camera_data_action_owner(cam):
    """The camera data-block that carries lens animation, or None."""
    data = getattr(cam, "data", None)
    return data if data is not None and hasattr(data, "lens") else None


def stash_existing_lens_take(cam) -> None:
    """Park any lens animation alongside its object take.

    Lens keyframes cannot live on the object's action: `lens` belongs to the
    camera DATA block, which has its own animation_data. Both have to be
    detached together, or applying a second take would leave the previous take's
    zoom still driving the lens.
    """
    data = _camera_data_action_owner(cam)
    ad = data.animation_data if data is not None else None
    if ad is None or ad.action is None:
        return
    shown = data.lens
    ad.action.use_fake_user = True
    ad.action = None
    data.lens = shown  # detaching exposes the underlying value; keep what was shown


def detach_lens_take(cam) -> None:
    """Stop driving the lens from a baked take, keeping the shown focal length."""
    stash_existing_lens_take(cam)


def stash_existing_take(cam) -> None:
    """Consecutive takes must never destroy earlier ones: park the camera's
    current action under a numbered name with a fake user (so it survives
    save/reload) and detach it. Called at RECORD START (a still-attached
    action would be evaluated by play-during-record and fight the live
    stream — the "camera flies to old keyframes" bug) and again defensively
    before the bake writes."""
    ad = cam.animation_data
    if ad is None or ad.action is None:
        return
    # Preserve the evaluated pose visible at the current frame. Detaching an
    # Action can expose the object's underlying transform immediately; without
    # restoring these values, the next live pose anchors against hidden stale
    # data and the camera appears to fly away at record start.
    shown_loc = cam.location.copy()
    shown_rot = cam.rotation_quaternion.copy()
    action = ad.action
    action.use_fake_user = True
    if not action.name.startswith(TAKE_PREFIX):
        action.name = _next_take_name()
    ad.action = None
    cam.location = shown_loc
    cam.rotation_quaternion = shown_rot


def bake_and_insert(
    samples: Sequence[Tuple[int, Tuple[float, float, float, float], Optional[Vec3]]],
    start_ns: int,
    end_ns: int,
    review: bool = True,
    name: Optional[str] = None,
    reanchor: bool = False,
    anchor_quat: Optional[Quaternion] = None,
    anchor_loc: Optional[Vector] = None,
    move_scale_override: Optional[float] = None,
) -> Tuple[int, float, int]:
    """Resample the take at scene fps and keyframe the driven camera starting
    at the current frame. Keyframed values are offset-composed (the camera
    space the operator saw live), hemisphere-aligned along the whole take so
    the four F-curves never jump. Samples that carry position also produce
    location keyframes through the same offsets frozen at record time.

    With reanchor=True (a take applied from the library) the take lives in a
    foreign tracking origin, so the live offsets are meaningless for it: the
    take is re-anchored so its first baked sample maps to the camera's current
    pose and the motion plays out relative to wherever the camera is, instead
    of teleporting to the phone's old tracking origin. move_scale_override is
    the position scale frozen when Apply began; it affects translation only.

    With review=False (an auto-uploaded / imported take) the baked action is
    detached after baking so it does not fight the live drive — it lives on as
    a fake-user data-block the user can apply from the Action editor.
    Returns (frame_count, fps, first_keyed_frame)."""
    scene = bpy.context.scene
    fps = scene.render.fps / scene.render.fps_base
    smoothing = float(getattr(scene, "pocketrig_record_smoothing", 0.0))
    rot_samples = [(s.t, s.q) for s in samples]
    quats: List = takes.bake(rot_samples, start_ns, end_ns, fps, smoothing)
    if not quats:
        state.record_frame_start = None
        state.record_q_offset = None
        state.record_loc_offset = None
        state.record_move_scale = None
        state.record_camera_quat = None
        state.record_camera_loc = None
        return 0, fps, scene.frame_current

    focal_samples = [(s.t, s.focal_mm) for s in samples]
    focals: List[float] = takes.bake_focal(focal_samples, start_ns, end_ns, fps)
    pos_samples = [(s.t, s.pos) for s in samples]
    positions: List[Vec3] = []
    if any(pos is not None for _ts, pos in pos_samples):
        positions = takes.bake_segmented_positions(
            pos_samples, start_ns, end_ns, fps, smoothing
        )

    from . import apply as apply_mod  # local import: no cycle at module load

    cam = apply_mod._ensure_camera(scene)
    stash_existing_take(cam)
    # Unconditionally, even when this take has no zoom: otherwise a take shot at
    # a fixed lens would keep playing the PREVIOUS take's zoom. Record start
    # stashes too, but Apply and .take import reach the baker without it.
    stash_existing_lens_take(cam)
    move_scale = (
        move_scale_override
        if move_scale_override is not None
        else state.record_move_scale
        if state.record_move_scale is not None
        else state.applied_move_scale
    )
    if state.record_q_offset is not None:
        offset = state.record_q_offset
    elif state.record_camera_quat is not None:
        offset = state.record_camera_quat @ Quaternion(quats[0]).inverted()
    else:
        offset = state.q_offset if state.q_offset is not None else Quaternion()
    if state.record_loc_offset is not None:
        loc_offset = state.record_loc_offset
    elif state.record_camera_loc is not None and positions:
        loc_offset = state.record_camera_loc - move_scale * (
            offset @ Vector(positions[0])
        )
    else:
        loc_offset = state.loc_offset if state.loc_offset is not None else cam.location.copy()
    state.record_q_offset = None
    state.record_loc_offset = None
    state.record_move_scale = None
    state.record_camera_quat = None
    state.record_camera_loc = None
    # Bake where recording STARTED, not wherever the playhead rolled to
    # (play-during-record moves it during the take).
    frame0 = (
        state.record_frame_start
        if state.record_frame_start is not None
        else scene.frame_current
    )
    state.record_frame_start = None
    # Keyframing below walks the camera through the take; remember where the
    # live stream has it so ending a take never teleports the view.
    live_loc = cam.location.copy()
    live_rot = cam.rotation_quaternion.copy()

    if reanchor and quats:
        # Applied from the library: discard the live offsets and anchor the
        # take to the camera's current pose. take_offset maps the take's first
        # baked orientation onto live_rot; loc_offset then places the first
        # baked position onto live_loc. Frame 0 becomes exactly the camera's
        # current pose (no fly-away); every later frame is relative to it, in
        # the home frame — the positional twin of re-center (spec §5/§6).
        target_rot = anchor_quat.copy() if anchor_quat is not None else live_rot
        target_loc = anchor_loc.copy() if anchor_loc is not None else live_loc
        q0 = Quaternion(quats[0])
        offset = target_rot @ q0.inverted()
        if positions:
            loc_offset = target_loc - move_scale * (offset @ Vector(positions[0]))
        else:
            loc_offset = target_loc.copy()

    # Compose every keyed value first, then write the curves in bulk.
    # keyframe_insert() per frame per channel does a sorted insert into a
    # growing array, so cost grows with the square of the take length: a
    # 5-minute 60 fps take took 22 s and locked the UI for all of it.
    composed_rots: List[Quaternion] = []
    prev: Quaternion | None = None
    for q in quats:
        composed = offset @ Quaternion(q)
        if prev is not None and prev.dot(composed) < 0:
            composed.negate()
        composed_rots.append(composed)
        prev = composed
    composed_locs: List[Vector] = []
    if positions:
        composed_locs = [
            loc_offset + move_scale * (offset @ Vector(p)) for p in positions
        ]

    # One keyframe_insert per data_path creates the action, slot, channel bag
    # and F-curves the way this Blender version expects, and honours the user's
    # default interpolation. Everything after that is filled in bulk.
    cam.rotation_quaternion = composed_rots[0]
    cam.keyframe_insert(data_path="rotation_quaternion", frame=frame0)
    if composed_locs:
        cam.location = composed_locs[0]
        cam.keyframe_insert(data_path="location", frame=frame0)

    _fill_curves(cam, "rotation_quaternion", frame0, composed_rots)
    if composed_locs:
        _fill_curves(cam, "location", frame0, composed_locs)

    # Lens (spec 4.5). Keyframed on the camera DATA block, which owns `lens` and
    # has its own action: a zoom performed during the take has to survive into it,
    # or the lens control would only work live. Focal length is absolute, so it
    # needs none of the re-anchoring the transform does -- a 35 mm lens is 35 mm
    # wherever the camera ends up.
    cam_data = _camera_data_action_owner(cam)
    if focals and cam_data is not None:
        live_lens = cam_data.lens
        # A DEDICATED action, not whatever keyframe_insert would pick. Left to
        # itself it files the lens into the object's action as a second slot,
        # where the legacy flat curve view returns the object's rotation curves
        # instead and the lens curve is silently unreachable. An own action also
        # gives the operator something named they can see and manage.
        base = _unique_action_name(name) if name else _next_take_name()
        cam_data.animation_data_create()
        cam_data.animation_data.action = bpy.data.actions.new(
            f"{base}{LENS_SUFFIX}"
        )
        cam_data.lens = focals[0]
        cam_data.keyframe_insert(data_path="lens", frame=frame0)
        _fill_curves(cam_data, "lens", frame0, [(f,) for f in focals])
        cam_data.lens = live_lens
        lens_ad = cam_data.animation_data
        if lens_ad is not None and lens_ad.action is not None:
            lens_ad.action.use_fake_user = True
            if not review:
                lens_ad.action = None
                cam_data.lens = live_lens

    cam.location = live_loc
    cam.rotation_quaternion = live_rot

    ad = cam.animation_data
    if ad is not None and ad.action is not None:
        ad.action.name = _unique_action_name(name) if name else _next_take_name()
        ad.action.use_fake_user = True
        if not review:
            # Imported / auto-uploaded: keep the take as a data-block but leave
            # the camera on its live pose, undisturbed by the animation system.
            ad.action = None
    # A take longer than the scene must stay scrubbable: grow the range.
    last_frame = frame0 + len(quats) - 1
    if last_frame > scene.frame_end:
        scene.frame_end = last_frame
    return len(quats), fps, frame0
