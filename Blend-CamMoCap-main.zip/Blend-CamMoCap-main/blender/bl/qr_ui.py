# SPDX-License-Identifier: GPL-3.0-or-later
"""QR pairing image + plain-text fallback (spec/protocol.md section 9).

segno is imported lazily inside refresh() so headless tests never require
the wheel; if it is unavailable the panel simply shows the text pairing row.
"""

from __future__ import annotations

import os
import platform
import socket
import tempfile
from typing import Optional, Tuple
from urllib.parse import quote

import bpy
import bpy.utils.previews

_ICON_KEY = "pocketrig_qr"
_pcoll = None
_cached_ip: Optional[str] = None


def get_lan_ip() -> str:
    """LAN-facing IP via the UDP connect trick (no packet is sent)."""
    global _cached_ip
    if _cached_ip is not None:
        return _cached_ip
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 80))
        _cached_ip = sock.getsockname()[0]
    except OSError:
        _cached_ip = "127.0.0.1"
    finally:
        sock.close()
    return _cached_ip


def build_uri(host: str, port: int, token: str, name: str) -> str:
    return (
        f"pocketrig://connect?v=1&host={host}&port={port}"
        f"&token={token}&name={quote(name, safe='')}"
    )


def refresh(server) -> None:
    """(Re)render the pairing QR PNG for the given server and load it as a
    preview icon. Failure is non-fatal: the text row still pairs."""
    global _pcoll, _cached_ip
    cleanup()
    _cached_ip = None  # network may have changed since last session
    try:
        import segno  # lazy: bundled wheel in Blender, absent in headless CI
    except ImportError:
        return
    uri = build_uri(get_lan_ip(), server.port, server.token, platform.node() or "host")
    png_dir = bpy.app.tempdir or tempfile.gettempdir()
    png_path = os.path.join(png_dir, "pocketrig_qr.png")
    try:
        segno.make(uri, error="m").save(png_path, scale=6, border=2)
        _pcoll = bpy.utils.previews.new()
        _pcoll.load(_ICON_KEY, png_path, "IMAGE")
    except Exception:
        cleanup()


def get_icon_id() -> int:
    """Preview icon id for template_icon(), or 0 when no QR is loaded."""
    if _pcoll is None:
        return 0
    preview = _pcoll.get(_ICON_KEY)
    return preview.icon_id if preview is not None else 0


def get_pairing_text(server) -> Tuple[str, str]:
    """("192.168.x.x:47800", "code: ABCDEF") for the manual-entry row."""
    return f"{get_lan_ip()}:{server.port}", f"code: {server.token}"


def cleanup() -> None:
    global _pcoll
    if _pcoll is not None:
        try:
            bpy.utils.previews.remove(_pcoll)
        except Exception:
            pass
        _pcoll = None
