# SPDX-License-Identifier: GPL-3.0-or-later
"""Module-level runtime state shared by the bl layer. All access happens on
Blender's main thread (timer callbacks / operators); the Server object it
holds does its own locking."""

from __future__ import annotations

from typing import Optional

from mathutils import Quaternion, Vector

from ..core.filters import OneEuroQuat, OneEuroVec3

# Live session (core.session.Server) or None when stopped.
server = None

# Live smoothing (display only, never touches the recorded take). Reset on
# connect and re-center so the camera snaps crisply, then eases.
live_filter = OneEuroQuat()
disp_quat: Optional[Quaternion] = None  # last displayed (possibly smoothed) pose
# Position twin: filters the RAW protocol position (before offset/scale) so
# movement scale never amplifies ARCore's noise floor.
live_pos_filter = OneEuroVec3()

# Re-center offset: camera = q_offset @ q_protocol. None until first capture.
q_offset: Optional[Quaternion] = None

# "Home" framing captured at connect (the camera's orientation before we start
# driving it). Re-center snaps the camera back to this, so the button has a
# visible, useful effect instead of re-zeroing in place. None until connect.
home_quat: Optional[Quaternion] = None
home_loc: Optional[Vector] = None

# 6DOF (spec/coordinate-systems.md section 6): cam_loc = loc_offset +
# scale * (q_offset @ p_pose). loc_offset is None until anchored against a
# pose that carries position; None also means "re-anchor at the camera's
# current location on the next positional pose" (no-jump rule).
loc_offset: Optional[Vector] = None
applied_move_scale: float = 1.0  # the scale loc_offset was computed with

# Last APPLIED positional pose (protocol frame), for the section-6 host
# guards: a timestamp gap or an impossible jump between consecutive applied
# positions means the tracker restarted/relocalized -> re-anchor, never jump.
last_pos: Optional[Vector] = None
last_pos_ts: Optional[int] = None

# Last applied protocol pose (hemisphere reference + dedup by seq).
last_seq: Optional[int] = None
last_pose_quat: Optional[Quaternion] = None
# Smoothed angular speed, for the shake-hold gate only. The raw single-frame
# figure stays in use for the teleport guard, which is looking for exactly the
# one-frame spike this average is designed to suppress.
shake_dps: float = 0.0
# Timestamp of the last applied pose, for angular speed. Deliberately separate
# from last_pos_ts: that one only advances on POSITIONAL poses, so using it here
# made the divisor grow through a tracking-loss run and under-reported angular
# speed exactly when a recovering visual tracker is most likely to jump.
last_pose_ts: Optional[int] = None

# Last focal length written to the camera data (mm). None until the phone drives
# the lens; used to avoid re-writing an unchanged value every tick, which would
# dirty the dependency graph at the timer rate for nothing.
last_focal_mm: Optional[float] = None

# Latest phone-reported 6DOF acquisition state. "unknown" is backward
# compatible with rotation-only and pre-quality senders.
tracking_quality = "unknown"
tracking_issue = "none"

# Recording edge detection on the main thread: the tick that first sees
# recording pins the bake frame (the playhead may roll during the take —
# play-during-record) and starts/stops timeline playback.
was_recording = False
record_frame_start: Optional[int] = None
record_prev_frame: Optional[int] = None  # wrap/end detection for auto-stop
host_stop_requested = False  # auto-stop asked the phone; awaiting its STOP
# Immutable record-start mapping. Live offsets may re-anchor through a quality
# gap while rolling; baking must still use the mapping the operator started in.
record_q_offset: Optional[Quaternion] = None
record_loc_offset: Optional[Vector] = None
record_move_scale: Optional[float] = None
record_camera_quat: Optional[Quaternion] = None
record_camera_loc: Optional[Vector] = None

# Timeline playback is driven by OUR timer advancing scene.frame_current from
# wall-clock — NOT bpy.ops.screen.animation_play. That operator manages a
# wmTimer, and toggling it from inside a bpy.app.timers callback dereferenced a
# null window/screen and hard-crashed Blender (EXCEPTION_ACCESS_VIOLATION in
# ED_screen_animation_play), especially when a take was applied twice. Our own
# stepping is crash-proof and stops exactly on the target frame.
playing = False
play_wall0: Optional[float] = None  # time.monotonic() when playback started
play_frame0: Optional[int] = None  # scene.frame_current when playback started

# Review mode: after a take bakes, the live drive pauses and Blender plays
# the take back once — scrub freely; Re-center or the next Record resumes
# live. Never entered in background mode (headless tests keep driving).
reviewing = False
review_stop_frame: Optional[int] = None
last_bake_source: Optional[str] = None  # "offline" | "live" — for the panel
last_take_name: Optional[str] = None  # name of the take being shown
last_take_has_position = False
last_take_move_scale: Optional[float] = None

# Applying a library take is a small transaction, not just a file transfer.
# The visible camera pose is frozen when Apply begins and is the anchor used
# by the baker when the upload eventually arrives.  This closes the old race
# where live tracking kept moving during transfer and silently changed the
# placement of the take.
applying_take_name: Optional[str] = None
applying_take_id: Optional[str] = None
applying_started_at: Optional[float] = None
apply_anchor_quat: Optional[Quaternion] = None
apply_anchor_loc: Optional[Vector] = None
# Position scale belongs to the Apply transaction just like its pose anchor.
# Freeze it at button press so transfer latency or a stale live anchor cannot
# change the resulting camera motion.
apply_move_scale: Optional[float] = None
apply_error: Optional[str] = None

# Take library (spec 5.11): the revision last synced into the scene collection,
# so apply_tick only rebuilds the UIList when the phone's list actually changed.
take_list_rev = -1

# Manual pause (spec 5.8): live drive suspended without ending the session.
# Resuming re-anchors BOTH offsets against the current pose (soft resume) so
# the camera continues from where it is — the operator may have moved.
paused = False
pending_soft_resume = False
# A phone display/source/lifecycle boundary. The next raw pose is rebased
# against the currently visible camera without changing the user's Home.
pending_frame_rebase = False
sent_paused = None  # last pause state pushed to the phone (None = push next)

# One-shot flags consumed by apply_tick().
manual_recenter = False
pending_auto_recenter = False

# Auto-recenter on the first pose of each pairing ("no setup ritual").
# Headless tests disable it via set_offset_identity_for_test().
auto_recenter_enabled = True
seen_hello_count = 0
seen_pairing_count = 0

# Scene fps cache: read on the main thread, handed to the session thread via
# the injected get_scene_fps callable (never touch bpy off-thread).
scene_fps_cache = 24.0

# For the "phone can't connect?" hint row.
server_started_at: Optional[float] = None
ever_connected = False

# Viewport capture (spec/viewport-channel.md). Held here rather than created per
# tick because it owns a draw handler and an encode thread, and a leaked one
# keeps capturing into a stream nobody is reading.
#: The camera capture. Held here rather than created per tick because it owns a
#: GPU offscreen buffer and an encode thread, and a leaked one keeps drawing the
#: scene into a stream nobody is reading.
camera_capture = None
#: Last size list published in WELCOME, so the tick only republishes on change.
viewport_sizes_published = None
#: Last viewport ceiling pushed in PARAMS. Held rather than recomputed because
#: it is deliberately sticky: the measurement is only valid while the stream is
#: working, so an idle period must keep the last good figure instead of
#: replacing it with a free-running event loop's rate.
viewport_max_fps_published = None
viewport_error = None

# Last (live, record, move_scale) tuple pushed to / received from the phone
# (spec 5.7 mirror). None forces a full push (fresh pairing).
synced_params = None


def reset() -> None:
    global server, q_offset, home_quat, last_seq, last_pose_quat, last_pose_ts
    global shake_dps
    global manual_recenter
    global pending_auto_recenter, auto_recenter_enabled, seen_hello_count
    global seen_pairing_count
    global scene_fps_cache, server_started_at, ever_connected, disp_quat
    global home_loc, loc_offset, applied_move_scale, last_pos, last_pos_ts
    global was_recording, record_frame_start, pending_frame_rebase
    global record_q_offset, record_loc_offset, record_move_scale
    global record_camera_quat, record_camera_loc
    global tracking_quality, tracking_issue, last_focal_mm
    server = None
    q_offset = None
    home_quat = None
    home_loc = None
    loc_offset = None
    applied_move_scale = 1.0
    last_pos = None
    last_pos_ts = None
    live_filter.reset()
    live_pos_filter.reset()
    disp_quat = None
    last_seq = None
    last_pose_quat = None
    shake_dps = 0.0
    last_pose_ts = None
    tracking_quality = "unknown"
    tracking_issue = "none"
    last_focal_mm = None
    global record_prev_frame, reviewing, review_stop_frame
    global paused, pending_soft_resume, sent_paused
    global host_stop_requested, last_bake_source, last_take_has_position
    global last_take_move_scale
    global applying_take_name, applying_take_id, applying_started_at
    global apply_anchor_quat, apply_anchor_loc, apply_move_scale, apply_error
    global playing, play_wall0, play_frame0
    was_recording = False
    record_frame_start = None
    record_q_offset = None
    record_loc_offset = None
    record_move_scale = None
    record_camera_quat = None
    record_camera_loc = None
    record_prev_frame = None
    host_stop_requested = False
    playing = False
    play_wall0 = None
    play_frame0 = None
    reviewing = False
    review_stop_frame = None
    last_bake_source = None
    last_take_has_position = False
    last_take_move_scale = None
    applying_take_name = None
    applying_take_id = None
    applying_started_at = None
    apply_anchor_quat = None
    apply_anchor_loc = None
    apply_move_scale = None
    apply_error = None
    global take_list_rev, last_take_name
    last_take_name = None
    take_list_rev = -1
    paused = False
    pending_soft_resume = False
    pending_frame_rebase = False
    sent_paused = None
    manual_recenter = False
    pending_auto_recenter = False
    auto_recenter_enabled = True
    seen_hello_count = 0
    seen_pairing_count = 0
    global synced_params
    global camera_capture, viewport_sizes_published, viewport_error
    global viewport_max_fps_published
    if camera_capture is not None:
        camera_capture.stop()
    camera_capture = None
    viewport_sizes_published = None
    viewport_max_fps_published = None
    viewport_error = None
    scene_fps_cache = 24.0
    server_started_at = None
    ever_connected = False
    synced_params = None


def set_offset_identity_for_test() -> None:
    """Test hook: pin q_offset to identity and disable auto-recenter so
    headless conformance tests compare camera quats against raw protocol
    values (auto-recenter-on-connect would otherwise fight them)."""
    global q_offset, auto_recenter_enabled, pending_auto_recenter
    q_offset = Quaternion()  # identity
    auto_recenter_enabled = False
    pending_auto_recenter = False
