# SPDX-License-Identifier: GPL-3.0-or-later
"""The viewport frame server. No bpy — desktop-testable, like the rest of core/.

Owns the TCP listener that carries pixels (spec/viewport-channel.md §2), and
nothing else: capture belongs to the bl layer because it needs a GPU context and
Blender's main thread, and encoding belongs wherever the frame came from. This
takes finished bytes and gets them onto a socket, or drops them.

**Drop, never queue.** The one rule this module exists to enforce. A viewport
frame is state, not an event: only the latest matters, and a queue converts a
bandwidth problem into a latency one — the operator ends up watching a smooth
stream of stale pictures, which is worse than a gap because it looks correct.
The pose path has lived by the same rule since v1 for the same reason.

Measured, the sender blocked for 0.07 ms at p95 at the operating point, so the
drop path should almost never fire on a healthy link. It exists for the other
kind.
"""

from __future__ import annotations

import socket
import threading
import time
from typing import Callable, Dict, List, Optional, Tuple

from . import protocol
from .constants import (
    VIEWPORT_PORT,
    VIEWPORT_PORT_RANGE_END,
)

#: Frames wait no longer than this for the socket to accept them. A viewfinder
#: frame that is one interval late is already worth less than the next one.
SEND_TIMEOUT_S = 0.05

#: How many un-reported frames to keep stamps for. A conformant client need never
#: send VIEWPORT_STAT at all (§5.2), so this must be bounded rather than trusted.
_MAX_PENDING_STAMPS = 64

#: Connections the kernel may hold while we are busy accepting.
#:
#: This was 1, which turned any momentary delay into a lasting outage. A client
#: whose connect times out abandons a connection that is still queued here; the
#: host later accepts it and waits AUTH_TIMEOUT_S for a token that will never
#: arrive, and with a backlog of one every retry in that window is refused. Each
#: refusal produces another abandoned connection, so it sustains itself and only
#: a restart clears it. Observed twice against a phone whose 3 s connect timeout
#: is shorter than the 5 s this host was prepared to wait.
LISTEN_BACKLOG = 8

#: How long a viewport connection may sit unauthenticated. The token arrives in
#: the first line; a peer that never sends one is not a client.
#:
#: **This MUST NOT block other connections**, which is why authentication runs
#: off the accept loop. It is longer than any client's connect timeout on
#: purpose -- a slow phone deserves the grace -- and that is precisely why one
#: silent peer must not be able to spend it on everyone else's behalf.
AUTH_TIMEOUT_S = 5.0


def configure_listener(sock: socket.socket) -> None:
    """Set the address-reuse option that means what we want on this platform.

    `SO_REUSEADDR` does not mean the same thing on Windows as it does on POSIX.
    On POSIX it lets a listener rebind a port still in `TIME_WAIT`, which is
    what a host restarting wants. On Windows it lets a **second process bind a
    port another process is already listening on** -- closer to POSIX's
    `SO_REUSEPORT`, and with no restriction at all. Both binds succeed, only one
    of them ever receives a connection, and the other advertises a port that
    silently swallows every client.

    That is not hypothetical. Two Blender instances left running produced exactly
    it: the second reported `viewport_port` 47810, listed a listener on
    0.0.0.0:47810, and every connection from the phone timed out.

    So Windows gets `SO_EXCLUSIVEADDRUSE`, which is Microsoft's documented
    option for servers: the second bind fails loudly, `start()` returns None,
    WELCOME omits the port, and the client never chases it. POSIX keeps
    `SO_REUSEADDR`, where it is both correct and wanted.
    """
    if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):  # Windows only
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
    else:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)


def silence_udp_connreset(sock: socket.socket) -> None:
    """Stop Windows reporting ICMP Port Unreachable on a UDP socket.

    On Windows, sending a datagram to a host that is no longer listening makes
    the OS raise `ConnectionResetError` (WSAECONNRESET, 10054) from the **next**
    `recvfrom` on that socket -- not from the send that caused it. POSIX does not
    report ICMP errors on an unconnected UDP socket at all, so code written and
    tested there treats any `OSError` from `recvfrom` as "the socket is closed"
    and stops reading.

    For this host that is severe: the phone walks out of range, the next ACK or
    parameter push bounces, and the receive loop exits. Blender still looks
    connected and never hears another pose until the server is restarted.

    `SIO_UDP_CONNRESET` is Microsoft's documented switch for exactly this. The
    loop also guards the exception, because this ioctl is not available
    everywhere and one of the two must be enough on its own.
    """
    if not hasattr(socket, "SIO_UDP_CONNRESET"):  # not Windows
        return
    try:
        sock.ioctl(socket.SIO_UDP_CONNRESET, False)
    except OSError:
        pass  # the loop guard is the fallback


class ViewportStream:
    """Accepts one viewport connection and pushes frames at it.

    One connection at a time, deliberately. A second viewer would double the
    bandwidth and halve the frame budget for the operator actually holding the
    phone, and the product pairs exactly one phone per session anyway (spec
    §8).
    """

    def __init__(
        self,
        token_check: Callable[[str], bool],
        port: Optional[int] = None,
    ) -> None:
        self._token_check = token_check
        self._requested_port = port
        self._sock: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None
        self._running = threading.Event()
        self._lock = threading.Lock()

        self.port: Optional[int] = None
        self._conn: Optional[socket.socket] = None
        self._peer: Optional[Tuple[str, int]] = None

        #: Counts frames PRODUCED, not sent. A dropped frame still advances it,
        #: or the receiver cannot tell "the host skipped one" from "the network
        #: lost one" (spec/viewport-channel.md §4).
        self._ordinal = 0

        self.frames_sent = 0
        self.frames_dropped = 0
        #: Connections that went wrong between handshake and accept. Ordinary on
        #: a flaky link; fatal only if the loop treats them as the end.
        self.accepts_failed = 0
        #: ordinal -> capture_ns, for the round trip in §4. Bounded, because a
        #: client that never reports must not grow this without limit, and a
        #: report older than a second is not a latency figure anyone wants.
        self._stamps: Dict[int, int] = {}
        self.bytes_sent = 0
        self._last_send_ms = 0.0

    # ------------------------------------------------------------------ API

    def start(self) -> Optional[int]:
        """Bind and start accepting. Returns the port, or None on failure.

        Failure is not fatal anywhere: WELCOME simply omits `viewport_port` and
        the client never attempts a connection, exactly as the take listener
        degrades (spec §5.2).

        A port is returned only when this process genuinely owns it -- see
        `configure_listener` for why that needed saying out loud on Windows.
        """
        if self._running.is_set():
            return self.port
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        configure_listener(sock)
        bound = None
        candidates = (
            [self._requested_port]
            if self._requested_port is not None
            else range(VIEWPORT_PORT, VIEWPORT_PORT_RANGE_END + 1)
        )
        for candidate in candidates:
            try:
                sock.bind(("0.0.0.0", candidate))
                bound = sock.getsockname()[1]
                break
            except OSError:
                continue
        if bound is None:
            sock.close()
            return None

        sock.listen(LISTEN_BACKLOG)
        sock.settimeout(0.5)
        self._sock = sock
        self.port = bound
        self._running.set()
        self._thread = threading.Thread(
            target=self._accept_loop, name="pocketrig-viewport", daemon=True
        )
        self._thread.start()
        return bound

    def note_presented(self, ordinal: int) -> Optional[float]:
        """A frame reached the screen. Returns its round trip in ms, or None.

        **This crosses no clock boundary**, which is the whole reason §4 makes
        `ordinal` and `capture_ns` mandatory: the host stamps with its own clock,
        the phone echoes only the ordinal back, and the host subtracts against
        the same clock. The phone's own timestamps are in its clock domain and
        are not comparable here.

        None means the ordinal is unknown -- too old, or from a previous
        connection -- which is not an error and must not be reported as latency.
        """
        with self._lock:
            captured = self._stamps.pop(ordinal, None)
            # Everything older is now unreachable: reports arrive in order and a
            # skipped one is a dropped frame, not a pending measurement.
            for older in [k for k in self._stamps if k < ordinal]:
                del self._stamps[older]
        if captured is None:
            return None
        return (time.perf_counter_ns() - captured) / 1e6

    def stop(self) -> None:
        self._running.clear()
        self._close_conn()
        if self._sock is not None:
            try:
                self._sock.close()
            except OSError:
                pass
            self._sock = None
        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None
        self.port = None

    @property
    def connected(self) -> bool:
        with self._lock:
            return self._conn is not None

    def peer_port(self) -> Optional[int]:
        """Source port of the active viewer, or None.

        Exposed because "is anyone connected" cannot distinguish a viewer that
        has just been replaced from the one replacing it, which is exactly the
        distinction a reconnect turns on.
        """
        with self._lock:
            return self._peer[1] if self._peer else None

    def stats(self) -> Dict[str, object]:
        with self._lock:
            total = self.frames_sent + self.frames_dropped
            return {
                "connected": self._conn is not None,
                "peer": self._peer[0] if self._peer else None,
                "frames_sent": self.frames_sent,
                "frames_dropped": self.frames_dropped,
                "drop_pct": (
                    round(self.frames_dropped / total * 100.0, 1) if total else 0.0
                ),
                "bytes_sent": self.bytes_sent,
                "last_send_ms": round(self._last_send_ms, 3),
                "ordinal": self._ordinal,
            }

    def send_frame(
        self, payload: bytes, capture_ns: int, width: int = 0, height: int = 0
    ) -> bool:
        """Send one encoded frame. Returns False if it was dropped.

        Never blocks for longer than [SEND_TIMEOUT_S]. The ordinal advances
        either way, which is what lets the receiver tell a host-side skip from a
        network loss.
        """
        with self._lock:
            conn = self._conn
            ordinal = self._ordinal
            self._ordinal += 1
        if conn is None:
            return False

        header = protocol.encode_viewport_frame_header(
            ordinal, capture_ns, len(payload), width=width, height=height
        )
        started = time.perf_counter()
        try:
            conn.settimeout(SEND_TIMEOUT_S)
            conn.sendall(header + payload)
        except (socket.timeout, OSError):
            # A timeout here means the link cannot keep up. Dropping is the
            # correct response, not a failure -- but a socket that has already
            # buffered part of a frame is no longer at a frame boundary, so the
            # connection has to go rather than resynchronise.
            with self._lock:
                self.frames_dropped += 1
            self._close_conn()
            return False

        elapsed_ms = (time.perf_counter() - started) * 1000.0
        with self._lock:
            self.frames_sent += 1
            self.bytes_sent += len(payload) + len(header)
            self._last_send_ms = elapsed_ms
            # Stamped only once it is actually away. A dropped frame never
            # reaches a screen, so it has no round trip to wait for and would
            # sit in here forever.
            self._stamps[ordinal] = capture_ns
            if len(self._stamps) > _MAX_PENDING_STAMPS:
                for old in sorted(self._stamps)[:-_MAX_PENDING_STAMPS]:
                    del self._stamps[old]
        return True

    # ------------------------------------------------------------ internals

    def _close_conn(self) -> None:
        with self._lock:
            conn, self._conn, self._peer = self._conn, None, None
            # Ordinals restart per connection, so a stamp from the old one would
            # be matched against a different frame entirely.
            self._stamps.clear()
        if conn is not None:
            try:
                conn.close()
            except OSError:
                pass

    def _accept_loop(self) -> None:
        """Accept, and hand each connection straight off to be authenticated.

        The loop must never do work that a peer can make slow. Authenticating
        inline meant one connection that opened and said nothing stalled every
        other for AUTH_TIMEOUT_S, which with the old backlog of 1 was an outage
        that fed itself.
        """
        sock = self._sock
        assert sock is not None
        while self._running.is_set():
            try:
                conn, addr = sock.accept()
            except socket.timeout:
                continue
            except OSError:
                # Only stop() closes the listener, and it clears the flag first.
                # Anything else is one connection going wrong, not the end of
                # the socket: a peer that resets between the handshake and our
                # accept raises ConnectionAbortedError here (WSAECONNABORTED),
                # which is an OSError, and treating that as fatal killed the
                # accept loop for good. The kernel then completed handshakes
                # into the backlog with nobody accepting them, so the port
                # looked open, `nc` connected and received nothing, and every
                # client timed out once the backlog filled. Exactly the bug the
                # UDP recv loop had, missed here because the sweep looked for
                # socket options rather than loops that die on any error.
                if not self._running.is_set():
                    break
                self.accepts_failed += 1
                continue
            threading.Thread(
                target=self._admit,
                args=(conn, addr),
                name="pocketrig-viewport-auth",
                daemon=True,
            ).start()

    def _admit(self, conn: socket.socket, addr) -> None:
        """Authenticate one connection and, if it is good, make it the viewer."""
        try:
            if not self._authenticate(conn):
                conn.close()
                return
        except Exception:  # noqa: BLE001 - hostile input must not kill a thread
            try:
                conn.close()
            except OSError:
                pass
            return
        if not self._running.is_set():
            conn.close()
            return
        # A new viewer replaces the old one rather than being refused: a phone
        # that reconnected after a Wi-Fi blip would otherwise be locked out by
        # its own dead socket until the session ended.
        self._close_conn()
        conn.settimeout(SEND_TIMEOUT_S)
        with self._lock:
            self._conn = conn
            self._peer = addr
            self._ordinal = 0

    def _authenticate(self, conn: socket.socket) -> bool:
        """One newline-terminated token line, matching the take upload's shape.

        Same threat model as the rest of the protocol (spec §9): honest LAN-grade
        access control, not cryptography. A wrong token gets no reply at all, so
        a scanner learns nothing from the difference.
        """
        conn.settimeout(AUTH_TIMEOUT_S)
        buffer = b""
        # One byte at a time is fine here and nowhere else: the line is under
        # 128 bytes and this no longer runs on the accept loop, so its slowness
        # costs only the connection being authenticated.
        while len(buffer) < 128:
            chunk = conn.recv(1)
            if not chunk:
                return False
            if chunk == b"\n":
                break
            buffer += chunk
        return self._token_check(buffer.decode("utf-8", "replace").strip())


#: Sizes camera mode offers. Real resolutions, not decimation steps.
#:
#: The deleted framebuffer path could only divide the operator's viewport by
#: whole numbers, so it had to advertise whatever decimation happened to yield.
#: An offscreen draw has no such constraint, and the draw itself barely moves --
#: 0.74 ms at 1158x798 against 0.73 ms at 480x330, being priced by scene rather
#: than pixels. Readback and packing do scale, but gently: 2.1 ms to 5.0 ms
#: across six times the pixels. So the list is chosen for phone screens and
#: framing, not for what capture can afford.
CAMERA_SIZES: List[List[int]] = [[1280, 720], [960, 540], [640, 360]]


def camera_sizes(render_width: int, render_height: int,
                 pixel_aspect_x: float = 1.0,
                 pixel_aspect_y: float = 1.0) -> List[List[int]]:
    """Camera-mode sizes, matched to the shape the render is actually seen in.

    The viewfinder MUST have the render's aspect. A 16:9 list against a 4:3
    render would letterbox the phone against a frame the camera is not actually
    shooting, which for an instrument used to judge framing is a correctness bug
    rather than a cosmetic one.

    **The render's aspect is not its resolution's aspect.** Pixels are square
    only by default: a non-square `pixel_aspect` stretches the finished image
    without changing the pixel count. This function ignored that, and a frame
    sweep caught it against Blender's own `Camera.view_frame` -- at a 2:1 pixel
    aspect the shot is 2.902 wide and the advertised list said 1.451, so the
    operator would have been framing against proportions off by a factor of two.
    Anamorphic and some broadcast formats are exactly this.

    [render_width] and [render_height] are the pixels the render will actually
    produce, so a caller applying a resolution percentage must apply it before
    calling: advertising more pixels than the camera renders would be inventing
    detail that is not in the shot.

    Both axes are capped, not just width. Stretching along Y makes the frame
    taller than it is wide, and deriving height from an uncapped width would
    then invent rows for the same reason an uncapped width invents columns.
    """
    if render_width <= 0 or render_height <= 0:
        return [list(s) for s in CAMERA_SIZES]
    scale_x = pixel_aspect_x if pixel_aspect_x > 0 else 1.0
    scale_y = pixel_aspect_y if pixel_aspect_y > 0 else 1.0
    aspect = (render_width * scale_x) / (render_height * scale_y)
    out = []
    for width, _height in CAMERA_SIZES:
        w = min(width, render_width)
        h = max(1, int(round(w / aspect)))
        if h > render_height:
            h = render_height
            w = max(1, int(round(h * aspect)))
        # Even dimensions: odd sizes are a portability hazard the moment a
        # chroma-subsampled codec joins the list, and cost nothing to avoid.
        pair = [max(2, w - (w % 2)), max(2, h - (h % 2))]
        if pair not in out:
            out.append(pair)
    return out


def pack_rgb(pixels, step: int) -> Tuple[bytes, int, int]:
    """Flip, decimate and drop alpha if there is any. Returns (payload, w, h).

    Lives here, away from the `gpu` call that feeds it, so it can be tested at
    all -- and next to `advertised_sizes`, because the two MUST agree on the
    size decimation yields or the host advertises a frame it never sends.
    This is where both of the bugs that shipped garbage to the phone lived.

    **The flip is not cosmetic.** A framebuffer readback starts at the bottom
    left, so row 0 is the bottom of the picture and an unflipped frame arrives
    upside down.

    Dimensions are read **off the array** rather than computed. `1585 // 2` is
    792 but numpy's `[::2]` yields 793, and a receiver told the wrong width
    reshapes garbage — that mismatch silently corrupted an early lab corpus.
    [step] is 1 for every caller today, the decimating path having been
    deleted. It stays because a mode that renders large and ships small is the
    obvious next use, and because the tests that pin the flip use it.
    """
    import numpy as np

    # One indexing pass does the flip and the decimation together; the copy
    # below is the only pass over the pixels.
    array = pixels[::-step, ::step] if step > 1 else pixels[::-1]
    # Drop alpha only if the caller brought any. Measured, slicing it off costs
    # 2.24 ms at 1158x798 -- 20% of the whole capture -- because it turns a
    # contiguous row-reversed copy into a strided one. An offscreen draw
    # composites against the world background and returns a solid 255, so the
    # channel was never worth reading; `capture_camera_rgb` now asks the
    # framebuffer for three and this branch is what lets both shapes through.
    if array.shape[2] > 3:
        array = array[:, :, :3]
    packed = np.ascontiguousarray(array)
    return packed.tobytes(), packed.shape[1], packed.shape[0]


def drawable_shading(shading: str, engine: str) -> Optional[str]:
    """What to draw the viewfinder with, or None to use what the view has.

    `draw_view3d` into an offscreen renders **synchronously, once**. Blender's
    own engines cooperate with that: EEVEE and Workbench draw the frame and it
    is there when the call returns. Cycles does not -- its viewport render is
    progressive, accumulated by the engine into buffers of its own over many
    samples -- so a one-shot offscreen draw comes back with the world background
    and nothing in it.

    Measured, and it is not subtle: the same camera at the same size gives a
    full render under EEVEE and a flat 63/255 fill under Cycles. With overlays
    suppressed, as a viewfinder wants them, the fill is pure black. That is the
    whole of the "Rendered makes the stream go black" report.

    So Rendered is honoured only for engines that draw when asked. Everything
    else falls back to Material Preview, which is EEVEE, is synchronous, and is
    the closest thing to what the operator was looking at. A viewfinder that
    shows the shot in the wrong shading is useful; one that shows black is not.

    The test is the `BLENDER_` prefix rather than a list of engine names,
    because it has to give the right answer for engines that did not exist when
    it was written. Blender's built-ins are `BLENDER_EEVEE*` and
    `BLENDER_WORKBENCH`; Cycles ships as `CYCLES`, and third-party path tracers
    are progressive for the same reason Cycles is. Guessing wrong in this
    direction costs accuracy; guessing wrong in the other costs the picture.
    """
    if shading != "RENDERED":
        return None
    return None if engine.startswith("BLENDER_") else "MATERIAL"


#: What share of one event-loop iteration each profile lets capture fill.
#:
#: A share of the *iteration*, not of the second, because that is the quantity
#: with a consequence. The loop is paced by the viewport's redraw; capture that
#: fits inside an iteration lands in time the loop spends waiting anyway, and
#: capture that overruns stretches every iteration it touches -- which is the
#: only way this feature can make Blender feel slow.
#:
#: Measured on the reference host, one iteration is 33.3 ms and capture is
#: 9-17 ms depending on size, so `balanced` keeps the largest size and `light`
#: steps down. Rate is deliberately not a lever: 20 fps costs the same share of
#: the main thread as 30 and returns a third fewer frames.
CAPTURE_PROFILES: Dict[str, float] = {
    "light": 0.35,
    "balanced": 0.65,
    "smooth": 0.90,
}

#: Smoothing on the cost estimate the controller steers by.
#:
#: Slow on purpose. A single capture at one size has measured anywhere between
#: 9.4 and 23.9 ms across runs, so a controller reacting to the last frame would
#: change the operator's resolution at random.
_COST_SMOOTHING = 0.15

#: How long a chosen size must stand before another change is allowed.
#:
#: Changing size reallocates the offscreen and visibly re-scales the phone's
#: picture, so it is a change the operator sees. Rare and decisive beats
#: responsive.
_DWELL_S = 4.0

#: Consecutive evaluations that must agree before acting. With the dwell above
#: this is deliberately belt and braces: the cost estimate is smoothed, held for
#: seconds, and then still has to be wrong twice running.
_AGREE = 2

#: Observations at a new size before its cost is worth quoting as a reference.
#:
#: The first capture after a size change reallocates the offscreen and reads
#: high, and the smoothing above needs a second or so to converge. Taking the
#: reference from the first sample inflates it, which makes the "has the scene
#: got lighter" test below fire on nothing at all -- measured on the real host,
#: that put `light` into a slow oscillation between two sizes and cost it the
#: whole saving it was asked for.
_SETTLE_SAMPLES = 30

#: How much cheaper the current size must get before a size that overran is
#: tried again.
#:
#: The alternative is a timer, and a timer answers the wrong question. A size
#: was abandoned because it did not fit *this* scene; the thing that should
#: bring it back is evidence that the scene changed, not the clock running out.
#: Without either, a test caught the controller deadlocking -- the reading that
#: condemned a size was never refreshed, because the only way to refresh it was
#: to use the size it had condemned.
_LIGHTER_SCENE = 0.7


class CaptureBudget:
    """Picks the size that fills, but does not overrun, one loop iteration.

    A hill-climb over the sizes the host advertises, steered by what capture
    actually measured at the size it is on. It deliberately carries **no cost
    model**: it never predicts what an unvisited size would cost, it moves one
    step and looks. A model would need constants, and the constants would be the
    reference machine's -- which is the mistake this class exists to stop the
    operator having to make on their own machine.

    Rate is not a lever here, and that is measured rather than assumed: asking
    for 20 fps costs the same share of the main thread as asking for 30 and
    returns a third fewer frames, because captures spaced further apart each
    cost more. Size is the control that moves cost, so size is what this moves.

    Bpy-free, like `CapturePacer` beside it, because the half of this feature
    that can be tested is the half that decides things.
    """

    def __init__(self, sizes, profile: str = "balanced") -> None:
        #: Largest first, matching `camera_sizes`.
        self.sizes: List[Tuple[int, int]] = [tuple(s) for s in sizes]
        self.profile = profile if profile in CAPTURE_PROFILES else "balanced"
        self._index = 0
        self._cost_s: Dict[Tuple[int, int], float] = {}
        self._interval_s = 0.0
        self._last_change = 0.0
        self._votes = 0
        self._direction = 0
        #: Sizes that overran and have not earned another try.
        self._blocked: set = set()
        #: What the size we stepped down to cost once it settled. The yardstick
        #: for "has the scene got lighter since".
        self._cost_when_blocked: Optional[float] = None
        self._settling = 0
        #: Set once the smallest size still does not fit. Nothing left to give.
        self.at_floor = False

    @property
    def size(self) -> Optional[Tuple[int, int]]:
        return self.sizes[self._index] if self.sizes else None

    # ---------------------------------------------------------------- inputs

    def observe(self, now: float, size, capture_s: float,
                loop_interval_s: float) -> None:
        """One capture happened. Feeds the estimate this steers by."""
        if capture_s <= 0 or loop_interval_s <= 0:
            return
        key = tuple(size)
        previous = self._cost_s.get(key)
        self._cost_s[key] = (
            capture_s if previous is None
            else previous + (capture_s - previous) * _COST_SMOOTHING
        )
        self._interval_s = loop_interval_s
        if key in self.sizes:
            self._index = self.sizes.index(key)
        if self._cost_when_blocked is None and self._blocked:
            self._settling += 1
            if self._settling >= _SETTLE_SAMPLES:
                self._cost_when_blocked = self._cost_s[key]

    # --------------------------------------------------------------- output

    def choose(self, now: float):
        """The size to move to, or None to stay where we are.

        Returns None far more often than not: a size change is visible on the
        phone and reallocates a GPU buffer, so it has to be earned.
        """
        if not self.sizes or self._interval_s <= 0:
            return None
        cost = self._cost_s.get(self.sizes[self._index])
        if cost is None:
            return None

        budget = CAPTURE_PROFILES[self.profile] * self._interval_s
        if cost > budget:
            want = 1  # too expensive: smaller
        elif self._fits_larger(cost, budget):
            want = -1  # room to spare: larger
        else:
            want = 0

        if want <= 0:
            # Fitting, or wanting more: either way we are not out of room, and
            # a stale "at floor" would have the phone reporting a scene as
            # hopeless while the stream is meeting its budget.
            self.at_floor = False
        if want == 0 or not self._can_move(want):
            self._votes = 0
            self._direction = 0
            return None
        if want != self._direction:
            self._direction = want
            self._votes = 1
            return None
        self._votes += 1
        if self._votes < _AGREE or now - self._last_change < _DWELL_S:
            return None

        if want > 0:
            self._blocked.add(self.sizes[self._index])
            # Filled once the new size's estimate has settled, which is the
            # figure "has it got lighter since" is measured against. Not from
            # the first sample: that one pays for reallocating the offscreen.
            self._cost_when_blocked = None
            self._settling = 0
        self._index += want
        self._last_change = now
        self._votes = 0
        self._direction = 0
        return self.sizes[self._index]

    # -------------------------------------------------------------- helpers

    def _can_move(self, want: int) -> bool:
        index = self._index + want
        if 0 <= index < len(self.sizes):
            return True
        # Off the small end means even the smallest size overruns an iteration.
        # Say so rather than thrash: the operator can see it, and no setting
        # this class owns will fix it.
        self.at_floor = want > 0
        return False

    def _fits_larger(self, cost: float, budget: float) -> bool:
        """Is there room to step up, on evidence rather than on a guess?"""
        if self._index == 0:
            return False
        larger = self.sizes[self._index - 1]
        if larger not in self._blocked:
            return True
        # It overran before. Only the scene getting materially cheaper is a
        # reason to think it would not again -- and when it has, every block
        # goes, because one lighter scene invalidates all of them at once.
        reference = self._cost_when_blocked
        if reference is not None and cost < reference * _LIGHTER_SCENE:
            self._blocked.clear()
            self._cost_when_blocked = None
            self._settling = 0
            return True
        return False


#: Window for the achieved-rate and loop-rate figures. Long enough to be steady,
#: short enough that changing size or rate shows up within a second or two.
RATE_WINDOW_S = 3.0

#: Longest a viewer may sit on the same picture while nothing is changing.
#:
#: Change detection catches the camera exactly and the depsgraph approximately;
#: viewport shading is the obvious gap, and anything that alters the image
#: without ever being evaluated is another. This bounds how stale the phone can
#: get when something slips through, at one draw per second on a parked rig.
IDLE_KEEPALIVE_S = 1.0

#: Below this many samples the loop rate is a guess, so pacing does not use it.
_MIN_LOOP_SAMPLES = 8

#: Recent capture costs kept, for the reported figure and for the "is the loop
#: slow because of us" question. Short: capture cost tracks what the operator is
#: doing on the PC, so a long window would report a condition that has passed.
_COST_SAMPLES = 8


class CapturePacer:
    """Decides whether this tick should capture, and says why when it does not.

    Carved out of `CameraCapture.tick` for the same reason `pack_rgb` was carved
    out of the capture call: the `gpu` half cannot be tested at all -- drawing
    raises under `--background` -- so anything that can live without bpy must,
    or it ships untested. Both of the bugs that halved the stream's frame rate
    lived in the four lines this class replaces, and neither had a test.

    **The host cannot capture faster than its own event loop.** A
    `bpy.app.timers` callback fires once per loop iteration, and the loop is
    locked to the viewport's redraw rate whenever the viewport redraws -- 30 Hz
    measured, against the 120 Hz the tick asks for, and 175 Hz when nothing is
    redrawing at all. So the requested rate is a ceiling on a ceiling, and a
    period that is not a whole number of loop intervals cannot be delivered.
    This snaps to what is achievable and reports what it snapped to, rather than
    missing the request silently.

    **A capture's own depsgraph evaluation is not a scene change.**
    `capture_camera_rgb` calls `evaluated_depsgraph_get()`, which fires the
    handler that feeds `note_change`. The boolean this replaces was then cleared
    at the end of the same tick, so the next tick always saw "nothing changed"
    while the camera was visibly moving: measured, 256 captures against 256
    idle skips, one for one, costing exactly half the frame rate. Snapshotting a
    *counter* after the capture returns absorbs our own evaluation without
    swallowing anyone else's.

    The camera is tracked separately, by the transform the tick writes rather
    than by any handler, so live pose motion is exact and needs no evaluation to
    be noticed. Parented, driven and constrained cameras are not in that
    transform at all, which is what the counter is still for.
    """

    def __init__(self, target_fps: float = 20.0,
                 keepalive_s: float = IDLE_KEEPALIVE_S) -> None:
        self.target_fps = float(target_fps)
        self.keepalive_s = float(keepalive_s)

        self._changes = 0
        self._changes_at_capture = -1
        self._camera_at_capture: Optional[tuple] = None

        self._tick_times: List[float] = []
        self._capture_times: List[float] = []
        self._capture_costs: List[float] = []
        self._next_due: Optional[float] = None
        self._last_sent = 0.0

        self.skipped_gate = 0
        self.skipped_idle = 0
        self.skipped_busy = 0
        #: Idle skips since the last capture. Non-zero means a low rate is the
        #: scene standing still, not the host falling behind, and only the host
        #: can tell those apart.
        self._idle_since_capture = 0

    # ------------------------------------------------------------- observation

    def observe_tick(self, now: float) -> None:
        """One capture opportunity happened. Call every tick, before deciding.

        Counted even when the tick goes on to skip, because this measures the
        *loop*, not the stream -- and the loop is the ceiling.
        """
        self._tick_times.append(now)
        cutoff = now - RATE_WINDOW_S
        while self._tick_times and self._tick_times[0] < cutoff:
            self._tick_times.pop(0)

    def note_change(self) -> None:
        """Something in the scene was evaluated. Must stay trivial.

        Fed by `depsgraph_update_post`, which fires often. It counts rather than
        latching, so a capture can tell updates that predate it from updates
        that followed it -- including the one it caused itself.
        """
        self._changes += 1

    # ---------------------------------------------------------------- decision

    def should_capture(self, now: float, camera_key: Optional[tuple],
                       busy: bool) -> str:
        """"" to capture, otherwise the reason not to.

        Order matters. The rate gate comes first because it is the cheapest and
        the most often true; `busy` comes before the change check so a frame
        still in flight does not consume the change that would have justified
        the next one.
        """
        if self._next_due is not None and now < self._next_due - self._slack():
            self.skipped_gate += 1
            return "gate"
        if busy:
            # The previous frame is still encoding or sending. Capturing again
            # spends main-thread time on a picture that will be replaced, and
            # takes it straight out of the operator's own interactivity.
            self.skipped_busy += 1
            self._idle_since_capture = 0
            return "busy"
        if not self._changed(camera_key) and (now - self._last_sent) < self.keepalive_s:
            self.skipped_idle += 1
            self._idle_since_capture += 1
            return "idle"
        return ""

    def note_captured(self, now: float, camera_key: Optional[tuple],
                      cost_s: float = 0.0) -> None:
        """A frame was drawn. Call AFTER the capture returns, never before.

        After, because the capture's own `evaluated_depsgraph_get` fires the
        change handler part-way through: snapshotting the counter here absorbs
        it. Nothing genuine can be lost to the delay -- bpy is single-threaded,
        so no other change can land while the draw is running.

        [cost_s] is what the capture took, and it is here rather than in the
        caller's statistics because it is the only way to tell "the loop is
        slow" from "the loop is slow *because of us*". Those want opposite
        advice: nothing on the phone fixes the first, and a smaller size fixes
        the second.
        """
        self._changes_at_capture = self._changes
        self._camera_at_capture = camera_key
        self._last_sent = now
        self._idle_since_capture = 0
        if cost_s > 0:
            self._capture_costs.append(cost_s)
            del self._capture_costs[:-_COST_SAMPLES]

        self._capture_times.append(now)
        cutoff = now - RATE_WINDOW_S
        while self._capture_times and self._capture_times[0] < cutoff:
            self._capture_times.pop(0)

        period = self._effective_period()
        if self._next_due is None or self._next_due < now - period:
            # First frame, or so far behind that stepping the deadline forward
            # would fire a catch-up burst. Resync instead: the frames are gone
            # and sending four at once does not bring them back.
            self._next_due = now + period
        else:
            self._next_due += period

    # ----------------------------------------------------------------- figures

    @property
    def loop_fps(self) -> float:
        """How often the host's event loop offers us a chance, per second.

        The real ceiling, and it is not ours to raise: timers fire once per
        iteration and the iteration is the viewport's redraw.
        """
        if len(self._tick_times) < 2:
            return 0.0
        span = self._tick_times[-1] - self._tick_times[0]
        return (len(self._tick_times) - 1) / span if span > 0 else 0.0

    @property
    def achieved_fps(self) -> float:
        if len(self._capture_times) < 2:
            return 0.0
        span = self._capture_times[-1] - self._capture_times[0]
        return (len(self._capture_times) - 1) / span if span > 0 else 0.0

    @property
    def capture_ms(self) -> float:
        """Mean capture cost over the last few frames.

        A mean rather than the newest sample, which is what this used to report
        and what made a sweep across sizes unreadable: consecutive captures of
        the same scene at the same size measured 9.7 ms and 27.9 ms, so a single
        value said nothing about either the size or the rate it was recorded
        under. It is also what the panel prints, where a figure that jumps by 3x
        between redraws reads as instability rather than as sampling.
        """
        return self._capture_cost_s() * 1000.0

    @property
    def effective_fps(self) -> float:
        """The rate actually being aimed at, once the loop has had its say.

        Reported because it is often not the rate that was asked for, and a
        control that silently means something else is worse than one with a
        coarser scale.
        """
        period = self._effective_period()
        return 1.0 / period if period > 0 else 0.0

    @property
    def limited_by(self) -> Optional[str]:
        """Why the achieved rate is below the requested one, or None.

        Three answers, and telling them apart is the whole point. `idle` is the
        change detector doing its job on a parked rig -- reporting "1 of 20 fps"
        against that reads as a fault. `loop` is the host's event loop, which no
        setting on the phone can raise, so offering a smaller size against it
        would be advice that cannot work. `capture` is us being too slow, which
        is the only one of the three a smaller size does help.
        """
        if self.target_fps <= 0 or self.achieved_fps >= self.target_fps * 0.8:
            return None
        if self._idle_since_capture:
            return "idle"
        interval = self._loop_interval()
        if interval > 0 and self._capture_cost_s() >= interval * 0.9:
            # The loop is slow, and we are why: a capture that does not fit in
            # an iteration stretches every iteration it lands in.
            return "capture"
        aim = self.effective_fps
        if aim > 0 and self.achieved_fps >= aim * 0.8:
            # Delivering everything the loop allows, just not what was asked.
            return "loop"
        return "capture"

    # ----------------------------------------------------------------- helpers

    def _changed(self, camera_key: Optional[tuple]) -> bool:
        if self._changes_at_capture < 0:
            return True  # nothing drawn yet, so anything is a change
        if camera_key != self._camera_at_capture:
            return True
        return self._changes != self._changes_at_capture

    def _loop_interval(self) -> float:
        loop = self.loop_fps
        if loop <= 0 or len(self._tick_times) < _MIN_LOOP_SAMPLES:
            return 0.0
        return 1.0 / loop

    def _capture_cost_s(self) -> float:
        if not self._capture_costs:
            return 0.0
        return sum(self._capture_costs) / len(self._capture_costs)

    def _slack(self) -> float:
        """How early a capture may fire to hit a loop boundary.

        Half an interval, and it is what makes a rate the loop cannot divide
        come out right *on average*. A 50 ms period against a 33.3 ms loop can
        only ever fire at 33.3 or 66.7; with the deadline carried forward and
        this slack it alternates between them and averages the 20 fps that was
        asked for. Without it every deadline rounds up to 66.7 and the request
        for 20 quietly becomes 15.

        The unevenness is real and is the right trade: a viewfinder answers
        "where is the camera pointing", and 33/67 alternation is invisible in
        that job where losing a quarter of the frames is not.
        """
        return self._loop_interval() / 2.0

    def _effective_period(self) -> float:
        """The requested period, floored at one loop interval.

        Asking for more than the loop can offer is not an error and must not be
        treated as one -- a phone cannot know what the host's viewport redraw
        rate is, and that rate changes with what the operator is doing. It is
        clamped here so `effective_fps` reports something true, and the excess
        shows up as `limited_by == "loop"` rather than as a permanent shortfall
        with no stated cause.
        """
        period = 1.0 / self.target_fps if self.target_fps > 0 else 0.0
        interval = self._loop_interval()
        if interval <= 0 or period <= 0:
            return period
        return max(period, interval)
