# SPDX-License-Identifier: GPL-3.0-or-later
"""Live smoothing for the preview camera: a One-Euro adaptive low-pass filter
adapted to quaternions (slerp instead of lerp, angular speed as the driver).

One-Euro trades latency against jitter *as a function of speed*: when the phone
is nearly still it filters hard (calm hold), and as it moves faster the cutoff
rises so the camera keeps up without lag. That is exactly the behaviour a
handheld virtual camera wants. This is display-only — the recorded take is the
raw pose stream, so live smoothing never touches what gets baked.

Pure Python, no bpy: unit-tested on desktop (see tests/test_filters.py).
"""

from __future__ import annotations

import math
from typing import Optional, Tuple

Quat = Tuple[float, float, float, float]


def _dot(a: Quat, b: Quat) -> float:
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3]


def _normalized(q: Quat) -> Quat:
    n = math.sqrt(_dot(q, q))
    # `or 1.0` alone let a NaN norm through (NaN is truthy), so every component
    # became NaN and the slerp below divided by zero. Non-finite input has no
    # meaningful direction: fall back to identity.
    if not (n > 0.0) or math.isinf(n):
        return (1.0, 0.0, 0.0, 0.0)
    return (q[0] / n, q[1] / n, q[2] / n, q[3] / n)


def _neg(q: Quat) -> Quat:
    return (-q[0], -q[1], -q[2], -q[3])


def slerp(a: Quat, b: Quat, t: float) -> Quat:
    """Shortest-path spherical interpolation, a→b by t∈[0,1]. Normalized."""
    d = _dot(a, b)
    if d < 0.0:  # take the shorter arc (q ≡ -q)
        b, d = _neg(b), -d
    # `not (d <= 0.9995)` so a NaN dot takes the lerp branch as well; see the
    # matching note in core/takes.slerp for why the old ordering divided by zero.
    if not (d <= 0.9995):  # almost parallel: lerp + renormalize (avoids div-by-~0)
        r = (
            a[0] + t * (b[0] - a[0]),
            a[1] + t * (b[1] - a[1]),
            a[2] + t * (b[2] - a[2]),
            a[3] + t * (b[3] - a[3]),
        )
        return _normalized(r)
    theta0 = math.acos(max(-1.0, min(1.0, d)))
    sin0 = math.sin(theta0)
    theta = theta0 * t
    sa = math.sin(theta0 - theta) / sin0
    sb = math.sin(theta) / sin0
    return (
        a[0] * sa + b[0] * sb,
        a[1] * sa + b[1] * sb,
        a[2] * sa + b[2] * sb,
        a[3] * sa + b[3] * sb,
    )


def _alpha(cutoff_hz: float, dt: float) -> float:
    tau = 1.0 / (2.0 * math.pi * cutoff_hz)
    return 1.0 / (1.0 + tau / dt)


Vec3 = Tuple[float, float, float]


def live_pos_filter_params(smoothing: float) -> Tuple[float, float]:
    """Map the 0..1 Live-smoothing slider to (min_cutoff_hz, beta) for the
    POSITION filter. Same cutoff curve as rotation (one slider, one feel);
    beta is per m/s — ~2 m/s of hand travel sheds most of the smoothing lag."""
    s = max(0.0, min(1.0, smoothing))
    min_cutoff = 8.0 * (0.06 ** s)
    beta = 0.5
    return min_cutoff, beta


def live_filter_params(smoothing: float) -> Tuple[float, float]:
    """Map the 0..1 UI slider to (min_cutoff_hz, beta).

    smoothing 0 disables filtering (caller passes through). Higher values lower
    the min cutoff (more smoothing when nearly still); beta is fixed so fast
    motion always sheds most of the lag. min_cutoff spans ~8 Hz (barely) down to
    ~0.5 Hz (heavy) log-uniformly."""
    s = max(0.0, min(1.0, smoothing))
    min_cutoff = 8.0 * (0.06 ** s)
    beta = 0.05
    return min_cutoff, beta


class OneEuroVec3:
    """One-Euro over 3-vectors (camera position, meters). Same structure as
    OneEuroQuat with lerp instead of slerp and metric speed as the driver.
    Applied to the RAW protocol position before offset/scale, so scale never
    amplifies the noise floor."""

    def __init__(self, min_cutoff: float = 1.0, beta: float = 0.5, d_cutoff: float = 1.0):
        self.min_cutoff = min_cutoff
        self.beta = beta
        self.d_cutoff = d_cutoff
        self._x: Optional[Vec3] = None
        self._speed = 0.0  # filtered speed (m/s)
        self._t_ns: Optional[int] = None

    def reset(self) -> None:
        self._x = None
        self._speed = 0.0
        self._t_ns = None

    def update(self, p: Vec3, t_ns: int) -> Vec3:
        if self._x is None or self._t_ns is None:
            self._x, self._t_ns, self._speed = p, t_ns, 0.0
            return p
        dt = (t_ns - self._t_ns) / 1e9
        if dt <= 0.0:
            return self._x
        self._t_ns = t_ns
        x = self._x
        d = math.sqrt(
            (p[0] - x[0]) ** 2 + (p[1] - x[1]) ** 2 + (p[2] - x[2]) ** 2
        )
        self._speed += _alpha(self.d_cutoff, dt) * (d / dt - self._speed)
        a = _alpha(self.min_cutoff + self.beta * self._speed, dt)
        self._x = (
            x[0] + a * (p[0] - x[0]),
            x[1] + a * (p[1] - x[1]),
            x[2] + a * (p[2] - x[2]),
        )
        return self._x


class OneEuroQuat:
    """Stateful One-Euro filter over unit quaternions. Feed successive samples
    with monotonic timestamps; get the smoothed orientation back."""

    def __init__(self, min_cutoff: float = 1.0, beta: float = 0.05, d_cutoff: float = 1.0):
        self.min_cutoff = min_cutoff
        self.beta = beta
        self.d_cutoff = d_cutoff
        self._x: Optional[Quat] = None      # last filtered quat
        self._speed = 0.0                   # filtered angular speed (rad/s)
        self._t_ns: Optional[int] = None    # last sample timestamp

    def reset(self) -> None:
        """Forget state so the next sample is passed through verbatim (used on
        connect and re-center so the camera snaps crisply, then eases)."""
        self._x = None
        self._speed = 0.0
        self._t_ns = None

    def update(self, q: Quat, t_ns: int) -> Quat:
        q = _normalized(q)
        if self._x is None or self._t_ns is None:
            self._x, self._t_ns, self._speed = q, t_ns, 0.0
            return q
        dt = (t_ns - self._t_ns) / 1e9
        if dt <= 0.0:  # duplicate/again out-of-order timestamp: hold
            return self._x
        self._t_ns = t_ns
        # angular distance between current filtered value and the new raw sample
        d = max(-1.0, min(1.0, abs(_dot(self._x, q))))
        raw_speed = (2.0 * math.acos(d)) / dt  # rad/s
        self._speed += _alpha(self.d_cutoff, dt) * (raw_speed - self._speed)
        cutoff = self.min_cutoff + self.beta * self._speed
        self._x = slerp(self._x, q, _alpha(cutoff, dt))
        return self._x
