# SPDX-License-Identifier: GPL-3.0-or-later
"""UDP session server for pocketrig protocol v1. No bpy — desktop-testable.

One daemon thread owns the socket and all protocol logic. The bl layer (or a
test) talks to it only through the thread-safe public API. The recv loop must
never die on hostile input: every datagram is handled inside a try/except and
malformed packets are counted, not raised.
"""

from __future__ import annotations

import platform
import secrets
import socket
import threading
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, NamedTuple, Optional, Set, Tuple

from . import protocol, takes
from .viewport_stream import (
    LISTEN_BACKLOG,
    ViewportStream,
    configure_listener,
    silence_udp_connreset,
)
from .constants import (
    ADDON_VERSION,
    CLIENT_GONE_TIMEOUT,
    DEFAULT_PORT,
    MSG_ACK,
    MSG_BYE,
    MSG_FRAME_RESET,
    MSG_HELLO,
    MSG_PARAMS,
    MSG_PAUSE,
    MSG_PING,
    MSG_POSE,
    MSG_RECENTER,
    MSG_SEEK,
    MSG_TAKE_LIST,
    MSG_VIEWPORT_CONTROL,
    MSG_VIEWPORT_STAT,
    MSG_RECORD_START,
    MSG_RECORD_STOP,
    PORT_RANGE_END,
    PROTOCOL_VERSION,
    RELIABLE_GIVE_UP,
    RELIABLE_RESEND_INTERVAL,
    RELIABLE_TYPES,
    TOKEN_ALPHABET,
    TOKEN_LENGTH,
)

Quat = Tuple[float, float, float, float]
Vec3 = Tuple[float, float, float]
# One pose stream sample. Position is present only for 6DOF senders (spec 4.1)
# and focal length only when the sender drives the lens (spec 4.5).
Sample = takes.RowSample
Addr = Tuple[str, int]


class LivePose(NamedTuple):
    """The newest accepted POSE.

    A NamedTuple so the existing positional consumers keep working while new
    fields can be appended -- the same append-only discipline the wire itself
    uses (spec section 4).
    """

    seq: int
    timestamp_ns: int
    quat: Quat
    flags: int
    pos: Optional[Vec3]
    #: Lens focal length in mm, 0.0 when the sender is not driving it (spec 4.5).
    focal_length_mm: float = 0.0

_IDLE_TIMEOUT = 0.5  # recv timeout with nothing pending
_ROLLING_MAXLEN = 256  # >= 2 s of poses at 100 Hz (spec asks >= 1 s)


def generate_token() -> str:
    return "".join(secrets.choice(TOKEN_ALPHABET) for _ in range(TOKEN_LENGTH))


def _token_format_valid(token: object) -> bool:
    return (
        isinstance(token, str)
        and len(token) == TOKEN_LENGTH
        and all(c in TOKEN_ALPHABET for c in token)
    )


@dataclass(frozen=True)
class BakeRequest:
    """Handed to the main thread after RECORD_STOP."""

    samples: List[Sample]  # (timestamp_ns, quat, pos-or-None) inside [start, end]
    start_ns: int
    end_ns: int
    sample_count: int  # how many POSEs the client claims it sent in-window
    source: str = "live"  # "offline" | "live" — which take was baked (§5.10)
    # A live take enters review (pause + play it back). An auto-uploaded /
    # imported take just bakes into a named action without disturbing the
    # live drive or the playhead.
    review: bool = True
    name: Optional[str] = None  # user's take name (§5.11), for the action
    # A take applied from the library lives in a foreign tracking origin: its
    # samples have no relation to the current live offsets, so bake it
    # re-anchored to the camera's *current* pose (its first sample maps to
    # wherever the camera is; the motion plays out relative). Only the genuine
    # standalone apply sets this — a live recording's offline delivery shares
    # the live session's tracking frame and keeps the live offsets.
    reanchor: bool = False
    # Stable phone-generated identity spanning RECORD_START, STOP, TCP upload,
    # and RECORD_BAKED. None is retained for protocol-v1 legacy peers and
    # standalone library applies.
    take_id: Optional[str] = None


@dataclass
class _Pending:
    data: bytes
    addr: Addr
    next_at: float
    deadline: float


class Server:
    """pocketrig UDP server.

    `get_scene_fps`, `server_name` and `host_version` are injected so this
    module never touches bpy; tests pass plain lambdas.
    """

    def __init__(
        self,
        port: Optional[int] = None,
        *,
        get_scene_fps: Callable[[], float],
        server_name: Optional[str] = None,
        host_app: str = "blender",
        host_version: str = "",
        addon_version: str = ADDON_VERSION,
        take_timeout: float = 10.0,
    ) -> None:
        self._requested_port = port  # None -> DEFAULT..RANGE_END, 0 -> ephemeral
        self._get_scene_fps = get_scene_fps
        self._server_name = server_name or platform.node() or "pocketrig-host"
        self._host_app = host_app
        self._host_version = host_version
        self._addon_version = addon_version

        self._sock: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None
        self._running = threading.Event()
        self._lock = threading.Lock()

        self.token: str = ""
        self.port: int = 0

        # Offline-take transfer (spec 5.10): TCP listener on the same port
        # number; a finished take uploads here and replaces the live samples.
        self._take_timeout = take_timeout
        self._tcp: Optional[socket.socket] = None
        self._tcp_thread: Optional[threading.Thread] = None
        self.take_port: Optional[int] = None
        # Per-take transaction maps. The old single upload/pending slots could
        # marry a delayed upload to a later recording; explicit keys make
        # reorder, duplication and rapid user input deterministic.
        self._offline_takes: Dict[str, dict] = {}
        self._pending_offline: Dict[str, dict] = {}
        self._host_stop_deadline: Optional[float] = None

        # Viewport channel (spec/viewport-channel.md). Its own listener on its
        # own port: the take listener is listen(1) with a blocking serial
        # reader, so sharing it would starve take uploads, and the pose flow
        # must never queue behind pixels.
        self.viewport = ViewportStream(token_check=lambda t: t == self.token)
        self.viewport_port: Optional[int] = None
        #: What the bl layer can currently produce, for WELCOME. Set by the
        #: main thread because only it may ask Blender how big a region is.
        self.viewport_video: Optional[dict] = None
        #: Modes this host offers, newest-capable first. A list from v1 so the
        #: scene mode can be added without a negotiation redesign.
        self.viewport_modes: Optional[list] = None
        self._viewport_request: Optional[dict] = None
        self._viewport_stat: Optional[dict] = None
        #: Capture to on-screen, in the host's own clock. None until a client
        #: reports; a conformant one never has to (§5.2).
        self.viewport_latency_ms: Optional[float] = None

        # Pairing / liveness (guarded by _lock).
        self._client_addr: Optional[Addr] = None
        self._client_name: Optional[str] = None
        self._last_rx: Optional[float] = None  # monotonic, any packet from client
        self._hello_count = 0  # every processed HELLO epoch (pairing/reconnect)
        self._pairing_count = 0  # fresh operator pairings only

        # Pose stream. Single reference assignment -> atomic under the GIL.
        self._latest_pose: Optional[LivePose] = None
        self._last_pose_seq = 0
        self._rolling: List[Sample] = []  # ring of recent samples

        # Recording (guarded by _lock).
        self._recording = False
        self._record_start_ns = 0
        self._record_take_key: Optional[str] = None
        self._record_take_id: Optional[str] = None
        self._record_buffer: List[Sample] = []
        # FIFO of takes to bake on the main thread. A queue (not a single slot)
        # so a batch of auto-uploaded offline takes never clobbers each other.
        self._bake_queue: List[BakeRequest] = []
        self._recenter_requested = False
        self._frame_reset_requested = False
        self._params_request: Optional[dict] = None  # phone-side slider change
        self._pause_request: Optional[bool] = None  # phone-side pause toggle
        self._seek_request: Optional[dict] = None  # phone-side timeline seek
        # Take library (spec 5.11): the phone's take list, and a monotonic
        # revision so the UI can tell when it changed.
        self._take_list: List[dict] = []
        self._take_list_rev = 0

        # Reliability (guarded by _lock).
        self._send_seq = 0
        self._pending: Dict[int, _Pending] = {}
        self._seen_reliable: Set[tuple] = set()

        # Stats.
        self.malformed_count = 0
        #: Take-upload connections that went wrong before we could read them.
        #: Ordinary on a flaky link; fatal only if the loop treats them as the
        #: end of the listener.
        self.take_accepts_failed = 0
        #: Datagrams that bounced (Windows ICMP unreachable). Not an
        #: error: the phone went away and will say hello again.
        self.bounced_count = 0
        self.pose_count = 0

    # ------------------------------------------------------------------ API

    def start(self) -> None:
        """Bind the socket (call from the UI thread so the OS firewall prompt
        has user-action context) and start the recv thread."""
        if self._running.is_set():
            return
        self.token = generate_token()
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        silence_udp_connreset(sock)
        if self._requested_port is None:
            last_err: Optional[OSError] = None
            for p in range(DEFAULT_PORT, PORT_RANGE_END + 1):
                try:
                    sock.bind(("0.0.0.0", p))
                    last_err = None
                    break
                except OSError as exc:
                    last_err = exc
            if last_err is not None:
                sock.close()
                raise last_err
        else:
            sock.bind(("0.0.0.0", self._requested_port))
        self.port = sock.getsockname()[1]
        self._sock = sock
        self._running.set()

        # Take-upload listener: same port NUMBER, TCP (spec 5.10). Failure is
        # graceful — WELCOME then omits take_port and clients record live-only.
        try:
            tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            configure_listener(tcp)
            tcp.bind(("0.0.0.0", self.port))
            # Uploads are processed serially on the accept loop, on purpose:
            # one take at a time, in order. But a backlog of 1 meant the second
            # phone connection to arrive during an upload was REFUSED rather
            # than queued -- and a refused upload is a lost take, not a retry.
            # Queue them instead; serial processing is the design, refusing is
            # not. Caught as an intermittent WinError 10061 in the suite under
            # load, which is the same failure a phone would hit on a slow disk.
            tcp.listen(LISTEN_BACKLOG)
            tcp.settimeout(0.5)
            self._tcp = tcp
            self.take_port = self.port
            self._tcp_thread = threading.Thread(
                target=self._take_loop, name="pocketrig-takes", daemon=True
            )
            self._tcp_thread.start()
        except OSError:
            self._tcp = None
            self.take_port = None

        # Failure is graceful, exactly like the take listener: WELCOME simply
        # omits viewport_port and the client never attempts a connection.
        self.viewport_port = self.viewport.start()

        self._thread = threading.Thread(
            target=self._run, name="pocketrig-session", daemon=True
        )
        self._thread.start()

    def stop(self) -> None:
        if not self._running.is_set():
            return
        self._running.clear()
        with self._lock:
            addr = self._client_addr
            self._client_addr = None
            self._client_name = None
            self._pending.clear()
            self._bake_queue.clear()
            self._offline_takes.clear()
            self._pending_offline.clear()
        if self._sock is not None:
            if addr is not None:
                try:  # best-effort BYE; we are gone before any resend
                    seq = self._next_seq()
                    self._sock.sendto(
                        protocol.encode_bye(seq, time.monotonic_ns()), addr
                    )
                except OSError:
                    pass
            try:
                self._sock.close()
            except OSError:
                pass
        self.viewport.stop()
        self.viewport_port = None
        self.viewport_modes = None
        if self._tcp is not None:
            try:
                self._tcp.close()
            except OSError:
                pass
        if self._tcp_thread is not None:
            self._tcp_thread.join(timeout=2.0)
            self._tcp_thread = None
        self._tcp = None
        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None
        self._sock = None

    @property
    def is_client_connected(self) -> bool:
        with self._lock:
            return (
                self._client_addr is not None
                and self._last_rx is not None
                and (time.monotonic() - self._last_rx) < CLIENT_GONE_TIMEOUT
            )

    @property
    def client_name(self) -> Optional[str]:
        with self._lock:
            return self._client_name

    @property
    def latest_pose(self) -> Optional[LivePose]:
        """The newest accepted POSE, or None. Single reference read: atomic."""
        return self._latest_pose

    @property
    def recording(self) -> bool:
        with self._lock:
            return self._recording

    @property
    def finalizing(self) -> bool:
        """A recorded take is awaiting its offline upload or bake handoff."""
        with self._lock:
            return bool(self._pending_offline) or any(
                req.take_id is not None for req in self._bake_queue
            )

    @property
    def busy(self) -> bool:
        """True while record/finalize work must exclude Apply/Pull."""
        with self._lock:
            return self._recording or bool(self._pending_offline) or any(
                req.take_id is not None for req in self._bake_queue
            )

    @property
    def last_packet_age(self) -> Optional[float]:
        """Seconds since any packet from the paired client, None if never."""
        with self._lock:
            if self._last_rx is None:
                return None
            return time.monotonic() - self._last_rx

    @property
    def hello_count(self) -> int:
        """Bumps whenever a HELLO is processed (pairing or reconnect)."""
        with self._lock:
            return self._hello_count

    @property
    def pairing_count(self) -> int:
        """Fresh pairings only. Reconnects need control re-sync but must not
        force an interactive camera back to Paused."""
        with self._lock:
            return self._pairing_count

    def take_bake_request(self) -> Optional[BakeRequest]:
        with self._lock:
            return self._bake_queue.pop(0) if self._bake_queue else None

    def take_recenter_request(self) -> bool:
        with self._lock:
            req, self._recenter_requested = self._recenter_requested, False
            return req

    def take_frame_reset_request(self) -> bool:
        """Consume an internal pose-reference boundary request.

        Unlike RECENTER this preserves pause/review and the user's Home.
        """
        with self._lock:
            req, self._frame_reset_requested = self._frame_reset_requested, False
            return req

    def take_params_request(self) -> Optional[dict]:
        """Latest PARAMS body from the phone (spec 5.7), or None."""
        with self._lock:
            req, self._params_request = self._params_request, None
            return req

    def take_pause_request(self) -> Optional[bool]:
        """Latest PAUSE body from the phone (spec 5.8), or None."""
        with self._lock:
            req, self._pause_request = self._pause_request, None
            return req

    def take_seek_request(self) -> Optional[dict]:
        """Latest SEEK body from the phone (spec 5.9), or None."""
        with self._lock:
            req, self._seek_request = self._seek_request, None
            return req

    def take_viewport_request(self) -> Optional[dict]:
        """Latest VIEWPORT_CONTROL body, or None (viewport-channel.md 5.1)."""
        with self._lock:
            req, self._viewport_request = self._viewport_request, None
            return req

    def latest_viewport_stat(self) -> Optional[dict]:
        """Most recent presentation report. Read-only: it is not consumed,
        because the panel wants to keep showing the last known figure rather
        than blanking between frames."""
        with self._lock:
            return dict(self._viewport_stat) if self._viewport_stat else None

    # ---------------------------------------------------- take library (5.11)

    def request_take_list(self) -> None:
        """Ask the phone for its take library (spec 5.11)."""
        with self._lock:
            addr = self._client_addr
        if addr is None:
            return
        self._send_reliable(
            protocol.encode_take_list_request(self._next_seq(), time.monotonic_ns()),
            addr,
        )

    def request_take_pull(self, take_id: str) -> None:
        """Ask the phone to upload a specific take (spec 5.11)."""
        with self._lock:
            addr = self._client_addr
        if addr is None:
            return
        self._send_reliable(
            protocol.encode_take_pull(self._next_seq(), time.monotonic_ns(), take_id),
            addr,
        )

    def get_take_list(self) -> Tuple[int, List[dict]]:
        """(revision, takes) — the phone's last-reported library. The revision
        bumps whenever the list changes so the panel can refresh cheaply."""
        with self._lock:
            return self._take_list_rev, list(self._take_list)

    def send_paused(self, paused: bool) -> None:
        """Push the host's authoritative pause state to the phone."""
        with self._lock:
            addr = self._client_addr
        if addr is None:
            return
        self._send_reliable(
            protocol.encode_pause(self._next_seq(), time.monotonic_ns(), paused),
            addr,
        )

    def send_params(
        self,
        live_smoothing: float,
        record_smoothing: float,
        move_scale: float,
        layout: Optional[str] = None,
        take_source: Optional[str] = None,
        lens_mm: Optional[float] = None,
        shake_hold_dps: Optional[float] = None,
        viewport_max_fps: Optional[float] = None,
    ) -> None:
        """Push the host's authoritative parameter values to the phone."""
        with self._lock:
            addr = self._client_addr
        if addr is None:
            return
        self._send_reliable(
            protocol.encode_params(
                self._next_seq(),
                time.monotonic_ns(),
                live_smoothing,
                record_smoothing,
                move_scale,
                layout=layout,
                take_source=take_source,
                lens_mm=lens_mm,
                shake_hold_dps=shake_hold_dps,
                viewport_max_fps=viewport_max_fps,
            ),
            addr,
        )

    def notify_baked(
        self,
        frames: int,
        fps: float,
        received: int,
        sent: int,
        source: str = "live",
        take_id: Optional[str] = None,
    ) -> None:
        """Send RECORD_BAKED (reliable) to the paired client, if any."""
        with self._lock:
            addr = self._client_addr
        if addr is None:
            return
        data = protocol.encode_record_baked(
            self._next_seq(), time.monotonic_ns(), frames, fps, received, sent,
            source, take_id=take_id,
        )
        self._send_reliable(data, addr)

    def notify_error(self, code: str, message: str = "") -> None:
        """Send a recoverable operation error to the paired phone."""
        with self._lock:
            addr = self._client_addr
        if addr is None:
            return
        data = protocol.encode_error(
            self._next_seq(), time.monotonic_ns(), code, message[:256],
        )
        self._send_reliable(data, addr)

    def request_stop_from_host(self) -> None:
        """Ask the PHONE to end the take (host reasons, e.g. scene end frame,
        spec 5.4): the phone replies with its normal RECORD_STOP and upload.
        If it never answers, a 5 s deadline bakes the live buffer instead.
        Idempotent while a request is outstanding."""
        with self._lock:
            if not self._recording:
                return
            if self._host_stop_deadline is not None:
                return  # already asked
            addr = self._client_addr
            latest = self._latest_pose
            take_id = self._record_take_id
            if addr is None:
                pass  # no client to ask: fall through to local stop
            else:
                self._host_stop_deadline = time.monotonic() + 5.0
        if addr is None:
            self.stop_recording_from_host()
            return
        end_ns = latest[1] if latest is not None else time.monotonic_ns()
        self._send_reliable(
            protocol.encode_record_stop(
                self._next_seq(), time.monotonic_ns(), end_ns, 0,
                take_id=take_id,
            ),
            addr,
        )

    # ---------------------------------------------------- offline takes (5.10)

    def _take_loop(self) -> None:
        tcp = self._tcp
        assert tcp is not None
        while self._running.is_set():
            try:
                conn, _addr = tcp.accept()
            except socket.timeout:
                continue
            except OSError:
                # Only stop() closes this listener, and it clears the flag
                # first. Anything else is one connection going wrong -- a phone
                # that resets between the handshake and our accept raises
                # ConnectionAbortedError here, an OSError -- and treating that
                # as fatal ends take uploads for the rest of the session. The
                # port stays open and the phone's uploads simply never land,
                # which loses the lossless recording rather than a preview.
                if not self._running.is_set():
                    break
                self.take_accepts_failed += 1
                continue
            try:
                self._receive_take(conn)
            except Exception:
                self.malformed_count += 1
            finally:
                try:
                    conn.close()
                except OSError:
                    pass

    def _receive_take(self, conn: socket.socket) -> None:
        """One upload (spec 5.10): header line, sample_count JSONL rows, 'ok'."""
        import json as _json

        conn.settimeout(5.0)
        f = conn.makefile("rb")
        header_raw = f.readline(1 << 16)
        header = _json.loads(header_raw)
        if (
            header.get("format") != "pocketrig-take"
            or header.get("version") != 0
            or header.get("token") != self.token
        ):
            return  # silently drop (wrong token: no reply at all)
        count = header.get("sample_count")
        start_ns = header.get("start_ns")
        end_ns = header.get("end_ns")
        if not (
            isinstance(count, int)
            and 0 < count <= takes.MAX_TAKE_ROWS
            and isinstance(start_ns, int)
            and isinstance(end_ns, int)
        ):
            return
        name = header.get("name")
        if not isinstance(name, str):
            name = None
        take_id = header.get("take_id")
        if not isinstance(take_id, str) or not (1 <= len(take_id) <= 128):
            take_id = None
        # Every row is validated (takes.parse_row): a malformed or non-finite
        # sample aborts the whole upload without an "ok", so the host falls back
        # to its live copy instead of baking garbage onto the camera. Quality
        # gating of `p` lives in the shared parser.
        samples: List[Sample] = []
        for _ in range(count):
            samples.append(takes.parse_row(_json.loads(f.readline(1 << 16))))
        with self._lock:
            take = {
                "samples": samples,
                "start": start_ns,
                "end": end_ns,
                "count": count,
                "name": name,
                "take_id": take_id,
            }

            # A transaction id is authoritative. Legacy peers without one can
            # still match the sole active/legacy-pending take, preserving v1
            # compatibility without letting a delayed modern upload attach to
            # a different recording.
            key: Optional[str] = None
            if take_id is not None:
                if take_id == self._record_take_id:
                    key = self._record_take_key
                elif take_id in self._pending_offline:
                    key = take_id
            elif self._recording and self._record_take_id is None:
                key = self._record_take_key
            else:
                legacy = [
                    k for k, p in self._pending_offline.items()
                    if p.get("take_id") is None
                ]
                if len(legacy) == 1:
                    key = legacy[0]

            if key is not None:
                self._offline_takes[key] = take
                self._finish_offline_locked(key)
                conn.sendall(b"ok\n")
            elif self._recording or self._pending_offline:
                # A transaction is active but this upload names another one.
                # Do not apply it as a library take and do not acknowledge it.
                return
            else:
                # Standalone upload (the user pulled a take from Blender, or
                # pushed one from the phone). Not recording -> APPLY it: bake
                # and show it on the camera (review), so "import a take" has a
                # visible result instead of a silent data-block. Queued so a
                # batch all apply in order.
                self._bake_queue.append(
                    BakeRequest(
                        take["samples"], take["start"], take["end"], take["count"],
                        source="offline", review=True, name=take.get("name"),
                        reanchor=True,
                    )
                )
                conn.sendall(b"ok\n")

    def _finish_offline_locked(self, key: str) -> None:
        """Marry one arrived upload with its explicit pending stop (lock held)."""
        pending = self._pending_offline.get(key)
        take = self._offline_takes.get(key)
        if pending is None or take is None:
            return
        del self._offline_takes[key]
        del self._pending_offline[key]
        self._bake_queue.append(
            BakeRequest(
                take["samples"], take["start"], take["end"], take["count"],
                source="offline",
                take_id=pending.get("take_id"),
            )
        )

    def _service_offline(self) -> None:
        """Deadlines: upload never arrived -> bake the live fallback; the
        phone never answered a host stop -> stop locally."""
        now = time.monotonic()
        with self._lock:
            due = [
                key for key, pending in self._pending_offline.items()
                if now >= pending["deadline"]
            ]
            for key in due:
                pending = self._pending_offline.pop(key)
                self._offline_takes.pop(key, None)
                self._bake_queue.append(
                    BakeRequest(
                        pending["fallback"],
                        pending["start"],
                        pending["end"],
                        pending["count"],
                        take_id=pending.get("take_id"),
                    )
                )
            host_stop_due = (
                self._host_stop_deadline is not None
                and now >= self._host_stop_deadline
                and self._recording
            )
            if host_stop_due:
                self._host_stop_deadline = None
        if host_stop_due:
            self.stop_recording_from_host()

    # ------------------------------------------------------------ internals

    def _next_seq(self) -> int:
        with self._lock:
            return self._next_seq_locked()

    def _next_seq_locked(self) -> int:
        # Callers either hold the lock or accept the tiny race on stop().
        self._send_seq += 1
        return self._send_seq

    def _send(self, data: bytes, addr: Addr) -> None:
        sock = self._sock
        if sock is None:
            return
        try:
            sock.sendto(data, addr)
        except OSError:
            pass

    def _send_reliable(self, data: bytes, addr: Addr) -> None:
        msg = protocol.decode(data)
        assert msg is not None
        now = time.monotonic()
        with self._lock:
            self._pending[msg.seq] = _Pending(
                data, addr, now + RELIABLE_RESEND_INTERVAL, now + RELIABLE_GIVE_UP
            )
        self._send(data, addr)

    def _service_pending(self) -> None:
        now = time.monotonic()
        resend: List[Tuple[bytes, Addr]] = []
        with self._lock:
            dead = [s for s, p in self._pending.items() if now >= p.deadline]
            for s in dead:  # give up; client-gone timeout covers the UI state
                del self._pending[s]
            for p in self._pending.values():
                if now >= p.next_at:
                    p.next_at = now + RELIABLE_RESEND_INTERVAL
                    resend.append((p.data, p.addr))
        for data, addr in resend:
            self._send(data, addr)

    def _run(self) -> None:
        sock = self._sock
        assert sock is not None
        while self._running.is_set():
            with self._lock:
                has_pending = bool(self._pending)
            sock.settimeout(
                RELIABLE_RESEND_INTERVAL / 2 if has_pending else _IDLE_TIMEOUT
            )
            try:
                data, addr = sock.recvfrom(65535)
            except socket.timeout:
                pass
            except OSError:
                # Only stop() closes this socket, and stop() clears the flag
                # first. Anything else is a datagram that bounced -- on Windows
                # a phone that goes away makes the NEXT recvfrom raise
                # ConnectionResetError, which is an OSError, and treating that
                # as "closed" left Blender connected but permanently deaf.
                if not self._running.is_set():
                    break
                self.bounced_count += 1
                continue
            else:
                try:
                    self._handle(data, addr)
                except Exception:
                    self.malformed_count += 1
            self._service_pending()
            self._service_offline()

    def _handle(self, data: bytes, addr: Addr) -> None:
        msg = protocol.decode(data)
        if msg is None:
            self.malformed_count += 1
            return

        with self._lock:
            is_client = addr == self._client_addr
            if is_client:
                self._last_rx = time.monotonic()

        if msg.msg_type in RELIABLE_TYPES:
            # ACK every reliable datagram, duplicates included (spec section 6).
            self._send(
                protocol.encode_ack(self._next_seq(), time.monotonic_ns(), msg.seq),
                addr,
            )
            # A restarted phone legitimately resets its sequence space to 1.
            # If the OS reuses the same UDP source port, (addr, seq) alone
            # aliases the previous session's HELLO and the host would ACK it
            # forever without sending WELCOME. Reliable HELLO retries are the
            # identical datagram, so their stable header timestamp safely
            # distinguishes retry vs restarted sender.
            key = (
                (addr, msg.seq, msg.timestamp_ns)
                if msg.msg_type == MSG_HELLO
                else (addr, msg.seq)
            )
            with self._lock:
                if key in self._seen_reliable:
                    return  # duplicate: ACKed above, processed once
                self._seen_reliable.add(key)
                if len(self._seen_reliable) > 8192:
                    self._seen_reliable.clear()  # session-scale bound

        if msg.msg_type == MSG_POSE:
            if is_client:
                self._handle_pose(msg)
        elif msg.msg_type == MSG_HELLO:
            self._handle_hello(msg, addr)
        elif msg.msg_type == MSG_PING:
            if is_client:
                self._send(
                    protocol.encode_pong(
                        self._next_seq(),
                        time.monotonic_ns(),
                        msg.timestamp_ns,
                        time.monotonic_ns(),
                    ),
                    addr,
                )
        elif msg.msg_type == MSG_ACK:
            with self._lock:
                p = self._pending.get(msg.acked_seq)
                if p is not None and p.addr == addr:
                    del self._pending[msg.acked_seq]
        elif msg.msg_type == MSG_RECORD_START:
            if is_client:
                self._handle_record_start(msg)
        elif msg.msg_type == MSG_RECORD_STOP:
            if is_client:
                self._handle_record_stop(msg)
        elif msg.msg_type == MSG_RECENTER:
            if is_client:
                with self._lock:
                    if not self._recording:  # MUST ignore while recording
                        self._recenter_requested = True
        elif msg.msg_type == MSG_FRAME_RESET:
            if is_client:
                with self._lock:
                    if not self._recording:
                        self._frame_reset_requested = True
        elif msg.msg_type == MSG_PARAMS:
            if is_client:
                with self._lock:
                    self._params_request = dict(msg.body)
        elif msg.msg_type == MSG_PAUSE:
            if is_client and isinstance(msg.body.get("paused"), bool):
                with self._lock:
                    self._pause_request = msg.body["paused"]
        elif msg.msg_type == MSG_SEEK:
            if is_client:
                with self._lock:
                    if not self._recording:  # MUST ignore while recording
                        self._seek_request = dict(msg.body)
        elif msg.msg_type == MSG_TAKE_LIST:
            # The phone's take library (spec 5.11). Requests carry no "takes"
            # key; only responses update our cached list.
            if is_client and isinstance(msg.body.get("takes"), list):
                takes = [t for t in msg.body["takes"] if isinstance(t, dict)]
                with self._lock:
                    self._take_list = takes
                    self._take_list_rev += 1
        elif msg.msg_type == MSG_VIEWPORT_CONTROL:
            if is_client:
                with self._lock:
                    self._viewport_request = dict(msg.body)
        elif msg.msg_type == MSG_VIEWPORT_STAT:
            # Telemetry about a preview: latest-wins, never queued. Keeping a
            # history would grow without bound on a session nobody is watching.
            if is_client:
                with self._lock:
                    self._viewport_stat = dict(msg.body)
                    # The figure that needs no shared clock: our stamp, our
                    # clock, the phone echoing only which frame it was.
                    ordinal = msg.body.get("ordinal")
                    if isinstance(ordinal, int):
                        trip = self.viewport.note_presented(ordinal)
                        if trip is not None:
                            self.viewport_latency_ms = round(trip, 1)
        elif msg.msg_type == MSG_BYE:
            if is_client:
                with self._lock:
                    self._client_addr = None
                    self._client_name = None
                    self._recording = False
                    self._record_buffer = []
                    self._pending.clear()
        # WELCOME/PONG/ERROR/RECORD_BAKED from a client: not ours to handle.

    def _handle_pose(self, msg: protocol.PoseMsg) -> None:
        with self._lock:
            if msg.seq <= self._last_pose_seq:
                return  # latest-wins: late/duplicate datagrams are dropped
            self._last_pose_seq = msg.seq
            self.pose_count += 1
            sample = takes.RowSample(
                msg.timestamp_ns, msg.quat, msg.pos,
                msg.focal_length_mm if msg.focal_length_mm > 0.0 else None,
            )
            self._rolling.append(sample)
            if len(self._rolling) > _ROLLING_MAXLEN:
                del self._rolling[: len(self._rolling) - _ROLLING_MAXLEN]
            if self._recording and msg.timestamp_ns >= self._record_start_ns:
                self._record_buffer.append(sample)
        self._latest_pose = LivePose(
            msg.seq, msg.timestamp_ns, msg.quat, msg.flags, msg.pos,
            msg.focal_length_mm,
        )

    def _handle_hello(self, msg: protocol.JsonMsg, addr: Addr) -> None:
        body = msg.body
        if body.get("protocol_version") != PROTOCOL_VERSION:
            self._send_reliable(
                protocol.encode_error(
                    self._next_seq(),
                    time.monotonic_ns(),
                    "version_unsupported",
                    f"host speaks protocol v{PROTOCOL_VERSION}",
                ),
                addr,
            )
            return
        token = body.get("token")
        if token != self.token:
            with self._lock:
                live = (
                    self._client_addr is not None
                    and self._last_rx is not None
                    and (time.monotonic() - self._last_rx) < CLIENT_GONE_TIMEOUT
                )
            if live and _token_format_valid(token):
                code, detail = "busy", "another client is paired"
            else:
                code, detail = "bad_token", "token does not match this session"
            self._send_reliable(
                protocol.encode_error(
                    self._next_seq(), time.monotonic_ns(), code, detail
                ),
                addr,
            )
            return
        # Valid token: adopt (new pairing, reconnect or Wi-Fi roam) silently.
        # Every HELLO triggers state re-sync, but only a genuinely fresh
        # pairing may apply start-paused. A same-session roam/reconnect inside
        # the liveness window preserves the operator's current state.
        now = time.monotonic()
        with self._lock:
            previous_addr = self._client_addr
            previous_rx = self._last_rx
            fresh_pairing = previous_addr is None or (
                previous_addr != addr
                and (
                    previous_rx is None
                    or (now - previous_rx) >= CLIENT_GONE_TIMEOUT
                )
            )
            self._client_addr = addr
            self._client_name = str(body.get("device_name", "phone"))
            self._last_rx = now
            self._last_pose_seq = 0  # client may have restarted its seq space
            self._hello_count += 1
            if fresh_pairing:
                self._pairing_count += 1
            # A reconnect MUST preserve an in-flight take (spec 8), but a fresh
            # pairing is a new session: an orphaned take from a phone that went
            # away mid-recording would otherwise keep the host "recording"
            # forever and refuse the new phone's first Record. End it through
            # the normal host-stop path so its samples still bake.
            orphaned_take = fresh_pairing and self._recording
        if orphaned_take:
            self.stop_recording_from_host()
        try:
            fps = float(self._get_scene_fps())
        except Exception:
            fps = 24.0
        self._send_reliable(
            protocol.encode_welcome(
                self._next_seq(),
                time.monotonic_ns(),
                self._server_name,
                self._host_app,
                self._host_version,
                self._addon_version,
                fps,
                take_port=self.take_port,
                viewport_port=self.viewport_port,
                viewport_video=self.viewport_video,
                viewport_modes=self.viewport_modes,
            ),
            addr,
        )

    def _handle_record_start(self, msg: protocol.JsonMsg) -> None:
        start_ns = msg.body.get("start_timestamp_ns")
        if not isinstance(start_ns, int):
            return
        take_id = msg.body.get("take_id")
        if not isinstance(take_id, str) or not (1 <= len(take_id) <= 128):
            take_id = None
        with self._lock:
            busy = self._recording or bool(self._pending_offline)
            if not busy:
                self._recording = True
                self._record_start_ns = start_ns
                self._record_take_id = take_id
                self._record_take_key = take_id or f"legacy:{start_ns}:{msg.seq}"
                # Splice: poses already received whose sensor time is in-window.
                self._record_buffer = [s for s in self._rolling if s[0] >= start_ns]
        if busy:
            # Silently dropping this used to strand the phone: the generic
            # reliable handler had already ACKed the datagram, so the phone
            # treated it as a started take and waited out its finalization
            # timeout. Answer instead, so it can abandon the take at once.
            self.notify_error(
                "record_rejected", "a take is already being recorded or baked"
            )

    def stop_recording_from_host(self) -> None:
        """Host-initiated take end (e.g. the timeline reached the scene's end
        frame). Bakes exactly like a phone RECORD_STOP; the phone learns the
        take is over from the RECORD_BAKED that follows (spec 5.5)."""
        with self._lock:
            if not self._recording:
                return
            self._recording = False
            take_id = self._record_take_id
            samples = [
                s for s in self._record_buffer if s[0] >= self._record_start_ns
            ]
            self._record_buffer = []
            end_ns = samples[-1][0] if samples else self._record_start_ns
            # The phone never sent its count: report received as sent.
            self._bake_queue.append(
                BakeRequest(
                    samples, self._record_start_ns, end_ns, len(samples),
                    take_id=take_id,
                )
            )
            self._record_take_key = None
            self._record_take_id = None

    def _handle_record_stop(self, msg: protocol.JsonMsg) -> None:
        end_ns = msg.body.get("end_timestamp_ns")
        if not isinstance(end_ns, int):
            return
        sample_count = msg.body.get("sample_count")
        if not isinstance(sample_count, int):
            sample_count = 0
        offline = msg.body.get("offline") is True
        stop_take_id = msg.body.get("take_id")
        if not isinstance(stop_take_id, str) or not (1 <= len(stop_take_id) <= 128):
            stop_take_id = None
        with self._lock:
            if not self._recording:
                return
            # Modern transactions must agree exactly. Legacy remains valid
            # only when both sides omitted the field.
            if stop_take_id != self._record_take_id:
                return
            self._recording = False
            self._host_stop_deadline = None  # the phone answered
            take_key = self._record_take_key
            take_id = self._record_take_id
            samples = [
                s
                for s in self._record_buffer
                if self._record_start_ns <= s[0] <= end_ns
            ]
            self._record_buffer = []
            if offline:
                # An upload follows (spec 5.10): hold the live samples as the
                # fallback; the deadline bakes them if the upload never lands.
                assert take_key is not None
                self._pending_offline[take_key] = {
                    "fallback": samples,
                    "start": self._record_start_ns,
                    "end": end_ns,
                    "count": sample_count,
                    "deadline": time.monotonic() + self._take_timeout,
                    "take_id": take_id,
                }
                self._finish_offline_locked(take_key)  # upload may have raced ahead
            else:
                self._bake_queue.append(
                    BakeRequest(
                        samples, self._record_start_ns, end_ns, sample_count,
                        take_id=take_id,
                    )
                )
            self._record_take_key = None
            self._record_take_id = None
