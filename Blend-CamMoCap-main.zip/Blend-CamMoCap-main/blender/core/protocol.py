# SPDX-License-Identifier: GPL-3.0-or-later
"""Wire codec for pocketrig protocol v1 (spec/protocol.md).

Everything is little-endian. Header is 16 bytes: magic "PR", u8 version,
u8 msg_type, u32 seq, u64 timestamp_ns. decode() returns None for anything
that must be silently dropped (bad magic, wrong version, truncated body,
invalid JSON, unknown msg_type) — callers never raise on hostile input.
"""

from __future__ import annotations

import json
import math
import struct
from dataclasses import dataclass
from typing import Final, Any, Dict, Optional, Tuple, Union

from .constants import (
    FLAG_HAS_POSITION,
    FLAG_ISSUE_MASK,
    FLAG_ISSUE_SHIFT,
    FLAG_QUALITY_MASK,
    FLAG_QUALITY_SHIFT,
    MAGIC,
    MSG_ACK,
    MSG_BYE,
    MSG_ERROR,
    MSG_FRAME_RESET,
    MSG_VIEWPORT_CONTROL,
    MSG_VIEWPORT_STAT,
    VIEWPORT_CODEC_JPEG,
    VIEWPORT_CODEC_NAMES,
    VIEWPORT_FLAG_KEYFRAME,
    VIEWPORT_FRAME_VERSION,
    VIEWPORT_MAGIC,
    VIEWPORT_MAX_PAYLOAD_GUARD,
    MSG_HELLO,
    MSG_PARAMS,
    MSG_PAUSE,
    MSG_PING,
    MSG_SEEK,
    MSG_TAKE_LIST,
    MSG_TAKE_PULL,
    MSG_PONG,
    MSG_POSE,
    MSG_RECENTER,
    MSG_RECORD_BAKED,
    MSG_RECORD_START,
    MSG_RECORD_STOP,
    MSG_WELCOME,
    PROTOCOL_VERSION,
)

TRACKING_QUALITY_NAMES = {
    0: "unknown",
    1: "warming",
    2: "good",
    3: "degraded",
    4: "lost",
    5: "recovering",
}
TRACKING_ISSUE_NAMES = {
    0: "none",
    1: "initializing",
    2: "insufficient_features",
    3: "insufficient_light",
    4: "excessive_motion",
    5: "bad_state",
    6: "camera_unavailable",
    7: "unknown",
}


def tracking_quality(flags: int) -> str:
    """Decode the append-only POSE quality field; old senders are unknown."""
    code = (flags & FLAG_QUALITY_MASK) >> FLAG_QUALITY_SHIFT
    return TRACKING_QUALITY_NAMES.get(code, "unknown")


def tracking_issue(flags: int) -> str:
    """Decode the append-only POSE issue field without rejecting future bits."""
    code = (flags & FLAG_ISSUE_MASK) >> FLAG_ISSUE_SHIFT
    return TRACKING_ISSUE_NAMES.get(code, "unknown")

_HEADER = struct.Struct("<2sBBIQ")  # magic, version, msg_type, seq, timestamp_ns
_POSE_BODY = struct.Struct("<5fHH")  # qw qx qy qz focal_length_mm flags reserved
_POSE_POS = struct.Struct("<3f")  # pos_x pos_y pos_z (spec section 4.1)
_ACK_BODY = struct.Struct("<I")  # acked_seq

HEADER_SIZE = _HEADER.size  # 16
POSE_SIZE = HEADER_SIZE + _POSE_BODY.size  # 40
POSE_6DOF_SIZE = POSE_SIZE + _POSE_POS.size  # 52
ACK_SIZE = HEADER_SIZE + _ACK_BODY.size  # 20

# msg_types whose body is UTF-8 JSON.
JSON_TYPES = frozenset(
    {
        MSG_HELLO,
        MSG_WELCOME,
        MSG_PONG,
        MSG_ERROR,
        MSG_RECORD_START,
        MSG_RECORD_STOP,
        MSG_RECORD_BAKED,
        MSG_RECENTER,
        MSG_PARAMS,
        MSG_PAUSE,
        MSG_SEEK,
        MSG_TAKE_LIST,
        MSG_TAKE_PULL,
        MSG_FRAME_RESET,
        MSG_VIEWPORT_CONTROL,
        MSG_VIEWPORT_STAT,
    }
)
# msg_types with no body at all.
EMPTY_TYPES = frozenset({MSG_BYE, MSG_PING})

Quat = Tuple[float, float, float, float]
Vec3 = Tuple[float, float, float]

#: magic | version | codec | flags | ordinal | capture_ns | w | h | payload_len
#:
#: Dimensions ride every frame rather than being inferred from the negotiated
#: size. The operator can drag a viewport edge at any moment, which changes what
#: capture produces without any control message being exchanged -- so a receiver
#: holding the advertised size would be reshaping to a stale one. JPEG happens to
#: self-describe, but the channel should not depend on the codec to carry the
#: geometry of its own frames.
_VIEWPORT_HEADER = struct.Struct("<4sBBHIQHHI")

#: Re-exported so the codec and its callers cite one number, not two.
VIEWPORT_MAX_PAYLOAD: Final[int] = VIEWPORT_MAX_PAYLOAD_GUARD

#: Size of the frame header on the wire, for receivers that read it in one go.
VIEWPORT_HEADER_SIZE: Final[int] = 28


@dataclass(frozen=True)
class ViewportFrameHeader:
    codec: int
    flags: int
    ordinal: int
    capture_ns: int
    width: int
    height: int
    payload_len: int

    @property
    def is_keyframe(self) -> bool:
        return bool(self.flags & VIEWPORT_FLAG_KEYFRAME)

    @property
    def codec_name(self) -> str:
        return VIEWPORT_CODEC_NAMES.get(self.codec, "unknown")


@dataclass(frozen=True)
class PoseMsg:
    seq: int
    timestamp_ns: int
    quat: Quat  # (w, x, y, z)
    focal_length_mm: float
    flags: int
    pos: Optional[Vec3] = None  # meters, protocol world frame; spec section 4.1
    msg_type: int = MSG_POSE


@dataclass(frozen=True)
class AckMsg:
    seq: int
    timestamp_ns: int
    acked_seq: int
    msg_type: int = MSG_ACK


@dataclass(frozen=True)
class EmptyMsg:
    """BYE or PING — header only."""

    seq: int
    timestamp_ns: int
    msg_type: int


@dataclass(frozen=True)
class JsonMsg:
    """Any control message with a JSON body."""

    seq: int
    timestamp_ns: int
    msg_type: int
    body: Dict[str, Any]


Message = Union[PoseMsg, AckMsg, EmptyMsg, JsonMsg]


def encode_header(msg_type: int, seq: int, timestamp_ns: int) -> bytes:
    return _HEADER.pack(MAGIC, PROTOCOL_VERSION, msg_type, seq, timestamp_ns)


def encode_pose(
    seq: int,
    timestamp_ns: int,
    quat: Quat,
    flags: int = 0,
    focal_length_mm: float = 0.0,
    pos: Optional[Vec3] = None,
) -> bytes:
    """40-byte rotation-only POSE, or 52-byte 6DOF when `pos` is given (the
    position_valid flag tracks `pos` — spec section 4.1 forbids the flag
    without the bytes or vice versa, so callers cannot get it wrong)."""
    if pos is not None:
        flags |= FLAG_HAS_POSITION
    else:
        flags &= ~FLAG_HAS_POSITION
    data = encode_header(MSG_POSE, seq, timestamp_ns) + _POSE_BODY.pack(
        quat[0], quat[1], quat[2], quat[3], focal_length_mm, flags, 0
    )
    if pos is not None:
        data += _POSE_POS.pack(pos[0], pos[1], pos[2])
    return data


def encode_ack(seq: int, timestamp_ns: int, acked_seq: int) -> bytes:
    return encode_header(MSG_ACK, seq, timestamp_ns) + _ACK_BODY.pack(acked_seq)


def encode_bye(seq: int, timestamp_ns: int) -> bytes:
    return encode_header(MSG_BYE, seq, timestamp_ns)


def encode_ping(seq: int, timestamp_ns: int) -> bytes:
    return encode_header(MSG_PING, seq, timestamp_ns)


def encode_json(msg_type: int, seq: int, timestamp_ns: int, body: Dict[str, Any]) -> bytes:
    payload = json.dumps(body, separators=(",", ":")).encode("utf-8")
    return encode_header(msg_type, seq, timestamp_ns) + payload


def encode_hello(
    seq: int, timestamp_ns: int, device_name: str, app_version: str, token: str
) -> bytes:
    return encode_json(
        MSG_HELLO,
        seq,
        timestamp_ns,
        {
            "device_name": device_name,
            "app_version": app_version,
            "protocol_version": PROTOCOL_VERSION,
            "token": token,
        },
    )


def encode_welcome(
    seq: int,
    timestamp_ns: int,
    server_name: str,
    host_app: str,
    host_version: str,
    addon_version: str,
    scene_fps: float,
    take_port: Optional[int] = None,
    viewport_port: Optional[int] = None,
    viewport_modes: Optional[list] = None,
    viewport_video: Optional[Dict[str, Any]] = None,
) -> bytes:
    body = {
        "server_name": server_name,
        "host_app": host_app,
        "host_version": host_version,
        "addon_version": addon_version,
        "protocol_version": PROTOCOL_VERSION,
        "scene_fps": scene_fps,
    }
    if take_port is not None:
        body["take_port"] = take_port  # offline-take TCP upload (spec 5.10)
    if viewport_port is not None:
        # Viewport channel (viewport-channel.md section 3). Absence means the
        # host cannot stream and the client MUST NOT connect, so these are
        # omitted entirely rather than sent as nulls.
        body["viewport_port"] = viewport_port
        # Lists from v1 even holding one entry: adding a codec or the scene mode
        # then stays additive instead of becoming a negotiation redesign.
        body["viewport_modes"] = list(viewport_modes or ["camera"])
        if viewport_video is not None:
            body["viewport_video"] = viewport_video
    return encode_json(MSG_WELCOME, seq, timestamp_ns, body)


def encode_pong(seq: int, timestamp_ns: int, t1: int, t2: int) -> bytes:
    return encode_json(MSG_PONG, seq, timestamp_ns, {"t1": t1, "t2": t2})


def encode_error(seq: int, timestamp_ns: int, code: str, message: str = "") -> bytes:
    return encode_json(MSG_ERROR, seq, timestamp_ns, {"code": code, "message": message})


def encode_record_start(
    seq: int,
    timestamp_ns: int,
    start_timestamp_ns: int,
    take_id: Optional[str] = None,
) -> bytes:
    body = {"start_timestamp_ns": start_timestamp_ns}
    if take_id is not None:
        body["take_id"] = take_id
    return encode_json(MSG_RECORD_START, seq, timestamp_ns, body)


def encode_record_stop(
    seq: int,
    timestamp_ns: int,
    end_timestamp_ns: int,
    sample_count: int,
    offline: bool = False,
    take_id: Optional[str] = None,
) -> bytes:
    body = {"end_timestamp_ns": end_timestamp_ns, "sample_count": sample_count}
    if offline:
        body["offline"] = True  # an offline-take upload follows (spec 5.10)
    if take_id is not None:
        body["take_id"] = take_id
    return encode_json(MSG_RECORD_STOP, seq, timestamp_ns, body)


def encode_record_baked(
    seq: int,
    timestamp_ns: int,
    frames: int,
    fps: float,
    received: int,
    sent: int,
    source: str = "live",
    take_id: Optional[str] = None,
) -> bytes:
    body = {
        "frames": frames,
        "fps": fps,
        "received": received,
        "sent": sent,
        "source": source,  # "offline" | "live" (spec 5.10)
    }
    if take_id is not None:
        body["take_id"] = take_id
    return encode_json(
        MSG_RECORD_BAKED,
        seq,
        timestamp_ns,
        body,
    )


def encode_recenter(seq: int, timestamp_ns: int) -> bytes:
    return encode_json(MSG_RECENTER, seq, timestamp_ns, {})


def encode_params(
    seq: int,
    timestamp_ns: int,
    live_smoothing: float,
    record_smoothing: float,
    move_scale: float,
    layout: Optional[str] = None,
    take_source: Optional[str] = None,
    lens_mm: Optional[float] = None,
    shake_hold_dps: Optional[float] = None,
    viewport_max_fps: Optional[float] = None,
) -> bytes:
    body = {
        "live_smoothing": live_smoothing,
        "record_smoothing": record_smoothing,
        "move_scale": move_scale,
    }
    if shake_hold_dps is not None:
        # Spec 5.7. Mirrored so the phone's "position held" cue uses the same
        # number we do; 0.0 means the gate is off. Sent even at 0, because
        # absent means "unchanged" and off is a value, not a silence.
        body["shake_hold_dps"] = float(shake_hold_dps)
    if layout is not None:
        body["layout"] = layout  # "portrait" | "landscape" (spec 5.7)
    if take_source is not None:
        body["take_source"] = take_source  # "offline" | "live" (spec 5.7)
    if lens_mm is not None:
        # Host -> phone only: our current lens, so the phone's rail opens ON it
        # instead of asserting a value and reframing the shot (spec 5.7, 4.5).
        body["lens_mm"] = float(lens_mm)
    if viewport_max_fps is not None:
        # Host -> phone only: the viewport rate this host has MEASURED itself
        # reaching, so the phone's Refresh control can show where its own range
        # stops meaning anything (viewport-channel.md 5.3).
        #
        # It cannot ride WELCOME, which is why it is here. The ceiling is the
        # host's event-loop rate under load, and at pairing there is no load --
        # the loop free-runs six times faster than it will once the camera is
        # moving, so a number measured then would be a promise the host cannot
        # keep.
        body["viewport_max_fps"] = float(viewport_max_fps)
    return encode_json(MSG_PARAMS, seq, timestamp_ns, body)


def encode_pause(seq: int, timestamp_ns: int, paused: bool) -> bytes:
    return encode_json(MSG_PAUSE, seq, timestamp_ns, {"paused": bool(paused)})


def encode_seek(
    seq: int, timestamp_ns: int, frame: Optional[int] = None
) -> bytes:
    """Seek the host timeline: a frame number, or None = the scene start."""
    body = {"frame": int(frame)} if frame is not None else {"to": "start"}
    return encode_json(MSG_SEEK, seq, timestamp_ns, body)


def encode_take_list_request(seq: int, timestamp_ns: int) -> bytes:
    """Host -> phone: ask for the take library (spec 5.11)."""
    return encode_json(MSG_TAKE_LIST, seq, timestamp_ns, {})


def encode_take_list(seq: int, timestamp_ns: int, takes: list) -> bytes:
    """Phone -> host: the take library (spec 5.11)."""
    return encode_json(MSG_TAKE_LIST, seq, timestamp_ns, {"takes": takes})


def encode_take_pull(seq: int, timestamp_ns: int, take_id: str) -> bytes:
    """Host -> phone: upload this take to me (spec 5.11)."""
    return encode_json(MSG_TAKE_PULL, seq, timestamp_ns, {"id": take_id})


def encode_frame_reset(seq: int, timestamp_ns: int, reason: str) -> bytes:
    """Phone -> host: the next POSE starts a new raw reference frame."""
    return encode_json(MSG_FRAME_RESET, seq, timestamp_ns, {"reason": reason})


def encode_viewport_control(
    seq: int,
    timestamp_ns: int,
    mode: str,
    codec: Optional[str] = None,
    size: Optional[Tuple[int, int]] = None,
    fps: Optional[float] = None,
    quality: Optional[int] = None,
    overlays: Optional[bool] = None,
    profile: Optional[str] = None,
) -> bytes:
    """Phone -> host: start, reconfigure or stop the viewport stream.

    `mode="off"` carries nothing else and must be accepted at any time,
    including mid-recording -- the stream is a preview and nothing about it may
    block ending a take (spec/viewport-channel.md section 5.1).
    """
    body: dict = {"mode": mode}
    if codec is not None:
        body["codec"] = codec
    if size is not None:
        body["size"] = [int(size[0]), int(size[1])]
    if fps is not None:
        body["fps"] = float(fps)
    if quality is not None:
        body["quality"] = int(quality)
    if overlays is not None:
        # Whether the operator's own viewport overlays -- 3D cursor, grid,
        # relationship lines -- are drawn into the phone's picture. Absent means
        # the host keeps whatever it had, so a client that does not know about
        # this field never changes it (viewport-channel.md 5.1).
        body["overlays"] = bool(overlays)
    if profile is not None:
        # Hand size selection to the host. Only it can see what a capture costs
        # on this machine and this scene, and both change under the operator's
        # hands (viewport-channel.md 5.1).
        body["profile"] = str(profile)
    return encode_json(MSG_VIEWPORT_CONTROL, seq, timestamp_ns, body)


def encode_viewport_stat(
    seq: int, timestamp_ns: int, ordinal: int, decoded_ns: int, presented_ns: int
) -> bytes:
    """Phone -> host: frame `ordinal` reached the screen.

    Unreliable on purpose. The timestamps are in the PHONE's clock domain
    (section 2), so only their difference means anything to the host; the host's
    own round trip against the frame's capture stamp is the figure that needs no
    shared clock.
    """
    return encode_json(
        MSG_VIEWPORT_STAT,
        seq,
        timestamp_ns,
        {
            "ordinal": int(ordinal),
            "decoded_ns": int(decoded_ns),
            "presented_ns": int(presented_ns),
        },
    )


def encode_viewport_frame_header(
    ordinal: int,
    capture_ns: int,
    payload_len: int,
    width: int = 0,
    height: int = 0,
    codec: int = VIEWPORT_CODEC_JPEG,
    keyframe: bool = True,
) -> bytes:
    """The 24-byte frame header (spec/viewport-channel.md section 4).

    `ordinal` counts frames PRODUCED, not sent. A host that drops a frame under
    backpressure still advances it, or the receiver cannot tell "the host
    skipped one" from "the network lost one".
    """
    return _VIEWPORT_HEADER.pack(
        VIEWPORT_MAGIC,
        VIEWPORT_FRAME_VERSION,
        int(codec),
        VIEWPORT_FLAG_KEYFRAME if keyframe else 0,
        int(ordinal) & 0xFFFFFFFF,
        int(capture_ns) & 0xFFFFFFFFFFFFFFFF,
        int(width) & 0xFFFF,
        int(height) & 0xFFFF,
        int(payload_len),
    )


def decode_viewport_frame_header(data: bytes) -> Optional[ViewportFrameHeader]:
    """Parse a frame header, or None if it is not one.

    None means the reader has lost sync, and the caller MUST close the
    connection rather than hunt for the next plausible header -- a
    desynchronised reader cannot tell a payload byte from a header byte.
    """
    if len(data) < _VIEWPORT_HEADER.size:
        return None
    magic, version, codec, flags, ordinal, capture_ns, width, height, payload_len = (
        _VIEWPORT_HEADER.unpack_from(data, 0)
    )
    if magic != VIEWPORT_MAGIC or version != VIEWPORT_FRAME_VERSION:
        return None
    if codec not in VIEWPORT_CODEC_NAMES:
        return None
    if payload_len <= 0 or payload_len > VIEWPORT_MAX_PAYLOAD:
        return None
    return ViewportFrameHeader(
        codec=codec,
        flags=flags,
        ordinal=ordinal,
        capture_ns=capture_ns,
        width=width,
        height=height,
        payload_len=payload_len,
    )


def decode(data: bytes) -> Optional[Message]:
    """Decode one datagram; None means "silently drop" (spec sections 2, 4).

    POSE packets longer than 40 bytes are accepted with extra bytes ignored
    (v2-forward rule). Unknown msg_type values yield None.
    """
    if len(data) < HEADER_SIZE:
        return None
    magic, version, msg_type, seq, timestamp_ns = _HEADER.unpack_from(data, 0)
    if magic != MAGIC or version != PROTOCOL_VERSION:
        return None

    if msg_type == MSG_POSE:
        if len(data) < POSE_SIZE:
            return None
        qw, qx, qy, qz, focal_mm, flags, _res = _POSE_BODY.unpack_from(data, HEADER_SIZE)
        # A pose is geometry, so it must be usable as geometry. f32 carries NaN
        # and infinity happily, and a non-finite quaternion reaching the live
        # drive writes NaN into the camera transform, where it propagates
        # through the dependency graph. The quaternion must also have a
        # direction to normalize. Treat a violation as a malformed packet
        # (section 2): drop it. Latest-wins makes a dropped pose free.
        if not all(math.isfinite(c) for c in (qw, qx, qy, qz)):
            return None
        if qw * qw + qx * qx + qy * qy + qz * qz <= 0.0:
            return None
        # Position needs BOTH the flag and the bytes (spec section 4.1); a long
        # packet without the flag is rotation-only, extra bytes ignored.
        pos: Optional[Vec3] = None
        if flags & FLAG_HAS_POSITION and len(data) >= POSE_6DOF_SIZE:
            pos = _POSE_POS.unpack_from(data, POSE_SIZE)
            if not all(math.isfinite(c) for c in pos):
                return None
        return PoseMsg(seq, timestamp_ns, (qw, qx, qy, qz), focal_mm, flags, pos)

    if msg_type == MSG_ACK:
        if len(data) < ACK_SIZE:
            return None
        (acked_seq,) = _ACK_BODY.unpack_from(data, HEADER_SIZE)
        return AckMsg(seq, timestamp_ns, acked_seq)

    if msg_type in EMPTY_TYPES:
        return EmptyMsg(seq, timestamp_ns, msg_type)

    if msg_type in JSON_TYPES:
        raw = data[HEADER_SIZE:]
        if not raw:
            body: Dict[str, Any] = {}
        else:
            try:
                body = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                return None
            if not isinstance(body, dict):
                return None
        return JsonMsg(seq, timestamp_ns, msg_type, body)

    return None  # unknown msg_type: MUST be ignored
