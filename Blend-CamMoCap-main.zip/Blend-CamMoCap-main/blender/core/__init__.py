# SPDX-License-Identifier: GPL-3.0-or-later
"""pocketrig core: pure-Python protocol, session and math. Never imports bpy."""
