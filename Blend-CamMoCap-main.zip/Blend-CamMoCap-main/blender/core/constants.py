# SPDX-License-Identifier: GPL-3.0-or-later
"""Project-wide constants. The codename/version strings live ONLY here."""

from typing import Final

CODENAME: Final[str] = "pocketrig"
ADDON_VERSION: Final[str] = "0.1.0"

PROTOCOL_VERSION: Final[int] = 1

# Server binds DEFAULT_PORT; if taken, tries up to PORT_RANGE_END (inclusive).
DEFAULT_PORT: Final[int] = 47800
PORT_RANGE_END: Final[int] = 47809

MAGIC: Final[bytes] = b"PR"

# Message types (spec/protocol.md section 3).
MSG_POSE: Final[int] = 0x01
MSG_BYE: Final[int] = 0x0F
MSG_HELLO: Final[int] = 0x10
MSG_WELCOME: Final[int] = 0x11
MSG_PING: Final[int] = 0x12
MSG_PONG: Final[int] = 0x13
MSG_ERROR: Final[int] = 0x1F
MSG_RECORD_START: Final[int] = 0x20
MSG_RECORD_STOP: Final[int] = 0x21
MSG_RECORD_BAKED: Final[int] = 0x22
MSG_RECENTER: Final[int] = 0x23
MSG_PARAMS: Final[int] = 0x24
MSG_PAUSE: Final[int] = 0x25
MSG_SEEK: Final[int] = 0x26
MSG_TAKE_LIST: Final[int] = 0x27
MSG_TAKE_PULL: Final[int] = 0x28
MSG_FRAME_RESET: Final[int] = 0x29
# Viewport channel control plane (spec/viewport-channel.md section 5). Only the
# control messages travel here; frames ride their own TCP connection.
MSG_VIEWPORT_CONTROL: Final[int] = 0x2A
MSG_VIEWPORT_STAT: Final[int] = 0x2B
MSG_ACK: Final[int] = 0x30

# Message types that use the resend-until-ACK layer (spec section 6).
RELIABLE_TYPES: Final[frozenset] = frozenset(
    {
        MSG_BYE,
        MSG_HELLO,
        MSG_WELCOME,
        MSG_ERROR,
        MSG_RECORD_START,
        MSG_RECORD_STOP,
        MSG_RECORD_BAKED,
        MSG_RECENTER,
        MSG_PARAMS,
        MSG_PAUSE,
        MSG_SEEK,
        MSG_TAKE_LIST,
        MSG_TAKE_PULL,
        MSG_FRAME_RESET,
        # VIEWPORT_CONTROL is reliable: starting or stopping a stream is a
        # deliberate act and must not be lost. VIEWPORT_STAT deliberately is
        # NOT -- it is telemetry about a preview, and a resend layer would cost
        # more than the information is worth.
        MSG_VIEWPORT_CONTROL,
    }
)

POSE_SEND_HZ: Final[int] = 100

# POSE flags (spec section 4).
FLAG_RECORDING: Final[int] = 0x0001
FLAG_HAS_POSITION: Final[int] = 0x0002  # spec section 4.1 (protocol v1.1)
FLAG_QUALITY_SHIFT: Final[int] = 2
FLAG_QUALITY_MASK: Final[int] = 0x001C
FLAG_ISSUE_SHIFT: Final[int] = 5
FLAG_ISSUE_MASK: Final[int] = 0x00E0

# Values carried in the append-only POSE flag fields (spec section 4.2).
TRACKING_UNKNOWN: Final[int] = 0
TRACKING_WARMING: Final[int] = 1
TRACKING_GOOD: Final[int] = 2
TRACKING_DEGRADED: Final[int] = 3
TRACKING_LOST: Final[int] = 4
TRACKING_RECOVERING: Final[int] = 5

ISSUE_NONE: Final[int] = 0
ISSUE_INITIALIZING: Final[int] = 1
ISSUE_INSUFFICIENT_FEATURES: Final[int] = 2
ISSUE_INSUFFICIENT_LIGHT: Final[int] = 3
ISSUE_EXCESSIVE_MOTION: Final[int] = 4
ISSUE_BAD_STATE: Final[int] = 5
ISSUE_CAMERA_UNAVAILABLE: Final[int] = 6
ISSUE_UNKNOWN: Final[int] = 7

# Reliability / lifecycle timing (seconds unless noted).
RELIABLE_RESEND_INTERVAL: Final[float] = 0.200  # resend unacked reliable msg
RELIABLE_GIVE_UP: Final[float] = 5.0  # stop resending, enter error state
CLIENT_GONE_TIMEOUT: Final[float] = 8.0  # no packet from client -> "gone"

# Session token alphabet: uppercase minus lookalikes 0/O/1/I (spec section 9).
TOKEN_ALPHABET: Final[str] = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
TOKEN_LENGTH: Final[int] = 6


# ----------------------------------------------------------- viewport channel

#: The viewport stream binds this port, then walks upward like the pose port
#: does. A separate socket from both the pose flow and the take listener: the
#: take listener is listen(1) with a blocking serial reader, so sharing it would
#: starve take uploads, and the pose flow must never queue behind pixels.
VIEWPORT_PORT: Final[int] = 47810
VIEWPORT_PORT_RANGE_END: Final[int] = 47819

#: Frame header magic and version (spec/viewport-channel.md section 4).
VIEWPORT_MAGIC: Final[bytes] = b"PRVP"
VIEWPORT_FRAME_VERSION: Final[int] = 1

#: Codec ids. 0 is reserved so a zeroed header cannot decode as a valid frame.
VIEWPORT_CODEC_JPEG: Final[int] = 1
VIEWPORT_CODEC_NAMES: Final[dict] = {VIEWPORT_CODEC_JPEG: "jpeg"}

#: Frame flags. Bit 0 says the frame stands alone, which is the permission the
#: transport relies on to drop frames freely.
VIEWPORT_FLAG_KEYFRAME: Final[int] = 0x0001

#: A frame larger than this is not a frame; it is a desynchronised reader about
#: to allocate whatever a garbage length said. Lives here rather than in the
#: codec so both the sender and any receiver can cite one number.
VIEWPORT_MAX_PAYLOAD_GUARD: Final[int] = 8 * 1024 * 1024
