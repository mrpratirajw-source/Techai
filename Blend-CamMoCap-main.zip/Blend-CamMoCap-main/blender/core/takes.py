# SPDX-License-Identifier: GPL-3.0-or-later
"""Pure quaternion math for take baking. No bpy — unit-tested on desktop.

Quaternions are (w, x, y, z) tuples, Hamilton convention. q and -q are the
same rotation; every public function that consumes a sequence hemisphere-
aligns it so component-wise operations (gaussian smoothing, keyframes) are
continuous.
"""

from __future__ import annotations

import math
from statistics import median
from typing import List, NamedTuple, Optional, Sequence, Tuple

Quat = Tuple[float, float, float, float]
Sample = Tuple[int, Quat]  # (timestamp_ns, quat)
Vec3 = Tuple[float, float, float]
PosSample = Tuple[int, Vec3]  # (timestamp_ns, position)
PosMaybeSample = Tuple[int, Optional[Vec3]]
class RowSample(NamedTuple):
    """One take sample: everything the baker needs for one instant.

    A NamedTuple so fields can be appended without disturbing positional use,
    matching the append-only discipline of the wire itself.
    """

    t: int
    q: Quat
    pos: Optional[Vec3]
    #: Lens focal length in mm, None when the sender was not driving the lens.
    focal_mm: Optional[float] = None

# Upper bound on rows in one take body (spec 5.10). ~1.4 h at 100 Hz; a header
# claiming more is refused outright rather than sized into memory.
MAX_TAKE_ROWS = 500_000

# Quality names (spec 4.2/5.10) whose rows carry usable camera position. Any
# other name marks an invalid-position row even when `p` is present: the phone
# keeps raw `p` as evidence for future reconstruction, but it is not a
# trustworthy camera translation and MUST NOT be baked as one.
_POSITION_VALID_QUALITY = (None, "unknown", "good")


def _finite(value: object) -> float:
    """A JSON number that is safe to do geometry with, else ValueError.

    bool is rejected explicitly: it is an int subclass, so `True` would
    otherwise sail through as 1.0.
    """
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"expected a number, got {type(value).__name__}")
    out = float(value)
    if not math.isfinite(out):
        raise ValueError("non-finite number")
    return out


def parse_row(row: object) -> RowSample:
    """One JSONL take row (spec 5.10) -> a validated (timestamp, quat, position).

    Raises ValueError for anything the baker cannot honestly use. Every take row
    reaching the bake path goes through here — TCP upload, phone push, and
    `.take` file import alike — so the three cannot drift apart.

    This exists because unvalidated rows were not merely a hostile-input
    concern: a truncated `.partial` write or a corrupt file could put a
    non-finite quaternion into `cam.rotation_quaternion` keyframes, and NaN in a
    transform propagates through the dependency graph and is painful to undo.
    Rejecting the row loudly loses one take; accepting it corrupts a scene.
    """
    if not isinstance(row, dict):
        raise ValueError("row is not a JSON object")
    ts = _finite(row.get("t"))
    quat = row.get("q")
    if not isinstance(quat, (list, tuple)) or len(quat) != 4:
        raise ValueError("q must be a 4-element array")
    q = tuple(_finite(c) for c in quat)
    if math.sqrt(sum(c * c for c in q)) <= 0.0:
        raise ValueError("q has zero magnitude and no direction")

    pos: Optional[Vec3] = None
    raw_pos = row.get("p")
    if raw_pos is not None:
        if not isinstance(raw_pos, (list, tuple)) or len(raw_pos) != 3:
            raise ValueError("p must be a 3-element array")
        pos = tuple(_finite(c) for c in raw_pos)  # type: ignore[assignment]
    quality = row.get("quality")
    if quality is not None and not isinstance(quality, str):
        raise ValueError("quality must be a string")
    if quality not in _POSITION_VALID_QUALITY:
        pos = None  # raw evidence retained on the phone; not valid translation

    # Lens focal length (spec 4.5), optional per row: a take recorded by a
    # sender that was not driving the lens simply has none. Unlike position it
    # has no validity flag -- a focal length is either present or absent.
    focal_mm: Optional[float] = None
    raw_focal = row.get("f")
    if raw_focal is not None:
        mm = _finite(raw_focal)
        if mm <= 0.0:
            raise ValueError("f must be a positive focal length in mm")
        focal_mm = mm

    return RowSample(int(ts), q, pos, focal_mm)  # type: ignore[arg-type]


def normalize(q: Quat) -> Quat:
    n = math.sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3])
    # `not (n > 0.0)` also catches NaN, where `n == 0.0` is False and every
    # later division would silently propagate NaN into a camera transform.
    if not (n > 0.0) or math.isinf(n):
        return (1.0, 0.0, 0.0, 0.0)
    return (q[0] / n, q[1] / n, q[2] / n, q[3] / n)


def multiply(q1: Quat, q2: Quat) -> Quat:
    """Hamilton product q1 (x) q2 — applies q2 first, then q1."""
    w1, x1, y1, z1 = q1
    w2, x2, y2, z2 = q2
    return (
        w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2,
        w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
        w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2,
        w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2,
    )


def conjugate(q: Quat) -> Quat:
    return (q[0], -q[1], -q[2], -q[3])


def inverse(q: Quat) -> Quat:
    """Inverse for any non-zero quaternion (== conjugate for unit ones)."""
    n2 = q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3]
    if n2 == 0.0:
        return (1.0, 0.0, 0.0, 0.0)
    return (q[0] / n2, -q[1] / n2, -q[2] / n2, -q[3] / n2)


def dot(q1: Quat, q2: Quat) -> float:
    return q1[0] * q2[0] + q1[1] * q2[1] + q1[2] * q2[2] + q1[3] * q2[3]


def negate(q: Quat) -> Quat:
    return (-q[0], -q[1], -q[2], -q[3])


def slerp(q1: Quat, q2: Quat, t: float) -> Quat:
    """Shortest-path spherical interpolation; t in [0, 1]."""
    d = dot(q1, q2)
    if d < 0.0:
        q2 = negate(q2)
        d = -d
    # `not (d <= 0.9995)` rather than `d > 0.9995` so a NaN dot takes the nlerp
    # branch too. Under the old ordering NaN skipped this test, then
    # `min(1.0, NaN)` returned 1.0 (NaN comparisons are False), giving
    # theta = acos(1) = 0 and sin(0) = 0 as the divisor below —
    # a ZeroDivisionError raised from pure resampling math.
    if not (d <= 0.9995):  # nearly parallel: nlerp is exact enough and stable
        q = tuple(a + t * (b - a) for a, b in zip(q1, q2))
        return normalize(q)  # type: ignore[arg-type]
    d = min(1.0, d)
    theta = math.acos(d)
    s = math.sin(theta)
    if s == 0.0:  # unreachable via the guard above; never divide by zero
        return normalize(q1)
    w1 = math.sin((1.0 - t) * theta) / s
    w2 = math.sin(t * theta) / s
    return (
        w1 * q1[0] + w2 * q2[0],
        w1 * q1[1] + w2 * q2[1],
        w1 * q1[2] + w2 * q2[2],
        w1 * q1[3] + w2 * q2[3],
    )


def hemisphere_align(quats: Sequence[Quat]) -> List[Quat]:
    """Negate each quat whose dot with its aligned predecessor is negative."""
    out: List[Quat] = []
    prev: Quat | None = None
    for q in quats:
        if prev is not None and dot(prev, q) < 0.0:
            q = negate(q)
        out.append(q)
        prev = q
    return out


def resample(
    samples: Sequence[Sample], start_ns: int, end_ns: int, fps: float
) -> List[Quat]:
    """Slerp-resample at scene fps. frame_count = floor((end-start)*fps/1e9)+1.

    Frame times before the first / after the last raw sample clamp to the
    nearest sample. `samples` must be sorted by timestamp; empty input -> [].
    """
    if not samples or end_ns < start_ns or fps <= 0.0:
        return []
    frame_count = int(math.floor((end_ns - start_ns) * fps / 1e9 + 1e-9)) + 1
    times = [s[0] for s in samples]
    quats = [s[1] for s in samples]
    out: List[Quat] = []
    hi = len(samples) - 1
    idx = 0
    for f in range(frame_count):
        t = start_ns + f * 1e9 / fps
        if t <= times[0]:
            out.append(quats[0])
            continue
        if t >= times[hi]:
            out.append(quats[hi])
            continue
        while idx < hi - 1 and times[idx + 1] <= t:
            idx += 1
        t0, t1 = times[idx], times[idx + 1]
        u = (t - t0) / (t1 - t0) if t1 > t0 else 0.0
        out.append(slerp(quats[idx], quats[idx + 1], u))
    return out


def gaussian_smooth(quats: Sequence[Quat], sigma_frames: float) -> List[Quat]:
    """Component-wise gaussian blur, then re-normalize each quaternion.

    Input must already be hemisphere-aligned. Kernel is truncated at 3 sigma
    and re-normalized at the boundaries (no phantom padding). sigma <= 0 is
    a no-op copy.
    """
    if sigma_frames <= 0.0 or len(quats) < 2:
        return list(quats)
    radius = max(1, int(math.ceil(3.0 * sigma_frames)))
    weights = [math.exp(-0.5 * (k / sigma_frames) ** 2) for k in range(-radius, radius + 1)]
    n = len(quats)
    out: List[Quat] = []
    for i in range(n):
        acc = [0.0, 0.0, 0.0, 0.0]
        wsum = 0.0
        for k in range(-radius, radius + 1):
            j = i + k
            if j < 0 or j >= n:
                continue
            w = weights[k + radius]
            wsum += w
            q = quats[j]
            acc[0] += w * q[0]
            acc[1] += w * q[1]
            acc[2] += w * q[2]
            acc[3] += w * q[3]
        out.append(normalize((acc[0] / wsum, acc[1] / wsum, acc[2] / wsum, acc[3] / wsum)))
    return out


def resample_positions(
    samples: Sequence[PosSample], start_ns: int, end_ns: int, fps: float
) -> List[Vec3]:
    """Per-axis linear resample at scene fps — the positional twin of
    resample(), same frame-count rule and clamping behaviour."""
    if not samples or end_ns < start_ns or fps <= 0.0:
        return []
    frame_count = int(math.floor((end_ns - start_ns) * fps / 1e9 + 1e-9)) + 1
    times = [s[0] for s in samples]
    positions = [s[1] for s in samples]
    out: List[Vec3] = []
    hi = len(samples) - 1
    idx = 0
    for f in range(frame_count):
        t = start_ns + f * 1e9 / fps
        if t <= times[0]:
            out.append(positions[0])
            continue
        if t >= times[hi]:
            out.append(positions[hi])
            continue
        while idx < hi - 1 and times[idx + 1] <= t:
            idx += 1
        t0, t1 = times[idx], times[idx + 1]
        u = (t - t0) / (t1 - t0) if t1 > t0 else 0.0
        p0, p1 = positions[idx], positions[idx + 1]
        out.append(
            (
                p0[0] + u * (p1[0] - p0[0]),
                p0[1] + u * (p1[1] - p0[1]),
                p0[2] + u * (p1[2] - p0[2]),
            )
        )
    return out


def gaussian_smooth_positions(
    positions: Sequence[Vec3], sigma_frames: float
) -> List[Vec3]:
    """Component-wise gaussian blur (no normalization — positions are not
    unit vectors). Same truncated-at-3-sigma kernel as gaussian_smooth."""
    if sigma_frames <= 0.0 or len(positions) < 2:
        return list(positions)
    radius = max(1, int(math.ceil(3.0 * sigma_frames)))
    weights = [math.exp(-0.5 * (k / sigma_frames) ** 2) for k in range(-radius, radius + 1)]
    n = len(positions)
    out: List[Vec3] = []
    for i in range(n):
        acc = [0.0, 0.0, 0.0]
        wsum = 0.0
        for k in range(-radius, radius + 1):
            j = i + k
            if j < 0 or j >= n:
                continue
            w = weights[k + radius]
            wsum += w
            p = positions[j]
            acc[0] += w * p[0]
            acc[1] += w * p[1]
            acc[2] += w * p[2]
        out.append((acc[0] / wsum, acc[1] / wsum, acc[2] / wsum))
    return out


def bake_focal(
    samples: Sequence[Tuple[int, Optional[float]]],
    start_ns: int,
    end_ns: int,
    fps: float,
) -> List[float]:
    """Focal length per frame, or [] when no sample carries one.

    Linearly interpolated and clamped at the ends, like position. Deliberately
    NOT smoothed by the recording-smoothing slider: a zoom is a deliberate
    creative move, and filtering it would only add lag to the thing the operator
    was performing. Rows without a focal length are skipped, so a take where the
    sender started driving the lens partway through holds the first known value
    across the earlier frames rather than inventing a zoom from nothing.
    """
    known = sorted(
        ((t, mm) for t, mm in samples if mm is not None), key=lambda s: s[0]
    )
    if not known or end_ns < start_ns or fps <= 0.0:
        return []
    frame_count = int(math.floor((end_ns - start_ns) * fps / 1e9 + 1e-9)) + 1
    times = [t for t, _ in known]
    values = [mm for _, mm in known]
    out: List[float] = []
    hi = len(known) - 1
    idx = 0
    for frame in range(frame_count):
        t = start_ns + frame * 1e9 / fps
        if t <= times[0]:
            out.append(values[0])
            continue
        if t >= times[hi]:
            out.append(values[hi])
            continue
        while idx < hi - 1 and times[idx + 1] <= t:
            idx += 1
        t0, t1 = times[idx], times[idx + 1]
        u = (t - t0) / (t1 - t0) if t1 > t0 else 0.0
        out.append(values[idx] + u * (values[idx + 1] - values[idx]))
    return out


def bake_positions(
    samples: Sequence[PosSample],
    start_ns: int,
    end_ns: int,
    fps: float,
    smoothing: float = 0.0,
) -> List[Vec3]:
    """Raw position samples -> optionally smoothed, per-frame positions.

    Mirrors bake(): the same sigma_seconds = 0.25 * smoothing rule, applied on
    the raw samples before resampling, so one Recording-smoothing slider
    governs rotation and position identically."""
    samples = sorted(samples, key=lambda s: s[0])
    positions = [s[1] for s in samples]
    if smoothing > 0.0 and len(samples) >= 3:
        dts = [
            (samples[i + 1][0] - samples[i][0]) / 1e9 for i in range(len(samples) - 1)
        ]
        dts = [d for d in dts if d > 0.0]
        if dts:
            sigma_seconds = 0.25 * smoothing
            sigma_samples = sigma_seconds / median(dts)
            positions = gaussian_smooth_positions(positions, sigma_samples)
    resampled = list(zip((s[0] for s in samples), positions))
    return resample_positions(resampled, start_ns, end_ns, fps)


def bake_segmented_positions(
    samples: Sequence[PosMaybeSample],
    start_ns: int,
    end_ns: int,
    fps: float,
    smoothing: float = 0.0,
) -> List[Vec3]:
    """Bake position without inventing motion across invalid tracking gaps.

    Contiguous valid runs are smoothed independently. During an invalid run,
    output holds the preceding valid endpoint. A recovered run is translated
    so its first sample equals that held endpoint, preserving its subsequent
    relative motion without exposing a changed tracking origin. Before the
    first and after the last valid run, the nearest valid position is held.

    With no invalid rows this is exactly :func:`bake_positions`.
    """
    ordered = sorted(samples, key=lambda s: s[0])
    if not ordered or end_ns < start_ns or fps <= 0.0:
        return []
    if all(pos is not None for _ts, pos in ordered):
        return bake_positions(
            [(ts, pos) for ts, pos in ordered if pos is not None],
            start_ns,
            end_ns,
            fps,
            smoothing,
        )

    raw_segments: List[List[PosSample]] = []
    current: List[PosSample] = []
    for ts, pos in ordered:
        if pos is None:
            if current:
                raw_segments.append(current)
                current = []
        else:
            current.append((ts, pos))
    if current:
        raw_segments.append(current)
    if not raw_segments:
        return []

    # Smooth each valid island in isolation, then align every recovered island
    # to the last trustworthy endpoint. No sample on the far side of a gap can
    # influence the near side through the smoothing kernel.
    segments: List[List[PosSample]] = []
    previous_endpoint: Optional[Vec3] = None
    for raw in raw_segments:
        positions = [p for _ts, p in raw]
        if smoothing > 0.0 and len(raw) >= 3:
            dts = [
                (raw[i + 1][0] - raw[i][0]) / 1e9
                for i in range(len(raw) - 1)
                if raw[i + 1][0] > raw[i][0]
            ]
            if dts:
                sigma_samples = (0.25 * smoothing) / median(dts)
                positions = gaussian_smooth_positions(positions, sigma_samples)
        if previous_endpoint is not None:
            delta: Vec3 = (
                previous_endpoint[0] - positions[0][0],
                previous_endpoint[1] - positions[0][1],
                previous_endpoint[2] - positions[0][2],
            )
            positions = [
                (p[0] + delta[0], p[1] + delta[1], p[2] + delta[2])
                for p in positions
            ]
        segment = list(zip((s[0] for s in raw), positions))
        segments.append(segment)
        previous_endpoint = segment[-1][1]

    frame_count = int(math.floor((end_ns - start_ns) * fps / 1e9 + 1e-9)) + 1
    out: List[Vec3] = []
    seg_index = 0
    sample_index = 0
    for frame in range(frame_count):
        t = start_ns + frame * 1e9 / fps
        while seg_index + 1 < len(segments) and t >= segments[seg_index + 1][0][0]:
            seg_index += 1
            sample_index = 0
        segment = segments[seg_index]
        if t <= segment[0][0]:
            # Initial clamp, or the exact first frame of a recovered segment.
            out.append(segment[0][1])
            continue
        if t >= segment[-1][0]:
            # Includes every invalid interval before the next segment.
            out.append(segment[-1][1])
            continue
        while sample_index < len(segment) - 2 and segment[sample_index + 1][0] <= t:
            sample_index += 1
        t0, p0 = segment[sample_index]
        t1, p1 = segment[sample_index + 1]
        u = (t - t0) / (t1 - t0) if t1 > t0 else 0.0
        out.append(tuple(p0[i] + u * (p1[i] - p0[i]) for i in range(3)))
    return out


def bake(
    samples: Sequence[Sample],
    start_ns: int,
    end_ns: int,
    fps: float,
    smoothing: float = 0.0,
) -> List[Quat]:
    """Raw samples -> hemisphere-aligned, optionally smoothed, per-frame quats.

    `smoothing` is the 0..1 UI value; sigma_seconds = 0.25 * smoothing, applied
    on the RAW samples (~100 Hz cadence) before resampling, with
    sigma_samples = sigma_seconds / median_sample_dt. smoothing == 0 is exact
    slerp resampling with no filtering.
    """
    samples = sorted(samples, key=lambda s: s[0])
    quats = hemisphere_align([normalize(s[1]) for s in samples])
    if smoothing > 0.0 and len(samples) >= 3:
        dts = [
            (samples[i + 1][0] - samples[i][0]) / 1e9 for i in range(len(samples) - 1)
        ]
        dts = [d for d in dts if d > 0.0]
        if dts:
            sigma_seconds = 0.25 * smoothing
            sigma_samples = sigma_seconds / median(dts)
            quats = gaussian_smooth(quats, sigma_samples)
    aligned = list(zip((s[0] for s in samples), quats))
    return hemisphere_align(resample(aligned, start_ns, end_ns, fps))
