# Licensing

pocketrig is **free for noncommercial use**. Commercial use requires permission —
contact **bratuka@bratuka.dev**. The repository uses a different license per component,
on purpose:

| Component | License | Why |
|---|---|---|
| `android/` | [PolyForm Noncommercial 1.0.0](android/LICENSE) | The phone app is independent of Blender. Source-available and free for any noncommercial purpose; commercial use needs a separate license. |
| `spec/`, `fixtures/` | [CC BY-NC-4.0](https://creativecommons.org/licenses/by-nc/4.0/) | The wire protocol and shared test vectors: implement, share, and build on them with attribution, for noncommercial use. |
| `blender/`, `tools/` | [GPL-3.0-or-later](blender/LICENSE) | Blender add-ons import `bpy`, which is GPL, so the add-on **must** be GPL-compatible — a noncommercial license is legally impossible here. GPL still forbids closed, proprietary forks: any commercial use must itself stay open under GPL. `tools/` import `blender/core/`, so they inherit GPL. |

Repository meta-docs (`README.md`, `CONTRIBUTING.md`, `QUICKSTART.md`, `dev/`, this
file) are informational and may be reused freely. `dev/` describes how the code is put
together rather than what an implementation must do — `spec/` is the normative half, and
it is the one under CC BY-NC-4.0.

## Why the add-on can't be noncommercial

Blender's Python API (`bpy`) is GPL, and Blender's own policy treats any add-on that
imports it as a derivative work that must ship under a GPL-compatible license. The GPL
guarantees the freedom to use software commercially, so it does not permit adding a
"noncommercial only" restriction. This is a hard legal/technical constraint, not a
choice — and the Blender Extensions platform only accepts GPL-compatible licenses. The
strongest protection available for the add-on is therefore GPL copyleft, which already
blocks anyone from selling a closed, proprietary version of it.

SPDX identifiers in source headers: `PolyForm-Noncommercial-1.0.0`, `CC-BY-NC-4.0`,
`GPL-3.0-or-later`.
