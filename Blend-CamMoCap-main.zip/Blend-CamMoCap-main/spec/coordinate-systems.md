# Coordinate Systems & Rotation Conventions

License: CC-BY-NC-4.0. Normative. The shared vectors in
[`fixtures/orientation_cases.json`](../fixtures/orientation_cases.json) pin every rule in
this document; an implementation that passes them is conformant.

## 1. Quaternions

- Order **(w, x, y, z)**, unit norm, **Hamilton** convention, right-handed.
- A pose quaternion `q` rotates camera-frame vectors into world-frame vectors:
  `v_world = q ⊗ v_cam ⊗ q⁻¹`.
- `q` and `−q` encode the same rotation; receivers hemisphere-align consecutive samples
  (negate the incoming quaternion when `dot(q_prev, q_in) < 0`).
- Hamilton product, for reference — `q1 ⊗ q2` applies `q2` first, then `q1`:

```
w = w1·w2 − x1·x2 − y1·y2 − z1·z2
x = w1·x2 + x1·w2 + y1·z2 − z1·y2
y = w1·y2 − x1·z2 + y1·w2 + z1·x2
z = w1·z2 + x1·y2 − y1·x2 + z1·w2
```

## 2. The protocol frame (what POSE carries)

**World frame:** right-handed, **Z up**. The X/Y ground directions are arbitrary (the
sensor's yaw reference is arbitrary and re-centering handles absolute heading — see §5).

**Camera frame:** **+X right, +Y up, −Z forward** (the look direction is −Z).

This is *exactly Blender's convention*: a Blender camera object with identity rotation
looks along −Z (down) with +Y up. Consequently the Blender add-on applies the protocol
quaternion to `camera.rotation_quaternion` essentially verbatim (only the re-center offset
is composed in, §5). **The phone does all platform-specific conversion.** Rationale: there
is one Blender but potentially many phone platforms; the platform-specific math lives on
the platform-specific side, and the shared fixtures force every new client (e.g. iOS) to
prove its conversion.

## 3. Android → protocol conversion

Android's game rotation vector yields `q_sensor`, the rotation from the **device frame**
(natural portrait: +X right edge, +Y top edge, +Z out of the screen toward the user) to
Android's **world frame** (Z up, right-handed, arbitrary yaw reference — magnetometer-free).
Android's world frame is accepted as the protocol world frame as-is.

The rear camera looks along device **−Z**, so a portrait-held phone's device frame *is* the
protocol camera frame:

```
q_protocol = q_sensor ⊗ q_remap(display_rotation)
```

| `Display.rotation` | Physical grip (top of phone points…) | `q_remap` (w, x, y, z) |
|---|---|---|
| `ROTATION_0` | up (natural portrait) | (1, 0, 0, 0) |
| `ROTATION_90` | left | (√2⁄2, 0, 0, **−√2⁄2**) — Rz(−90°) |
| `ROTATION_180` | down | (0, 0, 0, 1) — Rz(180°) |
| `ROTATION_270` | right | (√2⁄2, 0, 0, **+√2⁄2**) — Rz(+90°) |

`q_remap` re-labels the device axes so that "camera up" follows the grip: e.g. with the
phone top pointing left, camera-up is the device's +X. Note Android defines `ROTATION_90`
as the device rotated 90° **counter-clockwise** from natural (content compensates
clockwise).

Implementations MUST normalize `q_protocol` before sending (guards f32 drift).

### 3.1 Display and pose-source continuity

Changing Android display orientation relabels a display-oriented pose frame. Switching
between the game-rotation-vector and ARCore sources can likewise change the input
reference even when the phone has not physically moved. These are internal frame-boundary
events, **not** user re-centering.

The sender MUST keep each emitted POSE as one rigid transform: quaternion and position are
expressed in the same protocol world frame. In particular, it MUST NOT left-correct the
quaternion while leaving position unchanged. That creates two different world frames inside
one POSE and rotates translational movement onto incorrect axes.

A sender with several internal sources SHOULD go further and emit one *continuous* world
frame across them, per `protocol.md` §5.12: at an internal boundary, rotate **both**
quaternion and position by the same world rotation so the first pose after the boundary
equals the last one before it. The two sources' frames differ by an arbitrary fixed rotation
(measured on the reference phone: a ~90° yaw about world up, unchanged across headings), and
that difference is otherwise delivered as a single enormous step for the host to guess at.
Applying one rotation to both components keeps `q⁻¹ · p` invariant, so it re-expresses the
same physical transform rather than corrupting it — the distinction that makes this safe
where a quaternion-only correction was not.

The reference continuity flow is FRAME_RESET (`protocol.md` §5.12): gate POSE output, send
the reliable boundary, wait for ACK, then resume with the newest raw pose. The host preserves
the visible camera by recomputing both of its composition offsets against that first pose.
It does not alter pause/review state or the stored Home. RECENTER remains only the deliberate
user-facing Home operation in §5.

### Worked check (fixture `landscape90_north_level`)

Phone held landscape, top pointing left (`ROTATION_90`), rear camera looking "north" (+Y
world), level. Device axes in world: X_dev = +Z_w, Y_dev = −X_w, Z_dev = −Y_w →
`q_sensor = (0.5, 0.5, −0.5, 0.5)`. Multiply by Rz(−90°): `q_protocol = (√2⁄2, √2⁄2, 0, 0)`
— identical to the portrait phone in the same physical camera pose. Both landscape grips
and portrait converge on the same protocol value; that is the invariant the fixtures
enforce.

## 4. Blender side

- Force the camera object's `rotation_mode = 'QUATERNION'` while driving (no Euler flips).
- Apply: `camera.rotation_quaternion = q_offset ⊗ q_protocol` (after hemisphere alignment
  against the previously applied quaternion).
- Baked keyframes go on `rotation_quaternion` (4 channels), hemisphere-aligned along the
  whole take so F-curves never jump.
- Euler values in fixtures use Blender's `'XYZ'` mode (matrix `R = Rz·Ry·Rx`) in degrees,
  for human checking only; quaternions are the ground truth.

## 5. Re-centering (the offset quaternion)

The sensor's yaw reference is arbitrary, and game-rotation-vector yaw drifts slowly. Both
are handled by one mechanism on the Blender side. On **connect**, the camera's orientation
before we start driving it is captured as the *home framing* `q_home`, and the offset is set
so the camera stays put while phone motion becomes relative to it:

```
q_home   = q_camera_at_connect
q_offset = q_home ⊗ (q_protocol_latest)⁻¹      # camera = q_offset ⊗ q_protocol = q_home
```

**Re-center** (panel button or phone tap) re-applies that same formula against the *stored*
`q_home` and the phone's current orientation. The camera therefore **snaps back to the home
framing** and the current phone pose becomes the new neutral — a visible, useful reset that
recovers accumulated yaw drift and awkward angles. (Re-zeroing against the camera's *live*
orientation instead would be a near-no-op whenever the phone is held still at the moment of
the tap, which is why the home framing is anchored at connect.)

Left-composition preserves local-frame motion: phone tilts up → camera tilts up about *its
own* X axis regardless of where the offset points it. During recording the offset is frozen
at its value from record start (re-center is disabled mid-take).

## 6. Position (6DOF, protocol v1.1 — normative)

POSE's optional position (protocol §4.1) is the camera's location in **meters** in the
same right-handed Z-up world frame the quaternion is expressed in. Its origin is arbitrary
(wherever the phone's tracker happened to start); only displacement carries meaning, and
re-centering absorbs the origin entirely.

The host drives the camera as one rigid transform, offset-composed on the left exactly
like rotation, with a host-side movement scale `s` (default 1.0; >1 amplifies hand motion,
<1 tames it):

```
cam_rot = q_offset ⊗ q_pose
cam_loc = t_offset + s · R(q_offset) · p_pose        # R(q) = rotate vector by q
```

**Re-center (6DOF)** extends §5 with the position analogue, against the stored home
placement:

```
q_offset = q_home ⊗ (q_pose)⁻¹
t_offset = loc_home − s · R(q_offset) · p_pose
```

The camera snaps back to its home placement, and subsequent phone translation is relative
to it, rotated into the home frame — walking forward moves the camera along its *own* view
direction regardless of where the offset points it (the positional twin of §5's
left-composition property).

Host rules:

- When `s` changes, hosts MUST recompute `t_offset` against the latest pose so the camera
  never jumps on a scale change.
- Both offsets are frozen during recording (as in §5).
- When position_valid drops (tracking loss), the host keeps driving rotation and holds the
  camera's last location; when it returns, the host MUST re-anchor `t_offset` against the
  camera's current location before applying it (no jump on recovery).
- Hosts SHOULD also re-anchor (outside recording) when the position stream itself betrays a
  tracker restart that the sender failed to flag: a gap of > 250 ms between the *timestamps*
  of consecutively applied positional poses (arrival timing proves nothing — a buggy sender
  can repeat a stale pose at full rate with a frozen timestamp), or an implied speed
  `|Δp| / Δt` above a handful of m/s (real handheld translation tops out near 3 m/s; visual
  trackers relocalizing do far more — the reference host uses 5 m/s). A spurious re-anchor
  is harmless by construction — the camera continues from where it is — which is why these
  guards are safe to apply aggressively.
- The same reasoning applies to **orientation** for 6DOF senders (visual trackers rotate
  their world on loop closure; inertial fusion never discontinues): on an implied angular
  speed no wrist produces (reference host: > 1200 °/s; whip pans reach ~700 °/s), hosts
  SHOULD re-express `q_offset` against the new reference — `q_offset ← q_shown ⊗ q_new⁻¹`,
  where `q_shown` is the currently displayed camera orientation — so the view holds, and
  then re-anchor `t_offset` too (the position mapping `R(q_offset)` just changed).
  This guard MUST remain active while position is **invalid**. A visual tracker hands over
  a rotated world precisely when its position is untrusted — during the recovery dwell
  after a loss, when a correct sender is reporting `RECOVERING` and withholding position —
  so gating it on position validity switches it off for the one window it exists to cover.
  Measured on device: ARCore's orientation returned 0.93 s before its position did, and the
  camera snapped through that gap. Identify a visual sender by a non-`UNKNOWN` quality
  field (`protocol.md` §4.2) or by position having been present, not by this pose carrying
  position. Rotation-only inertial senders stay exempt.
- Hosts SHOULD low-pass the displayed position (display only, never recorded data) with the
  same speed-adaptive character as rotation, applied to the RAW protocol position *before*
  movement scale — so scale amplifies motion, never the tracker's noise floor.
- **Shake-hold:** above an angular speed no framing move produces (the reference host
  defaults to 500 °/s, below the relocalization guard) the camera is being shaken/whipped
  hard enough that a visual-inertial sender motion-blurs and its position dead-reckons into a
  clean constant-velocity drift while still reporting *tracked*. Hosts SHOULD HOLD the
  displayed position while angular speed is that high (orientation keeps tracking) and
  re-anchor when it calms, so the drifting positions are never applied. This targets the
  exact regime where 6DOF position is untrustworthy without rejecting slow deliberate
  translation.
  The threshold is **operator-configurable** and may be switched off entirely
  (`protocol.md` §5.7 `shake_hold_dps`). No single value is correct: the gate must sit above
  every legitimate fast reframe and below a genuine shake, and those overlap. 300 °/s is a
  90° turn in 0.3 s — a normal framing move — which is why the reference default is above it.
  Whether an unwanted hold or an unwanted drift is the worse failure depends on the shot.
- Measure that angular speed over a **short average rather than one sample interval**. A
  single interval is a poor estimator in both directions: quaternion noise at 100 Hz reads as
  tens of °/s, so a couple of noisy samples clear a gate while the device is nearly still,
  and a shake that rotates out and back inside one interval under-reports its own speed.
  Senders and hosts that both draw conclusions from this number MUST smooth it the same way,
  or their conclusions diverge. The average is derived from the previous pose and MUST be
  discarded whenever that pose is (a re-anchor, a frame boundary): an average that outlives
  its evidence holds position at the moment tracking is meant to resume. A smoothed gate
  releases over several samples, which is correct — an instant release is the single-interval
  behaviour this replaces.
