# pocketrig Viewport Channel — v3.5

License: CC-BY-NC-4.0. This document is normative for the viewport stream.
It extends [`protocol.md`](protocol.md), which remains normative for the pose
path and control messages.

Every quantitative claim here was measured before it was specified. The evidence
is `tools/viewport_lab/viewport-lab-results.md`; the numbers cited are from one
Windows/RTX 4070/OpenGL host and one Pixel 8 Pro, and are stated as the reason
for a decision rather than as a guarantee.

**Bitrate figures in this document are pessimistic.** The frame corpus they were
measured over was scrambled by a capture bug (see the correction at the head of
`viewport-lab-results.md`), which destroys spatial correlation and so overstates
what every codec costs. Timing, latency and capture figures are unaffected. No
requirement here changes: the link had roughly ten times the headroom needed, so
a lower real bitrate only widens the margin.

## 1. What this is for

The phone shows the operator what the Blender camera sees, so a shot can be
framed without looking at the monitor.

Two modes. **Camera** draws the scene camera into an offscreen buffer and
streams that — what the shot actually is, independent of what the operator is
doing on the host. **Scene** (not specified here) would ship geometry once and
let the phone render from its own pose. The negotiation in §3 names a *list* of
modes and codecs so the second arrives additively.

### Why there is no mode that streams the host's viewport

There was one, and it was deleted. It read the framebuffer the host had already
drawn, which made it three times cheaper — and made the phone's picture depend on
the operator not using Blender. Open another editor, switch windows, or simply
look at the scene from anywhere other than the camera, and the viewfinder showed
something that was not the shot. That is screen sharing, not a viewfinder, and
cost was never the axis the decision belonged on.

It had a second, quieter defect. The region framebuffer carries **alpha 0 over
geometry** with premultiplied colour — 20% of pixels on one real scene — so
dropping alpha rendered every object black. An offscreen draw composites against
the world background and returns a solid 255.

### What camera mode costs, and why it is affordable

2.5-5 ms of the host's main thread per frame against an idle viewport, and
roughly a third to a half of that thread with the phone live and the camera
moving, which is the condition that matters. Two facts carry it:

- **It works from a timer, with no viewport redraw involved** — verified 12 ticks
  out of 12 with the host window *minimised*, and again with the 3D view in free
  perspective while the camera moved, where six consecutive frames came out six
  distinct images framed by the camera. A draw-handler path structurally cannot
  do this, because nothing redraws.
- **Resolution is nearly free against an idle viewport, and is the main dial
  under load.** Against a *static* viewport the draw is 0.74 ms at 1158x798 and
  0.73 ms at 480x330 -- priced by scene, not by pixels -- and total capture is
  2.1 to 5.0 ms across six times the pixels.

  With the phone live and the camera moving it costs far more, and the size is
  what moves it. Measured across a full size x rate sweep at 30 fps, capture
  takes **42.0%** of the host's main thread at 1158x798 and **33.8%** at
  640x440. Hosts SHOULD still offer large sizes -- two fifths of the main thread
  for a full-size viewfinder is affordable, and the loop spends most of an
  iteration waiting on the display anyway -- but SHOULD NOT describe the size
  list as costing only bandwidth.

  **The readback is the cost, and it is a floor.** Split seven ways under a
  correct load at 1158x798, with a repeat measurement to establish that it
  reproduces (14.58 then 14.19 ms, 2.7% apart):

  | segment | ms | share |
  |---|---|---|
  | depsgraph evaluation | 0.06 | 0% |
  | camera matrices | 0.01 | 0% |
  | `draw_view3d` | 2.48 | 17% |
  | `read_color` | 8.89 | **61%** |
  | numpy copy | 0.25 | 2% |
  | flip and pack | 2.56 | 18% |
  | **total** | **14.58** | |

  Readback scales with pixels (8.89 ms at 0.92 MP, 4.68 ms at 0.28 MP) and does
  **not** scale with channel count or respond to double-buffering, so it is the
  transfer itself rather than a stall waiting for our own draw. Blender's Python
  `gpu` API exposes no asynchronous or pixel-buffer path, so a host cannot make
  it cheaper -- only ask for fewer pixels. **This is why the size list is the
  control that matters**, and why hosts SHOULD offer a small one.

  **A host SHOULD read three channels, not four.** An offscreen draw returns a
  solid 255 alpha, so the fourth channel is read only to be discarded, and
  discarding it turns a contiguous copy into a strided one: measured, 2.56 ms
  against 0.33 ms, which is 16-18% of the whole capture at the largest size.
  The readback itself costs the same either way.

  Four things that were expected to cost and do **not**, each measured against a
  baseline that reproduces to within 3%: `do_color_management` (-2%), the
  operator's overlays (-2%), their shading mode (-2%), and reading the previous
  frame's buffer instead of this one's (-2%). None is worth a code path.

  Four earlier revisions of this paragraph were wrong. The first claimed
  15.8/12.0/14.4 ms from a probe that rebuilt a `GPUOffScreen` every iteration
  and timed the allocation. The second claimed a flat 0.75 ms from a probe that
  measured a scene nobody was moving. The third blamed the operator's viewport
  redrawing alongside ours, from a probe that was measuring a rolling take
  against a paused host. The fourth reported a 12 ms draw that did not reproduce
  and called it a 14x gap against the operator's own redraw -- which was itself
  not a fair comparison, since a `PRE_VIEW`/`POST_PIXEL` span measures command
  submission and `draw_view3d` does not. Every number was real; none was the
  thing it was said to be.

### The rate is the host's event loop, not the request

**A host MUST NOT treat the requested rate as achievable, and MUST NOT assume it
can exceed its own event loop.** Capture runs on a timer callback, which fires
once per iteration of the host's main loop, and that loop runs at the rate the
operator's own viewport redraws: measured at **30 Hz** while the viewport
redraws and **64-175 Hz** when it does not, against the 120 Hz the timer asks
for. The requested rate is therefore a ceiling under a ceiling.

Two consequences that are not obvious and were both got wrong:

- **A host MUST NOT count a depsgraph evaluation it triggered itself as a scene
  change.** Reading the evaluated camera forces an evaluation, which fires the
  host's own change notification; treating that as "something changed" and then
  clearing the flag in the same pass makes the *next* opportunity see an
  unchanged scene while the camera is visibly moving. Measured, that cost
  exactly half the frame rate -- 256 captures against 256 skips, one for one --
  and where nothing else evaluates the scene at all, such as a minimised host,
  it collapses the stream to the idle keepalive.

- **A rate limit MUST carry its deadline forward rather than measuring from the
  last capture.** A period that is not a whole number of loop intervals can only
  fire on one boundary or the next; measuring afresh each time rounds every
  deadline up, so a request for 20 fps against a 30 Hz loop silently becomes 15.
  Carrying the deadline and allowing half an interval of slack alternates
  between the boundaries and averages the requested rate.

With both corrected, every advertised size meets 15, 20 and 30 fps exactly on
the reference host.

**Hosts SHOULD default to 30 fps.** The earlier advice here was 20, on the
assumption that a lower rate is a lighter one. It is not: measured, 20 fps costs
**49.7%** of the main thread against 30 fps at **50.4%**, for a third fewer
frames. Captures spaced further apart each cost more, so most of the saving is
given back. A host wanting to spend less SHOULD render a smaller frame rather
than a slower one.

A host MUST read the camera's **evaluated** transform, not the raw datablock's.
`matrix_world` is derived, so a host that writes a pose and reads the matrix in
the same tick gets the pose from before it — and with nothing else forcing a
depsgraph evaluation it stays stale indefinitely, streaming a frozen picture
while the camera visibly moves. It is also the only correct answer when the
camera is parented, driven or constrained.

## 2. Transport

The stream uses its **own TCP connection on its own port**, never the pose
socket and never the take-upload listener.

- Not the pose socket: POSE is latest-wins UDP at 100 Hz and must never queue
  behind a megabyte of pixels.
- Not the take listener: that reads uploads serially on its accept loop
  (`protocol.md` §5.10), so a viewport connection would starve take uploads and
  vice versa. Its backlog is deliberately larger than one — a second phone
  connection arriving mid-upload must queue rather than be refused, and a
  refused upload is a lost take.

TCP rather than UDP with fragmentation, for v1. Measured at the operating point,
the sender never blocked (0.07 ms at p95), no packets were lost, and the stream
used about a tenth of available goodput. UDP's advantage — discarding a damaged
frame instead of retransmitting it — costs a fragmentation and reassembly layer
that the measurements gave no reason to build yet. **A host SHOULD revisit this
if real use shows head-of-line stalls**; the frame format in §4 is transport
independent precisely so that change stays possible.

**The stream is not free to the pose path even on its own socket.** Measured,
round-trip latency to the phone rose from 6.0 ms to 9.9 ms at p95 while
streaming: a socket is not a radio, and pose datagrams cross the same air, the
same phone NIC and the same CPU. Hosts SHOULD treat the pose path as the
priority when the two compete, and MUST NOT let the viewport stream delay POSE
ingest.

## 3. Negotiation

WELCOME (`protocol.md` §5.2) gains three optional keys:

```json
{"viewport_port": 47810,
 "viewport_modes": ["camera"],
 "viewport_video": {"codecs": ["jpeg"],
                    "camera_sizes": [[1280, 720], [960, 540], [640, 360]],
                    "max_fps": 30}}
```

- Absence of `viewport_port` means the host cannot stream; the client MUST NOT
  attempt a connection.
- `viewport_modes` and `codecs` are **lists even when they hold one entry.**
  Adding a codec or the scene mode is then an additive change needing no version
  bump, exactly as `lens_mm` and `shake_hold_dps` were.
- A receiver MUST ignore modes and codecs it does not know, and MUST select from
  what it was offered rather than asserting a preference.

### The host advertises sizes; the client does not request them

`camera_sizes` is the set the host will render at, and a client MUST choose from
it. A host receiving anything else MUST answer `ERROR` with
`viewport_unsupported` and leave the stream in its previous state.

This is a smaller constraint than it was. An offscreen draw could render almost
any size — the list exists so the host keeps control of what it spends, not
because the sizes are all it can make.

**Advertised sizes MUST carry the render's aspect ratio.** A 16:9 list against a
4:3 render frames the phone against something the camera is not shooting, which
for an instrument used to judge framing is a correctness bug rather than a
cosmetic one. They SHOULD also be even in both axes: odd dimensions are a
portability hazard the moment a chroma-subsampled codec joins `codecs`, and cost
nothing to avoid.

**And the render's aspect ratio is not its resolution's aspect ratio.** Pixels
are square only by default; a non-square pixel aspect stretches the finished
image without changing the pixel count. The reference host derived the list from
resolution alone, and a frame sweep caught it against Blender's own
`Camera.view_frame`: at 1158x798 with a 2:1 pixel aspect the shot is 2.902 wide
and the list said 1.451. Anamorphic and several broadcast formats are exactly
this. Hosts MUST use `(width x pixel_aspect_x) / (height x pixel_aspect_y)`.

**A host MUST NOT advertise more pixels than the camera renders.** Upscaling a
viewfinder invents detail that is not in the shot — which includes honouring any
resolution percentage, since that is how many pixels the render will really
have. Both axes are capped, not only width: a pixel aspect that stretches
vertically makes an uncapped height invent rows for the same reason an uncapped
width invents columns.

## 4. Frame format

Every frame on the viewport connection is a 28-byte header followed by its
payload. Little-endian, matching `protocol.md` §1.

| Offset | Size | Type | Field |
|---|---|---|---|
| 0 | 4 | u8×4 | magic `0x50 0x52 0x56 0x50` ("PRVP") |
| 4 | 1 | u8 | version, `1` |
| 5 | 1 | u8 | codec — 1 = JPEG. 0 is reserved and MUST be rejected |
| 6 | 2 | u16 | flags — bit 0: frame is independently decodable |
| 8 | 4 | u32 | ordinal, per-connection, starts at 0, increments per frame *produced* |
| 12 | 8 | u64 | `capture_ns`, the host's monotonic clock at capture |
| 20 | 2 | u16 | `width` of this frame |
| 22 | 2 | u16 | `height` of this frame |
| 24 | 4 | u32 | `payload_len` |

**Dimensions ride every frame** rather than being inferred from the negotiated
size. A host MUST send the size it actually produced, not the size that was
requested — the two diverge across a reconfigure, where frames already in flight
carry the old size, and whenever a host clamps a request to what it can afford.
The rule earned its keep against the deleted viewport mode, where the operator
could resize a region with no control message exchanged at all; it is cheaper
than the class of bug it prevents, so it stays. JPEG happens to describe its own
dimensions, but the channel must not depend on the codec to carry the geometry
of its own frames.

Receivers MUST drop a frame whose magic or version does not match, and MUST NOT
attempt to resynchronise mid-stream — a desynchronised reader cannot tell a
payload byte from a header, and the connection should be closed instead.

### Why `ordinal` and `capture_ns` are mandatory rather than optional

They are what makes the stream measurable. Without an ordinal there is no way to
tell a dropped frame from a late one, and without a capture timestamp there is
no way to establish latency at all. The measurement in
`viewport-lab-results.md` §"End to end" is built entirely on these two fields:
the host stamps, the phone echoes the ordinal on presentation, and the host
subtracts against its own clock — **crossing no clock boundary**, so no
synchronisation is required.

`ordinal` counts frames *produced*, not frames sent. A host that drops a frame
under backpressure (§6) MUST still advance the ordinal, or the receiver cannot
distinguish "the host skipped one" from "the network lost one".

### Frames are independent

Every codec offered in v1 is all-intra, so flags bit 0 is set on every frame.

This is a **permission granted to the transport**: any frame may be discarded,
by the sender or the network, without corrupting any later frame. There is no
retransmission and no recovery state. A design that later adds an inter-frame
codec MUST clear bit 0 on dependent frames and MUST NOT assume the transport
still has that freedom.

JPEG is the v1 codec for that property as much as for its speed: measured, it
encodes in 0.82 ms for 9.4 Mbit/s, needs no codec session on either side, and has
no reorder window — a lost frame on a Wi-Fi link is simply a lost frame.

## 5. Control and statistics

Two new message types on the **existing pose socket**, from the free `0x2A`-`0x2F`
range. They are control-plane messages and belong where the session already is;
only pixels ride the viewport connection.

### 5.1 VIEWPORT_CONTROL (`0x2A`), phone → host, reliable

```json
{"mode": "camera", "codec": "jpeg", "size": [960, 540], "fps": 30,
 "quality": 75, "overlays": false}
{"mode": "off"}
```

Starts, reconfigures or stops the stream. `size` MUST be one the host advertised
in `camera_sizes`. A host receiving an unsupported combination MUST answer `ERROR` with
`viewport_unsupported` and leave the stream in its previous state.

**Every key except `mode` is optional, and absent means unchanged.** A host MUST
NOT read an omitted key as a default — a client that has never heard of a field
would otherwise silently reset a preference the operator set.

### Not every shading mode can be drawn to order

**A host MUST NOT stream a shading mode its render engine will not draw
synchronously.** An offscreen draw happens once and returns; a progressive
engine accumulates a viewport render over many samples into buffers of its own,
and hands back the world background.

Measured, the same camera at the same size: a full render under EEVEE, a flat
63/255 fill under Cycles. With overlays suppressed, as a viewfinder wants them,
that fill is pure black — which is what the operator sees the moment they switch
to Rendered.

Blender's own engines (`BLENDER_EEVEE*`, `BLENDER_WORKBENCH`) draw when asked.
A host SHOULD treat every other engine as progressive and substitute Material
Preview for Rendered, testing the engine identifier by prefix rather than
against a list of names — third-party path tracers are progressive for the same
reason Cycles is, and an engine that did not exist when the host was written
still has to get the right answer. Guessing wrong in this direction costs
accuracy; guessing wrong in the other costs the picture entirely.

A host SHOULD say when it has substituted, where the operator changing shading
will see it. Without that the viewfinder simply looks wrong.

### `profile`, and why the host chooses the size

`"light"`, `"balanced"` or `"smooth"`. When present the **host** selects the
size and the client MUST NOT send one; when absent the client selects, as
before.

Size is the only control that materially changes what a stream costs its host —
rate does not, measured — and what a given size costs depends on the scene and
the machine. A client can see neither. It cannot see that the operator switched
to Rendered shading, or opened a heavier file, and both change the answer while
the stream is running.

A profile names a share of **one event-loop iteration** that capture may fill:
0.35, 0.65 and 0.90 on the reference host. The iteration is the right unit
because it is the one with a consequence — capture that fits inside it lands in
time the loop spends waiting on the display anyway, and capture that overruns
stretches every iteration it touches, which is the only way this feature can
make the host feel slow.

Measured on a million-triangle scene in Rendered shading, where an EEVEE draw
per frame puts capture well past an iteration:

| profile | chose | stream | host's loop |
|---|---|---|---|
| light | 640x360 | 19.8 fps | 20.5 Hz |
| balanced | 640x360 | 18.6 fps | 19.5 Hz |
| smooth | 1280x720 | 16.6 fps | 16.6 Hz |

On a 229k-triangle scene in Solid shading all three sit at the largest advertised
size except `light`, which steps down and reports that even the smallest still
exceeds its share.

Requirements on a host that implements this:

- It MUST NOT predict what an unvisited size would cost. Moving one step and
  measuring is slower to converge and does not carry the reference machine's
  constants, which is the whole reason the client stopped choosing.
- It SHOULD change size rarely. A change reallocates buffers and visibly
  rescales the client's picture; the reference host requires a settled estimate,
  two consecutive agreeing evaluations and four seconds since the last change.
- It MUST NOT take a size's cost from the first capture after changing to it.
  That capture pays for reallocating the buffer and reads high; used as the
  reference for "what does this size cost", it makes a controller believe the
  scene got cheaper and oscillate. Observed on the reference host.
- It SHOULD report when the smallest size still exceeds the budget, rather than
  continuing to hunt. There is nothing left to give up and the client can say so.
- An unrecognised profile name MUST NOT be an error. A host that has not heard
  of it SHOULD fall back to `balanced`, so a newer client still gets a picture.

### `overlays`, and why it defaults off

Whether the host's own viewport overlays — 3D cursor, floor grid, relationship
lines — are drawn into the streamed picture.

A host that draws the camera by borrowing a real 3D view inherits that view's
overlay settings, so without suppressing them the viewfinder shows things that
are not in the shot: measured on one real scene, 1.72% of the frame. **Hosts
SHOULD default to `false`**, because the instrument is for judging framing.

It is not a performance setting. The overlay pass measured within noise of free
(−2% against a baseline that itself moves 3% between runs), and toggling the
host's own view setting twice per frame produced no extra viewport redraws and
no measurable change in main-thread share. It is offered because some overlays
— the floor grid especially — genuinely help place a camera, and that is the
operator's call rather than the protocol's.

A host that suppresses overlays by borrowing the operator's setting MUST restore
it, and MUST do so even if the draw raises. Leaving someone's overlays switched
off in their own viewport is a worse failure than any frame that might be lost.

Hosts MUST accept `{"mode": "off"}` at any time, including while recording. The
stream is a preview; nothing about it may block ending a take.

### 5.2 VIEWPORT_STAT (`0x2B`), phone → host, unreliable

```json
{"ordinal": 1240, "decoded_ns": 812634, "presented_ns": 814188}
```

Sent by the phone when a frame reaches the screen. Unreliable on purpose: it is
telemetry about a preview, and a resend layer for it would cost more than the
information is worth.

Hosts SHOULD use it for the latency figure and for backpressure (§6), and MUST
tolerate its complete absence — a client that never sends it is conformant, and
the stream must work regardless.

The timestamps are in the **phone's** clock domain (`protocol.md` §2), so only
their difference is meaningful to the host. The host's own round trip against
`capture_ns` is the figure that needs no shared clock.

### 5.3 `viewport_max_fps` in PARAMS, host → phone

The rate the host has **measured** its own event loop reaching, carried as an
optional key on the existing PARAMS message (`protocol.md` §5.7) rather than as
a new message type.

```json
{"live_smoothing": 0.3, "record_smoothing": 0.15, "move_scale": 1.0,
 "viewport_max_fps": 30}
```

It is deliberately **not** in WELCOME, where `viewport_video.max_fps` already
says what the host is willing to be *asked* for. Those are different numbers:
this one is the host's loop rate under load, and at pairing there is no load --
the loop free-runs several times faster than it will once the camera is moving,
so a figure measured then is a promise the host cannot keep.

- A host that has not measured a rate MUST omit the key. A receiver treats
  absence as "unchanged", so a fabricated default would pin a wrong ceiling on
  the client's controls and leave it there.
- A host SHOULD apply hysteresis before republishing. The loop rate jitters by a
  frame either way and PARAMS is a reliable message; the reference host moves it
  only on a change of 3 fps or more.
- A host SHOULD hold the last figure measured while the stream was working
  rather than replacing it with an idle one, and clients MUST treat it as
  advisory: it moves with what the operator is doing, so a client that clamped
  its own control to it would lock itself out of a rate the host later regains.

## 6. Backpressure: drop, never queue

When a frame cannot be sent without blocking, the host MUST **drop it and
advance the ordinal**. It MUST NOT queue frames.

This is the same rule the pose path already lives by, for the same reason
(`protocol.md` §1): a viewport frame is *state, not an event*. Only the latest
one matters, and a queue converts a bandwidth problem into a latency problem —
the operator ends up watching a smooth stream of stale pictures, which is worse
than a gap because it looks correct.

Measured, the sender blocked for 0.07 ms at p95 at the operating point, so this
rule should almost never fire on a healthy link. It exists for the unhealthy one.

A host SHOULD also skip capture entirely when the previous frame has not been
sent: capture costs 10-30 ms of Blender's main thread with the camera moving,
and spending it on a frame that will be dropped takes that time from the
operator's own interactivity.

## 7. Deliberately not specified

- **A mode that streams the host's viewport.** It existed and was deleted; see
  §1. Anyone reviving it should read that section first, and know that the
  premultiplied-alpha defect is inherent to the region framebuffer rather than
  incidental.
- **The scene mode.** Measured, glTF export preserves instancing well enough that
  a million triangles across 5000 objects ships in 0.50 MB, so the mode is
  promising. But incremental update is unsolved: a file-level diff cannot drive
  it, and a structured one that resends node transforms while leaving mesh
  buffers alone is a design in its own right.
- **Inter-frame codecs.** H.264 measured well and decodes on phone hardware in
  ~1.4 ms against JPEG's ~4.9 ms, but costs a 26 MB per-platform wheel against
  simplejpeg's 0.3 MB, for 3 ms of a budget with 30 ms of slack. `codecs` is a
  list so this can be revisited without a redesign.
- **Audio, and any host → phone direction other than frames.** Out of scope.
- **Encryption.** The threat model is unchanged from `protocol.md` §9: honest
  LAN-grade access control, not a hostile network. The viewport connection MUST
  validate the session token on connect, and that is all.

## 8. Revision history

- **v3.5** (2026-07-29) — advertised sizes take the render's *pixel* aspect and
  its resolution percentage, not the resolution alone. Found by sweeping frames
  under awkward scene conditions after the Cycles report, and checked against
  Blender's own `Camera.view_frame` rather than by eye.
- **v3.4** (2026-07-29) — Rendered shading is substituted for engines that
  will not draw an offscreen synchronously. Cycles returns the world background
  from a one-shot draw, which with overlays off is a black viewfinder.
- **v3.3** (2026-07-29) — `profile` added to VIEWPORT_CONTROL: the host picks
  the size against a share of its own event-loop iteration, because only it can
  see what a capture costs on its machine and its scene, and both move while the
  stream is running. Demonstrated backing off from 1280x720 to 640x360 on a
  million-triangle scene in Rendered shading, trading 2 fps of stream for 3 Hz
  of the host's own loop.
- **v3.2** (2026-07-29) — `overlays` added to VIEWPORT_CONTROL, defaulting off:
  a host drawing through a borrowed 3D view inherits its overlays, and a
  viewfinder showing the 3D cursor is showing something that is not in the shot.
  States explicitly that an omitted key in §5.1 means unchanged.
- **v3.1** (2026-07-29) — capture split seven ways under a correct load, with a
  repeat measurement. The readback is 61% of it and is a floor, so the size list
  is the control that matters; reading three channels instead of four is worth
  16-18% and is now recommended. Colour management, overlays, shading mode and
  double-buffered readback all measured free, and the 12 ms draw the previous
  revision reported did not reproduce.
- **v3** (2026-07-29) — the rate section is rewritten around the host's event
  loop, which is the ceiling nothing here had accounted for. Adds the two
  normative rules that cost half the frame rate between them: do not count your
  own depsgraph evaluation as a scene change, and carry the rate limit's
  deadline forward. `viewport_max_fps` (§5.3) carries the measured ceiling to
  the client. The default rate goes from 20 to 30, because 20 turned out to cost
  the same and deliver less, and the claim that resolution costs only bandwidth
  is withdrawn along with the paused-host measurement it rested on.
- **v2** (2026-07-28) — camera mode replaces the viewport-streaming mode, which
  is deleted rather than kept as an option. The measurement pass had chosen the
  framebuffer path on cost, which was the right answer to the wrong question: a
  viewfinder that depends on the operator not using their own application is not
  a viewfinder. `sizes` becomes `camera_sizes` and carries real resolutions.
- **v1** (2026-07-28) — first specification, written after the measurement pass
  rather than before it. The host-advertised size list, the all-intra permission
  and the drop-never-queue rule are all consequences of numbers in
  `tools/viewport_lab/viewport-lab-results.md`.
