# pocketrig Wire Protocol — v1

License: CC-BY-NC-4.0. This document is normative. Implementations MUST pass the shared test
vectors in [`fixtures/`](../fixtures/).

## 1. Overview

A phone (client) streams camera orientation to a DCC host add-on (server) on the same LAN,
and exchanges a small set of control messages (pairing, heartbeat, record start/stop).

- **Transport:** a single UDP socket on each side. One port, one flow, both directions.
- **Server** (Blender add-on) binds UDP port **47800**; if taken, tries 47801–47809.
- **Client** (phone) sends from an ephemeral port. The server learns the client's address
  from the client's packets — the phone always initiates.
- **Byte order:** little-endian everywhere.
- **Rates:** client SHOULD send POSE at a fixed 100 Hz regardless of sensor rate.
  Bandwidth at 100 Hz is ~4 KB/s.

Rationale (informative): poses are *state, not events* — only the latest matters, so
latest-wins UDP beats TCP head-of-line blocking (the "rubber-band" feel). Control messages
are rare (~10/session) and get a tiny resend-until-ACK layer on the same socket. One socket
= one firewall prompt.

## 2. Message header (16 bytes, all messages)

| Offset | Size | Type | Field | Notes |
|---|---|---|---|---|
| 0 | 2 | u8×2 | magic | `0x50 0x52` ("PR") |
| 2 | 1 | u8 | version | `1` |
| 3 | 1 | u8 | msg_type | see §3 |
| 4 | 4 | u32 | seq | per-sender, monotonically increasing, starts at 1 |
| 8 | 8 | u64 | timestamp_ns | sender's **monotonic** clock (never wall clock) |

Receivers MUST silently drop packets whose magic or version don't match (v1 receivers drop
version ≠ 1; see §7 for negotiation). Receivers MUST ignore unknown `msg_type` values.

`timestamp_ns` domains are per-sender and never compared across devices except via the
PING/PONG offset mechanism (§5.3). On Android this is `SensorEvent.timestamp` /
`elapsedRealtimeNanos()`; on the server, `time.monotonic_ns()`.

## 3. Message types

| Type | Name | Direction | Reliability | Body |
|---|---|---|---|---|
| `0x01` | POSE | phone → host | unreliable | binary, §4 |
| `0x0F` | BYE | either | reliable | none |
| `0x10` | HELLO | phone → host | reliable | JSON, §5.1 |
| `0x11` | WELCOME | host → phone | reliable | JSON, §5.2 |
| `0x12` | PING | phone → host | unreliable | none |
| `0x13` | PONG | host → phone | unreliable | JSON, §5.3 |
| `0x1F` | ERROR | host → phone | reliable | JSON, §5.6 |
| `0x20` | RECORD_START | phone → host | reliable | JSON, §5.4 |
| `0x21` | RECORD_STOP | either | reliable | JSON, §5.4 |
| `0x22` | RECORD_BAKED | host → phone | reliable | JSON, §5.5 |
| `0x23` | RECENTER | phone → host | reliable | JSON `{}` |
| `0x24` | PARAMS | either | reliable | JSON, §5.7 |
| `0x25` | PAUSE | either | reliable | JSON, §5.8 |
| `0x26` | SEEK | phone → host | reliable | JSON, §5.9 |
| `0x27` | TAKE_LIST | either | reliable | JSON, §5.11 |
| `0x28` | TAKE_PULL | host → phone | reliable | JSON, §5.11 |
| `0x29` | FRAME_RESET | phone → host | reliable | JSON, §5.12 |
| `0x2A` | VIEWPORT_CONTROL | phone → host | reliable | JSON, [viewport-channel.md](viewport-channel.md) §5.1 |
| `0x2B` | VIEWPORT_STAT | phone → host | unreliable | JSON, [viewport-channel.md](viewport-channel.md) §5.2 |
| `0x30` | ACK | either | unreliable | binary, §6 |

JSON bodies are UTF-8, no BOM. Unknown JSON keys MUST be ignored (forward compatibility).

## 4. POSE (0x01) — 40 bytes (rotation-only) or 52 bytes (6DOF)

Header (16 bytes), then:

| Offset | Size | Type | Field |
|---|---|---|---|
| 16 | 4 | f32 | q_w |
| 20 | 4 | f32 | q_x |
| 24 | 4 | f32 | q_y |
| 28 | 4 | f32 | q_z |
| 32 | 4 | f32 | focal_length_mm — lens focal length, §4.5. 0.0 means the sender is not driving the lens |
| 36 | 2 | u16 | flags — bit 0: sender believes recording is active; bit 1: position fields are valid (§4.1); bits 2–7: tracking quality (§4.2). Receivers MUST ignore flag bits they do not know. |
| 38 | 2 | u16 | reserved (send 0) |
| 40 | 4 | f32 | pos_x — 6DOF senders only, §4.1 |
| 44 | 4 | f32 | pos_y |
| 48 | 4 | f32 | pos_z |

- The quaternion is a **unit** quaternion `(w, x, y, z)`, Hamilton convention, encoding the
  virtual camera's orientation as defined in
  [`coordinate-systems.md`](coordinate-systems.md). Either sign of q is valid
  (q ≡ −q); receivers MUST hemisphere-align consecutive poses (negate if dot < 0).
- A pose must be usable as geometry: receivers MUST drop a POSE whose quaternion
  contains a non-finite component (NaN or ±infinity) or whose magnitude is zero,
  and MUST drop one whose position is non-finite, counting it as malformed. f32
  carries NaN happily, latest-wins makes a dropped pose free, and a non-finite
  value applied to a host camera transform propagates into the scene.
- `timestamp_ns` in the header is the **sensor sample time**, not the send time. Recording
  accuracy depends on this; send pacing does not affect it.
- Receivers MUST drop a POSE whose `seq` is ≤ the highest POSE seq already seen
  (latest-wins; late/duplicate datagrams are discarded).
- **Append-only rule:** receivers MUST accept POSE packets *longer* than they understand
  and ignore the extra bytes. Revisions only ever append fields (position landed this way
  in v1.1) — never reorder or repurpose existing offsets. The wire
  `version` byte stays `1` for appended fields; it only bumps on a breaking change.
- POSE is only accepted from a client address that has completed HELLO (§8).

### 4.1 Position (v1.1, added via the append-only rule)

- Position is the camera's location in **meters**, expressed in the same right-handed
  Z-up world frame as the quaternion (see `coordinate-systems.md` §6). Its origin is
  arbitrary per tracking session — only displacement carries meaning; the host's
  re-center mechanism absorbs the origin.
- Position is meaningful **iff** the packet is ≥ 52 bytes **and** flags bit 1 is set.
  Both conditions are required: a long packet with bit 1 clear is rotation-only
  (e.g. a 6DOF sender that lost tracking and keeps a fixed packet size), and a 40-byte
  packet with bit 1 set has no position to read.
- Rotation-only senders SHOULD send 40-byte POSE with bit 1 clear.
- A 6DOF sender that loses tracking MUST clear bit 1 until tracking recovers; the host
  degrades gracefully to rotation-only driving (holds the last camera location).

### 4.2 Tracking quality (v1.2, append-only flags)

Bits 2–4 carry a quality code and bits 5–7 carry a concise issue code. A zero quality
field means `UNKNOWN`, preserving the behavior of v1.0/v1.1 and rotation-only senders.

| bits 2–4 | quality | position-valid policy |
|---:|---|---|
| 0 | `UNKNOWN` | use bit 1 as the compatibility authority |
| 1 | `WARMING` | clear bit 1 |
| 2 | `GOOD` | bit 1 MAY be set when position bytes are present |
| 3 | `DEGRADED` | clear bit 1 |
| 4 | `LOST` | clear bit 1 |
| 5 | `RECOVERING` | clear bit 1 |
| 6–7 | reserved | treat as `UNKNOWN` |

| bits 5–7 | issue |
|---:|---|
| 0 | `NONE` |
| 1 | `INITIALIZING` |
| 2 | `INSUFFICIENT_FEATURES` |
| 3 | `INSUFFICIENT_LIGHT` |
| 4 | `EXCESSIVE_MOTION` |
| 5 | `BAD_STATE` |
| 6 | `CAMERA_UNAVAILABLE` |
| 7 | `UNKNOWN` |

A 6DOF sender SHOULD require at least 200 ms of stable tracked frames before `GOOD`,
enter `DEGRADED` immediately on a hard tracking failure, enter `LOST` after 500 ms of
continuous failure, and require at least 300 ms of stable tracked frames in `RECOVERING`
before restoring `GOOD`. A source-frame gap greater than 250 ms SHOULD also require
recovery. These dwell times prevent one-frame state flicker and prevent newly recovered
coordinates from being mistaken for continuous translation.

### 4.3 Rotation continuity through a position outage (v1.4)

Position and orientation do not fail together. A visual-inertial tracker loses
position when it cannot see, but orientation is available from inertial fusion
alone, which never discontinues.

A 6DOF sender that loses position SHOULD therefore keep **rotation tracking the
device** rather than repeating its last orientation, while clearing
position_valid as §4.1 requires. Freezing orientation is not a neutral choice: it
discards the framing the operator performs during the outage and then delivers
all of it as a single pose step when the tracker returns, which a host cannot
distinguish from a real whip pan except by the angular-speed guards of
[`coordinate-systems.md`](coordinate-systems.md) §6.

Substituting one estimator's orientation for another's is **not** valid directly:
two gravity-aligned world frames still have unrelated yaw references. A sender
MUST compose the continuation as a body-frame relative rotation against the last
jointly observed pair:

```
q_emit = q_visual_at_loss ⊗ (q_inertial_at_loss⁻¹ ⊗ q_inertial_now)
```

The bracketed term is `cam_at_loss ← cam_now`, expressed entirely in the camera
body frame, so the world-frame mismatch cancels; at the instant of loss it is
identity, making the handoff continuous by construction. On return the sender
SHOULD send `FRAME_RESET {"reason":"recovered"}` (§5.12), because its emitted
orientation and the resuming tracker's now differ by the outage drift.

### 4.4 Corroborating tracker translation (v1.6)

A visual-inertial tracker may report healthy tracking while it cannot actually
see, dead-reckoning meanwhile. Measured on the reference phone with the lens
covered and the device propped still: **5.21 s of `TRACKING` with
`trackingFailureReason` NONE, and 6.18 cm of camera translation that never
happened**, delivered as `GOOD`. At the 5–10× position scale hosts recommend for
desk work that is 30–60 cm of invented camera travel, and no host-side guard can
see it — the timestamps are continuous and the implied speed is entirely
plausible.

A 6DOF sender SHOULD therefore corroborate its tracker's translation against its
own inertial sensors, and clear position_valid when the two disagree.

Constant-velocity motion is inertially indistinguishable from rest, so tracker
displacement alone can never prove invention. The test is only meaningful while
the device is **demonstrably at rest**: if the accelerometer and gyroscope both
report stillness while the tracker reports the camera travelling, the tracker is
wrong. Senders SHOULD use net displacement over a window rather than path length,
because dead-reckoning drift is directional and accumulates while tracker noise
cancels. Measured separation over 1 s with the phone still throughout: 0.16 cm
p95 with a clear lens, 2.37 cm p95 while blind.

Senders SHOULD hold the verdict, rather than clearing it, while the device is
moving: the question is unanswerable then, and motion must not launder an
already-detected false claim. Blind dead-reckoning *during* real motion is
genuinely ambiguous and is deliberately out of scope — this targets the
pathology that is both catchable and the one operators actually hit, a held shot
quietly sliding away.

Reference thresholds and the recorded device evidence they were derived from are
in [`fixtures/motion_corroboration.json`](../fixtures/motion_corroboration.json).
Rotation is unaffected throughout: it does not depend on the camera seeing
anything (§4.3).

### 4.5 Focal length (v1.7)

`focal_length_mm` at offset 32 carries the virtual camera's lens focal length in
millimetres. It occupies the slot v1.0 reserved for exactly this and needs no
version bump: every prior sender wrote 0.0 there, which is the "not driving the
lens" value, so old senders and new hosts agree without a special case.

- **0.0, negative, or non-finite means the sender is not driving the lens.** A host
  MUST then leave its camera's focal length alone. An operator who set a lens in the
  DCC keeps it; a rotation-only phone never silently reframes the shot.
- A driving sender SHOULD send the same value on every POSE, not only when it
  changes. POSE is latest-wins state, not events (§1): a lens change sent once
  would be lost with the packet carrying it.
- Hosts SHOULD ignore values outside a plausible range (reference host: 1–5000 mm)
  rather than apply them, for the same reason they drop a non-finite quaternion.

Focal length rides on POSE rather than PARAMS because a zoom is a *performance*,
not a setting: it changes continuously during a shot, only the latest value
matters, and it must be captured with the take. PARAMS is the mirrored-settings
channel and is the wrong shape for it (§5.7).

The reverse direction is not symmetric. The host reporting *its* current lens is a
setting, not a performance, so it does travel on PARAMS as `lens_mm` (§5.7) — that is
what lets a sender's lens control open on the operator's value instead of asserting
one and reframing the shot the moment it is opened.

**Field of view follows from the host's sensor size**, exactly as a physical lens
does on a body. The protocol carries the lens, not the angle. Sensor dimensions
belong to the operator's DCC camera, like render aspect (§5.7), so a host MUST NOT
alter them to match the sender. A sender that wants a predictable angle of view
should say so in its own UI rather than assume a sensor size.

Live filtering rules are unchanged: focal length is a deliberate creative move, so
the reference host applies it directly rather than smoothing it, and smoothing
sliders do not affect it.

## 5. Control messages (JSON bodies)

### 5.1 HELLO (0x10), phone → host

```json
{"device_name": "Pixel 8 Pro", "app_version": "0.1.0", "protocol_version": 1, "token": "K3XG9A"}
```

`token` MUST equal the session token from the pairing payload (§9). A HELLO with a wrong or
missing token gets `ERROR {"code": "bad_token"}` and is otherwise ignored. A HELLO with a
valid token from a *new* address replaces the previous client address silently (Wi-Fi roam /
reconnect — same token resumes the session, §8).

### 5.2 WELCOME (0x11), host → phone

```json
{"server_name": "DESKTOP-BRE", "host_app": "blender", "host_version": "4.5.0",
 "addon_version": "0.1.0", "protocol_version": 1, "scene_fps": 24.0,
 "take_port": 47800}
```

`protocol_version` is the negotiated version (§7). `take_port` (v1.1, optional) is the
TCP port for offline-take upload (§5.10); its absence means the host cannot receive
offline takes and the client MUST record live-only.

`viewport_port`, `viewport_modes` and `viewport_video` (v1.10, optional) advertise the
viewport stream — see [`viewport-channel.md`](viewport-channel.md) §3. Absence of
`viewport_port` means the host cannot stream and the client MUST NOT connect. The mode
and codec fields are **lists even when they hold one entry**, so a second codec or the
scene mode is an additive change rather than a negotiation redesign.

### 5.3 PING (0x12) / PONG (0x13)

Client sends PING every 2 s (no body; the header `timestamp_ns` is the client send time
`t1`). Host replies immediately with PONG:

```json
{"t1": 123456789, "t2": 987654321}
```

`t1` echoes the PING's header timestamp (client clock); `t2` is the host's receive time
(host clock). Client computes `rtt = now − t1` and MAY keep NTP-style offset samples
(minimum-RTT sample wins) for future timeline sync. **PING doubles as the heartbeat** —
see §8 for timeout behavior.

### 5.4 RECORD_START (0x20) / RECORD_STOP (0x21), phone → host

```json
{"start_timestamp_ns": 111222333, "take_id": "9c6a5f91-d70a-46dc-a604-d255cd13fc55"}
{"end_timestamp_ns": 999888777, "sample_count": 512, "offline": true,
 "take_id": "9c6a5f91-d70a-46dc-a604-d255cd13fc55"}
```

Timestamps are in the **client's** POSE timestamp domain. On RECORD_START the host buffers
every accepted POSE with `timestamp_ns ≥ start_timestamp_ns` (hosts SHOULD keep a ≥ 1 s
rolling pose buffer so samples already in flight when RECORD_START arrives are not lost).
On RECORD_STOP the host bakes samples in `[start, end]`. `sample_count` is how many POSEs
the client sent inside the window, letting the host report packet loss.

`take_id` (v1.3, optional for backward compatibility) is a collision-resistant
identity generated once by the phone before RECORD_START. The same value MUST be
repeated in RECORD_STOP, the automatic TCP upload header (§5.10), and RECORD_BAKED
(§5.5). A modern host MUST NOT attach an upload carrying a different `take_id` to
the active or pending recording. A client MUST NOT begin another recording until
the current transaction reaches RECORD_BAKED or an explicit failure state.

`offline: true` (v1.1) announces that an offline-take upload follows (§5.10): the host
holds its live-streamed samples as a **fallback** and waits (SHOULD: ~10 s) for the upload
before baking; if the upload never completes, it bakes the live fallback — a take is never
lost, worst case it is the streamed one.

**Host → phone RECORD_STOP** (v1.1): the host may end a take (e.g. the timeline reached
the scene's end frame). The client MUST treat it exactly like the user pressing stop —
reply with its own RECORD_STOP (and upload, if recording offline). A client that never
answers gets the RECORD_BAKED-while-recording ending (§5.5) after the host's fallback
bake.

RECENTER (0x23, body `{}`) asks the host to re-capture its offset quaternion (see
`coordinate-systems.md` §5) so the camera's current framing becomes the new reference.
Hosts MUST ignore RECENTER while recording.

### 5.5 RECORD_BAKED (0x22), host → phone

```json
{"frames": 240, "fps": 24.0, "received": 500, "sent": 512,
 "take_id": "9c6a5f91-d70a-46dc-a604-d255cd13fc55"}
```

Sent after the bake completes so the phone can show "Baked 240 frames @ 24 fps".
When the corresponding RECORD_START had `take_id`, this message MUST echo it.

The host MAY end a take itself (v1.1 — e.g. the timeline reached the scene's end frame:
the scene is the shot, its end is the cut). No extra message exists for this on purpose:
a RECORD_BAKED arriving while the client still believes it is recording **means the host
ended the take**, and the client MUST leave its recording state on receipt. A host that
ends a take this way reports `sent` = `received` (it never saw the client's count).

### 5.7 PARAMS (0x24), either direction (added in v1.1)

```json
{"live_smoothing": 0.30, "record_smoothing": 0.15, "move_scale": 1.0,
 "layout": "landscape"}
```

`take_source` ("offline" | "live", optional, v1.1) selects what a finished take is baked
from: the client's lossless full-rate local recording uploaded after the cut (§5.10 —
the default and the better source), or the live-streamed poses (fallback/debug; the only
option for hosts/clients without take transfer).

`layout` ("portrait" | "landscape", optional, v1.1) — **deprecated as a mirrored parameter.**
It originally coupled the phone's screen orientation to the host's render aspect, but that
proved more annoying than useful (the render aspect is the operator's to set in Blender, and
deriving it from the phone forced the phone's orientation on connect). The reference host now
**neither derives layout from nor applies it to the render resolution, and does not send it**;
the reference phone treats shot orientation as a **local, manual** setting that only rotates
its own UI (default: lock the current orientation; portrait/landscape are explicit choices).
Receivers MUST still ignore the key gracefully
(a phone MAY accept a host-sent layout, but is not required to). A phone that does change its
own orientation SHOULD send FRAME_RESET (§5.12) before resuming POSE output. It MUST NOT
send RECENTER merely for a display change: RECENTER is the operator's deliberate Home action.

`shake_hold_dps` (number, optional, v1.9) — the angular speed above which the host holds
6DOF position (`coordinate-systems.md` §6, shake-hold). Mirrored like every other value
here: the host owns it, a phone PARAMS is a request, and the host does not echo an
honored one.

- **`0` disables the gate entirely**, and hosts MUST accept that. The hold trades a real
  risk (a blind tracker dead-reckoning a held shot into a slow drift) against a real
  annoyance (a legitimate fast reframe being mistaken for a shake), and which of those
  costs more is a property of the operator and the room, not something a protocol can
  decide. The same sentinel convention as §4.5's focal length.
- Hosts SHOULD clamp to [0, the §6 relocalization guard]. Above that guard the gate can
  never fire first, so a larger value is indistinguishable from that guard's threshold.
- **A sender that draws a "position held" cue MUST use the value it was given**, not its
  own default, or the cue stops describing what the host does — which is the entire reason
  the threshold is a cross-implementation invariant rather than a local constant. A sender
  that has not been told one uses its default until the first PARAMS arrives.
- The value the sender applies to its own quality marking (§4.2 `EXCESSIVE_MOTION`) is the
  same one, for the same reason: an offline take's invalid-position runs (§5.10) must mean
  what the host would have meant by them.

`lens_mm` (number, optional, v1.8) — **host → phone only, informational.** The host's
current camera focal length in millimetres, so a sender's lens UI can open *on the
operator's value* instead of asserting one of its own. Without it a sender has nothing
to show but a guess, and merely opening a lens control reframes the shot — the exact
thing §4.5's "0.0 means not driving" rule exists to prevent.

- A phone MUST NOT send `lens_mm`; driving the lens rides on POSE (§4.5). A host
  receiving it MUST ignore it, like any unknown key.
- The host SHOULD omit it while the *sender* is driving the lens: that value came from
  the phone, and reporting it back is both redundant and a loop.
- The host SHOULD omit it while its lens is **animated** (a baked take driving the
  camera, timeline scrubbing). PARAMS is reliable and per-frame lens values would
  flood the link; an animated lens is also not a value a sender can meaningfully adopt.
- A sender MUST NOT treat receiving it as permission to drive the lens. It changes
  what the sender would *start from*, nothing else.
- It is the host's live value, not a range: a host whose lens sits outside the
  sender's UI travel still reports it truthfully, and the sender is expected to adopt
  it exactly rather than clamp it into range (clamping on open would reframe the shot).

Session tuning parameters, mirrored on both UIs (Blender panel and phone).
Rules that keep the mirror loop-free:

- **The host owns the values.** A PARAMS from the phone is a request; the host clamps,
  applies, and does NOT echo back (the phone already shows what it asked for). A PARAMS
  from the host is truth; the phone updates its UI and does not reply.
- Each side sends PARAMS only on a **local user change** — never on applying a received
  one. The host additionally SHOULD send PARAMS once after WELCOME so the phone starts
  synced.
- All keys optional (receiver applies the ones present); unknown keys ignored as always.
- Ranges: smoothing values clamp to [0, 1]; `move_scale` clamps to (0, 100].
- `move_scale` scales **position/translation only**; it never scales rotation. The
  reference host uses it for live 6DOF, connected recordings, and manually applied
  6DOF takes.

### 5.8 PAUSE (0x25), either direction (added in v1.1)

```json
{"paused": true}
```

Suspends/resumes the host's live camera drive without ending the session — poses keep
flowing and are ignored while paused. Mirror rules are PARAMS's (§5.7): the host owns the
state, a phone PAUSE is a request, each side sends only on local user change, the host
pushes the current state on change (including entering/leaving its own review mode, so
the phone's button always reflects reality).

**Resuming never jumps**: on `paused: false` the host MUST re-anchor both offsets against
the current pose so the camera *continues from where it is* — the operator may have moved
while paused, and the camera itself may have been **manually reframed in the DCC** (a
primary use of pausing). The host SHOULD adopt the resumed framing as the new re-center
home: choosing a framing and going live with it is the most deliberate framing decision an
operator makes. (Re-center while paused remains the "discard, snap back to the old home"
alternative.) Hosts SHOULD ignore a pause request while recording. A RECORD_START
arriving while paused implies resume: the host MUST treat it exactly as
resume-then-record — the take starts from the current framing. Forgetting to resume
before recording must never be punishable.

### 5.9 SEEK (0x26), phone → host (added in v1.1)

```json
{"to": "start"}
{"frame": 120}
```

Moves the host's playhead: `{"to": "start"}` = the scene's start frame (the retake
button), `{"frame": N}` = an absolute frame, clamped to the scene range. Hosts MUST
ignore SEEK while recording. Seeking does not change pause/review state — a paused
operator can scrub from the phone.

### 5.10 Offline-take transfer (TCP, added in v1.1)

While recording, the client SHOULD capture every pose **locally at full sensor rate** —
the live POSE stream (§4) is then only the preview; loss or jumps on the network can no
longer damage the take. After RECORD_STOP the client uploads the take over TCP to
WELCOME's `take_port`:

```
line 1:  {"format": "pocketrig-take", "version": 0, "token": "K3XG9A",
          "take_id": "9c6a5f91-d70a-46dc-a604-d255cd13fc55",
          "start_ns": 111222333, "end_ns": 999888777, "sample_count": 512,
          "source": "sensor"}
lines 2…N+1:  {"t": <ns>, "q": [w,x,y,z], "p": [x,y,z],
                 "quality": "good", "issue": "none"}          (last three optional)
```

UTF-8 JSONL. The host validates the token (wrong token: close without reply), reads
exactly `sample_count` rows, replies `ok\n` and closes. A host MUST validate every
row before baking it and MUST reject the whole upload — no `ok` — if any row is
malformed: `t` must be a finite number, `q` exactly four finite components with
non-zero magnitude, and `p` (when present) exactly three finite components. One
corrupt row is a lost take; one accepted corrupt row is a corrupted scene, and a
truncated or interrupted capture file reaches this path without any attacker. Rows use the same timestamp
domain and protocol frames as POSE. The host bakes the uploaded take through the **same
bake path** as live takes. One upload at a time; a malformed or oversized upload is
dropped and the live fallback bakes at the deadline. This wire format is identical to the
`.take` file format, so a saved file IS an upload body minus the token.

For a just-finished connected recording, the upload header carries the same `take_id`
as RECORD_START/STOP. A later manual library push omits `take_id`: it is a standalone
Apply operation identified by its library `id`, not a continuation of the old record
transaction. The reference phone streams rows to a temporary file while recording,
flushes checkpoints, atomically finalizes the file before upload, and streams the file
over TCP without retaining the complete take in memory.

`quality` and `issue` use the lowercase names from §4.2. Their absence means `unknown`
and `none`. A row without `p`, or a row whose quality is `warming`, `degraded`, `lost`, or
`recovering`, is an invalid-position marker even when adjacent rows carry position. The
phone MAY retain `p` on a quality-marked row as raw evidence for future reconstruction;
it is not valid camera translation. A host MUST NOT interpolate positional motion through
such a run: it holds the last valid location and re-anchors the next valid segment
continuously. Rotation remains usable throughout when `q` is present.

### 5.11 Take library — TAKE_LIST (0x27) / TAKE_PULL (0x28) (added in v1.1)

The phone owns the take files; both sides browse them and move them on demand (there is no
automatic transfer). The host displays the phone's library and pulls what it wants; the
phone pushes what it wants. Uploads use the TCP channel of §5.10.

**TAKE_LIST** — host → phone `{}` requests the library; phone → host replies with it:

```json
{"takes": [
  {"id": "take-20260721-131716.take", "name": "Balcony pan",
   "duration_s": 10.6, "source": "arcore", "samples": 319,
   "position_samples": 301, "sent": false}
]}
```

`id` is a stable opaque handle (the phone's filename). `name` is the user's label. `sent`
is whether that take has already been delivered to *this* host. Hosts SHOULD request the
list on connect and after any pull; phones SHOULD reply promptly. A phone MAY cap the list
to its most recent takes. `position_samples` (optional, v1.3) is the number of rows whose
position is usable under §5.10's quality rules: greater than zero means the take can bake
6DOF location; zero means rotation-only; absence means an older peer did not advertise the
capability. UIs SHOULD show this directly instead of guessing from the historical `source`
label.

**TAKE_PULL** — host → phone `{"id": "take-…"}` asks the phone to upload that take. The
phone responds by uploading it over TCP (§5.10) with the take's `name` and `id` added to
the upload header, so the host names the baked action after it. An unknown id is ignored.

**Upload header additions (v1.1):** the §5.10 header MAY carry `"name"` and `"id"`; the
host uses `name` for the baked action's name and echoes `id` in the next TAKE_LIST as
`sent: true`. Pushed (phone-initiated) and pulled uploads are identical on the wire.

**Applying a library take is relative (host SHOULD).** A library take was captured in its
own tracking session, so its sample origin and yaw reference are unrelated to the host's
current re-center offsets (§5). When the host bakes such a take onto the camera, it SHOULD
**re-anchor** it: place the take's first sample at the camera's *current* pose and play the
motion out relative to it (the bake-time twin of the re-center formula in
[coordinate-systems §5/§6](coordinate-systems.md)). Applying a foreign take through stale
live offsets would fling the camera to the phone's old tracking origin. This applies to
takes delivered standalone (a pull, or a phone push while not recording); a take delivered
as the offline half of an *in-progress live recording* shares that session's tracking frame
and keeps the live offsets instead.

**Apply is a paused transaction.** On a host-initiated pull, the host pauses live driving
and freezes the camera's evaluated transform *before* sending TAKE_PULL. On a phone-initiated
push, the phone first sends reliable `PAUSE {"paused": true}` and waits for its ACK before
opening the TCP upload. The host processes PAUSE before its bake queue, so both directions
have the same ordering. The frozen transform—not a later live pose at upload completion—is
the re-anchor target above. A successful bake attaches the new action, starts one review
playback, and remains paused for scrubbing. `PAUSE false` / Go Live detaches the action while
preserving its currently evaluated transform, then re-anchors the next live pose. Apply,
Record, Re-center, source/scale changes, and another Apply are mutually excluded until
RECORD_BAKED or an explicit ERROR/timeout ends the operation.

The host MUST freeze the current `move_scale` when Apply begins, together with the camera
anchor, and use that value for the complete bake. It MUST NOT fall back to a scale last
adopted by the live driver: users commonly change position scale while paused/reviewing,
before applying a take. This is a host transaction rule and does not alter the upload body.

### 5.12 Pose-frame boundary — FRAME_RESET (0x29), phone → host

```json
{"reason":"display"}
{"reason":"source"}
{"reason":"resume"}
{"reason":"recovered"}
```

`recovered` (v1.4) is a visual tracker returning from a run where it could not
see. A sender that continued rotation by other means during that run (§4.3) has
been emitting orientation from a different estimator than the one now resuming,
so the two disagree by the drift accumulated over the outage — and the tracker
may additionally have relocalized. Both are reference changes, not camera motion.

Signals that subsequent raw POSE values may use a different display, pose-source, or visual
world reference. This is an internal continuity boundary, not user re-centering. The sender
MUST stop transmitting POSE before sending FRAME_RESET and resume only after its ACK. The
host then rebases its rotation and position offsets against the first fresh POSE so the
currently visible camera transform is unchanged. The host MUST preserve pause/review state
and the stored Home framing, and MUST ignore FRAME_RESET while recording. A paused host may
defer the rebase until its normal Go Live transition.

Quaternion and position in every POSE MUST always be **one rigid pair in one world frame**.
Senders MUST NOT correct only the quaternion: doing so rotates orientation and translation
in different frames and makes 6DOF movement axes incorrect.

**Sender-side frame continuity (v1.5, normative).** A sender with more than one internal
pose source SHOULD emit a single continuous world frame rather than exposing each source's
own frame. On an internal reference change it SHOULD compute the world-frame rotation `W`
that maps the incoming source's first pose onto the last pose it emitted, and thereafter
emit

```
q_out = W ⊗ q_raw            p_out = R(W) · p_raw
```

Because the same `W` is applied to both, `q_out`/`p_out` remain one rigid pair — position
expressed in the camera frame, `q⁻¹ · p`, is provably unchanged — so this is a re-expression
of the same physical transform in a rotated world frame, not a correction of one component.
It is exactly equivalent to the host composing `q_offset ⊗ W`, which is what the host would
have done on receiving FRAME_RESET; doing it at the sender makes it atomic with the source
change instead of dependent on a datagram arriving in a particular order.

This is **not** the reverted quaternion-only correction: that rotated `q` while leaving `p`
in the raw frame, so translation followed wrong axes, and its tests used only commuting
Z-axis rotations and missed it. Implementations MUST test `W` with non-commuting 3D
rotations and assert the `q⁻¹ · p` invariant.

Rationale: the two sources' frames differ by an arbitrary fixed rotation (measured on the
reference phone: a ~90° yaw). Absorbing that seam host-side requires a reliable control
message, a plausibility threshold, and an atomic slot handoff to all behave — the reference
implementation shipped all three and the seam still appeared intermittently, because none of
them can be ordered against a latest-wins UDP stream with certainty. A sender that never
emits a seam removes the failure mode rather than compensating for it. FRAME_RESET remains
required for the gating and host-state duties below; it is simply no longer the only thing
standing between a source switch and a visible jump.

### 5.6 ERROR (0x1F), host → phone

```json
{"code": "bad_token", "message": "human-readable detail"}
```

Codes v1:

| Code | Meaning | Client response |
|---|---|---|
| `bad_token` | HELLO token wrong or missing (§5.1) | abandon the connect attempt |
| `version_unsupported` | host speaks another protocol version (§7) | MAY retry lower |
| `busy` | another client is already paired (§8) | abandon the connect attempt |
| `record_rejected` | RECORD_START refused: the host is already recording or baking a take | leave the recording state at once |
| `bake_failed` | a recorded take produced no usable keyframes | surface the failure; the phone copy is still safe |
| `apply_failed` | a library/imported take could not be applied | surface the failure; nothing was changed |

Clients MUST ignore unknown codes gracefully (show the `message`, keep the
session). `record_rejected` exists because the reliability layer ACKs every
reliable datagram before dispatch (§6): without an explicit answer a refused
RECORD_START is indistinguishable from an accepted one, and the client waits out
its own finalization timeout believing it is recording. A host that refuses a
RECORD_START MUST send it. A client that receives it MUST leave the recording
state and MAY keep whatever it captured locally.

A host SHOULD avoid needing it: an in-flight take belonging to a client that
vanished is ended by the host when a *fresh* pairing arrives (§8 distinguishes a
reconnect, which preserves recording state, from a fresh pairing, which does
not), so a new phone is never refused because of an orphaned take.

## 6. ACK (0x30) and the reliability layer

ACK body: header (16 bytes) + `u32 acked_seq` (20 bytes total). An ACK acknowledges the
message with `seq == acked_seq` from the *other* side.

Rules for **reliable** messages (see table §3):

- Sender resends the identical datagram every **200 ms** until it receives a matching ACK;
  after **5 s** it gives up and enters the error/disconnected state.
- Receiver sends an ACK for **every** reliable datagram received, including duplicates
  (ACKs may be lost).
- Receiver deduplicates by `(address, seq)` — a reliable message is *processed* once.
  HELLO additionally includes its stable header timestamp in this identity: a restarted
  client may reuse the same UDP source port and reset `seq` to 1, while retries of one
  HELLO retain the same timestamp and remain exact duplicates.
- HELLO/WELCOME are also ACKed like any reliable message (no special cases).

## 7. Version negotiation

Client states its `protocol_version` in HELLO. If the host supports it, WELCOME carries the
same value. If not, host replies `ERROR {"code": "version_unsupported"}` listing its own
version in `message`, and the client MAY retry with a lower version. v1 hosts speak only v1.

## 8. Connection lifecycle

```
DISCONNECTED → (scan QR / manual entry) → HELLO loop → WELCOME received → CONNECTED/PAUSED
CONNECTED/PAUSED → PAUSE {false} → LIVE
LIVE → RECORD_START acked → RECORDING → FINALIZING (save → transfer → bake) → LIVE
any state → BYE → DISCONNECTED
```

The reference product begins an interactive pairing paused so connecting never moves the
camera unexpectedly. This is represented by the PAUSE control state; it does not add a
wire message or change WELCOME. A reconnect re-synchronizes PARAMS/PAUSE/library state but
MUST preserve the current pause/live/recording state rather than acting like a new pairing.
FINALIZING is a product state rather than a new message type. Controls that could start,
apply, pull, or reconfigure motion are locked until the matching RECORD_BAKED arrives.

- Client: 3 consecutive PINGs without PONG (~6 s) → show "reconnecting", return to the
  HELLO resend loop with the same token. POSE sending MAY continue while reconnecting.
- Host: no packet from the paired client for **8 s** → mark client gone (UI: "waiting for
  phone"), keep the session token valid; a re-HELLO with the same token resumes silently.
- Host accepts **one** paired client per session (v1). A HELLO with valid token from a new
  address is a reconnect (adopt new address). While a live client exists, a HELLO with a
  *different valid format* token → `ERROR {"code": "busy"}`.
- BYE is reliable; on receiving BYE, forget the peer (token stays valid until the server
  stops).

## 9. Pairing payload (QR code)

The host displays a QR code encoding a URI:

```
pocketrig://connect?v=1&host=192.168.1.23&port=47800&token=K3XG9A&name=DESKTOP-BRE
```

- `v` — pairing payload format version (1).
- `token` — 6 characters, uppercase A–Z + 2–9 (no 0/O/1/I), generated fresh per server
  start. This is honest LAN-grade access control, not cryptography; the threat model is
  "don't let a random device on the network drive/record the camera", not a hostile LAN.
- Manual fallback: the host UI shows `192.168.1.23:47800` and the token as plain text; the
  phone offers "enter address manually" with two fields (address, code).

## 10. The viewport channel

Specified in [`viewport-channel.md`](viewport-channel.md), which is normative for the
stream. It rides its **own TCP connection on its own port**, advertised in WELCOME
(§5.2), so the pose path is never contended by pixels. Its two control messages
(`0x2A`, `0x2B`) travel on this socket, because they are session control and only
frames belong on the other one.

Its shape was decided by measurement rather than assumption, and three of those
decisions are worth knowing from here:

- The host **advertises** the frame sizes it can produce and the client chooses among
  them, rather than requesting a size — and may take the choice back entirely, because
  only it can see what a frame costs on its own machine and scene.
- What the phone sees is the **camera drawn into an offscreen buffer**, not a copy of the
  operator's viewport. A mode that mirrored the viewport existed, was cheaper, and was
  deleted: a viewfinder that depends on the operator not using Blender is not one.
- Every v1 codec is all-intra, which is a **permission granted to the transport**: any
  frame may be dropped, by sender or network, without corrupting a later one.
- Under backpressure a host **drops the frame and advances the ordinal**, never queues.
  A viewport frame is state, not an event — the same rule POSE lives by (§1).

## 11. Reserved for future versions (informative)

- A future take-container revision may replace the current v0 JSONL transfer/file body
  (§5.10) without changing POSE semantics.
- The viewport channel's scene mode — shipping geometry once and rendering on the phone
  — is anticipated by its mode list but not yet specified.

## 12. Revision history

- **v1.10** (2026-07-28) — the viewport channel (§10,
  [`viewport-channel.md`](viewport-channel.md)): WELCOME advertises `viewport_port`,
  `viewport_modes` and `viewport_video`, and two new types carry its control plane —
  VIEWPORT_CONTROL (`0x2A`) and VIEWPORT_STAT (`0x2B`). Frames ride a separate TCP
  connection so pixels never contend with POSE. Additive and optional throughout, so no
  negotiation change: a host without `viewport_port` simply cannot stream, and a client
  that ignores the keys behaves exactly as before.
  Written *after* a measurement pass rather than before one, and its shape is a
  consequence of what was measured. The host advertises the sizes it can produce instead
  of accepting a request, because the capture path that costs ~5 ms reads the framebuffer
  Blender already drew and can only decimate by whole-number factors — the path that
  could honour an arbitrary size cost 10-25 ms and was not viable. Every v1 codec is
  all-intra, which is stated as a permission for the transport to drop frames freely
  rather than as an implementation note. Backpressure drops and advances the ordinal
  rather than queueing, for the reason §1 gives about POSE: a viewport frame is state,
  not an event, and a queue turns a bandwidth problem into a latency one.
  The mode and codec fields are lists from the first version even though each holds one
  entry, so adding H.264 or the scene mode later stays additive.

- **v1.9** (2026-07-28) — PARAMS gains `shake_hold_dps` (§5.7): the shake-hold angular
  speed becomes a mirrored session parameter instead of a fixed constant, and `0` turns the
  gate off. A single threshold cannot be right for everyone — the reference value was 500,
  lowered to 300 to catch shakes that a one-interval measurement under-reported, and then
  found to fire on ordinary fast reframes, because 300 deg/s is a 90-degree turn in
  0.3 s and that is a framing move, not a shake. Smoothing the measurement (v1.8-era, no
  wire change) fixed the noise half and left the ceiling too low. Exposing the threshold
  ends the search for a value that does not exist; the default returns to 500. Purely
  additive and optional, so no negotiation change. The value stays a cross-implementation
  invariant: a sender drawing a "position held" cue MUST use the host's value, not its own.

- **v1.8** (2026-07-25) — PARAMS gains `lens_mm` (§5.7), host → phone only: the host's
  current focal length, so a sender's lens control opens on the operator's value rather
  than asserting one. Purely additive and optional, so no version negotiation changes.
  Reporting is suppressed while the sender drives the lens or while the host's lens is
  animated, which keeps a reliable channel from carrying per-frame values.

- **v1.7** (2026-07-25) — the f32 at POSE offset 32 becomes `focal_length_mm` (§4.5),
  taking the slot v1.0 reserved for it. 0.0 keeps its old meaning of "not driving the
  lens", so every existing sender remains correct and no version bump is needed. Field
  of view follows from the host's sensor size, which stays the operator's, exactly as
  render aspect does.

- **v1.6** (2026-07-25) — §4.4 added: a 6DOF sender SHOULD corroborate its tracker's
  translation against its own inertial sensors and clear position_valid when they
  disagree, because a visual-inertial tracker reports healthy tracking while blind and
  dead-reckons (measured: 5.21 s and 6.18 cm of invented translation, marked GOOD). No
  host-side guard can catch it — timestamps stay continuous and the implied speed is
  plausible. The test applies only while the device is demonstrably at rest, since
  constant-velocity motion is inertially indistinguishable from rest. No wire change: this
  uses the existing §4.2 quality field.
- **v1.5** (2026-07-25) — §5.12 gains normative sender-side frame continuity: a sender with
  several internal pose sources SHOULD emit one continuous world frame, re-expressing an
  internal reference change as a world rotation applied to **both** quaternion and position.
  Measured on the reference phone, the rotation-vector and ARCore frames differ by a fixed
  ~90° yaw, and toggling between them moved the host camera by that amount. Host-side
  absorption via FRAME_RESET, an angular plausibility guard, and an atomic source handoff
  were all implemented and the jump remained intermittent, because none of them can be
  ordered against a latest-wins UDP stream with certainty. Emitting no seam removes the
  failure mode instead of compensating for it.
  This supersedes the earlier "senders emit unmodified raw poses" rule but NOT the reason
  behind it: correcting the quaternion alone is still forbidden, and implementations must
  prove the rigid-pair invariant under non-commuting rotations. No wire change.
- **v1.4** (2026-07-25) — §4.3 added: a 6DOF sender SHOULD keep rotation tracking
  through a position outage instead of freezing it, composed as a body-frame
  relative rotation so the two estimators' yaw references cancel, and announce
  the return with `FRAME_RESET {"reason":"recovered"}` (§5.12). Freezing
  orientation delivered every degree turned during an outage as one pose step on
  recovery. Hosts MUST also apply the §6 angular relocalization guard while
  position is invalid: that is precisely when a visual tracker hands over a
  rotated world, so gating the guard on position validity disabled it exactly
  when it was needed. No wire change; `recovered` is a new reason string and
  receivers already ignore unknown ones.
  ERROR (§5.6) gains `record_rejected` and documents the
  `bake_failed` / `apply_failed` codes the reference host already sent. A refused
  RECORD_START must now be answered rather than silently dropped, because §6 ACKs
  the datagram before dispatch and the client cannot otherwise tell refusal from
  acceptance. A fresh pairing ends an orphaned in-flight take so the next client
  is not refused because of it. Receivers already ignore unknown codes, so no
  wire change and no version byte bump.
  Also normative for ingest: a POSE whose quaternion is non-finite or has zero
  magnitude is malformed and MUST be dropped (§4), and a take row whose numbers
  are non-finite or whose `q`/`p` arrays are the wrong length MUST be rejected
  rather than baked (§5.10).
- **v1.3** (2026-07-23) — optional `take_id` binds RECORD_START, RECORD_STOP,
  automatic TCP upload, and RECORD_BAKED into one transaction. The reference client
  exposes save/transfer/bake finalization, prevents overlapping retakes, writes connected
  captures into the durable phone library, atomically finalizes them, and streams upload
  rows rather than retaining the whole take in RAM. Library Apply is ordered as pause,
  frozen-anchor transfer, bake, then review; `position_samples` advertises whether each
  library item can create 6DOF location curves. The wire `version` remains 1 because all
  JSON additions are optional and unknown keys are ignored.
  Apply also freezes the current translation-only `move_scale` with its pose anchor so a
  paused scale adjustment deterministically affects the selected take. No wire change.
- **v1.2** (2026-07-23) — append-only POSE flag fields report hysteretic tracking quality
  and issue (§4.2); optional per-row `quality`/`issue` names preserve the same evidence in
  offline takes. Invalid-position runs are explicit segment boundaries: hosts hold and
  continuously re-anchor recovery instead of inventing translation across a gap. The wire
  `version` remains 1 because no field moved and older peers ignore the added flag bits and
  JSON keys. The reference phone also defaults to a manually locked screen orientation;
  this is a phone-local UX policy and does not change the wire format or Blender render aspect.
- **v1.1** (2026-07-20) — POSE optionally carries position (§4.1) via the append-only
  rule; flags bit 1 defined as position_valid. PARAMS (0x24, §5.7) added for mirrored
  session tuning; old peers ignore the unknown type. Host-ended takes defined via
  RECORD_BAKED-while-recording (§5.5). PAUSE (0x25, §5.8) for suspending the live drive.
  SEEK (0x26, §5.9) and the PARAMS `layout` key for phone-side retakes and portrait/
  landscape shooting. Offline takes: WELCOME `take_port`, RECORD_STOP `offline` flag and
  host→phone direction, PARAMS `take_source`, and the TCP transfer (§5.10).
  Take library: TAKE_LIST (0x27) / TAKE_PULL (0x28) and upload `name`/`id` (§5.11).
  Pose-reference continuity: FRAME_RESET (0x29, §5.12) replaces sender-side quaternion-only
  correction at display/source/resume boundaries and keeps 6DOF rigid transforms coherent.
  Existing message formats remain wire-compatible with v1.0; FRAME_RESET continuity
  requires both reference peers to include the v1.1 extension.
  Later the same day: host-side SHOULDs added to `coordinate-systems.md` §6 (timestamp-gap
  and implausible-velocity re-anchoring) after a real sender bug demonstrated why arrival
  timing cannot be trusted. No wire change.
  Later still: the shake-hold host SHOULD (`coordinate-systems.md` §6) and the relative-apply
  host SHOULD (§5.11) — applying a library take re-anchors it to the camera's current pose
  instead of the phone's old tracking origin. No wire change.
  And: `layout` deprecated as a mirrored parameter (§5.7) — shot orientation is now phone-local
  and no longer touches the host render resolution. Key still travels on the wire; receivers
  ignore it gracefully. No wire change.
- **v1.0** — initial protocol.
