# Working on Blend-CamMoCap

Orientation for anyone picking this repository up, human or agent. It is short on
purpose; the detail lives in [`dev/`](dev/) and the normative rules live in
[`spec/`](spec/).

An Android phone drives Blender's camera over Wi-Fi, and one button bakes the motion into
ordinary keyframes. Blender also streams its camera back to the phone as a viewfinder.
No account, no cloud, no external upload.

## Before you change anything

**Keep the two seams.** They are what makes the test story work, and both are load-bearing:

- `blender/core/` imports **no `bpy`**. Wire codec, session, sockets, filters, takes,
  viewport pacing. All of it runs under desktop `pytest`.
- `android/protocol/` imports **nothing from Android**. Same codec, same frame maths,
  proved against the same fixtures.

Anything that can be decided without `bpy` or without Android belongs on the testable
side. When a decision turns out to be subtle, move it across rather than leaving it where
no test can reach it.

**`fixtures/` is frozen.** It is cross-platform ground truth consumed by both halves. If a
change makes a fixture test fail, the change is wrong. Adding cases is welcome; editing
one to make code pass is not.

**The wire protocol is versioned.** v1 changes only by its own forward-compatibility rules
(append-only POSE, ignore unknown types, optional keys). Anything else is v2 and starts as
a spec change, not a code change.

## Validation

```powershell
python -m pytest blender/tests -q            # host core, desktop Python, no bpy
./tools/test-all-blenders.ps1                # the above + headless on Blender 4.5 / 5.0 / 5.1
cd android
./gradlew.bat :protocol:test                 # codec and frame maths, pure JVM
./gradlew.bat :app:testDebugUnitTest         # app logic and the design gallery
```

All four before you believe a change. Two blind spots are structural, not accidental:

- **`blender/bl/` has no unit tests.** It imports `bpy`, so desktop pytest cannot see it
  at all. The headless matrix is its only coverage, and a broken headless script once
  shipped for a whole session because only the desktop and Android suites were run.
- **The capture path has no automated coverage anywhere**, because `gpu` drawing raises
  under `--background`. `tools/viewport_lab/in_blender/` is the only thing that exercises
  it, and it needs a real window.

For UI work, render it and look at it: `./tools/render-designs.ps1` draws every screen
state at four device profiles and four rotations in seconds. A state absent from
`TrayGallery.kt` never gets looked at.

## Rules that are expensive to rediscover

Each of these cost a debugging session. [`dev/constraints.md`](dev/constraints.md) has the
full set with the symptoms; these are the ones you are most likely to trip over first.

- **`bpy` is main-thread only**, and network work never goes near it. The add-on has one
  timer and everything touching the scene happens inside it.
- **Never call `bpy.ops` from that timer.** It has crashed Blender natively. Playback
  advances `frame_current` directly instead.
- **A timer callback owns the main thread while it runs.** Sleeping inside one to wait for
  a tick waits for the thread you are holding.
- **Installing an add-on does not reload it in a running Blender.** Restart fully before
  judging behaviour.
- **`blender_manifest.toml` names every bundled wheel, so all of them are committed.** A
  clone missing them cannot build the extension at all. Adding a wheel means adding it to
  the manifest *and* to `.gitignore`'s allow-list.
- **Latest-wins is a guarantee, not an optimisation.** Stale and duplicate POSE datagrams
  are dropped, never replayed or queued.
- **A long-lived loop exits from its own flag, never from an exception.** An accept loop
  that broke on `OSError` turned one aborted connection into a listener that was dead
  while still advertising its port.

## Product decisions that constrain code

- **One screen, one button.** A feature that adds a second mandatory control on the phone
  does not land, however good.
- **Pairing begins paused.** Tracking starts when the operator says *Go live*, so a
  reconnect never yanks the camera away from what they were doing.
- **Live filtering never touches recorded samples.** Smoothing shapes the preview; the
  bake resamples raw timestamped motion at scene FPS.
- **Every take is kept.** A new one never overwrites an old one.
- **The viewfinder shows the shot, not the screen.** It draws the camera into an offscreen
  buffer rather than mirroring the operator's viewport, so it keeps working while they are
  elsewhere in Blender. A mode that mirrored the viewport existed and was deleted.

## Conventions

- Commits: plain imperative subjects ("Fix bake off-by-one at take end"). No
  AI-attribution trailers. A commit that changes behaviour changes or adds a test.
- A regression test must be **run against the unfixed code and seen to fail** before it
  counts. Two have shipped here that passed against the bug they were written for.
- Licensing differs per directory: `blender/` and `tools/` are GPL-3.0-or-later (they
  import `bpy`), `android/` is PolyForm Noncommercial 1.0.0, `spec/` and `fixtures/` are
  CC BY-NC-4.0. See [LICENSES.md](LICENSES.md).
- Releases are tagged and their artifacts attached to the GitHub Releases tab. `release/`
  is a local staging folder and is ignored.

## Where to look

| | |
|---|---|
| [`dev/`](dev/) | Architecture, constraints, testing, measurement. Start here. |
| [`spec/`](spec/) | Normative: the wire protocol, coordinate conventions, viewport channel. |
| [`QUICKSTART.md`](QUICKSTART.md) | Build, install, run, troubleshoot. |
| [`CONTRIBUTING.md`](CONTRIBUTING.md) | Ground rules and how to open a PR. |

Behaviour disagreements are settled by `spec/` and `fixtures/`, in that order. Everything
else is a description of the code and can be wrong; if you find it wrong, fix it.
