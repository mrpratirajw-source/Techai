<h1 align="center">Blend-CamMoCap</h1>

<p align="center">
  <strong>Point your phone. Hit record. Done.</strong><br/>
  Turn an Android phone into a virtual camera for <a href="https://www.blender.org/">Blender</a>.
  Move the phone and Blender's camera moves with it over Wi-Fi,<br/>
  and one button bakes the motion into ordinary, editable keyframes.
</p>

<p align="center">
  <img alt="Android" src="https://img.shields.io/badge/Android-8.0%2B-3DDC84?style=flat-square&logo=android&logoColor=white">
  <img alt="Kotlin" src="https://img.shields.io/badge/Kotlin-2.1-7F52FF?style=flat-square&logo=kotlin&logoColor=white">
  <img alt="Jetpack Compose" src="https://img.shields.io/badge/Jetpack%20Compose-4285F4?style=flat-square&logo=jetpackcompose&logoColor=white">
  <img alt="Blender" src="https://img.shields.io/badge/Blender-4.2%2B-F5792A?style=flat-square&logo=blender&logoColor=white">
  <img alt="6DOF" src="https://img.shields.io/badge/6DOF-ARCore-4285F4?style=flat-square&logo=google&logoColor=white">
  <img alt="License" src="https://img.shields.io/badge/License-Noncommercial-1f6feb?style=flat-square">
</p>



https://github.com/user-attachments/assets/59b82688-9c31-446d-a038-593007736c6b



<p align="center">
  <a href="#news">News</a> &nbsp;&middot;&nbsp;
  <a href="#what-it-does">Features</a> &nbsp;&middot;&nbsp;
  <a href="#get-started-5-minutes">Get started</a> &nbsp;&middot;&nbsp;
  <a href="#download">Download</a> &nbsp;&middot;&nbsp;
  <a href="#how-it-works">How it works</a> &nbsp;&middot;&nbsp;
  <a href="#license">License</a>
</p>

<br/>

## News

- **29 Jul · A viewfinder on the phone.** Blender's camera streams live to the handset, so
  you can frame the shot without looking at the monitor.
- **26 Jul · The interface, rebuilt.** Turn the phone and every control turns with it,
  while the dock stays exactly where your thumb left it.
- **25 Jul · Lens control.** A zoom dial drives Blender's focal length, and a zoom you
  perform mid-take is recorded with the move.
- **21 Jul · Takes you can trust.** A searchable library on the phone, and every take
  uploaded losslessly after the cut rather than assembled from the live stream.

<br/>

## What it does

No account. No cloud. No subscription. No twelve-toggle setup screen. One screen, one button.
The phone and Blender talk directly on your Wi-Fi, and nothing ever leaves the room.

| Feature | What you get |
|---|---|
| **Live rotation tracking** | Pan, tilt and roll the phone; Blender's camera follows instantly, with latest-wins UDP so Wi-Fi jitter never rubber-bands the shot. |
| **6DOF (position) via ARCore** | Opt-in: walk, and the camera walks with you for real handheld parallax, not just rotation. When tracking degrades the phone says why ("point at a detailed surface", "add more light") and holds position instead of lurching. |
| **Blender's camera, on the phone** | A live viewfinder of the actual shot, so you can frame without looking at the monitor. It follows the camera whatever you are doing on the PC — another editor, another window, even minimised — because it draws the camera itself rather than mirroring your screen. Tell it how much effort to spend and Blender picks the detail to match your machine. |
| **Lens control on the phone** | A zoom dial under the viewfinder drives Blender's focal length, and a zoom you perform during a take is recorded with it. Taking the lens adopts the one you already set, so it never reframes your shot; hand it back with a tap. |
| **Record to editable keyframes** | One button bakes the move, resampled at scene FPS onto normal F-curves you can trim and tweak like any animation. |
| **Takes are lossless, not "whatever arrived"** | The phone records the take locally at full rate and uploads it after the cut, so Wi-Fi glitches only ever hit the live preview — never the take you keep. |
| **Shoot with no PC in sight** | Record straight to the phone, walk back, and apply the take to Blender later. The phone keeps a searchable take library you can rename, re-apply and delete. |
| **Shoot over your animation** | The timeline plays while you record, so you can hand-track a moving subject. Every take is kept; nothing is overwritten. |
| **Live-synced controls** | Smoothing, movement-scale and lens mirror between the phone and the Blender panel in real time. |
| **Pairing with no ritual** | Scan a QR code and you are paired. Tracking starts when *you* say **Go live**, so a fresh connection never yanks the camera away from what you were doing. Reopen the app and it silently reconnects. |

<br/>

## Get started (5 minutes)

You need an Android phone (8.0+), Blender 4.2+, and both devices on the same Wi-Fi.

1. **Install the add-on.** Grab the zip from [Download](#download) (or build it with
   `./tools/dev-install.ps1`), then in Blender open *Edit &rsaquo; Preferences &rsaquo; Get
   Extensions &rsaquo; Install from Disk* and pick the zip.
2. **Install the app.** Use the APK from [Download](#download) (or run
   `cd android && ./gradlew.bat :app:assembleDebug` and `adb install` it).
3. **Connect.** In Blender's 3D viewport press **N** and open the add-on's side panel (its tab
   is labeled **pocketrig**, the in-app name is still a placeholder). Click **Connect Phone**
   and allow the Windows Firewall prompt. A QR code appears.
4. **Pair.** On the phone tap **Scan to Connect**. (No scanner? Tap "enter address manually" and
   type the `ip:port` and code from the panel.)
5. **Go live.** The camera does *not* start moving on pairing — that would yank the viewport
   away from whatever you were doing. Tap **Go live** on the phone (or **Start tracking** in the
   panel) when you are ready; wherever the camera is now becomes the neutral pose.
6. **Record.** Hit the big red **Record**, move for about 10 seconds, then hit it again to stop.
   The phone shows "Baked N frames". Scrub the Blender timeline and edit the keyframes like any
   others.

Everything else is optional: tap **6DOF** to add positional tracking, turn on **Camera view** in
*Adjust* to see the shot on the phone, drag the zoom dial (or pinch the frame) to change the
lens, and **Center** whenever you want the current framing to be the new neutral.

> **Trouble connecting?** It is almost always router AP-isolation (join the phone's hotspot with
> the PC instead) or the firewall. See the [troubleshooting table](QUICKSTART.md#troubleshooting).

<br/>

## Download

Both halves are attached to every tagged release:

<p align="center">
  <a href="https://github.com/BrAtUkA/Blend-CamMoCap/releases/latest"><img alt="Latest release" src="https://img.shields.io/github/v/release/BrAtUkA/Blend-CamMoCap?style=for-the-badge&label=Download&color=1f6feb"></a>
</p>

Take `Blend-CamMoCap-<version>-app.apk` for the phone and
`Blend-CamMoCap-<version>-blender-addon.zip` for Blender. The APK is not signed for the Play
Store, so sideload it; the add-on installs on Blender 4.2+ (tested on 4.5, 5.0 and 5.1). Free
for noncommercial use; see [License](#license).

Prefer to build both from source? [QUICKSTART.md](QUICKSTART.md) is a two-line job.

<br/>

## How it works

The phone converts its sensor pose into Blender's exact camera convention and streams it as
small UDP packets: state, not events, so only the freshest pose ever matters and a dropped
packet is a brief freeze rather than a rubber-band. Blender applies it at 120 Hz, and recording
resamples the raw, timestamped stream at scene FPS.

The take you keep does not come from that stream. While you record, the phone also writes every
sample to its own storage at full rate and uploads that file over TCP after the cut, so the
lossy, latest-wins path is only ever the *preview* — a Wi-Fi glitch mid-take costs you nothing.

Frames travel the other way too. Blender draws the scene camera into an offscreen buffer and
sends it to the phone as JPEG over its own TCP connection, so the viewfinder shows the shot
rather than a mirror of your screen — it keeps working while you are in the shader editor, in
another window, or with Blender minimised. What that costs the PC depends on the scene and the
machine, so the host measures both and picks the resolution itself
([`spec/viewport-channel.md`](spec/viewport-channel.md)).

```mermaid
flowchart LR
    S["Phone sensors<br/>game-rotation-vector, ARCore VIO"] --> C["Convert to Blender<br/>camera frame"]
    C --> N["UDP, latest-wins<br/>100 Hz POSE"]
    C --> F["Full-rate recording<br/>on the phone"]
    N --> H["Blender add-on<br/>120 Hz apply"]
    H --> V["Live camera<br/>in the viewport"]
    H --> P["Camera drawn offscreen<br/>JPEG over TCP"]
    P --> W["Viewfinder<br/>on the phone"]
    F --> U["TCP upload<br/>after the cut"]
    U --> R["Bake<br/>slerp-resample at scene FPS"]
    R --> K["Editable<br/>keyframes"]

    style S fill:#132a17,color:#c9f7d4,stroke:#3ddc84
    style N fill:#1e3a5f,color:#cfe3ff,stroke:#3b82f6
    style F fill:#132a17,color:#c9f7d4,stroke:#3ddc84
    style U fill:#1e3a5f,color:#cfe3ff,stroke:#3b82f6
    style H fill:#3a1e12,color:#ffe0cf,stroke:#f5792a
    style K fill:#3b0764,color:#efe1ff,stroke:#a855f7
    style P fill:#1e3a5f,color:#cfe3ff,stroke:#3b82f6
    style W fill:#132a17,color:#c9f7d4,stroke:#3ddc84
```

The wire protocol ([`spec/protocol.md`](spec/protocol.md)) is small, versioned, and pinned by
shared cross-platform [test vectors](fixtures/): the same fixtures the Android (Kotlin) and
Blender (Python) sides both prove themselves against, so any future client such as an iOS port
can be verified for free. Live feel is not left to guesswork either. A
[Motion Lab](tools/motion_lab/) measures filter lag, jitter attenuation and bake fidelity, and
gates them against committed baselines on every test run.

<br/>

## Repository layout

| Path | What | License |
|---|---|---|
| [`android/`](android/) | Android app: Kotlin + Jetpack Compose, ARCore 6DOF | PolyForm Noncommercial 1.0.0 |
| [`blender/`](blender/) | Blender add-on: extension format, Blender 4.2+ | GPL-3.0-or-later |
| [`spec/`](spec/) | The wire protocol and coordinate conventions (normative) | CC BY-NC-4.0 |
| [`fixtures/`](fixtures/) | Cross-platform test vectors every implementation must pass | CC BY-NC-4.0 |
| [`tools/`](tools/) | Dev harness: fake phone, Motion Lab, Viewport Lab, install and test scripts | GPL-3.0-or-later |
| [`dev/`](dev/) | Developer notes: architecture, platform constraints, testing, measurement | informational |

Develop and test without a phone at all:

```powershell
python -m pytest blender/tests            # Blender core, desktop Python (no Blender needed)
python tools/fake_phone.py --mode walk    # drive the add-on with a synthetic 6DOF phone
./tools/dev-install.ps1                   # build + install the add-on (then restart Blender)
./tools/test-all-blenders.ps1             # headless matrix across Blender 4.5, 5.0 and 5.1
cd android; ./gradlew.bat :protocol:test  # frame math and codec vs the shared fixtures
```

See [QUICKSTART.md](QUICKSTART.md) for the full dev guide and [CONTRIBUTING.md](CONTRIBUTING.md)
to get involved. [`dev/`](dev/) has the shorter, sharper notes: how the pieces fit
([architecture](dev/architecture.md)), the platform rules that will bite you
([constraints](dev/constraints.md)), which suite covers what ([testing](dev/testing.md)), and
how the measurement labs work ([measurement](dev/measurement.md)).

<br/>

## License

Free for noncommercial use. Commercial use requires permission; contact **bratuka@bratuka.dev**.
Licenses differ per component (full detail in [LICENSES.md](LICENSES.md)):

- App: PolyForm Noncommercial 1.0.0
- Spec and fixtures: CC BY-NC-4.0
- Blender add-on and tools: GPL-3.0-or-later (Blender's `bpy` is GPL, so the add-on must be
  GPL-compatible; GPL still forbids closed, proprietary forks)

<br/>

<p align="center">
  Designed and built by <a href="https://github.com/BrAtUkA">BrAtUkA</a>
</p>

<p align="center">
  <a href="https://github.com/BrAtUkA">
    <picture>
      <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/BrAtUkA/BrAtUkA/main/imgs/logo-flat-white.png">
      <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/BrAtUkA/BrAtUkA/main/imgs/logo-flat-black.png">
      <img src="https://raw.githubusercontent.com/BrAtUkA/BrAtUkA/main/imgs/logo-flat-black.png" alt="BrAtUkA" height="30">
    </picture>
  </a>
</p>
