# Contributing

Thanks for looking at pocketrig. The project is small on purpose; so is this file.

## Ground rules

- **The One-Button Law**: one screen, one button.
  Features that add a second mandatory control on the phone don't land, however good.
- **The fixtures are frozen.** [`fixtures/`](fixtures/) are the cross-platform ground
  truth. If your change makes a fixture test fail, the change is wrong — never edit a
  fixture to make code pass. Adding *new* cases is welcome.
- **The wire protocol is versioned.** v1 ([`spec/protocol.md`](spec/protocol.md)) only
  changes by the spec's own forward-compat rules (append-only POSE, ignore-unknown-types).
  Anything else is v2 and starts as a spec PR, not a code PR.

## Dev setup

Everything is documented operationally in [QUICKSTART.md](QUICKSTART.md). Short version:

```powershell
python -m pytest blender/tests -q               # Blender core, desktop Python (no bpy)
./tools/test-all-blenders.ps1                   # headless matrix: Blender 4.5 / 5.0 / 5.1
cd android && ./gradlew.bat :protocol:test      # frame math + codec vs the same fixtures
cd android && ./gradlew.bat :app:testDebugUnitTest   # app logic + the design gallery
python tools/fake_phone.py --mode orbit         # drive the add-on with no phone at all
```

A PR is mergeable when all four suites pass. If you touch conversion math (quaternions,
frames, resampling), run the physical sanity ritual in QUICKSTART §B too.

Two things worth knowing before you trust a green run: `blender/bl/` imports `bpy`, so
desktop pytest cannot see it at all — only the headless matrix can. And the capture path
cannot be tested anywhere, because `gpu` drawing raises under `--background`.
[`dev/testing.md`](dev/testing.md) has the full picture, and
[`dev/constraints.md`](dev/constraints.md) has the platform rules that will bite you.

## Layout and licensing

| Path | What | License |
|---|---|---|
| `spec/`, `fixtures/` | protocol + test vectors (normative) | CC BY-NC-4.0 |
| `blender/` | add-on: `core/` is bpy-free and pytest-able, `bl/` is the bpy layer | GPL-3.0-or-later |
| `android/` | `:protocol` is a pure-JVM module; `:app` is the Compose app | PolyForm Noncommercial 1.0.0 |
| `tools/` | fake phone + install/test scripts | GPL-3.0-or-later |

Keep the seams: no `bpy` imports in `blender/core/`, no Android imports in `:protocol`.
That separation is what makes the test story work.

## The iOS app does not exist yet — that could be you

The spec and fixtures are openly licensed (CC BY-NC-4.0) so a Swift/CoreMotion client can
be built independently for noncommercial use. Start by making your conversion pass
[`fixtures/orientation_cases.json`](fixtures/orientation_cases.json), then speak the
protocol at an unmodified add-on. Open an issue and we'll add CoreMotion rows to the
fixtures with you.

## Commits

Plain, imperative subject lines ("Fix bake off-by-one at take end"). No AI-attribution
trailers. If a commit changes behaviour, it changes or adds a test.
