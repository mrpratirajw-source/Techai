# Quickstart (development)

License: CC0-1.0. The operational how-to for working on this repo.

Live rotation and 6DOF, record-to-keyframes, lossless offline takes with an on-phone take
library, and phone-driven lens control all work today. See
[What's here vs. what's next](#whats-here-vs-whats-next) at the bottom.

There are two paths. The **phone-free path** works right now with zero hardware. The
**full path** needs the Android phone.

---

## A. Phone-free path (no phone, no APK needed)

Everything except the phone can be exercised with the synthetic `fake_phone.py` client,
which speaks the exact same wire protocol.

### 1. Run the tests

```powershell
# Blender core (bpy-free) — desktop Python
python -m pytest blender/tests -q                 # full desktop suite

# Full headless matrix: pytest + live / record / recenter / 6dof / pause
# on Blender 4.5 / 5.0 / 5.1
./tools/test-all-blenders.ps1

# The phone side
cd android; ./gradlew.bat :protocol:test :app:testDebugUnitTest
```

### 2. Install the add-on into Blender

```powershell
./tools/dev-install.ps1                 # installs into 4.5, 5.0 and 5.1
# or a subset:
./tools/dev-install.ps1 -Versions 5.1
```

> **Do this after every change under `blender/`, and then fully restart Blender.**
> Installing an extension does not reload Python in a running Blender, and the headless
> tests load the add-on straight from the repo — so the whole matrix can pass while the
> Blender you are clicking in still runs the previous build. To check what is actually
> deployed, look in
> `%APPDATA%\Blender Foundation\Blender\<ver>\extensions\user_default\pocketrig\`.

### 3. Drive the Blender camera from the fake phone

1. Open Blender, press **N** in the 3D viewport, open the **pocketrig** tab.
2. Click **Connect Phone**. (This binds the UDP socket — approve the Windows Firewall
   prompt if it appears; that's why the bind happens on click, not at startup.) A QR code
   and a line like `192.168.1.23:47800  code: K3XG9A` appear.
3. In a terminal, point the fake phone at that address + token:

   ```powershell
   python tools/fake_phone.py --host 127.0.0.1 --port 47800 --token K3XG9A --mode orbit
   ```
   The viewport camera should orbit smoothly. Try `--mode shake` (handheld feel),
   `--mode walk` (6DOF: orbit + a circular walk driving the camera's position), or
   `--mode fixture --fixture-id upright_north` (holds a known orientation — the
   coordinate-sanity oracle).
4. Record a take unattended:

   ```powershell
   python tools/fake_phone.py --token K3XG9A --mode shake --record-after 2 --record-duration 5
   ```
   After ~7 s the panel shows the baked frame count; scrub the timeline to see the
   keyframed camera move.

---

## B. Full path (real phone)

### 1. Build + install the app

Any Android 8.0+ phone; 6DOF additionally needs
[ARCore support](https://developers.google.com/ar/devices). Developed against a Pixel 8 Pro.

```powershell
cd android
./gradlew.bat :app:assembleDebug
# with USB debugging enabled (or wireless debugging paired), then:
& "$env:LOCALAPPDATA/Android/Sdk/platform-tools/adb.exe" install -r `
  app/build/outputs/apk/debug/app-debug.apk
```

> Over wireless debugging the port changes every time it is re-enabled, so reconnect with
> `adb connect <ip>:<port>` using the address Developer options currently shows.

### 2. Connect and shoot

1. Put the **phone and PC on the same Wi-Fi network**.
2. Blender → **pocketrig** panel → **Connect Phone** (shows the QR).
3. On the phone: **Scan to Connect** → scan the QR. You are now paired but **paused** — the
   camera deliberately does not move yet, so connecting never yanks the viewport away from
   what you were doing.
4. Tap **Go live** on the phone (or **Start tracking** in the panel). The camera's current
   framing is captured as the neutral pose and it starts following.
5. **Sanity ritual** (catches any coordinate bug): hold the phone in portrait, rear camera
   facing away, level → Blender camera level. Tilt phone up → camera tilts up. Roll right →
   camera rolls right.
6. Tap **Center** on the phone (**Re-center** in the panel) any time to make the current framing the new neutral.
7. Big red **Record** → move the phone for ~10 s → press it again to **Stop**. The phone
   toasts "Baked N frames @ 24 fps"; scrub the Blender timeline. The scene's end frame also
   auto-stops the take — the timeline *is* the shot.

### 3. The rest of the surface

| Control | What it does |
|---|---|
| **6DOF** toggle | Adds ARCore positional tracking. The badge reports tracking health and tells you what to fix ("point at a detailed surface", "add more light"); when tracking is lost the position is held rather than lurching. |
| Zoom dial (below the frame) | Drives Blender's focal length, and a zoom performed during a take is baked with it. Blender owns the lens until you take it, and taking it adopts Blender's current lens, so it never reframes the shot. Drag the dial or pinch the frame to zoom; the button beside the dial takes the lens and hands it back, and is lit while you hold it. |
| **Take from** (panel) | `Offline (lossless)` — the default — bakes the phone's full-rate local recording, uploaded after the cut. `Live stream` bakes the streamed poses instead (fallback/debug). |
| **Record offline (no PC)** | Shoot with nothing to connect to. Takes land in the phone's library and upload when you next connect. |
| **Takes** drawer / **Phone takes** panel | Search, rename, re-apply and delete takes on the phone; **Apply to camera** bakes one into Blender. `Import .take file` loads one from disk. |
| **Pause** / **Go live** | Stops driving the camera so you can scrub and edit, then resumes. Applying a take also parks you in review. |

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| Phone scans QR but never connects | Same Wi-Fi? Many routers have **AP/client isolation** — join the **phone's hotspot** with the PC instead, then re-show the QR (the IP updates). |
| No connection + no firewall prompt seen | Allow UDP 47800 inbound: `New-NetFirewallRule -DisplayName "pocketrig" -Direction Inbound -Protocol UDP -LocalPort 47800 -Action Allow` (admin PowerShell). |
| Camera jumps/rubber-bands | Weak Wi-Fi; move closer to the AP or use the hotspot. UDP degrades as brief freezes, not multi-second stalls. |
| Slow yaw drift over minutes | Expected with the drift-free-but-magnetometer-free sensor; tap **Center** on the phone, or turn on **6DOF**, whose visual tracking does not drift this way. |
| Phone paired but the camera does not move | That is the intended state on connect. Tap **Go live** (phone) or **Start tracking** (panel). |
| A code change to `blender/` seems to have no effect | Run `./tools/dev-install.ps1` and **fully restart Blender** — the headless tests load the add-on from the repo, so they pass regardless of what is installed. |
| 6DOF says "point at a detailed surface" and never tracks | ARCore needs texture and light. Aim at a surface with visible detail (not a blank wall), and check the badge — it names the specific problem. |
| `gradlew` fails on JDK version | The build pins Android Studio's JBR 21 via `android/gradle.properties` (`org.gradle.java.home`). If Studio isn't at the default path, update that line. |

---

## What's here vs. what's next

Working today: live rotation tracking, 6DOF via ARCore with tracking-health reporting,
record-to-keyframes over a playing timeline, lossless offline takes with an on-phone take
library, phone-driven lens/focal control, and a live viewfinder of Blender's camera on the
phone ([spec/viewport-channel.md](spec/viewport-channel.md)).

Next up: an iOS client, and shipping geometry to the phone so it can render the shot from its
own pose instead of receiving frames.

The wire protocol is versioned and documented in [spec/protocol.md](spec/protocol.md), and
pinned by the shared [fixtures/](fixtures/) that both the Kotlin and Python sides prove
themselves against — so a future iOS app is a pure client implementation with no
reverse-engineering.
