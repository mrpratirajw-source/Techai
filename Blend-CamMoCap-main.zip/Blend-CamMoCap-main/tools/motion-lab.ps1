# SPDX-License-Identifier: GPL-3.0-or-later
# Full Motion Lab run: tier-1 (pure python) + tier-2 (headless Blender bake
# fidelity), gated against the committed baselines. Companion to
# test-all-blenders.ps1; see tools/motion_lab/run_lab.py for options.
param(
    [string]$Blender = "C:\Program Files\Blender Foundation\Blender 5.1\blender.exe"
)
$ErrorActionPreference = "Stop"
$repo = Split-Path -Parent $PSScriptRoot
python (Join-Path $repo "tools\motion_lab\quality_suite.py")
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python (Join-Path $repo "tools\motion_lab\run_lab.py") --full --blender $Blender
exit $LASTEXITCODE
