# SPDX-License-Identifier: GPL-3.0-or-later
"""
Builds .designs/index.html — the contact sheet for the phone UI renders.

The renders themselves come from the Kotlin gallery (ScreenGallery.kt), which
also writes manifest.json; this script only lays them out. Device dimensions are
read from that manifest rather than repeated here, so the sheet cannot describe
a phone differently from the renderer that drew it.

The sheet's one non-obvious job is showing every render at TRUE PHYSICAL SIZE.
A phone is ~460 ppi and a monitor ~100, so a pixel-accurate render appears about
four times too big — useless for judging whether a control is actually thumb-
reachable or a label actually readable. There is no way to know a monitor's real
pixel pitch from inside a browser, so the page asks once: drag a rule until it
matches a bank card (ISO/IEC 7810 ID-1, 85.60 mm), and store the result.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

DESIGNS = Path(__file__).resolve().parent.parent / ".designs"
RENDERS = DESIGNS / "renders"

#: Human titles for the render prefixes; anything unlisted falls back to its id.
SCREEN_TITLES = {
    "01-disconnected": "Disconnected — pair or shoot offline",
    "02-connecting": "Connecting",
    "03-live-rotation": "Live · rotation only",
    "04-live-6dof-good": "Live · 6DOF tracking well",
    "05-live-6dof-degraded": "Live · 6DOF degraded",
    "06-recording": "Recording",
    "07-paused": "Paused",
    "08-finalizing": "Finalizing a take",
    "09-reconnecting": "Reconnecting",
}


#: Folder name -> how it is presented. Ordered, so "current" always reads first.
VARIANT_TITLES = {
    "00-current": (
        "Current — the shipping UI",
        "The starting point. Everything wrong with the app is visible here; "
        "proposals get filed alongside, never over the top.",
    ),
    "01-tray": (
        "Proposal: thumb-anchored dock",
        "Grounded chrome, one dock in both orientations, camera-style zoom. "
        "Rendered over black.",
    ),
    "02-tray-on-scene": (
        "Proposal, over a camera image",
        "The same screens over a stand-in camera feed with a blown-out highlight "
        "and a deep shadow. This is the render that actually tests whether the "
        "chrome stays legible; black flatters everything.",
    ),
}


ROTATIONS = ("rot-0", "rot-90", "rot-180", "rot-270")

# Named by how the phone is HELD, because that is what the reader is holding
# when they compare two renders. "rot-90" is a folder name, not a description.
ROTATION_TITLES = {
    "rot-0": "Upright",
    "rot-90": "Turned clockwise",
    "rot-180": "Upside down",
    "rot-270": "Turned anticlockwise",
}


def collect() -> dict[str, dict[str, dict[str, str]]]:
    """{variant: {screen: {rotation__device: relative path}}}."""
    out: dict[str, dict[str, dict[str, str]]] = {}
    for png in sorted(RENDERS.glob("*/*/*.png")):
        variant, rotation = png.parent.parent.name, png.parent.name
        m = re.fullmatch(r"(.+)__(.+)\.png", png.name)
        if not m:
            continue
        screen, device = m.group(1), m.group(2)
        rel = png.relative_to(DESIGNS).as_posix()
        out.setdefault(variant, {}).setdefault(screen, {})[
            f"{rotation}__{device}"
        ] = rel
    return out


def build() -> Path:
    manifest = json.loads((DESIGNS / "manifest.json").read_text(encoding="utf-8"))
    devices = manifest["devices"]
    tree = collect()

    blocks, nav = [], []
    for variant in sorted(tree):
        vtitle, vblurb = VARIANT_TITLES.get(variant, (variant, ""))
        nav.append(f'<span class="navgroup">{vtitle}</span>')
        screens = tree[variant]
        cards = []
        for screen_id in sorted(screens):
            title = SCREEN_TITLES.get(screen_id, screen_id)
            anchor = f"{variant}--{screen_id}"
            nav.append(f'<a href="#{anchor}">{title}</a>')
            groups = []
            # Rotations, not orientations. The app no longer has a landscape
            # layout to photograph -- the window is always portrait and the phone
            # turning only turns the CONTENT -- so the axis worth comparing along
            # is how the phone is being held.
            for rotation in ROTATIONS:
                shots = []
                for d in devices:
                    rel = screens[screen_id].get(f"{rotation}__{d['id']}")
                    if not rel:
                        continue
                    font = (
                        f" · font {d['fontScale']}×"
                        if d["fontScale"] != 1.0
                        else ""
                    )
                    shots.append(
                        f'<figure class="shot" data-mm="{d["widthMm"]}">'
                        f'<img loading="lazy" src="{rel}" '
                        f'alt="{title} · {d["label"]} · {rotation}">'
                        f'<figcaption><b>{d["label"]}</b>'
                        f'<span>{d["widthDp"]}×{d["heightDp"]}dp · '
                        f'{d["widthMm"]}×{d["heightMm"]}mm{font}</span>'
                        f"</figcaption></figure>"
                    )
                if shots:
                    groups.append(
                        f'<div class="orient"><h3>{ROTATION_TITLES[rotation]}</h3>'
                        f'<div class="row">{"".join(shots)}</div></div>'
                    )
            cards.append(
                f'<section class="screen" id="{anchor}">'
                f"<h2>{title}</h2>{''.join(groups)}</section>"
            )
        blocks.append(
            f'<div class="variant"><header class="vhead"><h1>{vtitle}</h1>'
            f'<p>{vblurb}</p></header>{"".join(cards)}</div>'
        )

    notes = "".join(
        f"<li><b>{d['label']}</b> — {d['note']}</li>"
        for d in devices
        if d.get("note")
    )
    count = sum(len(s) for v in tree.values() for s in v.values())

    html = TEMPLATE.replace("{{NAV}}", "".join(nav))
    html = html.replace("{{CARDS}}", "".join(blocks))
    html = html.replace("{{NOTES}}", notes)
    html = html.replace("{{COUNT}}", str(count))

    out = DESIGNS / "index.html"
    out.write_text(html, encoding="utf-8")
    return out


TEMPLATE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>pocketrig — phone UI</title>
<style>
  :root {
    --bg:#0d0e11; --panel:#16181d; --line:#262a33;
    --fg:#e8eaef; --dim:#9aa1ad; --accent:#4ea1ff;
    --px-per-mm: 3.7795;
  }
  * { box-sizing:border-box; }
  body { margin:0; background:var(--bg); color:var(--fg);
    font:14px/1.5 ui-sans-serif,system-ui,"Segoe UI",sans-serif; }
  header { position:sticky; top:0; z-index:10; background:rgba(13,14,17,.94);
    backdrop-filter:blur(8px); border-bottom:1px solid var(--line); padding:14px 24px; }
  h1 { margin:0 0 4px; font-size:16px; letter-spacing:.2px; }
  .sub { color:var(--dim); font-size:12px; }
  .controls { display:flex; gap:20px; align-items:center; flex-wrap:wrap; margin-top:12px; }
  .controls label { color:var(--dim); font-size:12px; display:flex; gap:8px; align-items:center; }
  button { background:var(--panel); color:var(--fg); border:1px solid var(--line);
    border-radius:7px; padding:6px 12px; font-size:12px; cursor:pointer; }
  button:hover { border-color:var(--accent); }
  nav { display:flex; gap:6px; flex-wrap:wrap; padding:12px 24px; border-bottom:1px solid var(--line); }
  nav a { color:var(--dim); text-decoration:none; font-size:12px; padding:4px 9px;
    border:1px solid var(--line); border-radius:999px; white-space:nowrap; }
  nav a:hover { color:var(--fg); border-color:var(--accent); }
  main { padding:8px 24px 80px; }
  .vhead { padding:30px 0 6px; }
  .vhead h1 { font-size:19px; margin:0 0 6px; }
  .vhead p { margin:0; color:var(--dim); font-size:12px; max-width:70ch; }
  .screen { padding:26px 0; border-bottom:1px solid var(--line); }
  h2 { font-size:14px; font-weight:600; margin:0 0 6px; color:var(--fg); }
  h3 { font-size:11px; font-weight:600; margin:16px 0 10px; color:var(--dim);
    text-transform:uppercase; letter-spacing:.08em; }
  .row { display:flex; gap:28px; align-items:flex-start; overflow-x:auto; padding-bottom:8px; }
  .navgroup { color:var(--fg); font-size:11px; font-weight:600; padding:4px 6px;
    text-transform:uppercase; letter-spacing:.06em; width:100%; }
  figure { margin:0; }
  figure img { display:block; border:1px solid var(--line); border-radius:14px;
    background:#000; height:auto; }
  figcaption { margin-top:8px; font-size:11px; color:var(--dim); max-width:100%; }
  figcaption b { display:block; color:var(--fg); font-weight:600; }
  .cal { border:1px solid var(--line); border-radius:10px; padding:16px 18px;
    margin:18px 24px; background:var(--panel); }
  .cal[hidden] { display:none; }
  .card-rule { height:54px; border:2px dashed var(--accent); border-radius:8px;
    margin:12px 0; display:flex; align-items:center; justify-content:center;
    color:var(--dim); font-size:11px; }
  .notes { margin:18px 24px 0; color:var(--dim); font-size:12px; }
  .notes ul { padding-left:18px; }
  .notes li { margin:4px 0; }
</style>
</head>
<body>
<header>
  <h1>pocketrig — phone UI</h1>
  <div class="sub">{{COUNT}} renders of the real Compose screens. Not mockups — this is
    what the app draws.</div>
  <div class="controls">
    <label><input type="radio" name="mode" value="physical" checked> Physical size (as held)</label>
    <label><input type="radio" name="mode" value="fit"> Fit to column</label>
    <button id="calibrate">Calibrate screen size…</button>
    <span class="sub" id="calstate"></span>
  </div>
</header>

<div class="cal" id="calpanel" hidden>
  <div>Hold a bank card flat against the screen and drag until the dashed box matches it
    exactly. Every phone render is then shown at the size it really is in your hand.</div>
  <div class="card-rule" id="rule">85.60 mm — standard bank card</div>
  <input type="range" id="slider" min="2" max="12" step="0.005" style="width:min(560px,100%)">
  <div class="sub" id="readout"></div>
  <div style="margin-top:10px"><button id="done">Done</button></div>
</div>

<nav>{{NAV}}</nav>
<main>{{CARDS}}</main>
<div class="notes"><b>Device profiles</b><ul>{{NOTES}}</ul></div>

<script>
  const KEY = 'pocketrig.pxPerMm';
  const CARD_MM = 85.60;
  let pxPerMm = parseFloat(localStorage.getItem(KEY)) || 3.7795;
  let mode = 'physical';

  const $ = s => document.querySelector(s);
  const shots = [...document.querySelectorAll('.shot')];

  function apply() {
    document.documentElement.style.setProperty('--px-per-mm', pxPerMm);
    for (const f of shots) {
      const img = f.querySelector('img');
      if (mode === 'physical') {
        img.style.width = (parseFloat(f.dataset.mm) * pxPerMm) + 'px';
      } else {
        img.style.width = '';
        img.style.maxHeight = '78vh';
      }
    }
    $('#calstate').textContent = mode === 'physical'
      ? `1 mm = ${pxPerMm.toFixed(3)} px` + (localStorage.getItem(KEY) ? '' : ' (uncalibrated)')
      : '';
    $('#rule').style.width = (CARD_MM * pxPerMm) + 'px';
    $('#readout').textContent =
      `1 mm = ${pxPerMm.toFixed(3)} px · implies ${(pxPerMm * 25.4).toFixed(0)} ppi`;
  }

  $('#slider').value = pxPerMm;
  $('#slider').addEventListener('input', e => {
    pxPerMm = parseFloat(e.target.value);
    localStorage.setItem(KEY, pxPerMm);
    apply();
  });
  $('#calibrate').addEventListener('click', () => {
    $('#calpanel').hidden = !$('#calpanel').hidden;
  });
  $('#done').addEventListener('click', () => { $('#calpanel').hidden = true; });
  for (const r of document.querySelectorAll('input[name=mode]')) {
    r.addEventListener('change', e => { mode = e.target.value; apply(); });
  }
  apply();
</script>
</body>
</html>
"""


if __name__ == "__main__":
    print(f"wrote {build()}")
