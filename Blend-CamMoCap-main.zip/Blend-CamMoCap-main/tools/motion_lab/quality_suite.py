#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Q0.2 deterministic presentation-quality suite and candidate comparator.

Unlike the original Motion Lab regression numbers, this report preserves the
input fingerprint, labels the current implementation as a *baseline*, and
evaluates candidates using explicit relational safeguards.  Those safeguards
are engineering comparison limits, not claims of absolute real-world accuracy;
physical targets arrive with Q0.3 ground truth.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Sequence, Tuple

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE))

from presentation import LatestPosePresenter, run_scenario  # noqa: E402
from simulator import NS, PresentedFrame, Scenario, default_scenarios, qangle_deg, vlength, vsub  # noqa: E402
from synth import yaw_of  # noqa: E402

BASELINE = _HERE / "baselines" / "presentation_v1.json"
RESULTS_DOC = _HERE / "presentation-results.md"
SCHEMA = "pocketrig-presentation-quality"
VERSION = 1
FREQUENCIES = (0.25, 0.5, 1.0, 2.0, 3.0, 5.0)


def _rms(values: Iterable[float]) -> float:
    values = list(values)
    return math.sqrt(sum(value * value for value in values) / len(values))


def _percentile(values: Sequence[float], fraction: float) -> float:
    ordered = sorted(values)
    if not ordered:
        return 0.0
    index = fraction * (len(ordered) - 1)
    lo = int(math.floor(index))
    hi = int(math.ceil(index))
    if lo == hi:
        return ordered[lo]
    weight = index - lo
    return ordered[lo] * (1.0 - weight) + ordered[hi] * weight


def _frames_between(
    frames: Sequence[PresentedFrame], start_s: float, end_s: float
) -> List[PresentedFrame]:
    return [
        frame
        for frame in frames
        if start_s <= frame.presentation_ns / NS < end_s
    ]


def _steps(frames: Sequence[PresentedFrame]) -> Tuple[List[float], List[float]]:
    pos = [
        vlength(vsub(b.output.p, a.output.p))
        for a, b in zip(frames, frames[1:])
    ]
    rot = [
        qangle_deg(a.output.q, b.output.q)
        for a, b in zip(frames, frames[1:])
    ]
    return pos, rot


def _phase_gain(
    frames: Sequence[PresentedFrame], freq_hz: float, amplitude_deg: float = 18.0
) -> Tuple[float, float]:
    """Least-squares-like Fourier projection over complete scenario cycles."""
    usable = [frame for frame in frames if 0.5 <= frame.presentation_ns / NS < 7.5]
    values = [yaw_of(frame.output.q) for frame in usable]
    mean = sum(values) / len(values)
    sin_sum = cos_sum = sin_sq = cos_sq = sin_cos = 0.0
    y_sin = y_cos = 0.0
    omega = 2.0 * math.pi * freq_hz
    for frame, value in zip(usable, values):
        t_s = frame.presentation_ns / NS
        sine = math.sin(omega * t_s)
        cosine = math.cos(omega * t_s)
        centered = value - mean
        sin_sum += sine
        cos_sum += cosine
        sin_sq += sine * sine
        cos_sq += cosine * cosine
        sin_cos += sine * cosine
        y_sin += centered * sine
        y_cos += centered * cosine
    # Solve the 2x2 normal equations.  The selected windows are well
    # conditioned, but retain the guard so malformed inputs fail cleanly.
    det = sin_sq * cos_sq - sin_cos * sin_cos
    if abs(det) < 1e-12:
        raise ValueError("phase window is singular")
    sin_coeff = (y_sin * cos_sq - y_cos * sin_cos) / det
    cos_coeff = (y_cos * sin_sq - y_sin * sin_cos) / det
    output_amp = math.hypot(sin_coeff, cos_coeff)
    phase = math.atan2(-cos_coeff, sin_coeff)
    period = 2.0 * math.pi
    phase = (phase + math.pi) % period - math.pi
    lag_ms = phase / omega * 1000.0
    return lag_ms, output_amp / amplitude_deg


def _jerk_p95(frames: Sequence[PresentedFrame]) -> float:
    if len(frames) < 5:
        return 0.0
    velocities = []
    for a, b in zip(frames, frames[1:]):
        dt = (b.presentation_ns - a.presentation_ns) / NS
        velocities.append(tuple((b.output.p[i] - a.output.p[i]) / dt for i in range(3)))
    accelerations = []
    dt = (frames[1].presentation_ns - frames[0].presentation_ns) / NS
    for a, b in zip(velocities, velocities[1:]):
        accelerations.append(tuple((b[i] - a[i]) / dt for i in range(3)))
    jerks = []
    for a, b in zip(accelerations, accelerations[1:]):
        jerks.append(vlength(tuple((b[i] - a[i]) / dt for i in range(3))))
    return _percentile(jerks, 0.95)


def _settling_ms(
    frames: Sequence[PresentedFrame], stop_s: float, target_m: float, tolerance_m: float
) -> float:
    after = [frame for frame in frames if frame.presentation_ns / NS >= stop_s]
    errors = [abs(frame.output.p[0] - target_m) for frame in after]
    for index, frame in enumerate(after):
        if max(errors[index:]) <= tolerance_m:
            return (frame.presentation_ns / NS - stop_s) * 1000.0
    return (after[-1].presentation_ns / NS - stop_s) * 1000.0


def _relative_recovery_rmse(
    frames: Sequence[PresentedFrame], start_s: float, end_s: float
) -> float:
    segment = _frames_between(frames, start_s, end_s)
    if len(segment) < 2:
        return 0.0
    output0 = segment[0].output.p
    truth0 = segment[0].truth.p
    errors = [
        vlength(vsub(vsub(frame.output.p, output0), vsub(frame.truth.p, truth0)))
        for frame in segment
    ]
    return _rms(errors)


def collect_metrics(
    presenter_factory: Callable[[], LatestPosePresenter],
    scenarios: Sequence[Scenario],
) -> Dict[str, float]:
    runs = {
        scenario.name: run_scenario(scenario, presenter_factory())
        for scenario in scenarios
    }
    metrics: Dict[str, float] = {}

    stationary = runs["stationary_colored"]
    stable = _frames_between(stationary, 1.0, 10.0)
    metrics["stationary/position_rms_m"] = _rms(
        vlength(vsub(frame.output.p, frame.truth.p)) for frame in stable
    )
    metrics["stationary/rotation_rms_deg"] = _rms(
        qangle_deg(frame.output.q, frame.truth.q) for frame in stable
    )
    metrics["stationary/endpoint_drift_m"] = vlength(
        vsub(stable[-1].output.p, stable[0].output.p)
    )
    metrics["stationary/endpoint_drift_deg"] = qangle_deg(
        stable[-1].output.q, stable[0].output.q
    )

    for freq in FREQUENCIES:
        lag_ms, gain = _phase_gain(runs[f"sine_yaw_{freq:g}hz"], freq)
        metrics[f"response/{freq:g}hz_phase_lag_ms"] = lag_ms
        metrics[f"response/{freq:g}hz_gain"] = gain

    step = runs["step_translation"]
    after_stop = [frame.output.p[0] for frame in step if frame.presentation_ns / NS >= 1.5]
    metrics["response/stop_overshoot_pct"] = max(
        0.0, (max(after_stop) - 0.25) / 0.25 * 100.0
    )
    metrics["response/stop_settling_ms"] = _settling_ms(step, 1.5, 0.25, 0.005)

    reversal = runs["reversal_translation"]
    after_reversal = [
        frame.output.p[0]
        for frame in reversal
        if 1.5 <= frame.presentation_ns / NS < 2.5
    ]
    metrics["response/reversal_overshoot_pct"] = max(
        0.0, (max(after_reversal) - 0.25) / 0.25 * 100.0
    )

    mixed = runs["mixed_loop"]
    mixed_motion = _frames_between(mixed, 0.25, 8.5)
    mixed_pos_steps, mixed_rot_steps = _steps(mixed_motion)
    metrics["continuity/mixed_max_position_step_m"] = max(mixed_pos_steps)
    metrics["continuity/mixed_max_rotation_step_deg"] = max(mixed_rot_steps)
    metrics["smoothness/mixed_position_jerk_p95_mps3"] = _jerk_p95(mixed_motion)
    metrics["smoothness/mixed_repeated_pose_ratio"] = sum(
        p_step < 1e-12 and r_step < 1e-9
        for p_step, r_step in zip(mixed_pos_steps, mixed_rot_steps)
    ) / len(mixed_pos_steps)
    metrics["loop/closure_position_m"] = vlength(
        vsub(mixed[-1].output.p, mixed[0].output.p)
    )
    metrics["loop/closure_rotation_deg"] = qangle_deg(
        mixed[-1].output.q, mixed[0].output.q
    )
    output_ranges = [
        max(frame.output.p[axis] for frame in mixed_motion)
        - min(frame.output.p[axis] for frame in mixed_motion)
        for axis in range(3)
    ]
    truth_ranges = [
        max(frame.truth.p[axis] for frame in mixed_motion)
        - min(frame.truth.p[axis] for frame in mixed_motion)
        for axis in range(3)
    ]
    metrics["scale/mixed_position_gain"] = vlength(tuple(output_ranges)) / vlength(tuple(truth_ranges))

    degraded = runs["degraded_relocalization"]
    degraded_pos_steps, degraded_rot_steps = _steps(degraded)
    metrics["continuity/degraded_max_position_step_m"] = max(degraded_pos_steps)
    metrics["continuity/degraded_max_rotation_step_deg"] = max(degraded_rot_steps)
    metrics["recovery/post_dropout_relative_rmse_m"] = _relative_recovery_rmse(
        degraded, 5.6, 7.2
    )
    metrics["recovery/post_relocal_relative_rmse_m"] = _relative_recovery_rmse(
        degraded, 8.4, 10.5
    )

    ages_ms = [
        (frame.presentation_ns - frame.source_ns) / 1_000_000.0
        for scenario in scenarios
        for frame in runs[scenario.name]
        if frame.presentation_ns <= scenario.duration_ns
    ]
    # Consider active capture time only, not each scenario's settling tail.
    metrics["timing/source_age_p50_ms"] = _percentile(ages_ms, 0.50)
    metrics["timing/source_age_p95_ms"] = _percentile(ages_ms, 0.95)
    return metrics


# Relational safeguards for future candidates.  They are deliberately explicit
# and narrow: Q0.3 physical tests will establish absolute product targets.
MAX_LAG_INCREASE_MS = 20.0
MAX_SETTLING_INCREASE_MS = 80.0
MAX_GAIN_LOSS = 0.08


def compare_candidate(
    baseline: Dict[str, float], candidate: Dict[str, float]
) -> List[str]:
    failures: List[str] = []
    for freq in FREQUENCIES:
        lag = f"response/{freq:g}hz_phase_lag_ms"
        gain = f"response/{freq:g}hz_gain"
        if candidate[lag] > baseline[lag] + MAX_LAG_INCREASE_MS:
            failures.append(
                f"{lag}: +{candidate[lag] - baseline[lag]:.2f} ms exceeds +{MAX_LAG_INCREASE_MS:.0f} ms"
            )
        if candidate[gain] < baseline[gain] - MAX_GAIN_LOSS:
            failures.append(
                f"{gain}: loss {baseline[gain] - candidate[gain]:.3f} exceeds {MAX_GAIN_LOSS:.2f}"
            )
    settling = "response/stop_settling_ms"
    if candidate[settling] > baseline[settling] + MAX_SETTLING_INCREASE_MS:
        failures.append(
            f"{settling}: +{candidate[settling] - baseline[settling]:.2f} ms exceeds +{MAX_SETTLING_INCREASE_MS:.0f} ms"
        )

    limits = {
        "continuity/mixed_max_position_step_m": 0.005,
        "continuity/mixed_max_rotation_step_deg": 0.5,
        "continuity/degraded_max_position_step_m": 0.005,
        "continuity/degraded_max_rotation_step_deg": 0.5,
        "loop/closure_position_m": 0.005,
        "loop/closure_rotation_deg": 0.5,
    }
    for name, allowance in limits.items():
        if candidate[name] > baseline[name] + allowance:
            failures.append(
                f"{name}: {candidate[name]:.6f} exceeds baseline {baseline[name]:.6f} + {allowance:g}"
            )
    return failures


def run_suite(
    smoothing: float = 0.30, *, guards: bool = True
) -> Tuple[Tuple[Scenario, ...], Dict[str, float]]:
    scenarios = default_scenarios()
    metrics = collect_metrics(
        lambda: LatestPosePresenter(smoothing=smoothing, guards=guards), scenarios
    )
    return scenarios, metrics


def baseline_payload(
    scenarios: Sequence[Scenario], metrics: Dict[str, float]
) -> Dict[str, object]:
    return {
        "format": SCHEMA,
        "version": VERSION,
        "role": "regression-baseline-not-product-target",
        "presenter": "latest-s0.30",
        "scenario_fingerprints": {
            scenario.name: scenario.fingerprint for scenario in scenarios
        },
        "metrics": {name: round(value, 9) for name, value in sorted(metrics.items())},
        "absolute_tolerance": 1e-6,
    }


def check_baseline(payload: Dict[str, object]) -> List[str]:
    if not BASELINE.exists():
        return [f"missing {BASELINE}; run quality_suite.py --update-baseline"]
    expected = json.loads(BASELINE.read_text(encoding="utf-8"))
    failures: List[str] = []
    for field in ("format", "version", "role", "presenter", "scenario_fingerprints"):
        if payload[field] != expected.get(field):
            failures.append(f"baseline {field} changed")
    tolerance = float(expected.get("absolute_tolerance", 1e-6))
    expected_metrics = expected.get("metrics", {})
    measured = payload["metrics"]
    for name, value in expected_metrics.items():
        if name not in measured:
            failures.append(f"{name}: baseline exists but metric is absent")
        elif abs(measured[name] - value) > tolerance:
            failures.append(
                f"{name}: {measured[name]:.9f} outside baseline {value:.9f} ± {tolerance:g}"
            )
    for name in measured:
        if name not in expected_metrics:
            failures.append(f"{name}: measured but absent from baseline")
    return failures


def _write_report(
    baseline: Dict[str, float],
    probes: Sequence[Tuple[str, Dict[str, float], List[str]]],
    scenarios: Sequence[Scenario],
) -> None:
    lines = [
        "License: CC-BY-NC-4.0",
        "",
        "# Deterministic presentation results",
        "",
        "Generated by `python tools/motion_lab/quality_suite.py --report`.",
        "The current presenter is a regression baseline, **not an absolute product target**.",
        "Candidate limits are relational safeguards pending Q0.3 physical ground truth.",
        "",
        "## Frozen inputs",
        "",
        "| scenario | SHA-256 |",
        "|---|---|",
    ]
    lines.extend(f"| {scenario.name} | `{scenario.fingerprint}` |" for scenario in scenarios)
    lines += [
        "",
        "## Baseline metrics — current default (`latest-s0.30`)",
        "",
        "| metric | value |",
        "|---|---:|",
    ]
    lines.extend(f"| `{name}` | {value:.6f} |" for name, value in sorted(baseline.items()))
    lines += ["", "## Gate self-check probes", ""]
    for name, _metrics, failures in probes:
        lines.append(f"### {name}")
        lines.append("")
        if failures:
            lines.append("Expected result: **rejected**.")
            lines.append("")
            lines.extend(f"- {failure}" for failure in failures)
        else:
            lines.append("Unexpected result: passed all candidate gates.")
        lines.append("")
    RESULTS_DOC.write_text("\n".join(lines), encoding="utf-8", newline="\n")


def main() -> int:
    parser = argparse.ArgumentParser(prog="quality_suite")
    parser.add_argument("--update-baseline", action="store_true")
    parser.add_argument("--report", action="store_true")
    args = parser.parse_args()

    scenarios, baseline_metrics = run_suite()
    payload = baseline_payload(scenarios, baseline_metrics)
    if args.update_baseline:
        BASELINE.parent.mkdir(parents=True, exist_ok=True)
        BASELINE.write_text(
            json.dumps(payload, indent=2) + "\n", encoding="utf-8", newline="\n"
        )
        print(f"baseline written: {BASELINE}")

    slow_scenarios, slow = run_suite(smoothing=1.0)
    unsafe_scenarios, unsafe = run_suite(smoothing=0.30, guards=False)
    assert [s.fingerprint for s in scenarios] == [s.fingerprint for s in slow_scenarios]
    assert [s.fingerprint for s in scenarios] == [s.fingerprint for s in unsafe_scenarios]
    slow_failures = compare_candidate(baseline_metrics, slow)
    unsafe_failures = compare_candidate(baseline_metrics, unsafe)

    for name, value in sorted(baseline_metrics.items()):
        print(f"  {name:52s} {value:12.6f}")
    print(f"\nslow-probe rejected by {len(slow_failures)} gate(s)")
    print(f"unguarded-probe rejected by {len(unsafe_failures)} gate(s)")
    if args.report:
        _write_report(
            baseline_metrics,
            (("Over-smoothed probe", slow, slow_failures), ("Unguarded probe", unsafe, unsafe_failures)),
            scenarios,
        )
        print(f"report written: {RESULTS_DOC}")

    failures = check_baseline(payload)
    if not slow_failures:
        failures.append("over-smoothed probe was not rejected")
    if not unsafe_failures:
        failures.append("unguarded probe was not rejected")
    if failures:
        print("\nQUALITY SUITE FAILED")
        for failure in failures:
            print(" ", failure)
        return 1
    print("\nPRESENTATION BASELINE STABLE; BAD PROBES REJECTED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
