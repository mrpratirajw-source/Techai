#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Replay a .take trace against a LIVE pocketrig host — real UDP, real time.

The point: captured phone motion (a real handheld shake, THE landscape-
rotation capture) becomes a repeatable input you can watch in the viewport or
record, instead of a one-off wave of somebody's arm.

    python tools/motion_lab/replay.py traces/walk.take --token K3XG9A
    python tools/motion_lab/replay.py shake.take --host 192.168.1.23 --speed 2
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

_HERE = Path(__file__).resolve().parent
_REPO = _HERE.parents[1]
sys.path.insert(0, str(_HERE))
sys.path.insert(0, str(_REPO / "blender"))
sys.path.insert(0, str(_REPO / "tools"))

import traces  # noqa: E402
from fake_phone import Client, build_parser  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="replay", description="Stream a .take trace to a running host."
    )
    parser.add_argument("trace", type=Path)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=47800)
    parser.add_argument("--token", default="XXXXXX")
    parser.add_argument("--speed", type=float, default=1.0,
                        help="playback speed multiplier (2 = twice as fast)")
    parser.add_argument("--loop", action="store_true")
    args = parser.parse_args()

    header, samples = traces.read_trace(args.trace)
    print(f"{args.trace}: {len(samples)} samples, source={header.get('source')}")

    # Reuse fake_phone's protocol client with defaults, but drive the pose
    # stream from the trace instead of a generator.
    fp_args = build_parser().parse_args(["--mode", "orbit"])  # placeholder mode
    client = Client(args.host, args.port, args.token, fp_args)
    client.hello_until_welcome()
    from core import protocol as P  # noqa: E402  (single codec, never a copy)

    try:
        while True:
            wall0 = time.monotonic()
            t0 = samples[0][0]
            base_ns = time.monotonic_ns()
            for t_ns, q, p in samples:
                due = wall0 + (t_ns - t0) / 1e9 / args.speed
                delay = due - time.monotonic()
                if delay > 0:
                    time.sleep(delay)
                client.send(
                    P.encode_pose(
                        client.next_seq(),
                        base_ns + int((t_ns - t0) / args.speed),
                        q,
                        pos=p,
                    )
                )
                client.drain()
                client.service_pending()
            if not args.loop:
                break
    except KeyboardInterrupt:
        print("\ninterrupted")
    finally:
        client.bye()


if __name__ == "__main__":
    main()
