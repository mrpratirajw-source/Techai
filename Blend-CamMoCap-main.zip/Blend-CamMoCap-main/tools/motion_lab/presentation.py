# SPDX-License-Identifier: GPL-3.0-or-later
"""Presenter candidates for the deterministic Motion Lab.

`LatestPosePresenter` mirrors the current host policy closely enough to make
candidate comparisons meaningful: latest-wins delivery, source-timestamped
One-Euro filtering, location hold/re-anchor on loss or impossible motion, and
rotation-frame preservation on a relocalization-sized jump.  It is pure
Python and owns no Blender state.
"""

from __future__ import annotations

import math
import sys
from pathlib import Path
from typing import Optional, Tuple

_REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_REPO / "blender"))

from core import filters  # noqa: E402
from simulator import (  # noqa: E402
    NS,
    Packet,
    Pose,
    PresentedFrame,
    Quat,
    Scenario,
    Vec3,
    qangle_deg,
    qinv,
    qmul,
    qrotate,
    vadd,
    vlength,
    vscale,
    vsub,
)


class LatestPosePresenter:
    """Current latest-wins presentation policy with configurable smoothing.

    Guards can be disabled only for an intentionally bad comparison probe; the
    production-equivalent baseline always enables them.
    """

    POS_GAP_NS = 250_000_000
    TELEPORT_MPS = 5.0
    ROT_TELEPORT_DPS = 1200.0
    SHAKE_HOLD_DPS = 300.0

    def __init__(self, smoothing: float = 0.30, *, guards: bool = True):
        self.smoothing = max(0.0, min(1.0, smoothing))
        self.guards = guards
        q_cutoff, q_beta = filters.live_filter_params(self.smoothing)
        p_cutoff, p_beta = filters.live_pos_filter_params(self.smoothing)
        self.q_filter = filters.OneEuroQuat(q_cutoff, q_beta)
        self.p_filter = filters.OneEuroVec3(p_cutoff, p_beta)
        self.output: Optional[Pose] = None
        self.q_offset: Quat = (1.0, 0.0, 0.0, 0.0)
        self.loc_offset: Optional[Vec3] = None
        self.last_source_ns: Optional[int] = None
        self.last_raw_q: Optional[Quat] = None
        self.last_raw_p: Optional[Vec3] = None
        self.last_pos_ns: Optional[int] = None

    @property
    def name(self) -> str:
        suffix = "" if self.guards else "-unguarded"
        return f"latest-s{self.smoothing:.2f}{suffix}"

    def _filtered_q(self, q: Quat, t_ns: int) -> Quat:
        if self.smoothing <= 0.0:
            self.q_filter.reset()
            return q
        return self.q_filter.update(q, t_ns)

    def _filtered_p(self, p: Vec3, t_ns: int) -> Vec3:
        if self.smoothing <= 0.0:
            self.p_filter.reset()
            return p
        return self.p_filter.update(p, t_ns)

    def ingest(self, packet: Packet) -> None:
        frame = packet.frame
        t_ns = frame.source_ns
        if self.last_source_ns is not None and t_ns <= self.last_source_ns:
            return

        raw_q = frame.observed_q
        raw_p = frame.observed_p
        previous_output = self.output
        angular_dps = 0.0
        if self.last_raw_q is not None and self.last_source_ns is not None:
            dt_ns = t_ns - self.last_source_ns
            if dt_ns > 0:
                angular_dps = qangle_deg(self.last_raw_q, raw_q) / (dt_ns / NS)

        if previous_output is None:
            q_out = raw_q
            self.q_filter.reset()
        elif self.guards and angular_dps > self.ROT_TELEPORT_DPS:
            # Preserve the visible frame and absorb the raw world-frame jump.
            self.q_offset = qmul(previous_output.q, qinv(raw_q))
            self.q_filter.reset()
            q_out = previous_output.q
        else:
            q_out = qmul(self.q_offset, self._filtered_q(raw_q, t_ns))

        if previous_output is None:
            p_out = raw_p if raw_p is not None else (0.0, 0.0, 0.0)
            if raw_p is not None:
                p_world = qrotate(self.q_offset, raw_p)
                self.loc_offset = vsub(p_out, p_world)
        elif raw_p is None:
            # Position is unknown: hold now and make recovery continuity-safe.
            p_out = previous_output.p
            self.loc_offset = None
            self.p_filter.reset()
        elif self.guards and angular_dps > self.SHAKE_HOLD_DPS:
            p_out = previous_output.p
            self.loc_offset = None
            self.p_filter.reset()
        else:
            if self.guards and self.last_pos_ns is not None:
                dt_ns = t_ns - self.last_pos_ns
                if dt_ns > self.POS_GAP_NS:
                    self.loc_offset = None
                    self.p_filter.reset()
                elif dt_ns > 0 and self.last_raw_p is not None:
                    speed = vlength(vsub(raw_p, self.last_raw_p)) / (dt_ns / NS)
                    if speed > self.TELEPORT_MPS:
                        self.loc_offset = None
                        self.p_filter.reset()
            p_use = self._filtered_p(raw_p, t_ns)
            p_world = qrotate(self.q_offset, p_use)
            if self.loc_offset is None:
                self.loc_offset = vsub(previous_output.p, p_world)
            p_out = vadd(self.loc_offset, p_world)

        self.output = Pose(q_out, p_out)
        self.last_source_ns = t_ns
        self.last_raw_q = raw_q
        if raw_p is not None:
            self.last_raw_p = raw_p
            self.last_pos_ns = t_ns


def run_scenario(
    scenario: Scenario, presenter: LatestPosePresenter
) -> Tuple[PresentedFrame, ...]:
    """Replay one immutable scenario through one candidate.

    Packet arrival order can differ from sequence order.  The receive side
    accepts only a newer sequence, then the presentation tick consumes the
    newest accepted packet exactly as the real latest-slot host does.
    """
    arrivals = sorted(scenario.packets, key=lambda packet: (packet.arrival_ns, packet.seq))
    arrival_index = 0
    highest_received_seq = -1
    latest_packet: Optional[Packet] = None
    applied_seq = -1
    result = []

    for tick_ns in scenario.presentation_ns:
        while arrival_index < len(arrivals) and arrivals[arrival_index].arrival_ns <= tick_ns:
            packet = arrivals[arrival_index]
            arrival_index += 1
            if packet.seq > highest_received_seq:
                highest_received_seq = packet.seq
                latest_packet = packet
        if latest_packet is not None and latest_packet.seq > applied_seq:
            presenter.ingest(latest_packet)
            applied_seq = latest_packet.seq
        if presenter.output is not None and presenter.last_source_ns is not None:
            t_s = min(tick_ns, scenario.duration_ns) / NS
            result.append(
                PresentedFrame(
                    presentation_ns=tick_ns,
                    source_ns=presenter.last_source_ns,
                    output=presenter.output,
                    truth=scenario.truth_at(t_s),
                )
            )
    return tuple(result)
