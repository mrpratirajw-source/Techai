# SPDX-License-Identifier: GPL-3.0-or-later
"""Deterministic synthetic motion generators for the Motion Lab.

Everything is seeded/closed-form: two runs produce byte-identical traces, so
metric baselines are meaningful. Quaternions are (w, x, y, z), protocol frame
(upright base = camera level looking +Y, see fake_phone.py).
"""

from __future__ import annotations

import math
from typing import List, Optional, Tuple

Quat = Tuple[float, float, float, float]
Vec3 = Tuple[float, float, float]
Sample = Tuple[int, Quat, Optional[Vec3]]

SQ2 = math.sqrt(0.5)
UPRIGHT: Quat = (SQ2, SQ2, 0.0, 0.0)  # camera level, looking +Y


def qmul(a: Quat, b: Quat) -> Quat:
    w1, x1, y1, z1 = a
    w2, x2, y2, z2 = b
    return (
        w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2,
        w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
        w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2,
        w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2,
    )


def qnorm(q: Quat) -> Quat:
    n = math.sqrt(sum(c * c for c in q)) or 1.0
    return (q[0] / n, q[1] / n, q[2] / n, q[3] / n)


def q_axis(axis: Vec3, deg: float) -> Quat:
    h = math.radians(deg) / 2.0
    s = math.sin(h)
    return (math.cos(h), axis[0] * s, axis[1] * s, axis[2] * s)


def yaw_of(q: Quat) -> float:
    """World-Z yaw (deg) of a pose relative to UPRIGHT — the 1-DOF readout the
    pan/sine metrics use. Extracted from q_rel = q ⊗ UPRIGHT⁻¹ (a pure world-Z
    rotation for the generators below)."""
    inv = (UPRIGHT[0], -UPRIGHT[1], -UPRIGHT[2], -UPRIGHT[3])
    w, _x, _y, z = qmul(q, inv)
    return math.degrees(2.0 * math.atan2(z, w))


def _lcg(seed: int):
    x = seed & 0x7FFFFFFF
    while True:
        x = (1103515245 * x + 12345) & 0x7FFFFFFF
        yield x / 0x7FFFFFFF


def constant_pan(rate_dps: float, duration_s: float, rate_hz: float = 100.0) -> List[Sample]:
    """Steady world-Z pan at exactly rate_dps — the steady-state-lag probe."""
    n = int(duration_s * rate_hz)
    out: List[Sample] = []
    for i in range(n):
        t = i / rate_hz
        q = qnorm(qmul(q_axis((0, 0, 1), rate_dps * t), UPRIGHT))
        out.append((int(t * 1e9), q, None))
    return out


def sine_yaw(peak_dps: float, freq_hz: float, duration_s: float, rate_hz: float = 100.0) -> List[Sample]:
    """Sinusoidal yaw whose PEAK angular speed is peak_dps (A·2πf = peak)."""
    amp = peak_dps / (2.0 * math.pi * freq_hz)
    n = int(duration_s * rate_hz)
    out: List[Sample] = []
    for i in range(n):
        t = i / rate_hz
        q = qnorm(qmul(q_axis((0, 0, 1), amp * math.sin(2 * math.pi * freq_hz * t)), UPRIGHT))
        out.append((int(t * 1e9), q, None))
    return out


def noisy_hold(sigma_deg: float, duration_s: float, seed: int = 1234, rate_hz: float = 100.0) -> List[Sample]:
    """Stationary pose + seeded 3-axis jitter of ~sigma_deg RMS per axis —
    the jitter-attenuation probe. Noise is independent per sample (worst case
    for a low-pass; real sensor noise is kinder)."""
    rng = _lcg(seed)
    n = int(duration_s * rate_hz)
    out: List[Sample] = []
    for i in range(n):
        t = i / rate_hz
        # sum of two uniforms ~ triangular; scaled to sigma_deg RMS-ish
        def nz() -> float:
            return (next(rng) + next(rng) - 1.0) * sigma_deg * 1.73
        q = UPRIGHT
        q = qmul(q, q_axis((1, 0, 0), nz()))
        q = qmul(q, q_axis((0, 1, 0), nz()))
        q = qmul(q, q_axis((0, 0, 1), nz()))
        out.append((int(t * 1e9), qnorm(q), None))
    return out


def arc_walk(radius_m: float, duration_s: float, rate_hz: float = 100.0) -> List[Sample]:
    """6DOF closed-form: walk a circular arc at constant speed, camera panning
    with the tangent. Both channels are analytically known — the bake-fidelity
    probe."""
    n = int(duration_s * rate_hz)
    out: List[Sample] = []
    for i in range(n):
        t = i / rate_hz
        a = 2.0 * math.pi * t / duration_s  # one full lap over the trace
        pos = (radius_m * math.cos(a) - radius_m, radius_m * math.sin(a), 0.0)
        q = qnorm(qmul(q_axis((0, 0, 1), math.degrees(a)), UPRIGHT))
        out.append((int(t * 1e9), q, pos))
    return out


def at_cadence(samples: List[Sample], cadence_hz: float) -> List[Sample]:
    """Thin a trace to a slower source cadence (e.g. ARCore's ~30 Hz), keeping
    the first sample and then one per cadence period — the stepping probe's
    input."""
    period_ns = 1e9 / cadence_hz
    out: List[Sample] = []
    next_at = None
    for s in samples:
        if next_at is None or s[0] >= next_at:
            out.append(s)
            next_at = (s[0] if next_at is None else next_at) + period_ns
    return out
