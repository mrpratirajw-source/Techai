# SPDX-License-Identifier: GPL-3.0-or-later
"""Motion Lab tier-2, inside `blender --background --python`: streams a
closed-form 6DOF arc through the REAL UDP path, records it, and measures how
faithfully the bake reproduces the analytic ground truth — clean and under
5% seeded packet loss (latest-wins should shrug it off).

Prints one `LAB_METRICS {json}` line and `HEADLESS_LAB_DONE`; run_lab.py
--full parses and gates against baselines/tier2.json. Offset composition
correctness is headless_6dof.py's job — this file measures RESAMPLING
fidelity, so expectations compose with the state offsets directly.
"""

import json
import math
import sys
import time
import traceback
from pathlib import Path

_HERE = Path(__file__).resolve().parent
_REPO = _HERE.parents[1]
sys.path.insert(0, str(_HERE))
sys.path.insert(0, str(_REPO / "blender" / "tests"))

import bpy  # noqa: E402
from mathutils import Quaternion, Vector  # noqa: E402

import net  # noqa: E402
import synth  # noqa: E402
from _headless_common import FakePhone, load_addon, wait_for  # noqa: E402

RADIUS = 0.5
DURATION = 2.0
FPS = 24


def location_fcurves(action):
    fcs = [fc for fc in getattr(action, "fcurves", []) if fc.data_path == "location"]
    if not fcs:
        for layer in getattr(action, "layers", []):
            for strip in layer.strips:
                for bag in strip.channelbags:
                    fcs.extend(fc for fc in bag.fcurves if fc.data_path == "location")
    return sorted(fcs, key=lambda fc: fc.array_index)


def rotation_fcurves(action):
    fcs = [
        fc for fc in getattr(action, "fcurves", [])
        if fc.data_path == "rotation_quaternion"
    ]
    if not fcs:
        for layer in getattr(action, "layers", []):
            for strip in layer.strips:
                for bag in strip.channelbags:
                    fcs.extend(
                        fc for fc in bag.fcurves
                        if fc.data_path == "rotation_quaternion"
                    )
    return sorted(fcs, key=lambda fc: fc.array_index)


def closed_form(t_s: float):
    """The arc_walk generator's analytic pose at time t (protocol frame)."""
    a = 2.0 * math.pi * t_s / DURATION
    pos = (RADIUS * math.cos(a) - RADIUS, RADIUS * math.sin(a), 0.0)
    q = synth.qnorm(synth.qmul(synth.q_axis((0, 0, 1), math.degrees(a)), synth.UPRIGHT))
    return q, pos


def record_run(server, phone, apply_mod, state, scene, samples, base_ts_ns):
    """One full record flow over the given (possibly impaired) sample list.
    Returns (pos_max, pos_rms, rot_max_deg, frames)."""
    from pocketrig.core import constants as C
    from pocketrig.core import protocol as P

    start_ns = base_ts_ns + samples[0][0]
    end_ns = base_ts_ns + samples[-1][0]
    # A pre-roll pose establishes offsets before the window opens.
    seq = phone.pose(start_ns - 10_000_000, samples[0][1], pos=samples[0][2])
    wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
    phone.send_reliable(
        P.encode_record_start(phone.next_seq(), time.monotonic_ns(), start_ns),
        pump=apply_mod.apply_tick,
    )
    for t_ns, q, p in samples:
        s = phone.pose(base_ts_ns + t_ns, q, pos=p)
    wait_for(lambda: state.last_seq == s, pump=apply_mod.apply_tick)
    phone.send_reliable(
        P.encode_record_stop(
            phone.next_seq(), time.monotonic_ns(), end_ns, len(samples)
        ),
        pump=apply_mod.apply_tick,
    )
    phone.inbox.clear()  # drop this run's ACK bookkeeping noise for wait_msg
    baked = phone.wait_msg(C.MSG_RECORD_BAKED, pump=apply_mod.apply_tick)
    phone.ack(baked.seq)
    frames = baked.body["frames"]

    cam = scene.camera
    q_off = state.q_offset.copy()
    loc_off = state.loc_offset.copy()
    scale = state.applied_move_scale
    action = cam.animation_data.action
    loc_fc = location_fcurves(action)
    rot_fc = rotation_fcurves(action)
    assert len(loc_fc) == 3 and len(rot_fc) == 4, (len(loc_fc), len(rot_fc))

    pos_errs, rot_errs = [], []
    for f in range(frames):
        t_s = f / FPS
        q_true, p_true = closed_form(t_s)
        want_loc = loc_off + scale * (q_off @ Vector(p_true))
        got_loc = Vector([fc.keyframe_points[f].co[1] for fc in loc_fc])
        pos_errs.append((got_loc - want_loc).length)
        want_rot = q_off @ Quaternion(q_true)
        got_rot = Quaternion([fc.keyframe_points[f].co[1] for fc in rot_fc])
        d = min(1.0, abs(want_rot.dot(got_rot)))
        rot_errs.append(math.degrees(2.0 * math.acos(d)))
    pos_rms = math.sqrt(sum(e * e for e in pos_errs) / len(pos_errs))
    return max(pos_errs), pos_rms, max(rot_errs), frames


def live_run(state, apply_mod, scene, phone, samples, base_ts_ns, pop_at=None, pop=(0.0, 0.0, 0.0)):
    """Streams samples live (pumping per pose) and returns the largest
    single-application camera displacement — the pop-response probe.
    `pop` shifts every sample from index `pop_at` on (a relocalization step)."""
    locs = []
    for i, (t_ns, q, p) in enumerate(samples):
        if pop_at is not None and i >= pop_at and p is not None:
            p = (p[0] + pop[0], p[1] + pop[1], p[2] + pop[2])
        seq = phone.pose(base_ts_ns + t_ns, q, pos=p)
        wait_for(lambda: state.last_seq == seq, pump=apply_mod.apply_tick)
        locs.append(scene.camera.location.copy())
    return max((a - b).length for a, b in zip(locs[1:], locs))


def main() -> int:
    mod = load_addon()
    from pocketrig.bl import apply as apply_mod
    from pocketrig.bl import state
    from pocketrig.core.session import Server

    scene = bpy.context.scene
    scene.render.fps = FPS
    scene.render.fps_base = 1.0
    scene.frame_current = 1
    scene.pocketrig_live_smoothing = 0.0
    scene.pocketrig_record_smoothing = 0.0
    scene.pocketrig_move_scale = 1.0

    server = Server(
        port=0,
        get_scene_fps=lambda: state.scene_fps_cache,
        host_version=bpy.app.version_string,
    )
    server.start()
    state.server = server
    phone = FakePhone(server.port)
    try:
        phone.handshake(server.token)
        trace = synth.arc_walk(RADIUS, DURATION)

        m = {}
        p_max, p_rms, r_max, frames = record_run(
            server, phone, apply_mod, state, scene, trace, base_ts_ns=1_000_000_000
        )
        m["bake_pos_max_m"] = p_max
        m["bake_pos_rms_m"] = p_rms
        m["bake_rot_max_deg"] = r_max
        m["bake_frames"] = frames

        lossy = net.impair(trace, seed=42, loss=0.05)
        p_max, p_rms, r_max, frames = record_run(
            server, phone, apply_mod, state, scene, lossy, base_ts_ns=100_000_000_000
        )
        m["bake_pos_max_m_5pct_loss"] = p_max
        m["bake_pos_rms_m_5pct_loss"] = p_rms
        m["bake_rot_max_deg_5pct_loss"] = r_max

        # Live pop response, with the live filters at the default 0.30:
        # a 25 cm relocalization step (25 m/s at 10 ms cadence) must be eaten
        # by the teleport guard; a 4 cm step slips under the guard and must be
        # softened by the position filter instead of arriving as one pop.
        scene.pocketrig_live_smoothing = 0.30
        m["live_pop_max_step_m"] = live_run(
            state, apply_mod, scene, phone, trace, base_ts_ns=200_000_000_000,
            pop_at=len(trace) // 2, pop=(0.25, 0.0, 0.0),
        )
        m["live_softpop_max_step_m"] = live_run(
            state, apply_mod, scene, phone, trace, base_ts_ns=300_000_000_000,
            pop_at=len(trace) // 2, pop=(0.04, 0.0, 0.0),
        )
        scene.pocketrig_live_smoothing = 0.0

        print("LAB_METRICS " + json.dumps(m))
    finally:
        phone.bye()
        phone.close()
        server.stop()
        state.server = None
        try:
            mod.unregister()
        except Exception:
            traceback.print_exc()
    print("HEADLESS_LAB_DONE")
    return 0


if __name__ == "__main__":
    try:
        code = main()
    except Exception:
        traceback.print_exc()
        code = 2
    sys.exit(code)
