# SPDX-License-Identifier: GPL-3.0-or-later
"""Deterministic multi-clock 6DOF presentation simulator.

This module deliberately separates four things which the real product does at
different rates: physical motion, ARCore observation, phone transmission, and
Blender presentation.  A Scenario is generated once and can then be replayed
through any Presenter candidate, guaranteeing byte-for-byte equivalent input.

The simulator is not an ARCore replacement.  Its job is to expose timing,
filtering, continuity, and recovery mistakes using known ground truth before a
candidate reaches subjective phone testing.
"""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from typing import Callable, Iterable, List, Optional, Sequence, Tuple

from synth import Quat, UPRIGHT, Vec3, _lcg, q_axis, qmul, qnorm

NS = 1_000_000_000
PoseFn = Callable[[float], "Pose"]


@dataclass(frozen=True)
class Pose:
    q: Quat
    p: Vec3


@dataclass(frozen=True)
class CadenceSegment:
    start_s: float
    end_s: float
    rate_hz: float


@dataclass(frozen=True)
class SourceFrame:
    index: int
    source_ns: int
    truth: Pose
    observed_q: Quat
    observed_p: Optional[Vec3]


@dataclass(frozen=True)
class Packet:
    seq: int
    send_ns: int
    arrival_ns: int
    frame: SourceFrame


@dataclass(frozen=True)
class PresentedFrame:
    presentation_ns: int
    source_ns: int
    output: Pose
    truth: Pose


@dataclass(frozen=True)
class Impairment:
    delay_ms: float = 12.0
    jitter_ms: float = 4.0
    loss: float = 0.0
    reorder_every: int = 0
    burst_loss: Tuple[Tuple[float, float], ...] = ()


@dataclass(frozen=True)
class ObservationFaults:
    colored_pos_sigma_m: float = 0.0
    colored_rot_sigma_deg: float = 0.0
    colored_rho: float = 0.92
    pos_bias_mps: Vec3 = (0.0, 0.0, 0.0)
    rot_bias_dps: Vec3 = (0.0, 0.0, 0.0)
    position_dropouts: Tuple[Tuple[float, float], ...] = ()
    origin_changes: Tuple[Tuple[float, Vec3, Quat], ...] = ()


@dataclass(frozen=True)
class Scenario:
    name: str
    duration_ns: int
    truth_at: PoseFn
    source: Tuple[SourceFrame, ...]
    packets: Tuple[Packet, ...]
    presentation_ns: Tuple[int, ...]
    fingerprint: str


def qinv(q: Quat) -> Quat:
    return (q[0], -q[1], -q[2], -q[3])


def qdot(a: Quat, b: Quat) -> float:
    return sum(x * y for x, y in zip(a, b))


def qangle_deg(a: Quat, b: Quat) -> float:
    return math.degrees(2.0 * math.acos(min(1.0, abs(qdot(a, b)))))


def qrotate(q: Quat, p: Vec3) -> Vec3:
    pure = (0.0, p[0], p[1], p[2])
    out = qmul(qmul(q, pure), qinv(q))
    return (out[1], out[2], out[3])


def vadd(a: Vec3, b: Vec3) -> Vec3:
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def vsub(a: Vec3, b: Vec3) -> Vec3:
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def vscale(a: Vec3, scale: float) -> Vec3:
    return (a[0] * scale, a[1] * scale, a[2] * scale)


def vlength(a: Vec3) -> float:
    return math.sqrt(sum(x * x for x in a))


def _uniform(rng) -> float:
    return next(rng) * 2.0 - 1.0


def _in_ranges(t_s: float, ranges: Iterable[Tuple[float, float]]) -> bool:
    return any(start <= t_s < end for start, end in ranges)


def _source_times(
    segments: Sequence[CadenceSegment], jitter_ms: float, seed: int
) -> List[int]:
    rng = _lcg(seed)
    result: List[int] = []
    for segment in segments:
        if segment.rate_hz <= 0.0 or segment.end_s <= segment.start_s:
            raise ValueError(f"invalid cadence segment {segment!r}")
        period_s = 1.0 / segment.rate_hz
        count = int(math.ceil((segment.end_s - segment.start_s) * segment.rate_hz))
        for i in range(count):
            nominal = segment.start_s + i * period_s
            if nominal >= segment.end_s:
                break
            jitter_s = _uniform(rng) * jitter_ms / 1000.0 if i else 0.0
            candidate = int(round((nominal + jitter_s) * NS))
            if result:
                candidate = max(candidate, result[-1] + 1)
            result.append(candidate)
    return result


def _observe(
    truth: Pose,
    t_s: float,
    faults: ObservationFaults,
    pos_noise: List[float],
    rot_noise: List[float],
    rng,
) -> Tuple[Quat, Optional[Vec3]]:
    rho = max(0.0, min(0.9999, faults.colored_rho))
    innovation = math.sqrt(1.0 - rho * rho)
    for axis in range(3):
        pos_noise[axis] = (
            rho * pos_noise[axis]
            + innovation * _uniform(rng) * faults.colored_pos_sigma_m
        )
        rot_noise[axis] = (
            rho * rot_noise[axis]
            + innovation * _uniform(rng) * faults.colored_rot_sigma_deg
        )

    p = tuple(
        truth.p[i] + pos_noise[i] + faults.pos_bias_mps[i] * t_s
        for i in range(3)
    )
    q = truth.q
    for axis, basis in enumerate(((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0))):
        angle = rot_noise[axis] + faults.rot_bias_dps[axis] * t_s
        q = qmul(q, q_axis(basis, angle))

    for at_s, shift_p, shift_q in faults.origin_changes:
        if t_s >= at_s:
            q = qmul(shift_q, q)
            p = vadd(qrotate(shift_q, p), shift_p)

    observed_p = None if _in_ranges(t_s, faults.position_dropouts) else p
    return qnorm(q), observed_p


def _fingerprint(
    name: str,
    source: Sequence[SourceFrame],
    packets: Sequence[Packet],
    presentation_ns: Sequence[int],
) -> str:
    payload = {
        "name": name,
        "source": [
            [f.index, f.source_ns, f.observed_q, f.observed_p] for f in source
        ],
        "packets": [
            [p.seq, p.send_ns, p.arrival_ns, p.frame.index] for p in packets
        ],
        "presentation_ns": list(presentation_ns),
    }
    encoded = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()
    return hashlib.sha256(encoded).hexdigest()


def build_scenario(
    name: str,
    duration_s: float,
    truth_at: PoseFn,
    *,
    cadence: Sequence[CadenceSegment],
    source_jitter_ms: float = 0.8,
    send_hz: float = 100.0,
    presentation_hz: float = 120.0,
    tail_s: float = 0.5,
    impairment: Impairment = Impairment(),
    faults: ObservationFaults = ObservationFaults(),
    seed: int = 1,
) -> Scenario:
    """Generate immutable input once; all candidates replay this same object."""
    if duration_s <= 0 or send_hz <= 0 or presentation_hz <= 0:
        raise ValueError("duration and clock rates must be positive")
    source_times = _source_times(cadence, source_jitter_ms, seed)
    noise_rng = _lcg(seed ^ 0x243F6A88)
    pos_noise = [0.0, 0.0, 0.0]
    rot_noise = [0.0, 0.0, 0.0]
    source: List[SourceFrame] = []
    for index, t_ns in enumerate(source_times):
        t_s = t_ns / NS
        truth = truth_at(t_s)
        q, p = _observe(truth, t_s, faults, pos_noise, rot_noise, noise_rng)
        source.append(SourceFrame(index, t_ns, truth, q, p))
    if not source:
        raise ValueError("scenario produced no source frames")

    network_rng = _lcg(seed ^ 0x13198A2E)
    period_ns = int(round(NS / send_hz))
    send_end_ns = int(round(duration_s * NS))
    packets: List[Packet] = []
    source_index = 0
    seq = 0
    for send_ns in range(0, send_end_ns + 1, period_ns):
        while (
            source_index + 1 < len(source)
            and source[source_index + 1].source_ns <= send_ns
        ):
            source_index += 1
        frame = source[source_index]
        seq += 1
        send_s = send_ns / NS
        if _in_ranges(send_s, impairment.burst_loss):
            continue
        if impairment.loss and next(network_rng) < impairment.loss:
            continue
        jitter_ms = _uniform(network_rng) * impairment.jitter_ms
        delay_ms = max(0.0, impairment.delay_ms + jitter_ms)
        if impairment.reorder_every and seq % impairment.reorder_every == 0:
            delay_ms += max(20.0, impairment.jitter_ms * 4.0)
        arrival_ns = send_ns + int(round(delay_ms * 1_000_000))
        packets.append(Packet(seq, send_ns, arrival_ns, frame))

    present_end_ns = int(round((duration_s + tail_s) * NS))
    present_period_ns = int(round(NS / presentation_hz))
    presentation = tuple(range(0, present_end_ns + 1, present_period_ns))
    packet_tuple = tuple(packets)
    source_tuple = tuple(source)
    return Scenario(
        name=name,
        duration_ns=int(round(duration_s * NS)),
        truth_at=truth_at,
        source=source_tuple,
        packets=packet_tuple,
        presentation_ns=presentation,
        fingerprint=_fingerprint(name, source_tuple, packet_tuple, presentation),
    )


def stationary_truth(_t_s: float) -> Pose:
    return Pose(UPRIGHT, (0.0, 0.0, 0.0))


def sine_yaw_truth(freq_hz: float, amplitude_deg: float) -> PoseFn:
    def evaluate(t_s: float) -> Pose:
        yaw = amplitude_deg * math.sin(2.0 * math.pi * freq_hz * t_s)
        return Pose(qnorm(qmul(q_axis((0.0, 0.0, 1.0), yaw), UPRIGHT)), (0.0, 0.0, 0.0))

    return evaluate


def step_truth(
    step_at_s: float = 1.0,
    distance_m: float = 0.25,
    ramp_s: float = 0.5,
) -> PoseFn:
    """A finite-speed move followed by a hard stop.

    An instantaneous positional step is indistinguishable from a tracker
    teleport and should be rejected by the host guard.  This 0.5 m/s ramp is a
    physically plausible response/settling probe instead.
    """
    def evaluate(t_s: float) -> Pose:
        progress = min(1.0, max(0.0, (t_s - step_at_s) / ramp_s))
        return Pose(UPRIGHT, (distance_m * progress, 0.0, 0.0))

    return evaluate


def mixed_loop_truth(motion_end_s: float = 8.0) -> PoseFn:
    """Smooth, closed, mixed-axis SE(3) loop followed by a stationary tail."""
    def evaluate(t_s: float) -> Pose:
        u = min(max(t_s, 0.0), motion_end_s) / motion_end_s
        a = 2.0 * math.pi * u
        envelope = math.sin(math.pi * u) ** 2
        p = (
            0.35 * math.sin(a),
            0.20 * math.sin(2.0 * a),
            0.12 * (math.cos(a) - 1.0),
        )
        # World/local ordering is intentionally noncommuting.
        q = qmul(q_axis((0.0, 0.0, 1.0), 55.0 * math.sin(a)), UPRIGHT)
        q = qmul(q, q_axis((0.0, 1.0, 0.0), 28.0 * envelope * math.sin(2.0 * a)))
        q = qmul(q, q_axis((1.0, 0.0, 0.0), 18.0 * envelope * math.sin(3.0 * a)))
        return Pose(qnorm(q), p)

    return evaluate


def reversal_truth(
    start_s: float = 1.0,
    half_leg_s: float = 0.5,
    distance_m: float = 0.25,
) -> PoseFn:
    """Move out, reverse immediately, and return with finite physical speed."""
    def evaluate(t_s: float) -> Pose:
        if t_s <= start_s:
            x = 0.0
        elif t_s < start_s + half_leg_s:
            x = distance_m * (t_s - start_s) / half_leg_s
        elif t_s < start_s + 2.0 * half_leg_s:
            x = distance_m * (1.0 - (t_s - start_s - half_leg_s) / half_leg_s)
        else:
            x = 0.0
        return Pose(UPRIGHT, (x, 0.0, 0.0))

    return evaluate


def linear_truth(speed_mps: float = 0.25) -> PoseFn:
    def evaluate(t_s: float) -> Pose:
        return Pose(UPRIGHT, (speed_mps * t_s, 0.0, 0.0))

    return evaluate


def default_scenarios() -> Tuple[Scenario, ...]:
    """Frozen-seed scenario matrix for the Q0.2 quality report."""
    normal_net = Impairment(delay_ms=14.0, jitter_ms=6.0, loss=0.01, reorder_every=37)
    return (
        build_scenario(
            "stationary_colored",
            10.0,
            stationary_truth,
            cadence=(CadenceSegment(0.0, 10.0, 30.0),),
            impairment=normal_net,
            faults=ObservationFaults(
                colored_pos_sigma_m=0.0025,
                colored_rot_sigma_deg=0.18,
                pos_bias_mps=(0.00015, -0.00008, 0.00005),
                rot_bias_dps=(0.015, 0.0, -0.01),
            ),
            seed=1101,
        ),
        *tuple(
            build_scenario(
                f"sine_yaw_{freq:g}hz",
                8.0,
                sine_yaw_truth(freq, 18.0),
                cadence=(CadenceSegment(0.0, 8.0, 30.0),),
                impairment=normal_net,
                seed=1200 + int(freq * 100),
            )
            for freq in (0.25, 0.5, 1.0, 2.0, 3.0, 5.0)
        ),
        build_scenario(
            "step_translation",
            4.0,
            step_truth(),
            cadence=(CadenceSegment(0.0, 4.0, 30.0),),
            impairment=normal_net,
            seed=1301,
        ),
        build_scenario(
            "reversal_translation",
            4.0,
            reversal_truth(),
            cadence=(CadenceSegment(0.0, 4.0, 30.0),),
            impairment=normal_net,
            seed=1351,
        ),
        build_scenario(
            "mixed_loop",
            8.5,
            mixed_loop_truth(),
            cadence=(CadenceSegment(0.0, 8.5, 30.0),),
            impairment=normal_net,
            seed=1401,
        ),
        build_scenario(
            "degraded_relocalization",
            12.0,
            linear_truth(),
            cadence=(
                CadenceSegment(0.0, 4.0, 60.0),
                CadenceSegment(4.0, 8.0, 30.0),
                CadenceSegment(8.0, 12.0, 15.0),
            ),
            impairment=Impairment(
                delay_ms=18.0,
                jitter_ms=11.0,
                loss=0.03,
                reorder_every=23,
                burst_loss=((6.4, 6.75),),
            ),
            faults=ObservationFaults(
                colored_pos_sigma_m=0.001,
                colored_rot_sigma_deg=0.08,
                position_dropouts=((4.8, 5.35),),
                origin_changes=((8.0, (0.45, -0.20, 0.12), q_axis((0.0, 0.0, 1.0), 50.0)),),
            ),
            seed=1501,
        ),
    )
