#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Motion Lab runner: computes the objective feel metrics and gates them
against committed baselines.

    python tools/motion_lab/run_lab.py                  # check tier-1
    python tools/motion_lab/run_lab.py --update-baselines
    python tools/motion_lab/run_lab.py --report         # + write results doc

Tier-1 is deterministic pure-Python (filter lag, jitter attenuation,
stepping) — also wired into desktop pytest so the normal test run gates it.
Tier-2 (bake fidelity through a real headless Blender) runs via
tools/motion-lab.ps1. Exit code 0 = every gated metric within its band.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, List

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE))

import metrics  # noqa: E402
import synth  # noqa: E402

BASELINES = _HERE / "baselines" / "tier1.json"
BASELINES2 = _HERE / "baselines" / "tier2.json"
RESULTS_DOC = _HERE / "motion-lab-results.md"
DEFAULT_BLENDER = r"C:\Program Files\Blender Foundation\Blender 5.1\blender.exe"

SPEEDS_DPS = (15.0, 45.0, 90.0, 180.0)
SMOOTHINGS = (0.15, 0.30, 0.60)


def tier1_metrics() -> Dict[str, float]:
    """Every gated tier-1 number, deterministically."""
    out: Dict[str, float] = {}

    for s in SMOOTHINGS:
        for speed in SPEEDS_DPS:
            pan = synth.constant_pan(speed, duration_s=3.0)
            out[f"lag_ms/s{s:.2f}/{speed:g}dps"] = metrics.steady_state_lag_ms(pan, s, speed)
        noisy = synth.noisy_hold(sigma_deg=0.3, duration_s=4.0, seed=1234)
        out[f"attenuation_db/s{s:.2f}"] = metrics.jitter_attenuation_db(noisy, s)
        out[f"pos_lag_ms/s{s:.2f}"] = metrics.pos_lag_ms(1.0, s)
        out[f"pos_attenuation_db/s{s:.2f}"] = metrics.pos_attenuation_db(s)

    # Stepping: a 90 deg/s peak sine seen through the latest-wins ticker at
    # full rate vs thinned to ARCore's ~30 Hz cadence, raw and filtered.
    # These four numbers decide whether host-side interpolation gets built.
    sine = synth.sine_yaw(peak_dps=90.0, freq_hz=0.5, duration_s=4.0)
    full = metrics.repeat_to_ticker(sine)
    thin = metrics.repeat_to_ticker(synth.at_cadence(sine, 30.0))
    out["stepping_deg/100hz/raw"] = metrics.stepping_deg(full)
    out["stepping_deg/30hz/raw"] = metrics.stepping_deg(thin)
    out["stepping_deg/30hz/filtered0.30"] = metrics.stepping_deg(thin, smoothing=0.30)
    out["stepping_deg/30hz/max_step"] = metrics.max_step_deg(thin)

    return out


def _default_tol(name: str, value: float) -> float:
    rel = abs(value) * 0.10
    floor = 0.5 if "attenuation" in name else (2.0 if "lag" in name else 0.02)
    return max(rel, floor)


def check_tier1() -> List[str]:
    """Returns human-readable failures ([] = all gated metrics in band)."""
    if not BASELINES.exists():
        return [f"missing baselines file {BASELINES} — run --update-baselines"]
    baselines = json.loads(BASELINES.read_text(encoding="utf-8"))
    measured = tier1_metrics()
    failures: List[str] = []
    for name, spec in baselines.items():
        got = measured.get(name)
        if got is None:
            failures.append(f"{name}: baseline exists but metric not measured")
            continue
        if abs(got - spec["value"]) > spec["tol"]:
            failures.append(
                f"{name}: {got:.4f} outside {spec['value']:.4f} ± {spec['tol']:.4f}"
            )
    for name in measured:
        if name not in baselines:
            failures.append(f"{name}: measured but has no baseline — run --update-baselines")
    return failures


def tier2_metrics(blender_exe: str) -> Dict[str, float]:
    """Runs headless_lab.py inside Blender and parses its LAB_METRICS line."""
    import subprocess

    proc = subprocess.run(
        [
            blender_exe, "--background", "--factory-startup",
            "--python", str(_HERE / "headless_lab.py"),
        ],
        capture_output=True,
        text=True,
        timeout=300,
    )
    for line in proc.stdout.splitlines():
        if line.startswith("LAB_METRICS "):
            return {k: float(v) for k, v in json.loads(line[len("LAB_METRICS "):]).items()}
    raise RuntimeError(
        f"headless_lab produced no LAB_METRICS (exit {proc.returncode}):\n"
        + proc.stdout[-2000:] + proc.stderr[-2000:]
    )


def _tier2_tol(name: str, value: float) -> float:
    if "frames" in name:
        return 0.5  # frame counts are exact — any drift is a real bug
    # Bake fidelity floors: 1 mm positional, 0.05 deg rotational.
    floor = 0.05 if "rot" in name else 0.001
    return max(abs(value) * 0.25, floor)


def check_against(baselines_path: Path, measured: Dict[str, float]) -> List[str]:
    if not baselines_path.exists():
        return [f"missing baselines file {baselines_path} — run --update-baselines"]
    baselines = json.loads(baselines_path.read_text(encoding="utf-8"))
    failures: List[str] = []
    for name, spec in baselines.items():
        got = measured.get(name)
        if got is None:
            failures.append(f"{name}: baseline exists but metric not measured")
        elif abs(got - spec["value"]) > spec["tol"]:
            failures.append(
                f"{name}: {got:.4f} outside {spec['value']:.4f} ± {spec['tol']:.4f}"
            )
    for name in measured:
        if name not in baselines:
            failures.append(f"{name}: measured but has no baseline — run --update-baselines")
    return failures


def _write_baselines(path: Path, measured: Dict[str, float], tol_fn) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = {
        name: {"value": round(v, 6), "tol": round(tol_fn(name, v), 6)}
        for name, v in sorted(measured.items())
    }
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(f"baselines written: {path} ({len(data)} metrics)")


def update_baselines(full: bool, blender_exe: str) -> None:
    _write_baselines(BASELINES, tier1_metrics(), _default_tol)
    if full:
        _write_baselines(BASELINES2, tier2_metrics(blender_exe), _tier2_tol)


def write_report(measured: Dict[str, float]) -> None:
    lines = [
        "License: CC-BY-NC-4.0",
        "",
        "# Motion Lab results",
        "",
        "Objective feel metrics, generated by `tools/motion_lab/run_lab.py --report`.",
        "**These numbers are proxies**: they prevent regressions and settle",
        "\"did that change make it worse?\" with data; final feel judgment stays human.",
        "",
        "## Filter lag (ms behind a constant pan)",
        "",
        "| smoothing | " + " | ".join(f"{v:g} °/s" for v in SPEEDS_DPS) + " |",
        "|---|" + "---|" * len(SPEEDS_DPS),
    ]
    for s in SMOOTHINGS:
        row = [f"| {s:.2f}"]
        for speed in SPEEDS_DPS:
            row.append(f" {measured[f'lag_ms/s{s:.2f}/{speed:g}dps']:.1f}")
        lines.append(" |".join(row) + " |")
    lines += [
        "",
        "## Jitter attenuation (dB, stationary hold with ±0.3° noise; more negative = calmer)",
        "",
        "| smoothing | attenuation |",
        "|---|---|",
    ]
    for s in SMOOTHINGS:
        lines.append(f"| {s:.2f} | {measured[f'attenuation_db/s{s:.2f}']:.1f} dB |")
    lines += [
        "",
        "## Position filter (1 m/s line lag; ±5 mm noise attenuation at 30 Hz)",
        "",
        "| smoothing | lag | attenuation |",
        "|---|---|---|",
    ]
    for s in SMOOTHINGS:
        lines.append(
            f"| {s:.2f} | {measured[f'pos_lag_ms/s{s:.2f}']:.1f} ms "
            f"| {measured[f'pos_attenuation_db/s{s:.2f}']:.1f} dB |"
        )
    lines += [
        "",
        "## Stepping (RMS per-tick rotation on the 100 Hz apply ticker, 90 °/s sine)",
        "",
        "| stream | RMS step | note |",
        "|---|---|---|",
        f"| 100 Hz source, raw | {measured['stepping_deg/100hz/raw']:.3f}° | the sensor path |",
        f"| 30 Hz source, raw | {measured['stepping_deg/30hz/raw']:.3f}° | ARCore cadence, unfiltered |",
        f"| 30 Hz source, live filter 0.30 | {measured['stepping_deg/30hz/filtered0.30']:.3f}° | what users actually see |",
        f"| 30 Hz source, max single step | {measured['stepping_deg/30hz/max_step']:.3f}° | worst tick |",
        "",
        "Interpretation: if the filtered 30 Hz stepping sits near the 100 Hz raw line,",
        "host-side slerp interpolation for ARCore is NOT worth building; if it is",
        "several times larger, it is. Decided by these numbers, not by feel.",
        "",
    ]
    RESULTS_DOC.write_text("\n".join(lines), encoding="utf-8", newline="\n")
    print(f"report written: {RESULTS_DOC}")


def main() -> int:
    parser = argparse.ArgumentParser(prog="run_lab")
    parser.add_argument("--update-baselines", action="store_true")
    parser.add_argument("--report", action="store_true")
    parser.add_argument("--full", action="store_true", help="also run tier-2 (headless Blender)")
    parser.add_argument("--blender", default=DEFAULT_BLENDER)
    args = parser.parse_args()

    if args.update_baselines:
        update_baselines(args.full, args.blender)
        return 0

    measured = tier1_metrics()
    for name in sorted(measured):
        print(f"  {name:44s} {measured[name]:10.4f}")
    failures = check_tier1()
    if args.full:
        measured2 = tier2_metrics(args.blender)
        for name in sorted(measured2):
            print(f"  {name:44s} {measured2[name]:10.4f}")
        failures += check_against(BASELINES2, measured2)
    if args.report:
        write_report(measured)
    if failures:
        print("\nOUT OF BAND:")
        for f in failures:
            print(" ", f)
        return 1
    print("\nALL METRICS WITHIN BASELINES")
    return 0


if __name__ == "__main__":
    sys.exit(main())
