# SPDX-License-Identifier: GPL-3.0-or-later
"""Deterministic network impairment for replays — seeded, so an impaired run
is exactly reproducible (no netem on Windows; impairment happens in-sender).

Applies to unreliable POSE traffic only; control messages ride the resend
layer and are not the Lab's subject.
"""

from __future__ import annotations

from typing import List, Optional, Tuple


def _lcg(seed: int):
    x = seed & 0x7FFFFFFF
    while True:
        x = (1103515245 * x + 12345) & 0x7FFFFFFF
        yield x / 0x7FFFFFFF


def impair(
    samples: List[Tuple],
    seed: int = 42,
    loss: float = 0.0,
    reorder: float = 0.0,
    burst_gap: Optional[Tuple[int, int]] = None,
) -> List[Tuple]:
    """Returns the send schedule after impairment:
    - loss: fraction of samples silently dropped
    - reorder: fraction swapped with their successor (late datagram)
    - burst_gap: (start_index, count) — a contiguous outage window
    """
    rng = _lcg(seed)
    out = list(samples)
    if burst_gap is not None:
        start, count = burst_gap
        del out[start : start + count]
    kept = [s for s in out if loss <= 0.0 or next(rng) >= loss]
    if reorder > 0.0:
        i = 0
        while i < len(kept) - 1:
            if next(rng) < reorder:
                kept[i], kept[i + 1] = kept[i + 1], kept[i]
                i += 2
            else:
                i += 1
    return kept
