# SPDX-License-Identifier: GPL-3.0-or-later
"""Take format v0 — the Motion Lab's trace file, deliberately doubling as the
draft of M2's offline-take format (same (t, q, p) model as the POSE stream).

JSONL: first line is the header object, every further line one sample row.
JSONL over binary on purpose: diffable in git, crash-safe to append on the
phone, trivially parseable everywhere. gzip can come later if size ever
matters.

    {"format": "pocketrig-take", "version": 0, "source": "synth", ...}
    {"t": 0, "q": [1.0, 0.0, 0.0, 0.0], "p": [0.0, 0.0, 0.0]}
    {"t": 10000000, "q": [...]}                      # rotation-only row

Version 0 is PRIVATE to the lab until M2 hardens it into a public contract.
"""

from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

Quat = Tuple[float, float, float, float]
Vec3 = Tuple[float, float, float]
Sample = Tuple[int, Quat, Optional[Vec3]]  # (t_ns, quat, pos-or-None)

FORMAT_NAME = "pocketrig-take"
VERSION = 0
TRACE_FORMAT_NAME = "pocketrig-motion-trace"
TRACE_VERSION = 1


def make_header(source: str, rate_hz: float, device: str = "synthetic") -> dict:
    return {
        "format": FORMAT_NAME,
        "version": VERSION,
        "source": source,  # "synth" | "sensor" | "arcore"
        "device": device,
        "rate_hz": rate_hz,
    }


def write_trace(path: Path, header: dict, samples: List[Sample]) -> None:
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(header, separators=(",", ":")) + "\n")
        for t_ns, q, p in samples:
            row: dict = {"t": t_ns, "q": [round(c, 9) for c in q]}
            if p is not None:
                row["p"] = [round(c, 6) for c in p]
            f.write(json.dumps(row, separators=(",", ":")) + "\n")


def read_trace(path: Path) -> Tuple[dict, List[Sample]]:
    header, events = read_events(path)
    samples: List[Sample] = []
    if header.get("format") == FORMAT_NAME:
        rows = events
    else:
        rows = [row for row in events if row.get("kind") == "pose"]
    for row in rows:
        p = row.get("p")
        t = row.get("t", row.get("source_ns"))
        if t is None:
            raise ValueError(f"{path}: pose row has no source timestamp")
        q = _finite_vector(path, row.get("q"), 4, "q")
        pos = _finite_vector(path, p, 3, "p") if p is not None else None
        samples.append((int(t), q, pos))
    return header, samples


def read_events(path: Path) -> Tuple[dict, List[Dict[str, Any]]]:
    """Read either a legacy take-v0 trace or a motion-trace-v1 artifact.

    Trajectory-only callers use :func:`read_trace`; diagnostics use this
    function to retain configuration, tracking, and raw ARCore frame events.
    Unknown v1 event kinds are intentionally preserved for forward-compatible
    reports.
    """
    with open(path, "r", encoding="utf-8") as f:
        lines = [ln for ln in (line.strip() for line in f) if ln]
    if not lines:
        raise ValueError(f"{path}: empty trace")
    header = json.loads(lines[0])
    fmt = header.get("format")
    version = header.get("version")
    if fmt == FORMAT_NAME:
        if version != VERSION:
            raise ValueError(f"{path}: unsupported take version {version}")
    elif fmt == TRACE_FORMAT_NAME:
        if version != TRACE_VERSION:
            raise ValueError(f"{path}: unsupported motion trace version {version}")
    else:
        raise ValueError(f"{path}: unsupported trace format {fmt!r}")
    events = []
    for line_number, line in enumerate(lines[1:], start=2):
        value = json.loads(line)
        if not isinstance(value, dict):
            raise ValueError(f"{path}:{line_number}: event is not an object")
        events.append(value)
    return header, events


def _finite_vector(path: Path, value: Any, size: int, field: str):
    if not isinstance(value, (list, tuple)) or len(value) != size:
        raise ValueError(f"{path}: {field} must contain {size} numbers")
    result = tuple(float(component) for component in value)
    if not all(math.isfinite(component) for component in result):
        raise ValueError(f"{path}: {field} contains a non-finite number")
    return result
