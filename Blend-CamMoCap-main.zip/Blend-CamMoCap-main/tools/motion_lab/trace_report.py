# SPDX-License-Identifier: GPL-3.0-or-later
"""Summarize a phone motion trace without Blender or third-party packages."""

from __future__ import annotations

import argparse
import bisect
import json
import math
import statistics
from collections import Counter
from pathlib import Path
from typing import Any, Dict, Iterable, List

from traces import read_events, read_trace


def _percentile(values: List[float], fraction: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    index = (len(ordered) - 1) * fraction
    lower = math.floor(index)
    upper = math.ceil(index)
    if lower == upper:
        return ordered[lower]
    weight = index - lower
    return ordered[lower] * (1.0 - weight) + ordered[upper] * weight


def _interval_summary(timestamps_ns: Iterable[int]) -> Dict[str, Any]:
    values = list(timestamps_ns)
    deltas = [b - a for a, b in zip(values, values[1:])]
    positive_ms = [delta / 1e6 for delta in deltas if delta > 0]
    duration_ns = values[-1] - values[0] if len(values) >= 2 else 0
    unique_values = sorted(set(values))
    unique_duration_ns = unique_values[-1] - unique_values[0] if len(unique_values) >= 2 else 0
    return {
        "count": len(values),
        "unique_timestamps": len(unique_values),
        "duration_s": duration_ns / 1e9,
        "rate_hz": ((len(values) - 1) / (duration_ns / 1e9)) if duration_ns > 0 else None,
        "unique_rate_hz": (
            (len(unique_values) - 1) / (unique_duration_ns / 1e9)
            if unique_duration_ns > 0 else None
        ),
        "median_interval_ms": statistics.median(positive_ms) if positive_ms else None,
        "p95_interval_ms": _percentile(positive_ms, 0.95),
        "max_interval_ms": max(positive_ms) if positive_ms else None,
        "duplicate_timestamps": sum(delta == 0 for delta in deltas),
        "nonmonotonic_timestamps": sum(delta < 0 for delta in deltas),
    }


def _duration_by(frame_rows: List[Dict[str, Any]], field: str) -> Dict[str, float]:
    totals: Counter[str] = Counter()
    previous = None
    for row in frame_rows:
        frame_ns = int(row.get("frame_ns", 0))
        if frame_ns <= 0:
            continue
        if previous is not None:
            previous_ns, previous_value = previous
            delta = frame_ns - previous_ns
            if delta > 0:
                totals[previous_value] += delta / 1e9
        previous = (frame_ns, str(row.get(field, "UNKNOWN")))
    return dict(sorted(totals.items()))


def _numeric_vector(row: Dict[str, Any], field: str, size: int) -> tuple[float, ...] | None:
    value = row.get(field)
    if not isinstance(value, list) or len(value) != size:
        return None
    try:
        result = tuple(float(component) for component in value)
    except (TypeError, ValueError):
        return None
    return result if all(math.isfinite(component) for component in result) else None


def _distance(a: tuple[float, ...], b: tuple[float, ...]) -> float:
    return math.sqrt(sum((left - right) ** 2 for left, right in zip(a, b)))


def _quat_delta_degrees(a: tuple[float, ...], b: tuple[float, ...]) -> float:
    norm_a = math.sqrt(sum(value * value for value in a))
    norm_b = math.sqrt(sum(value * value for value in b))
    if norm_a <= 1e-12 or norm_b <= 1e-12:
        return math.nan
    dot = abs(sum(left * right for left, right in zip(a, b)) / (norm_a * norm_b))
    return math.degrees(2.0 * math.acos(min(1.0, max(-1.0, dot))))


def _distribution(values: List[float]) -> Dict[str, float | int | None]:
    finite = [value for value in values if math.isfinite(value)]
    return {
        "count": len(finite),
        "min": min(finite) if finite else None,
        "p05": _percentile(finite, 0.05),
        "median": statistics.median(finite) if finite else None,
        "p95": _percentile(finite, 0.95),
        "max": max(finite) if finite else None,
    }


_AF_STATE_NAMES = {
    0: "INACTIVE",
    1: "PASSIVE_SCAN",
    2: "PASSIVE_FOCUSED",
    3: "ACTIVE_SCAN",
    4: "FOCUSED_LOCKED",
    5: "NOT_FOCUSED_LOCKED",
    6: "PASSIVE_UNFOCUSED",
}

_AE_STATE_NAMES = {
    0: "INACTIVE",
    1: "SEARCHING",
    2: "CONVERGED",
    3: "LOCKED",
    4: "FLASH_REQUIRED",
    5: "PRECAPTURE",
}

_IMU_ACTIVITY_WINDOW_NS = 200_000_000


def _camera_state_summary(
    frame_rows: List[Dict[str, Any]], field: str, names: Dict[int, str],
) -> Dict[str, Any]:
    values = [int(row[field]) for row in frame_rows if field in row]
    named = Counter(names.get(value, f"UNKNOWN_{value}") for value in values)
    return {
        "count": len(values),
        "coverage": len(values) / len(frame_rows) if frame_rows else None,
        "states": dict(sorted(named.items())),
        "transitions": sum(left != right for left, right in zip(values, values[1:])),
    }


def _camera_metadata_summary(frame_rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    metadata_fields = {
        "af_state", "ae_state", "focus_distance_diopters",
        "exposure_time_ns", "sensitivity_iso",
    }
    available = [row for row in frame_rows if metadata_fields.intersection(row)]

    def finite(field: str, scale: float = 1.0) -> List[float]:
        result = []
        for row in frame_rows:
            try:
                value = float(row[field]) * scale
            except (KeyError, TypeError, ValueError):
                continue
            if math.isfinite(value):
                result.append(value)
        return result

    focus = finite("focus_distance_diopters")
    focus_steps = [abs(right - left) for left, right in zip(focus, focus[1:])]
    exposure_ms = finite("exposure_time_ns", 1e-6)
    sensitivity = finite("sensitivity_iso")
    return {
        "frames_with_any": len(available),
        "coverage": len(available) / len(frame_rows) if frame_rows else None,
        "autofocus": _camera_state_summary(frame_rows, "af_state", _AF_STATE_NAMES),
        "autoexposure": _camera_state_summary(frame_rows, "ae_state", _AE_STATE_NAMES),
        "focus_distance_diopters": _distribution(focus),
        "focus_step_diopters": _distribution(focus_steps),
        "focus_value_changes": sum(step > 1e-6 for step in focus_steps),
        "exposure_time_ms": _distribution(exposure_ms),
        "sensitivity_iso": _distribution(sensitivity),
        "motion_by_focus": _focus_motion_summary(frame_rows),
    }


def _imu_summary(imu_rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Summarize independent phone IMU evidence without inferring stationarity."""
    grouped: Dict[str, List[Dict[str, Any]]] = {}
    for row in imu_rows:
        grouped.setdefault(str(row.get("sensor", "unknown")), []).append(row)

    sensors: Dict[str, Any] = {}
    for sensor, rows in sorted(grouped.items()):
        valid = [
            (row, vector)
            for row in rows
            if (vector := _numeric_vector(row, "v", 3)) is not None
        ]
        source_times = [
            int(row["sensor_ns"])
            for row, _vector in valid
            if "sensor_ns" in row and int(row["sensor_ns"]) > 0
        ]
        observation_age_ms = [
            (int(row["observed_ns"]) - int(row["sensor_ns"])) / 1e6
            for row, _vector in valid
            if "observed_ns" in row
            and "sensor_ns" in row
            and int(row["sensor_ns"]) > 0
        ]
        magnitudes = [math.sqrt(sum(component * component for component in vector))
                      for _row, vector in valid]
        axes = {
            axis: _distribution([vector[index] for _row, vector in valid])
            for index, axis in enumerate(("x", "y", "z"))
        }
        summary: Dict[str, Any] = {
            **_interval_summary(source_times),
            "rows": len(rows),
            "valid_samples": len(valid),
            "malformed_samples": len(rows) - len(valid),
            "observation_age_ms": _distribution(observation_age_ms),
            "accuracy": dict(sorted(Counter(str(row.get("accuracy", "UNKNOWN")) for row in rows).items())),
            "axes": axes,
            "magnitude": _distribution(magnitudes),
        }
        if sensor == "gyroscope":
            summary["magnitude_rad_s"] = summary.pop("magnitude")
            summary["magnitude_deg_s"] = _distribution(
                [math.degrees(value) for value in magnitudes],
            )
        elif sensor == "accelerometer":
            summary["magnitude_m_s2"] = summary.pop("magnitude")
            summary["gravity_residual_m_s2"] = _distribution(
                [abs(value - 9.80665) for value in magnitudes],
            )
        sensors[sensor] = summary

    return {
        "rows": len(imu_rows),
        "sensors": sensors,
    }


def _pearson(left: List[float], right: List[float]) -> float | None:
    if len(left) != len(right) or len(left) < 2:
        return None
    left_mean = statistics.fmean(left)
    right_mean = statistics.fmean(right)
    numerator = sum(
        (a - left_mean) * (b - right_mean) for a, b in zip(left, right)
    )
    left_energy = sum((value - left_mean) ** 2 for value in left)
    right_energy = sum((value - right_mean) ** 2 for value in right)
    denominator = math.sqrt(left_energy * right_energy)
    return numerator / denominator if denominator > 1e-24 else None


def _arcore_imu_alignment_summary(
    frame_rows: List[Dict[str, Any]],
    imu_rows: List[Dict[str, Any]],
    marker_rows: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """Align independent IMU evidence to each tracked ARCore frame interval."""
    by_sensor: Dict[str, List[tuple[int, tuple[float, ...]]]] = {}
    for row in imu_rows:
        vector = _numeric_vector(row, "v", 3)
        try:
            sensor_ns = int(row["sensor_ns"])
        except (KeyError, TypeError, ValueError):
            continue
        if vector is None or sensor_ns <= 0:
            continue
        by_sensor.setdefault(str(row.get("sensor", "unknown")), []).append(
            (sensor_ns, vector),
        )
    for samples in by_sensor.values():
        samples.sort(key=lambda sample: sample[0])

    gyroscope = by_sensor.get("gyroscope", [])
    accelerometer = by_sensor.get("accelerometer", [])
    gyro_times = [sample[0] for sample in gyroscope]
    accel_times = [sample[0] for sample in accelerometer]
    intervals: List[Dict[str, Any]] = []
    previous: Dict[str, Any] | None = None

    for row in sorted(frame_rows, key=lambda value: int(value.get("frame_ns", 0))):
        if row.get("state") != "TRACKING":
            previous = None
            continue
        try:
            end_ns = int(row["frame_ns"])
        except (KeyError, TypeError, ValueError):
            previous = None
            continue
        if previous is None:
            previous = row
            continue
        start_ns = int(previous.get("frame_ns", 0))
        dt_s = (end_ns - start_ns) / 1e9
        if dt_s <= 0:
            previous = row
            continue

        gyro_start = bisect.bisect_right(gyro_times, start_ns)
        gyro_end = bisect.bisect_right(gyro_times, end_ns)
        gyro_values = [
            math.sqrt(sum(component * component for component in vector))
            for _timestamp, vector in gyroscope[gyro_start:gyro_end]
        ]
        gyro_deg_s = [math.degrees(value) for value in gyro_values]

        accel_start = bisect.bisect_right(accel_times, start_ns)
        accel_end = bisect.bisect_right(accel_times, end_ns)
        accel_values = accelerometer[accel_start:accel_end]
        accel_context_start = max(0, accel_start - 1)
        accel_context = accelerometer[accel_context_start:accel_end]
        accel_deltas = [
            _distance(left[1], right[1])
            for left, right in zip(accel_context, accel_context[1:])
        ]
        accel_residuals = [
            abs(math.sqrt(sum(component * component for component in vector)) - 9.80665)
            for _timestamp, vector in accel_values
        ]

        activity_start_ns = end_ns - _IMU_ACTIVITY_WINDOW_NS
        gyro_window_start = bisect.bisect_left(gyro_times, activity_start_ns)
        gyro_window = gyroscope[gyro_window_start:gyro_end]
        gyro_window_deg_s = [
            math.degrees(math.sqrt(sum(component * component for component in vector)))
            for _timestamp, vector in gyro_window
        ]
        accel_window_start = bisect.bisect_left(accel_times, activity_start_ns)
        accel_window_context_start = max(0, accel_window_start - 1)
        accel_window = accelerometer[accel_window_context_start:accel_end]
        accel_window_deltas = [
            _distance(left[1], right[1])
            for left, right in zip(accel_window, accel_window[1:])
            if right[0] >= activity_start_ns
        ]

        p0 = _numeric_vector(previous, "display_p", 3)
        p1 = _numeric_vector(row, "display_p", 3)
        q0 = _numeric_vector(previous, "display_q", 4)
        q1 = _numeric_vector(row, "display_q", 4)
        position_step = _distance(p0, p1) if p0 is not None and p1 is not None else None
        rotation_step = (
            _quat_delta_degrees(q0, q1) if q0 is not None and q1 is not None else None
        )
        if rotation_step is not None and not math.isfinite(rotation_step):
            rotation_step = None
        interval = {
            "frame_ns": end_ns,
            "dt_ms": dt_s * 1000.0,
            "position_step_m": position_step,
            "position_speed_m_s": position_step / dt_s if position_step is not None else None,
            "rotation_step_degrees": rotation_step,
            "rotation_speed_degrees_s": rotation_step / dt_s if rotation_step is not None else None,
            "gyro_samples": len(gyro_values),
            "gyro_peak_degrees_s": max(gyro_deg_s) if gyro_deg_s else None,
            "gyro_rms_degrees_s": math.sqrt(statistics.fmean(value * value for value in gyro_deg_s))
            if gyro_deg_s else None,
            "accelerometer_samples": len(accel_values),
            "accelerometer_delta_peak_m_s2": max(accel_deltas) if accel_deltas else None,
            "accelerometer_gravity_residual_peak_m_s2": max(accel_residuals)
            if accel_residuals else None,
            "gyro_activity_rms_degrees_s": math.sqrt(
                statistics.fmean(value * value for value in gyro_window_deg_s),
            ) if gyro_window_deg_s else None,
            "accelerometer_activity_rms_m_s2": math.sqrt(
                statistics.fmean(value * value for value in accel_window_deltas),
            ) if accel_window_deltas else None,
        }
        intervals.append(interval)
        previous = row

    fully_covered = [
        interval for interval in intervals
        if interval["gyro_samples"] > 0 and interval["accelerometer_samples"] > 0
    ]

    def finite_pairs(left_field: str, right_field: str) -> tuple[List[float], List[float]]:
        pairs = [
            (float(interval[left_field]), float(interval[right_field]))
            for interval in fully_covered
            if interval[left_field] is not None and interval[right_field] is not None
        ]
        return ([pair[0] for pair in pairs], [pair[1] for pair in pairs])

    position_gyro = finite_pairs("position_speed_m_s", "gyro_peak_degrees_s")
    position_accel = finite_pairs("position_speed_m_s", "accelerometer_delta_peak_m_s2")
    rotation_gyro = finite_pairs("rotation_speed_degrees_s", "gyro_peak_degrees_s")

    def values(rows: List[Dict[str, Any]], field: str) -> List[float]:
        return [float(interval[field]) for interval in rows if interval[field] is not None]

    def largest(field: str) -> List[Dict[str, Any]]:
        candidates = [interval for interval in intervals if interval[field] is not None]
        return sorted(candidates, key=lambda interval: float(interval[field]), reverse=True)[:10]

    def segment_summary(label: str, rows: List[Dict[str, Any]]) -> Dict[str, Any]:
        covered = [
            interval for interval in rows
            if interval["gyro_samples"] > 0 and interval["accelerometer_samples"] > 0
        ]
        return {
            "label": label,
            "intervals": len(rows),
            "coverage": len(covered) / len(rows) if rows else None,
            "position_speed_m_s": _distribution(values(rows, "position_speed_m_s")),
            "rotation_speed_degrees_s": _distribution(
                values(rows, "rotation_speed_degrees_s"),
            ),
            "gyro_peak_degrees_s": _distribution(values(rows, "gyro_peak_degrees_s")),
            "accelerometer_delta_peak_m_s2": _distribution(
                values(rows, "accelerometer_delta_peak_m_s2"),
            ),
            "gyro_activity_rms_degrees_s": _distribution(
                values(rows, "gyro_activity_rms_degrees_s"),
            ),
            "accelerometer_activity_rms_m_s2": _distribution(
                values(rows, "accelerometer_activity_rms_m_s2"),
            ),
        }

    markers = sorted(
        (
            (int(row["observed_ns"]), str(row.get("label", "MARK")))
            for row in marker_rows if "observed_ns" in row
        ),
        key=lambda marker: marker[0],
    )
    marker_segments: List[Dict[str, Any]] = []
    if markers:
        pre_rows = [interval for interval in intervals if interval["frame_ns"] < markers[0][0]]
        marker_segments.append(segment_summary("PRE", pre_rows))
        for index, (start_ns, label) in enumerate(markers):
            end_ns = markers[index + 1][0] if index + 1 < len(markers) else None
            rows = [
                interval for interval in intervals
                if interval["frame_ns"] >= start_ns
                and (end_ns is None or interval["frame_ns"] < end_ns)
            ]
            marker_segments.append(segment_summary(label, rows))

    return {
        "intervals": len(intervals),
        "fully_covered_intervals": len(fully_covered),
        "coverage": len(fully_covered) / len(intervals) if intervals else None,
        "activity_window_ms": _IMU_ACTIVITY_WINDOW_NS / 1e6,
        "position_speed_m_s": _distribution(values(intervals, "position_speed_m_s")),
        "rotation_speed_degrees_s": _distribution(
            values(intervals, "rotation_speed_degrees_s"),
        ),
        "gyro_peak_degrees_s": _distribution(values(intervals, "gyro_peak_degrees_s")),
        "accelerometer_delta_peak_m_s2": _distribution(
            values(intervals, "accelerometer_delta_peak_m_s2"),
        ),
        "gyro_activity_rms_degrees_s": _distribution(
            values(intervals, "gyro_activity_rms_degrees_s"),
        ),
        "accelerometer_activity_rms_m_s2": _distribution(
            values(intervals, "accelerometer_activity_rms_m_s2"),
        ),
        "correlations": {
            "position_speed_vs_gyro_peak": _pearson(*position_gyro),
            "position_speed_vs_accelerometer_delta_peak": _pearson(*position_accel),
            "rotation_speed_vs_gyro_peak": _pearson(*rotation_gyro),
        },
        "largest_position_intervals": largest("position_step_m"),
        "largest_rotation_intervals": largest("rotation_step_degrees"),
        "marker_segments": marker_segments,
    }


def _focus_motion_summary(frame_rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    changed_position: List[float] = []
    stable_position: List[float] = []
    changed_rotation: List[float] = []
    stable_rotation: List[float] = []
    changed_intervals = 0
    stable_intervals = 0
    previous: Dict[str, Any] | None = None

    for row in frame_rows:
        if row.get("state") != "TRACKING":
            previous = None
            continue
        if previous is None:
            previous = row
            continue

        af_changed = (
            "af_state" in previous and "af_state" in row
            and int(previous["af_state"]) != int(row["af_state"])
        )
        focus_changed = False
        try:
            focus_changed = abs(
                float(row["focus_distance_diopters"])
                - float(previous["focus_distance_diopters"])
            ) > 1e-6
        except (KeyError, TypeError, ValueError):
            pass
        changing = af_changed or focus_changed
        if changing:
            changed_intervals += 1
        else:
            stable_intervals += 1

        p0 = _numeric_vector(previous, "display_p", 3)
        p1 = _numeric_vector(row, "display_p", 3)
        if p0 is not None and p1 is not None:
            (changed_position if changing else stable_position).append(_distance(p0, p1))

        q0 = _numeric_vector(previous, "display_q", 4)
        q1 = _numeric_vector(row, "display_q", 4)
        if q0 is not None and q1 is not None:
            step = _quat_delta_degrees(q0, q1)
            if math.isfinite(step):
                (changed_rotation if changing else stable_rotation).append(step)
        previous = row

    return {
        "focus_changing_intervals": changed_intervals,
        "focus_stable_intervals": stable_intervals,
        "position_step_m": {
            "focus_changing": _distribution(changed_position),
            "focus_stable": _distribution(stable_position),
        },
        "rotation_step_degrees": {
            "focus_changing": _distribution(changed_rotation),
            "focus_stable": _distribution(stable_rotation),
        },
    }


def _anchor_summary(frame_rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    tracked = [row for row in frame_rows if row.get("state") == "TRACKING"]
    relative = [row for row in tracked if "relative_display_q" in row]
    raw_position_steps: List[float] = []
    relative_position_steps: List[float] = []
    raw_rotation_steps: List[float] = []
    relative_rotation_steps: List[float] = []

    previous: Dict[str, Any] | None = None
    for row in frame_rows:
        if row.get("state") != "TRACKING":
            previous = None
            continue
        if previous is not None and row.get("anchor_generation") == previous.get("anchor_generation"):
            raw_p0 = _numeric_vector(previous, "display_p", 3)
            raw_p1 = _numeric_vector(row, "display_p", 3)
            rel_p0 = _numeric_vector(previous, "relative_display_p", 3)
            rel_p1 = _numeric_vector(row, "relative_display_p", 3)
            if raw_p0 is not None and raw_p1 is not None:
                raw_position_steps.append(_distance(raw_p0, raw_p1))
            if rel_p0 is not None and rel_p1 is not None:
                relative_position_steps.append(_distance(rel_p0, rel_p1))

            raw_q0 = _numeric_vector(previous, "display_q", 4)
            raw_q1 = _numeric_vector(row, "display_q", 4)
            rel_q0 = _numeric_vector(previous, "relative_display_q", 4)
            rel_q1 = _numeric_vector(row, "relative_display_q", 4)
            if raw_q0 is not None and raw_q1 is not None:
                raw_rotation_steps.append(_quat_delta_degrees(raw_q0, raw_q1))
            if rel_q0 is not None and rel_q1 is not None:
                relative_rotation_steps.append(_quat_delta_degrees(rel_q0, rel_q1))
        previous = row

    generations = sorted(
        {int(row["anchor_generation"]) for row in frame_rows if "anchor_generation" in row},
    )

    def endpoint_delta(position_field: str, rotation_field: str) -> Dict[str, float | None]:
        position_rows: List[tuple[float, ...]] = []
        rotation_rows: List[tuple[float, ...]] = []
        for row in tracked:
            position = _numeric_vector(row, position_field, 3)
            rotation = _numeric_vector(row, rotation_field, 4)
            if position is not None:
                position_rows.append(position)
            if rotation is not None:
                rotation_rows.append(rotation)
        rotation_delta = (
            _quat_delta_degrees(rotation_rows[0], rotation_rows[-1])
            if rotation_rows else None
        )
        return {
            "position_m": _distance(position_rows[0], position_rows[-1])
            if position_rows else None,
            "rotation_degrees": rotation_delta
            if rotation_delta is None or math.isfinite(rotation_delta) else None,
        }

    return {
        "pose_modes": dict(sorted(Counter(str(row.get("pose_mode", "legacy")) for row in frame_rows).items())),
        "states": dict(sorted(Counter(str(row.get("anchor_state", "UNAVAILABLE")) for row in frame_rows).items())),
        "generations": generations,
        "tracked_frames": len(tracked),
        "relative_frames": len(relative),
        "relative_coverage": len(relative) / len(tracked) if tracked else None,
        "position_step_m": {
            "raw": _distribution(raw_position_steps),
            "relative": _distribution(relative_position_steps),
            "max_raw_minus_relative": max(
                (raw - rel for raw, rel in zip(raw_position_steps, relative_position_steps)),
                default=None,
            ),
        },
        "rotation_step_degrees": {
            "raw": _distribution(raw_rotation_steps),
            "relative": _distribution(relative_rotation_steps),
            "max_raw_minus_relative": max(
                (raw - rel for raw, rel in zip(raw_rotation_steps, relative_rotation_steps)),
                default=None,
            ),
        },
        "endpoint_delta": {
            "raw": endpoint_delta("display_p", "display_q"),
            "relative": endpoint_delta("relative_display_p", "relative_display_q"),
        },
    }


def _camera_inventory_summary(row: Dict[str, Any] | None) -> Dict[str, Any] | None:
    if row is None:
        return None
    configs = row.get("configs")
    if not isinstance(configs, list):
        return {"count": 0, "invalid": True}

    def pairs(field: str) -> List[List[int]]:
        values = {
            tuple(int(component) for component in config[field])
            for config in configs
            if isinstance(config, dict)
            and isinstance(config.get(field), list)
            and len(config[field]) == 2
        }
        return [list(value) for value in sorted(values)]

    def names(field: str) -> List[str]:
        return sorted(
            {str(config[field]) for config in configs if isinstance(config, dict) and field in config},
        )

    return {
        "count": len(configs),
        "camera_ids": names("camera_id"),
        "fps_ranges": pairs("fps_range"),
        "cpu_sizes": pairs("cpu_size"),
        "texture_sizes": pairs("texture_size"),
        "depth_sensor_usages": names("depth_sensor_usage"),
        "stereo_camera_usages": names("stereo_camera_usage"),
        "configs": configs,
    }


def _frame_window_summary(frame_rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    frame_times = [
        int(row["frame_ns"])
        for row in frame_rows
        if "frame_ns" in row and int(row["frame_ns"]) > 0
    ]
    observation_age_ms = [
        (int(row["observed_ns"]) - int(row["frame_ns"])) / 1e6
        for row in frame_rows
        if "observed_ns" in row and "frame_ns" in row and int(row["frame_ns"]) > 0
    ]
    anchor = _anchor_summary(frame_rows)
    metadata = _camera_metadata_summary(frame_rows)
    return {
        **_interval_summary(frame_times),
        "states": dict(sorted(Counter(str(row.get("state", "UNKNOWN")) for row in frame_rows).items())),
        "failure_reasons": dict(
            sorted(Counter(str(row.get("reason", "UNKNOWN")) for row in frame_rows).items()),
        ),
        "observation_age_median_ms": statistics.median(observation_age_ms)
        if observation_age_ms else None,
        "observation_age_p95_ms": _percentile(observation_age_ms, 0.95),
        "position_step_m": anchor["position_step_m"]["raw"],
        "rotation_step_degrees": anchor["rotation_step_degrees"]["raw"],
        "endpoint_delta": anchor["endpoint_delta"]["raw"],
        "exposure_time_ms": metadata["exposure_time_ms"],
        "sensitivity_iso": metadata["sensitivity_iso"],
    }


def _time_window_summary(
    frame_rows: List[Dict[str, Any]], window_s: float = 60.0,
) -> Dict[str, Any] | None:
    timed = [row for row in frame_rows if "observed_ns" in row]
    if not timed:
        return None
    timed.sort(key=lambda row: int(row["observed_ns"]))
    first_ns = int(timed[0]["observed_ns"])
    last_ns = int(timed[-1]["observed_ns"])
    window_ns = int(window_s * 1e9)
    first_rows = [row for row in timed if int(row["observed_ns"]) <= first_ns + window_ns]
    last_rows = [row for row in timed if int(row["observed_ns"]) >= last_ns - window_ns]
    return {
        "window_s": window_s,
        "trace_span_s": (last_ns - first_ns) / 1e9,
        "windows_overlap": first_ns + window_ns >= last_ns - window_ns,
        "first": _frame_window_summary(first_rows),
        "last": _frame_window_summary(last_rows),
    }


def _marker_segment_summary(
    frame_rows: List[Dict[str, Any]], marker_rows: List[Dict[str, Any]], settle_s: float = 1.5,
) -> List[Dict[str, Any]]:
    markers = [row for row in marker_rows if "observed_ns" in row]
    if not markers:
        return []
    trace_end_ns = max(
        (int(row.get("observed_ns", 0)) for row in frame_rows),
        default=int(markers[-1]["observed_ns"]),
    )
    result = []
    for index, marker in enumerate(markers):
        cue_ns = int(marker["observed_ns"])
        analysis_start_ns = cue_ns + int(settle_s * 1e9)
        end_ns = (
            int(markers[index + 1]["observed_ns"])
            if index + 1 < len(markers) else trace_end_ns + 1
        )
        rows = [
            row for row in frame_rows
            if analysis_start_ns <= int(row.get("observed_ns", -1)) < end_ns
        ]
        position_steps: List[float] = []
        rotation_steps: List[float] = []
        previous: Dict[str, Any] | None = None
        for row in rows:
            if row.get("state") != "TRACKING":
                previous = None
                continue
            if previous is not None:
                p0 = _numeric_vector(previous, "display_p", 3)
                p1 = _numeric_vector(row, "display_p", 3)
                if p0 is not None and p1 is not None:
                    position_steps.append(_distance(p0, p1))
                q0 = _numeric_vector(previous, "display_q", 4)
                q1 = _numeric_vector(row, "display_q", 4)
                if q0 is not None and q1 is not None:
                    step = _quat_delta_degrees(q0, q1)
                    if math.isfinite(step):
                        rotation_steps.append(step)
            previous = row
        focus = [
            float(row["focus_distance_diopters"])
            for row in rows if "focus_distance_diopters" in row
        ]
        result.append(
            {
                "index": index,
                "label": marker.get("label"),
                "cue_observed_ns": cue_ns,
                "settle_s": settle_s,
                "analyzed_duration_s": max(0.0, (end_ns - analysis_start_ns) / 1e9),
                "frames": len(rows),
                "states": dict(sorted(Counter(str(row.get("state", "UNKNOWN")) for row in rows).items())),
                "failure_reasons": dict(
                    sorted(Counter(str(row.get("reason", "UNKNOWN")) for row in rows).items()),
                ),
                "position_step_m": _distribution(position_steps),
                "rotation_step_degrees": _distribution(rotation_steps),
                "autofocus": _camera_state_summary(rows, "af_state", _AF_STATE_NAMES),
                "focus_distance_diopters": _distribution(focus),
            },
        )
    return result


def summarize(path: Path) -> Dict[str, Any]:
    header, events = read_events(path)
    _trajectory_header, samples = read_trace(path)
    pose_rows = [row for row in events if row.get("kind") == "pose"]
    frame_rows = [row for row in events if row.get("kind") == "arcore_frame"]
    tracking_rows = [row for row in events if row.get("kind") == "tracking"]
    config_rows = [row for row in events if row.get("kind") == "arcore_config"]
    inventory_rows = [row for row in events if row.get("kind") == "arcore_config_inventory"]
    marker_rows = [row for row in events if row.get("kind") == "marker"]
    imu_rows = [row for row in events if row.get("kind") == "imu"]

    pose_times = [int(row.get("source_ns", row.get("t"))) for row in pose_rows]
    if not pose_times:  # legacy take-v0 rows have no kind
        pose_times = [sample[0] for sample in samples]
    frame_times = [
        int(row["frame_ns"])
        for row in frame_rows
        if "frame_ns" in row and int(row["frame_ns"]) > 0
    ]
    observation_age_ms = [
        (int(row["observed_ns"]) - int(row["frame_ns"])) / 1e6
        for row in frame_rows
        if "observed_ns" in row and "frame_ns" in row and int(row["frame_ns"]) > 0
    ]

    state_counts = Counter(str(row.get("state", "UNKNOWN")) for row in frame_rows)
    reason_counts = Counter(str(row.get("reason", "UNKNOWN")) for row in frame_rows)
    sources = Counter(str(row.get("source", "unknown")) for row in pose_rows)
    norm_errors = [
        abs(math.sqrt(sum(component * component for component in sample[1])) - 1.0)
        for sample in samples
    ]

    return {
        "path": str(path),
        "format": header.get("format"),
        "version": header.get("version"),
        "header": header,
        "pose": {
            **_interval_summary(pose_times),
            "with_position": sum(sample[2] is not None for sample in samples),
            "sources": dict(sorted(sources.items())),
            "non_unit_quaternions": sum(error > 1e-3 for error in norm_errors),
            "max_quaternion_norm_error": max(norm_errors) if norm_errors else None,
        },
        "arcore_frames": {
            **_interval_summary(frame_times),
            "states": dict(sorted(state_counts.items())),
            "state_durations_s": _duration_by(frame_rows, "state"),
            "failure_reasons": dict(sorted(reason_counts.items())),
            "failure_reason_durations_s": _duration_by(frame_rows, "reason"),
            "observation_age_median_ms": statistics.median(observation_age_ms)
            if observation_age_ms else None,
            "observation_age_p95_ms": _percentile(observation_age_ms, 0.95),
        },
        "anchor": _anchor_summary(frame_rows),
        "camera_metadata": _camera_metadata_summary(frame_rows),
        "imu": _imu_summary(imu_rows),
        "arcore_imu_alignment": _arcore_imu_alignment_summary(
            frame_rows, imu_rows, marker_rows,
        ),
        "tracking_transitions": [
            {
                "observed_ns": row.get("observed_ns"),
                "frame_ns": row.get("frame_ns"),
                "state": row.get("state"),
                "reason": row.get("reason"),
            }
            for row in tracking_rows
        ],
        "arcore_config": config_rows[-1] if config_rows else None,
        "arcore_config_inventory": _camera_inventory_summary(
            inventory_rows[-1] if inventory_rows else None,
        ),
        "markers": [
            {
                "observed_ns": row.get("observed_ns"),
                "elapsed_s": (
                    (int(row["observed_ns"]) - int(header["started_ns"])) / 1e9
                    if "observed_ns" in row and "started_ns" in header else None
                ),
                "label": row.get("label"),
            }
            for row in marker_rows
        ],
        "marker_segments": _marker_segment_summary(frame_rows, marker_rows),
        "time_windows": _time_window_summary(frame_rows),
        "unknown_event_kinds": sorted(
            {
                str(row.get("kind"))
                for row in events
                if row.get("kind") not in {
                    "pose", "arcore_frame", "tracking", "arcore_config",
                    "arcore_config_inventory", "marker", None,
                    "imu",
                }
            },
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("trace", type=Path)
    parser.add_argument("--output", type=Path, help="also write the JSON report to this file")
    args = parser.parse_args()
    report = summarize(args.trace)
    rendered = json.dumps(report, indent=2, sort_keys=True)
    print(rendered)
    if args.output:
        args.output.write_text(rendered + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
