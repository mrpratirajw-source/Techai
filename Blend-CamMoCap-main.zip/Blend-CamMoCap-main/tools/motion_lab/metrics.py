# SPDX-License-Identifier: GPL-3.0-or-later
"""Objective feel metrics — pure Python, deterministic, no Blender, no UDP.

These exist because human feel-testing is noisy and can nudge tuning in the
wrong direction one plausible-sounding tweak at a time. The Lab's numbers are
proxies — they prevent regressions and settle "is X actually worse?"
arguments; the human still owns the final feel judgment.
"""

from __future__ import annotations

import math
import sys
from pathlib import Path
from typing import List, Optional, Tuple

_REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_REPO / "blender"))

from core import filters  # noqa: E402  (the code under test)

from synth import Sample, UPRIGHT, qmul, yaw_of  # noqa: E402

Quat = Tuple[float, float, float, float]


def _run_filter(samples: List[Sample], smoothing: float) -> List[Quat]:
    mc, beta = filters.live_filter_params(smoothing)
    f = filters.OneEuroQuat(mc, beta)
    return [f.update(q, t) for t, q, _p in samples]


def _angle_between(a: Quat, b: Quat) -> float:
    d = min(1.0, abs(sum(x * y for x, y in zip(a, b))))
    return math.degrees(2.0 * math.acos(d))


def steady_state_lag_ms(pan_samples: List[Sample], smoothing: float, rate_dps: float) -> float:
    """Filter lag on a constant-rate pan, converted from degrees-behind to
    milliseconds-behind. Measured at the end, where the exponential filter's
    transient has fully settled."""
    out = _run_filter(pan_samples, smoothing)
    lag_deg = _angle_between(pan_samples[-1][1], out[-1])
    return lag_deg / rate_dps * 1000.0


def jitter_attenuation_db(noisy_samples: List[Sample], smoothing: float) -> float:
    """How much of stationary jitter the filter removes: RMS angular deviation
    from the true pose, output vs input, in dB (more negative = calmer).
    First 20 samples dropped (filter settling)."""
    out = _run_filter(noisy_samples, smoothing)
    in_dev = [_angle_between(UPRIGHT, q) for _t, q, _p in noisy_samples[20:]]
    out_dev = [_angle_between(UPRIGHT, q) for q in out[20:]]

    def rms(xs: List[float]) -> float:
        return math.sqrt(sum(x * x for x in xs) / len(xs))

    return 20.0 * math.log10(max(rms(out_dev), 1e-12) / max(rms(in_dev), 1e-12))


def repeat_to_ticker(samples: List[Sample], ticker_hz: float = 100.0) -> List[Sample]:
    """Model the latest-wins pipeline: a slow source (e.g. ARCore ~30 Hz)
    re-emitted by the 100 Hz ticker — each tick carries the newest sample so
    far. This is exactly what the host applies."""
    if not samples:
        return []
    period_ns = 1e9 / ticker_hz
    out: List[Sample] = []
    idx = 0
    t = samples[0][0]
    end = samples[-1][0]
    while t <= end:
        while idx + 1 < len(samples) and samples[idx + 1][0] <= t:
            idx += 1
        out.append((int(t), samples[idx][1], samples[idx][2]))
        t += period_ns
    return out


def stepping_deg(applied: List[Sample], smoothing: Optional[float] = None) -> float:
    """How "steppy" the applied stream is: RMS of per-tick angular deltas.
    A 30 Hz source repeated on a 100 Hz ticker moves in bursts (0,0,big,0,0,
    big...); smooth motion moves evenly. Optionally runs the live filter
    first — the number that decides whether host-side interpolation is worth
    building."""
    quats = (
        _run_filter(applied, smoothing)
        if smoothing is not None
        else [q for _t, q, _p in applied]
    )
    deltas = [_angle_between(a, b) for a, b in zip(quats, quats[1:])]

    return math.sqrt(sum(d * d for d in deltas) / len(deltas))


def max_step_deg(applied: List[Sample]) -> float:
    """Largest single-tick rotation — the no-jump gate's rotational twin."""
    quats = [q for _t, q, _p in applied]
    return max(_angle_between(a, b) for a, b in zip(quats, quats[1:]))


def pos_lag_ms(speed_mps: float, smoothing: float, cadence_hz: float = 30.0) -> float:
    """Position-filter lag on a straight constant-velocity line at ARCore
    cadence, in milliseconds-behind."""
    mc, beta = filters.live_pos_filter_params(smoothing)
    f = filters.OneEuroVec3(mc, beta)
    dt_ns = int(1e9 / cadence_hz)
    t = 0
    x = 0.0
    out = f.update((0.0, 0.0, 0.0), t)
    for _ in range(int(3.0 * cadence_hz)):  # 3 s: fully settled
        t += dt_ns
        x += speed_mps / cadence_hz
        out = f.update((x, 0.0, 0.0), t)
    return (x - out[0]) / speed_mps * 1000.0


def pos_attenuation_db(smoothing: float, seed: int = 77, cadence_hz: float = 30.0) -> float:
    """Stationary position + seeded ±5 mm noise at ARCore cadence: residual
    RMS out/in, dB (more negative = calmer)."""
    from synth import _lcg  # seeded, deterministic

    mc, beta = filters.live_pos_filter_params(smoothing)
    f = filters.OneEuroVec3(mc, beta)
    rng = _lcg(seed)
    dt_ns = int(1e9 / cadence_hz)
    t = 0
    f.update((1.0, 0.0, 0.0), t)
    in_dev, out_dev = [], []
    for _ in range(int(6.0 * cadence_hz)):
        t += dt_ns
        n = (next(rng) - 0.5) * 0.01
        out = f.update((1.0 + n, 0.0, 0.0), t)
        in_dev.append(abs(n))
        out_dev.append(abs(out[0] - 1.0))

    def rms(xs: List[float]) -> float:
        return math.sqrt(sum(x * x for x in xs) / len(xs))

    return 20.0 * math.log10(max(rms(out_dev[20:]), 1e-12) / max(rms(in_dev[20:]), 1e-12))


def position_error_m(
    baked: List[Tuple[float, float, float]],
    expected: List[Tuple[float, float, float]],
) -> Tuple[float, float]:
    """(max, rms) positional error between a baked take and its closed form."""
    if len(baked) != len(expected):
        raise ValueError(f"length mismatch {len(baked)} != {len(expected)}")
    errs = [
        math.dist(b, e)
        for b, e in zip(baked, expected)
    ]
    rms = math.sqrt(sum(e * e for e in errs) / len(errs))
    return max(errs), rms
