#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""fake_phone: permanent phone-free dev harness for pocketrig.

Speaks protocol v1 to a running pocketrig server exactly like the Android
app would: HELLO resend until WELCOME, POSE at a fixed rate with monotonic
sensor timestamps, PING heartbeat, reliable RECORD_START/STOP, ACKs for
every reliable server message, BYE on exit (including Ctrl+C).

The codec is imported from blender/core/protocol.py — single source of
truth, never a copy.

Examples:
  python tools/fake_phone.py --mode orbit --duration 10
  python tools/fake_phone.py --uri "pocketrig://connect?v=1&host=192.168.1.23&port=47800&token=K3XG9A&name=PC"
  python tools/fake_phone.py --mode fixture --fixture-id upright_north
  python tools/fake_phone.py --record-after 2 --record-duration 3 --duration 8
"""

from __future__ import annotations

import argparse
import json
import math
import socket
import sys
import time
from pathlib import Path
from typing import Dict, Optional, Tuple
from urllib.parse import parse_qs, urlparse

_REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_REPO / "blender"))

from core import constants as C  # noqa: E402
from core import protocol as P  # noqa: E402

Quat = Tuple[float, float, float, float]

SQ2 = math.sqrt(0.5)
UPRIGHT_BASE: Quat = (SQ2, SQ2, 0.0, 0.0)  # camera level, looking +Y ("north")


def qmul(q1: Quat, q2: Quat) -> Quat:
    w1, x1, y1, z1 = q1
    w2, x2, y2, z2 = q2
    return (
        w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2,
        w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
        w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2,
        w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2,
    )


def qnorm(q: Quat) -> Quat:
    n = math.sqrt(sum(c * c for c in q)) or 1.0
    return (q[0] / n, q[1] / n, q[2] / n, q[3] / n)


def q_axis(axis: Tuple[float, float, float], deg: float) -> Quat:
    h = math.radians(deg) / 2.0
    s = math.sin(h)
    return (math.cos(h), axis[0] * s, axis[1] * s, axis[2] * s)


def pose_orbit(t: float) -> Quat:
    """Slow continuous pan: yaw about world Z at 15 deg/s over the level
    upright base — looks like a camera panning."""
    return qnorm(qmul(q_axis((0, 0, 1), 15.0 * t), UPRIGHT_BASE))


def pos_walk(t: float) -> Tuple[float, float, float]:
    """Slow 0.5 m-radius circular walk with a slight vertical bob — pairs with
    pose_orbit for a 6DOF stroll (protocol world frame, meters)."""
    a = 2.0 * math.pi * 0.1 * t  # one lap every 10 s
    return (
        0.5 * math.cos(a) - 0.5,  # start at the origin
        0.5 * math.sin(a),
        0.05 * math.sin(2.0 * math.pi * 0.9 * t),
    )


def pose_shake(t: float) -> Quat:
    """Orbit plus smooth pseudo-random handheld wobble: sums of sines at
    incommensurate frequencies, ~0.5 deg amplitude, in the camera frame."""
    def wob(f1, f2, p):
        return 0.35 * math.sin(2 * math.pi * f1 * t + p) + 0.2 * math.sin(
            2 * math.pi * f2 * t + 2.1 * p
        )

    q = pose_orbit(t)
    q = qmul(q, q_axis((1, 0, 0), wob(1.7, 4.3, 0.0)))
    q = qmul(q, q_axis((0, 1, 0), wob(1.1, 3.7, 1.0)))
    q = qmul(q, q_axis((0, 0, 1), wob(0.7, 2.9, 2.0)))
    return qnorm(q)


def load_fixture_quat(fixture_id: str) -> Quat:
    cases = json.loads(
        (_REPO / "fixtures" / "orientation_cases.json").read_text(encoding="utf-8")
    )["cases"]
    for case in cases:
        if case["id"] == fixture_id:
            return tuple(case["expected_protocol_quat"])  # type: ignore[return-value]
    known = ", ".join(c["id"] for c in cases)
    raise SystemExit(f"unknown --fixture-id {fixture_id!r}; known: {known}")


def parse_uri(uri: str) -> Dict[str, str]:
    parsed = urlparse(uri)
    if parsed.scheme != "pocketrig" or parsed.netloc != "connect":
        raise SystemExit(f"not a pocketrig pairing URI: {uri!r}")
    q = {k: v[0] for k, v in parse_qs(parsed.query).items()}
    missing = {"host", "port", "token"} - q.keys()
    if missing:
        raise SystemExit(f"pairing URI missing {sorted(missing)}")
    return q


class Client:
    def __init__(self, host: str, port: int, token: str, args) -> None:
        self.server = (host, port)
        self.token = token
        self.args = args
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("0.0.0.0", 0))
        self.sock.setblocking(False)
        self.seq = 0
        self.seen_server_seq: set = set()
        self.pending: Dict[int, Tuple[bytes, float, float]] = {}  # seq -> (data, next, deadline)
        self.welcomed = False
        self.pose_sent = 0
        self.record_sent = 0  # poses sent inside the record window
        self.recording = False
        self.record_start_ns = 0

    def next_seq(self) -> int:
        self.seq += 1
        return self.seq

    def send(self, data: bytes) -> None:
        self.sock.sendto(data, self.server)

    def send_reliable(self, data: bytes) -> int:
        msg_seq = P.decode(data).seq
        now = time.monotonic()
        self.pending[msg_seq] = (
            data,
            now + C.RELIABLE_RESEND_INTERVAL,
            now + C.RELIABLE_GIVE_UP,
        )
        self.send(data)
        return msg_seq

    def service_pending(self) -> None:
        now = time.monotonic()
        for seq in list(self.pending):
            data, next_at, deadline = self.pending[seq]
            if now >= deadline:
                del self.pending[seq]
                print(f"! reliable seq {seq} never ACKed (gave up after 5 s)")
            elif now >= next_at:
                self.pending[seq] = (data, now + C.RELIABLE_RESEND_INTERVAL, deadline)
                self.send(data)

    def drain(self) -> None:
        while True:
            try:
                data, addr = self.sock.recvfrom(65535)
            except BlockingIOError:
                return
            except OSError:
                return
            if addr != self.server:
                continue
            msg = P.decode(data)
            if msg is None:
                continue
            self.handle(msg)

    def handle(self, msg) -> None:
        if msg.msg_type == C.MSG_ACK:
            self.pending.pop(msg.acked_seq, None)
            return
        if msg.msg_type in C.RELIABLE_TYPES:
            self.send(P.encode_ack(self.next_seq(), time.monotonic_ns(), msg.seq))
            if msg.seq in self.seen_server_seq:
                return  # duplicate: ACKed again, processed once
            self.seen_server_seq.add(msg.seq)
        if msg.msg_type == C.MSG_WELCOME:
            if not self.welcomed:
                self.welcomed = True
                b = msg.body
                print(
                    f"< WELCOME from {b.get('server_name')} "
                    f"({b.get('host_app')} {b.get('host_version')}, "
                    f"addon {b.get('addon_version')}, scene {b.get('scene_fps')} fps)"
                )
        elif msg.msg_type == C.MSG_PONG:
            t1 = msg.body.get("t1", 0)
            rtt_ms = (time.monotonic_ns() - t1) / 1e6
            print(f"< PONG rtt={rtt_ms:.1f} ms")
        elif msg.msg_type == C.MSG_RECORD_BAKED:
            print(f"< RECORD_BAKED {msg.body}")
        elif msg.msg_type == C.MSG_ERROR:
            print(f"< ERROR {msg.body}")
            raise SystemExit(1)
        elif msg.msg_type == C.MSG_BYE:
            print("< BYE from server")
            raise SystemExit(0)

    # ------------------------------------------------------------------ run

    def hello_until_welcome(self) -> None:
        print(f"> HELLO to {self.server[0]}:{self.server[1]} (token {self.token})")
        self.send_reliable(
            P.encode_hello(
                self.next_seq(),
                time.monotonic_ns(),
                "fake_phone",
                C.ADDON_VERSION,
                self.token,
            )
        )
        deadline = time.monotonic() + C.RELIABLE_GIVE_UP
        while not self.welcomed:
            if time.monotonic() >= deadline:
                raise SystemExit("no WELCOME within 5 s — is the server running?")
            self.drain()
            self.service_pending()
            time.sleep(0.01)

    def pose_at(self, t: float) -> Quat:
        args = self.args
        if args.mode in ("orbit", "walk"):
            return pose_orbit(t)
        if args.mode == "shake":
            return pose_shake(t)
        return self.fixture_quat  # constant hold

    def pos_at(self, t: float) -> Optional[Tuple[float, float, float]]:
        return pos_walk(t) if self.args.mode == "walk" else None

    def run(self) -> None:
        args = self.args
        if args.mode == "fixture":
            self.fixture_quat = load_fixture_quat(args.fixture_id)
        self.hello_until_welcome()

        interval = 1.0 / args.rate
        start = time.monotonic()
        next_pose = start
        next_ping = start + 2.0
        record_at = start + args.record_after if args.record_after is not None else None
        record_stop_at = (
            record_at + args.record_duration if record_at is not None else None
        )
        end_at = start + args.duration if args.duration is not None else None
        last_report = start

        try:
            while True:
                now = time.monotonic()
                if end_at is not None and now >= end_at:
                    break
                if now >= next_pose:
                    ts_ns = time.monotonic_ns()
                    quat = self.pose_at(now - start)
                    flags = 1 if self.recording else 0
                    self.send(
                        P.encode_pose(
                            self.next_seq(),
                            ts_ns,
                            quat,
                            flags=flags,
                            pos=self.pos_at(now - start),
                        )
                    )
                    self.pose_sent += 1
                    if self.recording and ts_ns >= self.record_start_ns:
                        self.record_sent += 1
                    next_pose += interval
                    if next_pose < now:  # fell behind; do not burst
                        next_pose = now + interval
                if now >= next_ping:
                    self.send(P.encode_ping(self.next_seq(), time.monotonic_ns()))
                    next_ping += 2.0
                if record_at is not None and now >= record_at:
                    self.record_start_ns = time.monotonic_ns()
                    self.recording = True
                    self.record_sent = 0
                    print("> RECORD_START")
                    self.send_reliable(
                        P.encode_record_start(
                            self.next_seq(), time.monotonic_ns(), self.record_start_ns
                        )
                    )
                    record_at = None
                if record_stop_at is not None and now >= record_stop_at:
                    self.recording = False
                    print(f"> RECORD_STOP (sent {self.record_sent} poses in window)")
                    self.send_reliable(
                        P.encode_record_stop(
                            self.next_seq(),
                            time.monotonic_ns(),
                            time.monotonic_ns(),
                            self.record_sent,
                        )
                    )
                    record_stop_at = None
                if now - last_report >= 5.0:
                    print(f". {self.pose_sent} poses sent")
                    last_report = now
                self.drain()
                self.service_pending()
                time.sleep(min(0.002, interval / 4.0))
        except KeyboardInterrupt:
            print("\ninterrupted")
        finally:
            self.bye()

    def bye(self) -> None:
        print(f"> BYE ({self.pose_sent} poses sent total)")
        try:
            self.send_reliable(P.encode_bye(self.next_seq(), time.monotonic_ns()))
            deadline = time.monotonic() + 1.0  # brief best-effort wait for ACK
            while self.pending and time.monotonic() < deadline:
                self.drain()
                self.service_pending()
                time.sleep(0.01)
        except OSError:
            pass
        self.sock.close()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="fake_phone",
        description="Phone-free pocketrig client: streams synthetic or fixture "
        "poses to a running server.",
    )
    parser.add_argument("--uri", help="pocketrig://connect?... pairing URI "
                        "(overrides --host/--port/--token)")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=C.DEFAULT_PORT)
    parser.add_argument("--token", default="XXXXXX",
                        help="6-char session token shown in the Blender panel")
    parser.add_argument("--mode", choices=("orbit", "shake", "fixture", "walk"),
                        default="orbit",
                        help="walk = orbit rotation + 6DOF circular walk position")
    parser.add_argument("--fixture-id", default="upright_north",
                        help="orientation_cases.json id (mode=fixture)")
    parser.add_argument("--rate", type=float, default=float(C.POSE_SEND_HZ),
                        help="POSE rate in Hz")
    parser.add_argument("--record-after", type=float, default=None, metavar="N",
                        help="send RECORD_START N seconds in")
    parser.add_argument("--record-duration", type=float, default=3.0, metavar="N",
                        help="seconds between RECORD_START and RECORD_STOP")
    parser.add_argument("--duration", type=float, default=None, metavar="N",
                        help="exit (with BYE) after N seconds; default: run forever")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    host, port, token = args.host, args.port, args.token
    if args.uri:
        q = parse_uri(args.uri)
        host, port, token = q["host"], int(q["port"]), q["token"]
    Client(host, port, token, args).run()


if __name__ == "__main__":
    main()
