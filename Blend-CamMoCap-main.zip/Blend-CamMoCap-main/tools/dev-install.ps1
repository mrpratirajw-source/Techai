# SPDX-License-Identifier: GPL-3.0-or-later
# Build the pocketrig extension zip once, then install + enable it into each
# requested Blender version's user_default repository.
param(
    [string[]]$Versions = @("4.5", "5.0", "5.1")
)

$ErrorActionPreference = "Stop"
$repo = Split-Path -Parent $PSScriptRoot
$sourceDir = Join-Path $repo "blender"
$distDir = Join-Path $repo "dist"
New-Item -ItemType Directory -Force $distDir | Out-Null

function Get-BlenderExe([string]$Version) {
    return "C:\Program Files\Blender Foundation\Blender $Version\blender.exe"
}

# Build ONCE with the first available Blender.
$builder = $null
foreach ($v in $Versions) {
    $exe = Get-BlenderExe $v
    if (Test-Path $exe) { $builder = $exe; break }
}
if (-not $builder) {
    Write-Error "No Blender executable found for versions: $($Versions -join ', ')"
    exit 1
}

Write-Host "== Building extension zip (via $builder) =="
& $builder --command extension build --source-dir $sourceDir --output-dir $distDir
if ($LASTEXITCODE -ne 0) {
    Write-Error "extension build FAILED (exit $LASTEXITCODE)"
    exit 1
}
$zip = Get-ChildItem $distDir -Filter "pocketrig-*.zip" |
    Sort-Object LastWriteTime | Select-Object -Last 1
if (-not $zip) {
    Write-Error "build reported success but no pocketrig-*.zip found in $distDir"
    exit 1
}
Write-Host "Built: $($zip.FullName)"

$anyFailed = $false
foreach ($v in $Versions) {
    $exe = Get-BlenderExe $v
    if (-not (Test-Path $exe)) {
        Write-Warning "[$v] blender.exe not found - SKIPPED"
        $anyFailed = $true
        continue
    }
    Write-Host "== [$v] installing =="
    & $exe --command extension install-file -r user_default --enable $zip.FullName
    if ($LASTEXITCODE -eq 0) {
        Write-Host "[$v] install + enable OK"
    } else {
        Write-Warning "[$v] install FAILED (exit $LASTEXITCODE)"
        $anyFailed = $true
    }
}

if ($anyFailed) { exit 1 }
Write-Host "All versions installed successfully."
