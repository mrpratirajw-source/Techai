# SPDX-License-Identifier: GPL-3.0-or-later
# Full test matrix: desktop pytest, then both headless conformance scripts on
# every requested Blender version. Prints a summary table; exit 1 on any
# failure.
param(
    [string[]]$Versions = @("4.5", "5.0", "5.1")
)

$repo = Split-Path -Parent $PSScriptRoot
$testsDir = Join-Path $repo "blender\tests"
$results = @()

Write-Host "== desktop pytest (python 3.x) =="
python -m pytest $testsDir -q
$results += [pscustomobject]@{
    Target = "desktop python"; Test = "pytest"; Pass = ($LASTEXITCODE -eq 0)
}

$headless = @(
    @{ Script = "headless_live.py"; Sentinel = "HEADLESS_LIVE_PASS" },
    @{ Script = "headless_record.py"; Sentinel = "HEADLESS_RECORD_PASS" },
    @{ Script = "headless_recenter.py"; Sentinel = "HEADLESS_RECENTER_PASS" },
    @{ Script = "headless_6dof.py"; Sentinel = "HEADLESS_6DOF_PASS" },
    @{ Script = "headless_pause.py"; Sentinel = "HEADLESS_PAUSE_PASS" }
)

foreach ($v in $Versions) {
    $exe = "C:\Program Files\Blender Foundation\Blender $v\blender.exe"
    foreach ($h in $headless) {
        if (-not (Test-Path $exe)) {
            Write-Warning "[$v] blender.exe not found"
            $results += [pscustomobject]@{
                Target = "Blender $v"; Test = $h.Script; Pass = $false
            }
            continue
        }
        Write-Host "== [$v] $($h.Script) =="
        $out = & $exe --background --factory-startup --python (Join-Path $testsDir $h.Script) 2>&1 | Out-String
        $pass = ($LASTEXITCODE -eq 0) -and ($out -match [regex]::Escape($h.Sentinel))
        if ($pass) {
            Write-Host "  PASS"
        } else {
            Write-Host "  FAIL (exit $LASTEXITCODE) - output follows:"
            Write-Host $out
        }
        $results += [pscustomobject]@{
            Target = "Blender $v"; Test = $h.Script; Pass = $pass
        }
    }
}

Write-Host ""
Write-Host "== Summary =="
$results | Format-Table -AutoSize | Out-String | Write-Host

if ($results | Where-Object { -not $_.Pass }) {
    Write-Host "RESULT: FAILURES PRESENT"
    exit 1
}
Write-Host "RESULT: ALL PASS"
exit 0
