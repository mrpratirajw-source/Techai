# SPDX-License-Identifier: GPL-3.0-or-later
"""Where does Blender's main thread actually go while we stream?

Every capture measurement so far has timed *our* code and left the rest of the
second unexplained. Arithmetic on `p10`/`p11` says that rest is most of it: at
6.1 captures/s the period is 154 ms, of which capture is 37 ms and the rate gate
accounts for ~12 ms more. **Roughly 105 ms per frame -- about two thirds -- is
Blender doing something that is not us**, and nobody has looked at it.

That matters because it caps the whole feature. If capture were free the stream
would still only reach ~9 fps, so every optimisation aimed at the 37 ms is
fighting over a quarter of the budget. This probe measures the other three
quarters before any of that is designed.

**Four instruments, each bracketing one consumer of the main thread:**

- a free-running timer returning 0.0, which fires as fast as Blender's event
  loop will let anything fire. Its inter-call gap is the *ceiling* on main-thread
  availability, independent of what our tick asks for. This is the decisive
  number: `apply.TICK_INTERVAL` asks for 120 Hz, and the gate-pass counts in p11
  imply we are getting about 10.
- our own tick, wrapped so entry and exit are both stamped. Gives what the tick
  costs and, more usefully, how often it is actually called.
- `depsgraph_update_pre`/`_post`, which bracket scene evaluation. Split by
  whether they fired inside our tick, since `capture_camera_rgb` forces one
  itself and that cost is already inside the tick's own span.
- `PRE_VIEW`/`POST_PIXEL` draw handlers, which bracket the operator's viewport
  redraw. Also split by inside/outside the tick, because `draw_view3d` may fire
  the space's callbacks itself -- if it does, that is worth knowing on its own.

**Three windows, each adding one thing**, so cost is attributed rather than
inferred: `connected_still` is a live session with no poses arriving, `live_poses`
adds 100 Hz of moving poses, `live_streaming` adds the viewport stream. The
difference between consecutive tick rates is what each stage costs.

**The phone must be told to go live, and the camera must be checked afterwards.**
An interactive host starts *paused* on pairing, on purpose -- `apply_tick` says
so -- and a probe that only sends poses measures a session where nothing moves at
all. The first version of this probe did exactly that: it sent poses to a paused
host and recorded a rolling take instead, so its "load" was the playhead
advancing rather than the camera turning, and when the take auto-stopped the
scene went completely static and the stream fell to 0.9 fps on idle skips. Every
window therefore reports `camera_travel_deg`, and a window where the camera did
not move is not a measurement of anything.

This also puts a question mark over `p11`, which built its load the same way. If
its 19.5 ms draw was measured against a rolling timeline rather than a moving
camera, the cost is real but the cause named in the spec is not.

Whatever the four instruments do not account for is reported as `unaccounted`
rather than hidden: window redraws outside the 3D region, event handling, and
any block on buffer swap all land there. Naming it is the point -- it is the
term that has been invisible until now.

Interactive Blender only: `gpu` drawing raises under `--background`.

    blender scene.blend --python tools/viewport_lab/in_blender/main_thread_budget.py \\
        -- --out results/p12-main-thread.json
"""

from __future__ import annotations

import json
import math
import os
import pathlib
import sys
import time

import bpy

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from take_contention import FakePhone, FrameSink, _addon  # noqa: E402

#: Long enough for the distributions to settle at ~6 captures/s, short enough
#: that two windows plus setup stay under a minute.
WINDOW_S = 15.0

#: Discarded at the head of each window. The first captures pay for offscreen
#: allocation and shader compilation, which is real but is not steady state --
#: and in sweep mode also for the reconfigure that changes the offscreen size.
WARMUP_S = 2.0

#: Shorter windows for the sweep, which has nine of them rather than three.
#: Long enough to settle at 15-30 captures per second, which is all it needs:
#: the sweep is looking for a boundary, not a distribution.
SWEEP_WINDOW_S = 10.0


def _pct(values, q):
    if not values:
        return None
    ordered = sorted(values)
    return round(ordered[min(len(ordered) - 1, int(len(ordered) * q))], 2)


def _summary(values):
    if not values:
        return None
    return {
        "n": len(values),
        "p50": _pct(values, 0.50),
        "p95": _pct(values, 0.95),
        "max": round(max(values), 2),
        "sum_ms": round(sum(values), 1),
    }


def _minimise_window() -> None:
    """Minimise Blender, which is the condition camera mode exists for.

    Nothing redraws while the window is down, so the event loop stops being
    vsync-bound and the stream should get *faster* -- and the draw-handler path
    this design replaced could not produce a single frame here, because there is
    no redraw to hang a handler on.

    It is also the sharpest test of the change detector. With no viewport
    redrawing, the only thing that ever evaluates the scene is our own capture,
    so a host that counts its own evaluation as a scene change starves down to
    the idle keepalive instead of merely halving.

    Windows only, and failure is not fatal: an un-minimised run is still a run,
    it just measures the ordinary case twice.
    """
    try:
        import ctypes
        import ctypes.wintypes as wt

        SW_MINIMIZE = 6
        user32 = ctypes.windll.user32
        # By process id, not GetForegroundWindow. The foreground window when a
        # timer fires three seconds into a scripted launch is whatever the user
        # last clicked -- the first version of this minimised the console and
        # reported success while Blender carried on redrawing 451 times.
        found = []
        pid = os.getpid()

        @ctypes.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)
        def visit(hwnd, _lparam):
            owner = wt.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(owner))
            if owner.value == pid and user32.IsWindowVisible(hwnd):
                found.append(hwnd)
            return True

        user32.EnumWindows(visit, 0)
        for hwnd in found:
            user32.ShowWindow(hwnd, SW_MINIMIZE)
        print(f"BUDGET minimised {len(found)} window(s)", flush=True)
    except Exception as exc:  # noqa: BLE001
        print(f"BUDGET minimise unavailable: {exc}", flush=True)


def _gaps(stamps):
    """Inter-arrival gaps in ms, from a list of perf_counter stamps."""
    return [(b - a) * 1000.0 for a, b in zip(stamps, stamps[1:])]


class Recorder:
    """One window's worth of main-thread accounting.

    Every append here happens on the main thread inside an instrument, so it
    must stay trivial -- a list append and nothing else. Anything cleverer would
    show up in the very measurement it is taking.
    """

    def __init__(self, name: str) -> None:
        self.name = name
        self.t0 = time.perf_counter()
        self.free_stamps = []
        self.tick_stamps = []
        self.tick_ms = []
        self.deps_in = []
        self.deps_out = []
        self.draw_in = []
        self.draw_out = []
        #: Sampled from the free timer rather than the tick, so watching the
        #: camera never lands inside a budget term it would inflate.
        self.cam_quats = []
        self.frames_seen = set()
        self.state_at_open = None

    def travel_deg(self) -> float:
        """Total angular distance the camera actually covered, in degrees.

        The load model's own check. A window with poses arriving but a paused
        host reads ~0 here, which is what makes the difference between a
        measurement and a misunderstanding.
        """
        total = 0.0
        for a, b in zip(self.cam_quats, self.cam_quats[1:]):
            dot = min(1.0, abs(sum(x * y for x, y in zip(a, b))))
            total += 2.0 * math.degrees(math.acos(dot))
        return total

    def close(self):
        span = time.perf_counter() - self.t0
        tick_sum = sum(self.tick_ms)
        deps_out_sum = sum(self.deps_out)
        draw_out_sum = sum(self.draw_out)
        span_ms = span * 1000.0
        accounted = tick_sum + deps_out_sum + draw_out_sum
        return {
            "window": self.name,
            "span_s": round(span, 2),
            # Read this before anything below it. A window whose camera did not
            # move is not a measurement of a viewfinder under load.
            "camera_travel_deg": round(self.travel_deg(), 1),
            "timeline_frames_touched": len(self.frames_seen),
            "host_state": self.state_at_open,
            # The ceiling. If this is far below 1/TICK_INTERVAL, no amount of
            # making capture cheaper raises the stream's rate.
            "free_timer": {
                "n": len(self.free_stamps),
                "per_s": round(len(self.free_stamps) / span, 1) if span else None,
                "gap_ms": _summary(_gaps(self.free_stamps)),
            },
            "tick": {
                "n": len(self.tick_stamps),
                "per_s": round(len(self.tick_stamps) / span, 1) if span else None,
                "gap_ms": _summary(_gaps(self.tick_stamps)),
                "inside_ms": _summary(self.tick_ms),
            },
            # Inside-tick entries are already inside `tick.inside_ms`; they are
            # reported so the tick's own cost can be split, never added again.
            "depsgraph": {
                "outside_tick": _summary(self.deps_out),
                "inside_tick": _summary(self.deps_in),
            },
            "viewport_draw": {
                "outside_tick": _summary(self.draw_out),
                "inside_tick": _summary(self.draw_in),
            },
            "budget_pct": {
                "our_tick": round(100.0 * tick_sum / span_ms, 1) if span else None,
                "operator_redraw": (
                    round(100.0 * draw_out_sum / span_ms, 1) if span else None
                ),
                "depsgraph_outside_tick": (
                    round(100.0 * deps_out_sum / span_ms, 1) if span else None
                ),
                "unaccounted": (
                    round(100.0 * (span_ms - accounted) / span_ms, 1) if span else None
                ),
            },
        }


def main() -> None:
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    out_path = (
        pathlib.Path(argv[argv.index("--out") + 1]) if "--out" in argv
        else pathlib.Path("main-thread-budget.json")
    )

    sweep = "--sweep" in argv
    profiles = "--profiles" in argv
    minimise = "--minimise" in argv
    shading = argv[argv.index("--shading") + 1] if "--shading" in argv else None
    window_s = SWEEP_WINDOW_S if sweep else WINDOW_S
    result = {
        "format": "pocketrig-main-thread-budget",
        "version": 2,
        "mode": "profiles" if profiles else ("sweep" if sweep else "budget"),
        "minimised": minimise,
        "windows": [],
    }
    st = {"rec": None, "in_tick": False, "deps_t0": None, "draw_t0": None,
          "sweep": sweep, "profiles": profiles}

    # ------------------------------------------------------------ instruments

    def free_timer():
        rec = st["rec"]
        if rec is not None:
            rec.free_stamps.append(time.perf_counter())
            # Every size the host actually rendered during the window, sampled
            # here rather than in the tick so watching the controller costs
            # nothing that the controller is being judged on.
            state_mod = st.get("state")
            cap = state_mod.camera_capture if state_mod is not None else None
            if cap is not None and cap.active:
                st.setdefault("seen_sizes", []).append((cap.width, cap.height))
            scene = bpy.context.scene
            camera = scene.camera if scene else None
            if camera is not None:
                q = camera.matrix_world.to_quaternion()
                rec.cam_quats.append((q.w, q.x, q.y, q.z))
                rec.frames_seen.add(scene.frame_current)
        return 0.0

    def deps_pre(scene, depsgraph=None):
        st["deps_t0"] = time.perf_counter()

    def deps_post(scene, depsgraph=None):
        t0 = st["deps_t0"]
        rec = st["rec"]
        if t0 is None or rec is None:
            return
        ms = (time.perf_counter() - t0) * 1000.0
        (rec.deps_in if st["in_tick"] else rec.deps_out).append(ms)
        st["deps_t0"] = None

    def draw_pre():
        st["draw_t0"] = time.perf_counter()

    def draw_post():
        t0 = st["draw_t0"]
        rec = st["rec"]
        if t0 is None or rec is None:
            return
        ms = (time.perf_counter() - t0) * 1000.0
        (rec.draw_in if st["in_tick"] else rec.draw_out).append(ms)
        st["draw_t0"] = None

    def install(mods):
        """Wrap the tick before it is registered, and hang the rest off bpy."""
        apply_mod = mods["apply"]
        original = apply_mod._timer_callback

        def wrapped():
            rec = st["rec"]
            if rec is None:
                return original()
            entered = time.perf_counter()
            rec.tick_stamps.append(entered)
            st["in_tick"] = True
            try:
                return original()
            finally:
                st["in_tick"] = False
                rec.tick_ms.append((time.perf_counter() - entered) * 1000.0)

        # Registration in panel.py looks the attribute up at call time, so this
        # must happen BEFORE pocketrig.connect() or the real function is the one
        # that gets registered and the wrapper never runs.
        apply_mod._timer_callback = wrapped

        bpy.app.handlers.depsgraph_update_pre.append(deps_pre)
        bpy.app.handlers.depsgraph_update_post.append(deps_post)
        handles = (
            bpy.types.SpaceView3D.draw_handler_add(draw_pre, (), "WINDOW", "PRE_VIEW"),
            bpy.types.SpaceView3D.draw_handler_add(
                draw_post, (), "WINDOW", "POST_PIXEL"
            ),
        )
        bpy.app.timers.register(free_timer)

        def restore():
            apply_mod._timer_callback = original
            for handler, fn in (
                (bpy.app.handlers.depsgraph_update_pre, deps_pre),
                (bpy.app.handlers.depsgraph_update_post, deps_post),
            ):
                try:
                    handler.remove(fn)
                except ValueError:
                    pass
            bpy.types.SpaceView3D.draw_handler_remove(handles[0], "WINDOW")
            bpy.types.SpaceView3D.draw_handler_remove(handles[1], "WINDOW")
            try:
                bpy.app.timers.unregister(free_timer)
            except ValueError:
                pass

        st["restore"] = restore

    # --------------------------------------------------------------- sequence

    def open_window(name: str):
        """Start recording, after stamping what the host thinks it is doing.

        `paused` is here because a paused host silently invalidates the whole
        window: poses arrive, nothing moves, and the numbers describe an idle
        Blender wearing a load's clothes.
        """
        state = st["state"]
        srv = st["srv"]
        rec = Recorder(name)
        rec.state_at_open = {
            "paused": bool(getattr(state, "paused", None)),
            "recording": bool(getattr(srv, "recording", False)),
            "frame": bpy.context.scene.frame_current,
        }
        st["rec"] = rec

    def begin():
        mods = _addon()
        if "state" not in mods or "protocol" not in mods or "apply" not in mods:
            print("BUDGET_ERROR add-on modules not found", flush=True)
            return None
        install(mods)
        try:
            bpy.ops.pocketrig.connect()
        except Exception as exc:  # noqa: BLE001
            print(f"BUDGET_ERROR connect: {exc}", flush=True)
            return None
        state = mods["state"]
        srv = state.server
        if srv is None:
            print("BUDGET_ERROR no server", flush=True)
            return None

        if minimise:
            _minimise_window()
        if shading:
            # The realistic way a capture gets expensive: draw_view3d borrows
            # the operator's shading mode, so someone working in Material
            # Preview or Rendered is paying EEVEE for every viewfinder frame.
            found = mods["viewport"].find_view3d()
            if found is not None:
                found[2].shading.type = shading
                result["shading"] = shading
                print(f"BUDGET shading {shading}", flush=True)
        phone = FakePhone(mods["protocol"], srv.port, srv.token)
        phone.hello()
        time.sleep(0.4)
        st.update(phone=phone, state=state, srv=srv, mods=mods)
        # Go live the way the phone does. Poses sent to a paused host move
        # nothing at all -- see FakePhone.go_live.
        phone.go_live()
        # Deliberately NOT recording. A rolling take advances the playhead every
        # tick, which is its own heavy load and drowns out the one being
        # measured -- and when it auto-stops the scene goes static and the idle
        # skip suppresses the stream entirely.
        print(f"BUDGET window 1: connected_still, {window_s}s", flush=True)
        bpy.app.timers.register(open_first, first_interval=WARMUP_S)
        return None

    def open_first():
        open_window("connected_still")
        bpy.app.timers.register(to_poses, first_interval=window_s)
        return None

    def to_poses():
        result["windows"].append(st["rec"].close())
        st["rec"] = None
        st["phone"].start_poses()
        print(f"BUDGET window 2: live_poses, {window_s}s", flush=True)
        bpy.app.timers.register(open_second, first_interval=WARMUP_S)
        return None

    def open_second():
        open_window("live_poses")
        bpy.app.timers.register(to_streaming, first_interval=window_s)
        return None

    def to_streaming():
        """Walk the stream configurations, one window each.

        The extra rows exist to test one mechanism: the capture rate looks
        **quantised to the event loop**, because a `bpy.app.timers` callback
        cannot fire more than once per loop iteration. If that is right, asking
        for 20 fps against a 30 Hz loop cannot give 20 -- the 50 ms gate lands
        between iteration boundaries and rounds up to 66.7 ms, i.e. 15 -- and
        asking for *more* than the loop can give returns *more*, which is the
        opposite of how a rate limit is supposed to behave.
        """
        result["windows"].append(st["rec"].close())
        st["rec"] = None

        srv = st["srv"]
        # The tick publishes camera_sizes on its first pass; reading it before
        # that returns nothing and the host silently defaults, which is how an
        # earlier run recorded "size": null.
        offered = [tuple(s) for s in (srv.viewport_video or {}).get("camera_sizes") or []]
        result["sizes_offered"] = [list(s) for s in offered]
        big = offered[0] if offered else None
        small = offered[-1] if offered else None
        if st["profiles"]:
            # One window per profile, and the host owns the size in all three.
            # The question is not what it costs -- that is measured elsewhere --
            # but whether it lands somewhere sensible and then stays there.
            st["stages"] = [(name, None, 30.0) for name in
                            ("light", "balanced", "smooth")]
        elif st["sweep"]:
            # Every advertised size against every rate the phone can ask for.
            # The question is where capture crosses one event-loop iteration:
            # under it the capture fits in time the loop spends waiting on vsync
            # anyway, over it every iteration it lands in gets longer. That
            # boundary is what the Detail control actually moves, and it is not
            # visible from any single row.
            st["stages"] = [
                (f"{w}x{h}@{int(fps)}", (w, h), fps)
                for (w, h) in offered
                for fps in (15.0, 20.0, 30.0)
            ]
        else:
            st["stages"] = [
                ("live_streaming_20fps", big, 20.0),
                ("live_streaming_30fps", big, 30.0),
                ("live_streaming_30fps_small", small, 30.0),
            ]
        sink = FrameSink(srv.viewport_port, srv.token)
        sink.start()
        st["sink"] = sink
        time.sleep(0.3)
        next_stage()
        return None

    def next_stage():
        if not st["stages"]:
            finish()
            return None
        name, size, fps = st["stages"].pop(0)
        st["stage_name"] = name
        st["phone"].viewport_camera(
            size, fps=fps, profile=name if st["profiles"] else None
        )
        print(f"BUDGET {name}: {size} @ {fps} fps, {window_s}s", flush=True)
        bpy.app.timers.register(open_stage, first_interval=WARMUP_S)
        return None

    def open_stage():
        st["seen_sizes"] = []
        cap = st["state"].camera_capture
        st["frames_at_open"] = cap.frames_captured if cap is not None else 0
        open_window(st["stage_name"])
        bpy.app.timers.register(close_stage, first_interval=window_s)
        return None

    def close_stage():
        rec = st["rec"]
        cap = st["state"].camera_capture
        row = rec.close()
        # Counted over this window rather than read off `achieved_fps`, whose
        # own 3 s window straddles a configuration change.
        captured = (cap.frames_captured - st["frames_at_open"]) if cap else 0
        row["captures"] = captured
        row["captures_per_s"] = round(captured / row["span_s"], 2) if row["span_s"] else None
        row["capture_stats"] = cap.stats() if cap is not None else None
        row["sizes_used"] = sorted({tuple(x) for x in st.get("seen_sizes", [])})
        result["windows"].append(row)
        st["rec"] = None
        next_stage()
        return None

    def finish():
        st["phone"].stop_poses()
        st["sink"].stop()
        cap = st["state"].camera_capture
        result["capture_stats"] = cap.stats() if cap is not None else None
        result["frames_received"] = st["sink"].frames
        # Proves the PARAMS ceiling is being computed at all, and that it is the
        # loaded figure rather than the free-running one. Nothing else on this
        # host reads it back -- the probe's phone does not decode PARAMS.
        result["viewport_max_fps_published"] = getattr(
            st["state"], "viewport_max_fps_published", None
        )
        result["tick_interval_requested_ms"] = round(
            st["mods"]["apply"].TICK_INTERVAL * 1000.0, 2
        )
        scene = bpy.context.scene
        result["scene"] = {
            "file": bpy.data.filepath,
            "objects": len(scene.objects),
            "render": [scene.render.resolution_x, scene.render.resolution_y],
        }
        st["restore"]()

        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
        print("BUDGET_RESULT " + json.dumps(result), flush=True)
        print("BUDGET_DONE", flush=True)
        # os._exit, never bpy.ops.wm.quit_blender(): quitting from a timer is
        # the documented native-crash path. The file is already written and both
        # prints are flushed, so there is nothing left to lose.
        os._exit(0)

    bpy.app.timers.register(begin, first_interval=3.0)


if __name__ == "__main__":
    main()
