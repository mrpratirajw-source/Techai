# SPDX-License-Identifier: GPL-3.0-or-later
"""Why does our offscreen draw cost 20-40x the operator's whole redraw?

Blender redraws this scene into its own viewport in **0.95 ms**, measured with
`PRE_VIEW`/`POST_PIXEL` handlers. `GPUOffScreen.draw_view3d` of the same scene,
at a comparable size, costs 10-30 ms. Both are one draw of one scene on one GPU.
That gap is the last large unexplained number in the viewport channel, and it is
the difference between a viewfinder costing half the host's main thread and a
tenth of it.

**The previous version of this file measured the wrong thing.** It sent poses to
a host that was still paused -- an interactive host starts that way on purpose --
and started a recording, so the load it measured was the playhead advancing
frame by frame, not a camera turning. Its numbers (draw 19.5 ms, readback
9.6 ms, pack 2.7 ms) are real and describe something else. Every window here
reports `camera_travel_deg`, and one that did not move is not a measurement.

**Seven segments, not three.** The old split stopped at draw/read/pack, which
was too coarse to act on: "the draw is slow" admits at least four fixes. This
times the depsgraph evaluation, the camera matrix, the draw call, the bind, the
readback, the numpy copy and the pack separately, and records the operator's own
redraw in the same run so the ratio comes from one set of conditions rather than
two.

It also buckets by the gap since the previous capture. If cost tracks the gap,
the GPU pipeline going cold is the story and capturing *more* often is the fix.
If it does not, the cost is in the call itself.

**Then it varies one thing at a time**, in one session so the conditions match:

- `small` -- the same capture at a third of the pixels. If `draw` shrinks with
  it the draw is GPU work on pixels; if it does not, it is CPU work submitting a
  scene, and no resolution setting will touch it.
- `no_colour_mgmt` -- `do_color_management=True` runs a conversion pass we ask
  for. It is needed (without it the phone's picture is visibly dark), but its
  price has never been separated from the draw's.
- `no_overlays` -- `draw_view3d` borrows a real 3D view's settings, so whatever
  the operator has switched on gets drawn into our buffer too.
- `solid_shading` -- and likewise their shading mode, which on a
  MATERIAL_PREVIEW viewport means paying EEVEE for a viewfinder.
- `read_rgb` -- asking `read_color` for 3 channels instead of 4 moves a quarter
  less data and lets the pack skip dropping alpha.

Interactive Blender only: `gpu` drawing raises under `--background`.

    blender scene.blend --python tools/viewport_lab/in_blender/capture_stall.py \\
        -- --out results/p17-capture-split.json
"""

from __future__ import annotations

import json
import math
import os
import pathlib
import sys
import time

import bpy
import gpu

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from take_contention import FakePhone, FrameSink, _addon  # noqa: E402

WARMUP_S = 2.0
MEASURE_S = 8.0

#: One window each, in one session. Separate launches would re-answer the
#: question "was the machine the same?" for every row.
VARIANTS = (
    "baseline",
    "small",
    "no_colour_mgmt",
    "no_overlays",
    "solid_shading",
    "read_rgb",
    "ping_pong",
    # Baseline again, last. Two runs of this probe disagreed about the draw by
    # a factor of five, so every conclusion here needs to know whether the
    # first row still holds by the end of the session.
    "baseline_again",
)

SEGMENTS = ("depsgraph", "matrix", "draw", "bind", "read", "copy", "pack")


def _pct(values, q):
    if not values:
        return None
    ordered = sorted(values)
    return round(ordered[min(len(ordered) - 1, int(len(ordered) * q))], 3)


def _summary(values):
    if not values:
        return None
    return {
        "n": len(values),
        "p50": _pct(values, 0.50),
        "p95": _pct(values, 0.95),
        "max": round(max(values), 3),
        "mean": round(sum(values) / len(values), 3),
    }


def main() -> None:
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    out_path = (
        pathlib.Path(argv[argv.index("--out") + 1]) if "--out" in argv
        else pathlib.Path("capture-split.json")
    )
    result = {"format": "pocketrig-capture-split", "version": 3, "windows": []}
    rows = []
    redraw_ms = []
    cam_quats = []
    st = {"last": None, "draw_t0": None, "measuring": False, "variant": "baseline"}

    # --------------------------------------------------------- instruments

    def draw_pre():
        st["draw_t0"] = time.perf_counter()

    def draw_post():
        t0 = st["draw_t0"]
        if t0 is not None and st["measuring"]:
            # The comparison the whole file exists for: what one redraw of this
            # same scene costs Blender when it draws it for itself.
            redraw_ms.append((time.perf_counter() - t0) * 1000.0)
        st["draw_t0"] = None

    def sample_camera():
        scene = bpy.context.scene
        camera = scene.camera if scene else None
        if camera is not None and st["measuring"]:
            q = camera.matrix_world.to_quaternion()
            cam_quats.append((q.w, q.x, q.y, q.z))
        return 0.0

    def travel_deg():
        total = 0.0
        for a, b in zip(cam_quats, cam_quats[1:]):
            dot = min(1.0, abs(sum(x * y for x, y in zip(a, b))))
            total += 2.0 * math.degrees(math.acos(dot))
        return total

    # ------------------------------------------------------------- sequence

    def begin():
        mods = _addon()
        vp = mods.get("viewport")
        if vp is None or "protocol" not in mods:
            print("SPLIT_ERROR add-on not found", flush=True)
            return None
        vs = mods.get("viewport_stream")
        if vs is None:
            for name, mod in list(sys.modules.items()):
                if name.endswith(".core.viewport_stream") and "pocketrig" in name:
                    vs = mod
        try:
            bpy.ops.pocketrig.connect()
        except Exception as exc:  # noqa: BLE001
            print(f"SPLIT_ERROR connect: {exc}", flush=True)
            return None
        state = mods["state"]
        srv = state.server
        if srv is None:
            print("SPLIT_ERROR no server", flush=True)
            return None

        original = vp.capture_camera_rgb

        def split_capture(offscreen, scene, space, region, width, height):
            """`capture_camera_rgb`, segment by segment.

            Mirrors the shipped function line for line and delegates packing to
            the shipped `pack_rgb`. Installed over the real one, so the real
            CameraCapture on the real tick under real load calls this.
            """
            import numpy as np

            camera = scene.camera
            if camera is None:
                return None
            now = time.perf_counter()
            gap_ms = (now - st["last"]) * 1000.0 if st["last"] is not None else None
            st["last"] = now

            variant = st["variant"]
            channels = 3 if variant == "read_rgb" else 4

            # Draw into one buffer, read the OTHER -- the one drawn last tick,
            # which the GPU finished long ago. If `read_color` is mostly waiting
            # for our own draw to complete rather than moving bytes, this is
            # where that shows up, and the price is one frame of extra latency.
            if variant == "ping_pong":
                pair = st.get("pair")
                if pair is None or st.get("pair_size") != (width, height):
                    for old_buf in (pair or []):
                        old_buf.free()
                    pair = [
                        gpu.types.GPUOffScreen(width, height) for _ in range(2)
                    ]
                    st["pair"], st["pair_size"], st["flip"] = pair, (width, height), 0
                draw_into = pair[st["flip"]]
                read_from = pair[1 - st["flip"]]
                st["flip"] ^= 1
            else:
                draw_into = read_from = offscreen

            t = [time.perf_counter()]
            depsgraph = bpy.context.evaluated_depsgraph_get()
            camera_eval = camera.evaluated_get(depsgraph)
            t.append(time.perf_counter())
            view = camera_eval.matrix_world.inverted()
            proj = camera_eval.calc_matrix_camera(depsgraph, x=width, y=height)
            t.append(time.perf_counter())
            draw_into.draw_view3d(
                scene, bpy.context.view_layer, space, region, view, proj,
                do_color_management=variant != "no_colour_mgmt",
            )
            t.append(time.perf_counter())
            with read_from.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                t.append(time.perf_counter())
                buffer = framebuffer.read_color(
                    0, 0, width, height, channels, 0, "UBYTE"
                )
                t.append(time.perf_counter())
                buffer.dimensions = width * height * channels
                pixels = np.frombuffer(buffer, dtype=np.uint8).reshape(
                    height, width, channels
                ).copy()
            t.append(time.perf_counter())
            if channels == 3:
                # No alpha to drop, so the flip is the whole job and numpy can
                # do it as one contiguous row-reversed copy.
                packed = (
                    np.ascontiguousarray(pixels[::-1]).tobytes(), width, height
                )
            else:
                packed = vs.pack_rgb(pixels, 1)
            t.append(time.perf_counter())

            if st["measuring"]:
                row = {"gap_ms": round(gap_ms, 2) if gap_ms is not None else None}
                for name, a, b in zip(SEGMENTS, t, t[1:]):
                    row[name] = (b - a) * 1000.0
                row["total"] = (t[-1] - t[0]) * 1000.0
                rows.append(row)
            return packed

        vp.capture_camera_rgb = split_capture
        handles = (
            bpy.types.SpaceView3D.draw_handler_add(draw_pre, (), "WINDOW", "PRE_VIEW"),
            bpy.types.SpaceView3D.draw_handler_add(
                draw_post, (), "WINDOW", "POST_PIXEL"
            ),
        )
        bpy.app.timers.register(sample_camera)

        def restore():
            vp.capture_camera_rgb = original
            bpy.types.SpaceView3D.draw_handler_remove(handles[0], "WINDOW")
            bpy.types.SpaceView3D.draw_handler_remove(handles[1], "WINDOW")
            try:
                bpy.app.timers.unregister(sample_camera)
            except ValueError:
                pass

        st["restore"] = restore

        phone = FakePhone(mods["protocol"], srv.port, srv.token)
        phone.hello()
        # Live, and NOT recording. A rolling take advances the playhead every
        # tick, which is a different load entirely and is what the previous
        # version of this probe actually measured.
        phone.go_live()
        phone.start_poses()
        st.update(phone=phone, state=state, srv=srv, vp=vp)
        # Hand the main thread back before reading anything the tick publishes.
        #
        # This used to be time.sleep(0.4) followed by reading camera_sizes, and
        # the sleep is on the MAIN thread inside a timer callback -- so no tick
        # runs during it, camera_sizes is still unpublished afterwards, and the
        # size list comes back empty. The probe then silently skipped every
        # resize it thought it was making and reported a full-size number under
        # the label "small". Sleeping to wait for a tick is waiting for
        # something you are holding up.
        bpy.app.timers.register(arm, first_interval=1.5)
        return None

    def arm():
        srv = st["srv"]
        offered = (srv.viewport_video or {}).get("camera_sizes") or []
        if not offered:
            print("SPLIT_ERROR camera_sizes never published", flush=True)
            os._exit(1)
        sink = FrameSink(srv.viewport_port, srv.token)
        sink.start()
        st["phone"].viewport_camera(tuple(offered[0]), fps=30.0)
        result["sizes_offered"] = [list(x) for x in offered]
        print(f"SPLIT sizes={offered}", flush=True)
        st.update(sink=sink, offered=offered, pending=list(VARIANTS))
        next_variant()
        return None

    def apply_variant(name):
        """Set up one variant, returning the calls that undo it.

        The two that touch the operator's own 3D view save and restore it. A
        probe that leaves someone else's overlays switched off has changed the
        thing it was measuring, for every run after it.
        """
        found = st["vp"].find_view3d()
        space = found[2] if found else None
        undo = []
        if name == "small":
            st["phone"].viewport_camera(tuple(st["offered"][-1]), fps=30.0)
            undo.append(
                lambda: st["phone"].viewport_camera(
                    tuple(st["offered"][0]), fps=30.0
                )
            )
        if name == "no_overlays" and space is not None:
            was = space.overlay.show_overlays
            space.overlay.show_overlays = False
            undo.append(lambda: setattr(space.overlay, "show_overlays", was))
        if name == "solid_shading" and space is not None:
            was = space.shading.type
            space.shading.type = "SOLID"
            undo.append(lambda: setattr(space.shading, "type", was))
        return undo

    def next_variant():
        if not st["pending"]:
            finish()
            return None
        name = st["pending"].pop(0)
        st["variant"] = name
        st["undo"] = apply_variant(name)
        print(f"SPLIT variant {name}, {MEASURE_S}s", flush=True)
        bpy.app.timers.register(open_window, first_interval=WARMUP_S)
        return None

    def open_window():
        rows.clear()
        redraw_ms.clear()
        cam_quats.clear()
        st["measuring"] = True
        st["t0"] = time.perf_counter()
        bpy.app.timers.register(close_window, first_interval=MEASURE_S)
        return None

    def close_window():
        st["measuring"] = False
        span = time.perf_counter() - st["t0"]
        cap = st["state"].camera_capture
        row = {
            "variant": st["variant"],
            "span_s": round(span, 1),
            "captures": len(rows),
            "captures_per_s": round(len(rows) / span, 2) if span else None,
            "camera_travel_deg": round(travel_deg(), 1),
            "size": list(cap.stats()["size"]) if cap else None,
            "operator_redraw_ms": _summary(redraw_ms),
        }
        for key in SEGMENTS + ("total",):
            row[key] = _summary([r[key] for r in rows])
        if st["variant"].startswith("baseline"):
            with_gap = [r for r in rows if r["gap_ms"] is not None]
            with_gap.sort(key=lambda r: r["gap_ms"])
            if len(with_gap) >= 6:
                third = len(with_gap) // 3
                row["by_gap"] = {
                    label: {
                        "gap_ms_p50": _pct([r["gap_ms"] for r in group], 0.5),
                        **{
                            seg: _pct([r[seg] for r in group], 0.5)
                            for seg in ("draw", "read", "pack")
                        },
                    }
                    for label, group in (
                        ("shortest_gaps", with_gap[:third]),
                        ("middle_gaps", with_gap[third:2 * third]),
                        ("longest_gaps", with_gap[2 * third:]),
                    )
                }
        result["windows"].append(row)
        for undo in reversed(st["undo"]):
            undo()
        next_variant()
        return None

    def finish():
        st["phone"].stop_poses()
        st["sink"].stop()
        st["restore"]()
        for buf in st.get("pair") or []:
            buf.free()

        cap = st["state"].camera_capture
        result["capture_stats"] = cap.stats() if cap is not None else None
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
        print("SPLIT_RESULT " + json.dumps(result), flush=True)
        print("SPLIT_DONE", flush=True)
        os._exit(0)

    bpy.app.timers.register(begin, first_interval=3.0)


if __name__ == "__main__":
    main()
