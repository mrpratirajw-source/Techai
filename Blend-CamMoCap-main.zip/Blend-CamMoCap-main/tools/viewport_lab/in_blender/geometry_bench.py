# SPDX-License-Identifier: GPL-3.0-or-later
"""How much does it cost to ship the scene itself to the phone?

The 3D mode's premise is that geometry travels once and the phone then renders
from its own pose, so latency is zero by construction. That premise rests on
three numbers nobody has taken:

1. **How long does getting the geometry out of Blender take**, and how big is it?
2. **What does one edit cost?** If moving a single object forces a whole-scene
   resend, 3D mode needs an incremental sync protocol, which is a far larger
   design than "ship the scene". This is the number most likely to change the
   shape of the feature.
3. **Is glTF even the right container**, or is a flat binary buffer -- which the
   phone would have to be taught to read, but which needs no exporter -- cheaper
   by enough to matter?

Runs headless: geometry needs no GPU. Only the pixel capture did.
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path
from typing import Any, Dict, List

import bpy

_HERE = Path(__file__).resolve().parent
for _p in (str(_HERE), str(_HERE.parent)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import metrics_schema as ms  # noqa: E402
import scene_build  # noqa: E402


def _evaluated_meshes():
    """Every evaluated mesh in the scene, after modifiers.

    Evaluated, not source: a file whose meshes are light can still be heavy once
    subdivision and arrays are applied, and the source count would understate
    what actually has to travel.
    """
    dg = bpy.context.evaluated_depsgraph_get()
    for obj in bpy.context.scene.objects:
        if obj.type != "MESH":
            continue
        try:
            evaluated = obj.evaluated_get(dg)
            mesh = evaluated.to_mesh()
            if mesh is not None:
                yield evaluated, mesh
        except Exception:  # noqa: BLE001 - an unevaluable object is not fatal
            continue


def custom_binary(with_normals: bool = True, with_uvs: bool = True) -> Dict[str, Any]:
    """Pack the scene into flat interleaved buffers with numpy.

    The candidate that needs no exporter and no glTF parser on the phone: raw
    float32 positions (plus optional normals and UVs) and u32 indices, which is
    exactly what a GL vertex buffer wants. `foreach_get` copies straight out of
    Blender's arrays in C, so this should be far faster than any exporter that
    has to build a document first.
    """
    import numpy as np

    t0 = time.perf_counter()
    total_verts = 0
    total_tris = 0
    payload = 0
    for evaluated, mesh in _evaluated_meshes():
        if not len(mesh.loop_triangles) and hasattr(mesh, "calc_loop_triangles"):
            mesh.calc_loop_triangles()
        nverts = len(mesh.vertices)
        ntris = len(mesh.loop_triangles)
        if nverts == 0 or ntris == 0:
            evaluated.to_mesh_clear()
            continue

        co = np.empty(nverts * 3, dtype=np.float32)
        mesh.vertices.foreach_get("co", co)
        payload += co.nbytes

        idx = np.empty(ntris * 3, dtype=np.int32)
        mesh.loop_triangles.foreach_get("vertices", idx)
        payload += idx.astype(np.uint32).nbytes

        if with_normals:
            nrm = np.empty(nverts * 3, dtype=np.float32)
            try:
                mesh.vertices.foreach_get("normal", nrm)
                payload += nrm.nbytes
            except Exception:  # noqa: BLE001
                pass
        if with_uvs and mesh.uv_layers.active is not None:
            uvs = np.empty(len(mesh.loops) * 2, dtype=np.float32)
            try:
                mesh.uv_layers.active.data.foreach_get("uv", uvs)
                payload += uvs.nbytes
            except Exception:  # noqa: BLE001
                pass

        total_verts += nverts
        total_tris += ntris
        evaluated.to_mesh_clear()

    elapsed = (time.perf_counter() - t0) * 1000.0
    return {
        "ms": round(elapsed, 2),
        "bytes": payload,
        "vertices": total_verts,
        "triangles": total_tris,
    }


def gltf_export(path: Path, draco: bool) -> Dict[str, Any]:
    """Export a .glb, optionally Draco-compressed.

    An operator, so it runs from this script's context and never from a timer --
    `bl/apply.py` documents what calling operators from a timer did to Blender.
    """
    if path.exists():
        path.unlink()
    kwargs: Dict[str, Any] = {
        "filepath": str(path),
        "export_format": "GLB",
        "use_selection": False,
    }
    if draco:
        kwargs["export_draco_mesh_compression_enable"] = True
        kwargs["export_draco_mesh_compression_level"] = 6

    t0 = time.perf_counter()
    try:
        bpy.ops.export_scene.gltf(**kwargs)
    except Exception as exc:  # noqa: BLE001 - report, do not abort the matrix
        return {"error": f"{type(exc).__name__}: {exc}", "draco": draco}
    elapsed = (time.perf_counter() - t0) * 1000.0
    return {
        "ms": round(elapsed, 2),
        "bytes": path.stat().st_size if path.exists() else 0,
        "draco": draco,
    }


def depsgraph_eval_ms() -> float:
    """Cost of one full evaluation, which any resend has to pay first."""
    t0 = time.perf_counter()
    bpy.context.view_layer.update()
    bpy.context.evaluated_depsgraph_get()
    return round((time.perf_counter() - t0) * 1000.0, 3)


def delta_after_edit(tmp: Path) -> Dict[str, Any]:
    """Move one object, re-export, and compare.

    **The number that decides whether 3D mode needs an incremental protocol.**
    A glTF is a container: nudging one object rewrites its node transform, but
    the mesh buffers are unchanged, so a naive differ that only sees "the file
    changed" would resend everything. Comparing byte-identical prefixes is a
    proxy for how much a smart differ could avoid.
    """
    import numpy as np

    before = tmp / "before.glb"
    after = tmp / "after.glb"
    first = gltf_export(before, draco=False)
    if "error" in first:
        return first

    target = next(
        (o for o in bpy.context.scene.objects if o.type == "MESH"), None
    )
    if target is None:
        return {"error": "no mesh object to move"}
    target.location.x += 0.25
    bpy.context.view_layer.update()

    second = gltf_export(after, draco=False)
    if "error" in second:
        return second

    a = np.frombuffer(before.read_bytes(), dtype=np.uint8)
    b = np.frombuffer(after.read_bytes(), dtype=np.uint8)
    common = min(a.size, b.size)
    differing = int(np.count_nonzero(a[:common] != b[:common])) + abs(a.size - b.size)

    target.location.x -= 0.25  # leave the scene as we found it
    bpy.context.view_layer.update()
    return {
        "export_ms": second["ms"],
        "total_bytes": int(b.size),
        "differing_bytes": differing,
        "differing_pct": round(differing / max(1, b.size) * 100.0, 3),
    }


def measure_scene(scene_id: str, tmp: Path) -> Dict[str, Any]:
    row: Dict[str, Any] = {"scene": scene_id}
    row["depsgraph_eval_ms"] = depsgraph_eval_ms()
    row["custom_binary"] = custom_binary()
    row["gltf"] = gltf_export(tmp / f"{scene_id}.glb", draco=False)
    row["gltf_draco"] = gltf_export(tmp / f"{scene_id}_draco.glb", draco=True)
    row["delta_after_edit"] = delta_after_edit(tmp)

    # zstd is already in Blender's Python, and geometry -- unlike video frames --
    # is exactly the kind of data it compresses well.
    try:
        import zstandard

        blob = (tmp / f"{scene_id}.glb").read_bytes()
        compressor = zstandard.ZstdCompressor(level=3)
        t0 = time.perf_counter()
        packed = compressor.compress(blob)
        row["gltf_zstd"] = {
            "ms": round((time.perf_counter() - t0) * 1000.0, 2),
            "bytes": len(packed),
            "ratio": round(len(blob) / max(1, len(packed)), 2),
        }
    except Exception as exc:  # noqa: BLE001
        row["gltf_zstd"] = {"error": str(exc)}
    return row


def main() -> None:
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    import argparse

    ap = argparse.ArgumentParser(prog="geometry_bench")
    ap.add_argument("--scenes", default="synth_10k,synth_100k,synth_1m,synth_1m_manyobj")
    ap.add_argument("--blend", default=None)
    ap.add_argument("--label", default="local")
    ap.add_argument("--out", required=True)
    ap.add_argument("--tmp", default=None)
    args = ap.parse_args(argv)

    tmp = Path(args.tmp or (Path(args.out).parent / "geom_tmp"))
    tmp.mkdir(parents=True, exist_ok=True)
    results = ms.new_results("phase6")

    if args.blend:
        import hashlib

        blend = Path(args.blend)
        results["scene_info"] = {
            "source": "local-scene",
            "path": str(blend),
            "sha256": hashlib.sha256(blend.read_bytes()).hexdigest(),
        }
        ms.add_row(results, measure_scene(args.label, tmp))
    else:
        for scene_id in [s.strip() for s in args.scenes.split(",") if s.strip()]:
            info = scene_build.build_by_id(scene_id)
            row = measure_scene(scene_id, tmp)
            row["tri_count_actual"] = info["tri_count_actual"]
            row["object_count"] = info["object_count"]
            ms.add_row(results, row)

    ms.note(results, "Sizes are what leaves Blender, before any transport "
                     "framing. Textures are counted only as they appear inside "
                     "the .glb; a scene with large image textures moves far more "
                     "than its geometry alone.")
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8", newline="\n")
    print("GEOMETRY_BENCH " + json.dumps({"out": str(out)}))


if __name__ == "__main__":
    main()
