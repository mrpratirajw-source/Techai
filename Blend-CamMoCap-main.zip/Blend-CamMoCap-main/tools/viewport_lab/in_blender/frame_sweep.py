# SPDX-License-Identifier: GPL-3.0-or-later
"""Capture one frame under each awkward scene condition, and look at all of them.

Rendered shading streamed a black frame to the phone for a day, and nothing
anywhere reported an error: the capture ran, the rate was met, the header was
correct, the JPEG decoded. It was simply a picture of nothing, because Cycles
draws its viewport progressively and an offscreen draw asks once. It was found
by an operator switching shading, not by anything here.

That is a class, not an incident. Everything in this channel borrows the
operator's 3D view and the scene's settings, and each borrowed setting is a
condition nobody has drawn under. This walks the ones with a plausible route to
a wrong picture, captures a frame through the **shipped** `capture_camera_rgb`
for each, and writes a contact sheet so they can be judged the only way this
class can be judged -- by eye.

Per condition it also prints the two statistics that separate the failure modes
from a working frame without opening it:

- `mean` near 0 is black.
- `detail`, the mean absolute difference between horizontally adjacent pixels,
  near 0 is a flat fill -- a render of nothing. A real solid-shaded frame of
  this scene scores about 5.

Deliberately NOT covered, because the automated route to it is the documented
crash: local view, which needs `bpy.ops.view3d.localview` and `bpy.ops` must
never be called from a timer. It stays an untested condition rather than a
crashed probe.

    blender scene.blend --python tools/viewport_lab/in_blender/frame_sweep.py \\
        -- --out results/sweep.png
"""

from __future__ import annotations

import json
import os
import pathlib
import sys

import bpy
import gpu

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from take_contention import _addon  # noqa: E402

WIDTH, HEIGHT = 480, 330
COLUMNS = 4


def _conditions(scene, space):
    """(name, apply, restore) for each condition, applied one at a time.

    Every one restores what it touched. A probe that leaves the operator's
    scene altered has changed the thing every later row is measured against.
    """
    render = scene.render
    camera = scene.camera.data

    def setter(obj, attr, value):
        def apply():
            previous = getattr(obj, attr)
            setattr(obj, attr, value)
            return lambda: setattr(obj, attr, previous)
        return apply

    def world_off():
        previous = scene.world
        scene.world = None
        return lambda: setattr(scene, "world", previous)

    def pixel_aspect():
        was = (render.pixel_aspect_x, render.pixel_aspect_y)
        render.pixel_aspect_x, render.pixel_aspect_y = 2.0, 1.0
        return lambda: setattr_pair(render, was)

    def setattr_pair(obj, pair):
        obj.pixel_aspect_x, obj.pixel_aspect_y = pair

    def under(shading, apply):
        """Run a scene condition with the shading that can actually show it.

        The first version of this file did not do this, and it is the same
        mistake twice over: film transparency, an absent world and depth of
        field were all applied while the viewport happened to be in Solid, and
        Solid honours none of them. Every one of those rows came back byte for
        byte identical to the baseline, and would have been reported as "tested"
        for a condition it never exercised.
        """
        def wrapped():
            was = space.shading.type
            space.shading.type = shading
            undo = apply()

            def restore():
                undo()
                space.shading.type = was
            return restore
        return wrapped

    return [
        ("solid", setter(space.shading, "type", "SOLID")),
        ("wireframe", setter(space.shading, "type", "WIREFRAME")),
        ("material", setter(space.shading, "type", "MATERIAL")),
        ("rendered", setter(space.shading, "type", "RENDERED")),
        # Alpha is the oldest wound on this path: the deleted framebuffer mode
        # shipped black objects because it dropped a premultiplied alpha. We now
        # read three channels and never see alpha at all, so a transparent film
        # is the one setting that could bring the same failure back.
        ("film_transparent",
         under("MATERIAL", setter(render, "film_transparent", True))),
        ("no_world", under("MATERIAL", world_off)),
        # An orthographic camera goes through a different projection matrix.
        ("ortho_camera", setter(camera, "type", "ORTHO")),
        # Shift moves the frame without moving the camera, so a viewfinder that
        # ignored it would frame a shot that is not the shot.
        ("camera_shift", setter(camera, "shift_x", 0.25)),
        # A non-square pixel aspect stretches the render. If the viewfinder does
        # not stretch with it, the operator is judging the wrong proportions.
        ("pixel_aspect_2_1", pixel_aspect),
        ("dof", under("MATERIAL", setter(camera.dof, "use_dof", True))),
        # Half-size render. camera_sizes reads resolution_x/y and ignores the
        # percentage, so this is really a question about the advertised list.
        ("resolution_50pct", setter(render, "resolution_percentage", 50)),
    ]


def main() -> None:
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    out_path = (
        pathlib.Path(argv[argv.index("--out") + 1]) if "--out" in argv
        else pathlib.Path("frame-sweep.png")
    )

    def shoot():
        import numpy as np

        vp = _addon().get("viewport")
        if vp is None:
            print("SWEEP_ERROR add-on not found", flush=True)
            os._exit(1)
        found = vp.find_view3d()
        if found is None:
            print("SWEEP_ERROR no 3D view open", flush=True)
            os._exit(1)
        _area, region, space = found
        scene = bpy.context.scene
        if scene.camera is None:
            print("SWEEP_ERROR no scene camera", flush=True)
            os._exit(1)

        rows = []
        tiles = []
        for name, apply in _conditions(scene, space):
            undo = apply()
            try:
                offscreen = gpu.types.GPUOffScreen(WIDTH, HEIGHT)
                try:
                    captured = vp.capture_camera_rgb(
                        offscreen, scene, space, region, WIDTH, HEIGHT
                    )
                finally:
                    offscreen.free()
            finally:
                undo()

            if captured is None:
                rows.append({"condition": name, "error": "no frame"})
                tiles.append(np.zeros((HEIGHT, WIDTH, 3), dtype=np.uint8))
                continue
            payload, w, h = captured
            pixels = np.frombuffer(payload, dtype=np.uint8).reshape(h, w, 3)
            detail = float(
                np.abs(np.diff(pixels[:, :, 0].astype(np.int16), axis=1)).mean()
            )
            rows.append({
                "condition": name,
                "size": [w, h],
                "mean": round(float(pixels.mean()), 1),
                "detail": round(detail, 2),
                # The largest size the host would advertise under this
                # condition, because the size list is derived from the render
                # settings and some of these conditions change them.
                "advertised": vp.viewport_stream.camera_sizes(
                    scene.render.resolution_x, scene.render.resolution_y
                )[0],
            })
            tiles.append(pixels)

        print("SWEEP_TABLE " + json.dumps(rows), flush=True)
        for row in rows:
            print(
                "SWEEP %-18s mean=%-6s detail=%-6s %s" % (
                    row["condition"], row.get("mean", "-"), row.get("detail", "-"),
                    row.get("error", ""),
                ),
                flush=True,
            )

        # One contact sheet, in the order printed above. Reading eleven separate
        # files is eleven chances to correlate the wrong picture with the wrong
        # label; a grid in a known order is one.
        cols = COLUMNS
        rows_n = (len(tiles) + cols - 1) // cols
        sheet = np.full(
            (rows_n * HEIGHT, cols * WIDTH, 3), 32, dtype=np.uint8
        )
        for index, tile in enumerate(tiles):
            r, c = divmod(index, cols)
            sheet[r * HEIGHT:(r + 1) * HEIGHT, c * WIDTH:(c + 1) * WIDTH] = tile
            # A one-pixel border, so an all-black tile is still visibly a tile
            # rather than a hole in the sheet.
            sheet[r * HEIGHT, c * WIDTH:(c + 1) * WIDTH] = 200
            sheet[r * HEIGHT:(r + 1) * HEIGHT, c * WIDTH] = 200

        sh, sw = sheet.shape[:2]
        image = bpy.data.images.new("pocketrig_sweep", width=sw, height=sh, alpha=False)
        rgba = np.ones((sh, sw, 4), dtype=np.float32)
        rgba[:, :, :3] = sheet[::-1] / 255.0
        image.pixels.foreach_set(rgba.ravel())
        out_path.parent.mkdir(parents=True, exist_ok=True)
        image.filepath_raw = str(out_path.resolve())
        image.file_format = "PNG"
        image.save()
        print(f"SWEEP_WROTE {out_path}", flush=True)
        print("SWEEP_DONE", flush=True)
        os._exit(0)

    bpy.app.timers.register(shoot, first_interval=3.0)


if __name__ == "__main__":
    main()
