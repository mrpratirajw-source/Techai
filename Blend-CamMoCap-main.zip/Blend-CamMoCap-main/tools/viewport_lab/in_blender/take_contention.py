# SPDX-License-Identifier: GPL-3.0-or-later
"""Does streaming the camera cost the take anything?

The one interaction on this channel that can damage real work rather than a
preview. Camera mode spends ~11 ms of Blender's main thread per frame, and
`spec/viewport-channel.md` §2 says the pose path MUST win when the two compete.
This measures whether it does.

**The take's own sample count is the metric.** A first version of this measured
`state.last_seq`, which is the newest sequence *received* and advances on the UDP
thread whatever the main thread is doing -- it reported ~100/s in both windows
and proved nothing. Two takes are recorded instead, one with the stream off and
one with it on, and their baked sample counts compared. That is keyframe density,
which is what a take is made of.

Reading the code says this should be safe: `_record_buffer.append` happens inside
`_handle`, on the receive thread, so a live take is structurally insulated from
main-thread contention, and an offline take is recorded on the phone entirely.
The measurement exists because "should" is not "does", and because the main
thread is where the operator's own interactivity lives.

Interactive Blender only: `gpu` drawing raises under `--background`, so this
cannot join the headless suites.

    blender scene.blend --python tools/viewport_lab/in_blender/take_contention.py \\
        -- --out results/p8-take-contention.json
"""

from __future__ import annotations

import json
import pathlib
import socket
import sys
import threading
import time

import bpy

POSE_HZ = 100.0
WINDOW_S = 6.0


def _addon():
    """The installed extension's modules, however it was installed."""
    mods = {}
    for name, mod in list(sys.modules.items()):
        if "pocketrig" not in name:
            continue
        for tail in (".bl.state", ".bl.apply", ".core.protocol", ".bl.viewport"):
            if name.endswith(tail):
                mods[tail.rsplit(".", 1)[1]] = mod
    return mods


class FakePhone:
    """Minimal protocol-correct client, using the host's own encoders.

    Built on `core.protocol` rather than hand-rolled bytes: a wire mistake here
    would show up as contention that is not there.
    """

    def __init__(self, protocol, port: int, token: str) -> None:
        self.P = protocol
        self.addr = ("127.0.0.1", port)
        self.token = token
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.settimeout(1.0)
        self.seq = 0
        self.sent = 0
        self._running = threading.Event()
        self._thread = None

    def _next(self) -> int:
        self.seq += 1
        return self.seq

    def hello(self) -> None:
        self.sock.sendto(
            self.P.encode_hello(
                self._next(), time.monotonic_ns(),
                "contention-probe", "probe", self.token,
            ),
            self.addr,
        )

    def go_live(self) -> None:
        """Unpause the host, which no probe can skip and one probe did.

        An interactive host starts PAUSED on pairing on purpose (`apply_tick`:
        "start PAUSED so the camera is not fighting the user"). Poses sent
        before this move nothing at all, so a probe that omits it measures an
        idle Blender wearing a load's clothes -- and reports numbers for it.
        """
        self.sock.sendto(
            self.P.encode_pause(self._next(), time.monotonic_ns(), False),
            self.addr,
        )

    def record_start(self) -> None:
        self.sock.sendto(
            self.P.encode_record_start(
                self._next(), time.monotonic_ns(), time.monotonic_ns()
            ),
            self.addr,
        )

    def viewport_camera(self, size, fps=20.0, quality=75, profile=None) -> None:
        """Start the stream the way the phone does -- a real control message.

        A probe that pokes CameraCapture directly measures a different program
        from the one that ships.
        """
        self.sock.sendto(
            self.P.encode_viewport_control(
                self._next(), time.monotonic_ns(), "camera",
                codec="jpeg", size=size, fps=fps, quality=quality,
                profile=profile,
            ),
            self.addr,
        )

    def record_stop(self, end_ns: int, count: int) -> None:
        self.sock.sendto(
            self.P.encode_record_stop(
                self._next(), time.monotonic_ns(), end_ns, count, offline=False
            ),
            self.addr,
        )

    def start_poses(self) -> None:
        """A steady 100 Hz of gently moving poses, on its own thread."""
        self._running.set()

        def loop():
            import math

            t0 = time.perf_counter()
            period = 1.0 / POSE_HZ
            nxt = t0
            while self._running.is_set():
                now = time.perf_counter()
                if now < nxt:
                    time.sleep(max(0.0, nxt - now))
                nxt += period
                # A slow yaw, so the host has real work and the camera actually
                # moves -- a frozen pose would let the idle skip suppress every
                # frame and measure nothing.
                a = (time.perf_counter() - t0) * 0.4
                q = (math.cos(a / 2), 0.0, 0.0, math.sin(a / 2))
                try:
                    self.sock.sendto(
                        self.P.encode_pose(
                            self._next(), time.monotonic_ns(), q
                        ),
                        self.addr,
                    )
                    self.sent += 1
                except OSError:
                    pass

        self._thread = threading.Thread(target=loop, name="probe-poses", daemon=True)
        self._thread.start()

    def stop_poses(self) -> None:
        self._running.clear()
        if self._thread is not None:
            self._thread.join(timeout=1.0)


class FrameSink:
    """Reads the viewport stream and throws it away.

    Capture refuses to run with nobody connected, so the measurement needs a
    viewer. Discarding is the point: this measures the host, not the client.
    """

    def __init__(self, port: int, token: str) -> None:
        self.port = port
        self.token = token
        self.frames = 0
        self._running = threading.Event()
        self._thread = None

    def start(self) -> None:
        self._running.set()

        def loop():
            try:
                conn = socket.create_connection(("127.0.0.1", self.port), timeout=3)
                conn.sendall((self.token + "\n").encode())
                conn.settimeout(1.0)
                while self._running.is_set():
                    head = conn.recv(28)
                    if not head:
                        break
                    if len(head) < 28:
                        continue
                    length = int.from_bytes(head[24:28], "little")
                    got = 0
                    while got < length and self._running.is_set():
                        chunk = conn.recv(min(65536, length - got))
                        if not chunk:
                            return
                        got += len(chunk)
                    self.frames += 1
                conn.close()
            except OSError:
                pass

        self._thread = threading.Thread(target=loop, name="probe-sink", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._running.clear()


def _drain_bake(srv) -> int:
    """Total samples across every bake request queued so far.

    Drained rather than peeked: the queue is consumed by whoever asks, and a
    leftover from the first take would be counted again in the second.
    """
    total = 0
    while True:
        req = srv.take_bake_request()
        if req is None:
            return total
        total += len(req.samples)


def main() -> None:
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    out_path = pathlib.Path(argv[argv.index("--out") + 1]) if "--out" in argv \
        else pathlib.Path("take-contention.json")

    result = {"format": "pocketrig-take-contention", "version": 2, "takes": []}
    st = {"phase": 0}

    def begin():
        mods = _addon()
        if "state" not in mods or "protocol" not in mods:
            print("CONT_ERROR add-on modules not found", flush=True)
            return None
        try:
            bpy.ops.pocketrig.connect()
        except Exception as exc:  # noqa: BLE001
            print(f"CONT_ERROR connect: {exc}", flush=True)
            return None
        state = mods["state"]
        srv = state.server
        if srv is None:
            print("CONT_ERROR no server", flush=True)
            return None

        phone = FakePhone(mods["protocol"], srv.port, srv.token)
        phone.hello()
        time.sleep(0.5)
        phone.start_poses()
        print(f"CONT ready, viewport_port={srv.viewport_port}", flush=True)
        st.update(phone=phone, state=state, srv=srv, sink=None, mods=mods)
        bpy.app.timers.register(window_a, first_interval=1.5)
        return None

    def window_a():
        print("CONT take A: recording, stream OFF", flush=True)
        st["phone"].record_start()
        st["t_a0"] = time.perf_counter()
        bpy.app.timers.register(end_take_a, first_interval=WINDOW_S)
        return None

    def end_take_a():
        st["t_a1"] = time.perf_counter()
        phone, srv = st["phone"], st["srv"]
        phone.record_stop(time.monotonic_ns(), 0)
        time.sleep(0.4)
        st["take_a"] = _drain_bake(srv)
        print(f"CONT take A samples={st['take_a']}", flush=True)
        bpy.app.timers.register(start_stream, first_interval=0.5)
        return None

    def start_stream():
        srv = st["srv"]
        sink = FrameSink(srv.viewport_port, srv.token)
        sink.start()
        st["sink"] = sink
        time.sleep(0.3)
        # Whatever the host advertised for this scene; asking for anything else
        # earns viewport_unsupported and measures nothing.
        offered = (srv.viewport_video or {}).get("camera_sizes") or []
        size = tuple(offered[0]) if offered else None
        st["size"] = list(size) if size else None
        st["phone"].viewport_camera(size)
        # Let capture actually get going before the take starts, or window B
        # measures the ramp rather than the steady state.
        bpy.app.timers.register(window_b, first_interval=2.0)
        return None

    def window_b():
        print("CONT take B: recording, stream ON", flush=True)
        st["phone"].record_start()
        st["t_b0"] = time.perf_counter()
        st["frames_at_b0"] = st["sink"].frames
        bpy.app.timers.register(finish, first_interval=WINDOW_S)
        return None

    def finish():
        st["t_b1"] = time.perf_counter()
        phone, srv = st["phone"], st["srv"]
        phone.record_stop(time.monotonic_ns(), 0)
        time.sleep(0.4)
        st["take_b"] = _drain_bake(srv)
        phone.stop_poses()
        if st["sink"] is not None:
            st["sink"].stop()

        cap = st["state"].camera_capture
        a, b = st["take_a"], st["take_b"]
        span_a = st["t_a1"] - st["t_a0"]
        span_b = st["t_b1"] - st["t_b0"]
        result["takes"] = [
            {"name": "stream_off", "samples": a, "span_s": round(span_a, 2),
             "samples_per_s": round(a / span_a, 1) if span_a else None},
            {"name": "stream_on", "samples": b, "span_s": round(span_b, 2),
             "samples_per_s": round(b / span_b, 1) if span_b else None},
        ]
        if span_a and span_b and a:
            ra, rb = a / span_a, b / span_b
            result["take_density_delta_pct"] = round((rb - ra) / ra * 100.0, 1)
        result["poses_sent"] = phone.sent
        result["frames_during_take_b"] = (
            st["sink"].frames - st.get("frames_at_b0", 0) if st["sink"] else 0
        )
        result["stream_size"] = st.get("size")
        result["capture"] = cap.stats() if cap is not None else None
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
        print("CONT_RESULT " + json.dumps(result), flush=True)
        print("CONT_DONE", flush=True)
        return None

    bpy.app.timers.register(begin, first_interval=3.0)


if __name__ == "__main__":
    main()
