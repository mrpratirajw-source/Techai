# SPDX-License-Identifier: GPL-3.0-or-later
"""Write one real captured frame to a PNG, so it can be looked at.

The only check that catches the class of bug this path keeps producing. Twice a
change to the readback shipped something that decoded without error and was not
the picture: `np.asarray` reading a `gpu.types.Buffer` through its own lying
strides gave a channel-planar permutation, and a missing flip gave an
upside-down frame. Both passed every automated check there was, because both
produced a well-formed image of exactly the right size.

So this calls the **shipped** `capture_camera_rgb`, writes what it returned, and
prints statistics chosen for the two known failure modes:

- `adjacent_delta` -- mean absolute difference between horizontally neighbouring
  pixels. A real render of a solid-shaded scene is smooth and scores low single
  digits; a channel-planar permutation decorrelates neighbours and sends it into
  the tens.
- `top` and `bottom` -- mean brightness of the top and bottom quarters. A scene
  lit from above with a floor below is asymmetric, so a vertical flip swaps
  them. Not conclusive on its own, which is why the PNG is the real deliverable.

    blender scene.blend --python tools/viewport_lab/in_blender/dump_frame.py \\
        -- --out results/frame-check.png
"""

from __future__ import annotations

import os
import pathlib
import sys

import bpy
import gpu

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from take_contention import _addon  # noqa: E402

WIDTH, HEIGHT = 640, 440


def main() -> None:
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    out_path = (
        pathlib.Path(argv[argv.index("--out") + 1]) if "--out" in argv
        else pathlib.Path("frame-check.png")
    )
    shading = argv[argv.index("--shading") + 1] if "--shading" in argv else None
    engine = argv[argv.index("--engine") + 1] if "--engine" in argv else None

    def shoot():
        import numpy as np

        vp = _addon().get("viewport")
        if vp is None:
            print("DUMP_ERROR add-on not found", flush=True)
            os._exit(1)
        found = vp.find_view3d()
        if found is None:
            print("DUMP_ERROR no 3D view open", flush=True)
            os._exit(1)
        _area, region, space = found

        # Both ways round, in one run. `draw_view3d` borrows a real 3D view's
        # settings, so whatever the operator has switched on is drawn into our
        # buffer too -- and a viewfinder showing the 3D cursor is showing
        # something that is not in the shot. Whether the master overlay switch
        # actually suppresses that in an OFFSCREEN draw is not documented
        # anywhere, so it gets checked rather than assumed.
        if engine:
            bpy.context.scene.render.engine = engine
        if shading:
            space.shading.type = shading
        print(
            f"DUMP shading={space.shading.type} "
            f"engine={bpy.context.scene.render.engine}",
            flush=True,
        )

        # A raw four-channel read of the same view, so alpha can be looked at.
        # A black frame with alpha 0 is a compositing problem; a black frame
        # with alpha 255 is a drawing one, and they have nothing in common.
        raw = gpu.types.GPUOffScreen(WIDTH, HEIGHT)
        try:
            depsgraph = bpy.context.evaluated_depsgraph_get()
            camera = bpy.context.scene.camera.evaluated_get(depsgraph)
            raw.draw_view3d(
                bpy.context.scene, bpy.context.view_layer, space, region,
                camera.matrix_world.inverted(),
                camera.calc_matrix_camera(depsgraph, x=WIDTH, y=HEIGHT),
                do_color_management=True,
            )
            with raw.bind():
                fb = gpu.state.active_framebuffer_get()
                buf = fb.read_color(0, 0, WIDTH, HEIGHT, 4, 0, "UBYTE")
                buf.dimensions = WIDTH * HEIGHT * 4
                rgba = np.frombuffer(buf, dtype=np.uint8).reshape(
                    HEIGHT, WIDTH, 4
                ).copy()
        finally:
            raw.free()
        print(
            "DUMP rgba rgb_mean=%.1f alpha_mean=%.1f alpha_min=%d alpha_max=%d "
            "nonzero_rgb=%.2f%%" % (
                rgba[:, :, :3].mean(), rgba[:, :, 3].mean(),
                rgba[:, :, 3].min(), rgba[:, :, 3].max(),
                100.0 * (rgba[:, :, :3].any(axis=2)).mean(),
            ),
            flush=True,
        )

        shots = {}
        for label, wanted in (("overlays", True), ("clean", False)):
            offscreen = gpu.types.GPUOffScreen(WIDTH, HEIGHT)
            try:
                shots[label] = vp.capture_camera_rgb(
                    offscreen, bpy.context.scene, space, region,
                    WIDTH, HEIGHT, wanted,
                )
            finally:
                offscreen.free()
        # The shipped function borrows and restores the operator's setting
        # itself, so this must NOT do it too -- a probe that reproduces the
        # behaviour it is checking cannot catch it being wrong.
        if space.overlay.show_overlays is not True:
            print("DUMP_WARN operator overlay setting was not restored", flush=True)

        if any(v is None for v in shots.values()):
            print("DUMP_ERROR no scene camera", flush=True)
            os._exit(1)

        payload, w, h = shots["overlays"]
        expected = w * h * 3
        if len(payload) != expected:
            print(
                f"DUMP_ERROR {len(payload)} bytes for {w}x{h}, expected {expected}",
                flush=True,
            )
            os._exit(1)
        pixels = np.frombuffer(payload, dtype=np.uint8).reshape(h, w, 3)

        adjacent = float(
            np.abs(np.diff(pixels[:, :, 0].astype(np.int16), axis=1)).mean()
        )
        print(
            f"DUMP size={w}x{h} mean={pixels.mean():.1f} "
            f"adjacent_delta={adjacent:.2f} "
            f"top={pixels[: h // 4].mean():.1f} "
            f"bottom={pixels[-(h // 4):].mean():.1f}",
            flush=True,
        )

        clean = np.frombuffer(shots["clean"][0], dtype=np.uint8).reshape(h, w, 3)
        differing = int((pixels != clean).any(axis=2).sum())
        print(
            f"DUMP overlay_pixels_changed={differing} "
            f"({100.0 * differing / (w * h):.2f}%)",
            flush=True,
        )

        out_path.parent.mkdir(parents=True, exist_ok=True)
        for label, (body, bw, bh) in shots.items():
            arr = np.frombuffer(body, dtype=np.uint8).reshape(bh, bw, 3)
            image = bpy.data.images.new(
                f"pocketrig_{label}", width=bw, height=bh, alpha=False
            )
            # Blender's image buffer is bottom-up float RGBA; the payload is the
            # top-down RGB the phone receives, so flipping back here is what
            # makes the PNG show what the phone shows.
            rgba = np.ones((bh, bw, 4), dtype=np.float32)
            rgba[:, :, :3] = arr[::-1] / 255.0
            image.pixels.foreach_set(rgba.ravel())
            path = out_path.with_name(f"{out_path.stem}-{label}{out_path.suffix}")
            image.filepath_raw = str(path.resolve())
            image.file_format = "PNG"
            image.save()
            print(f"DUMP_WROTE {path}", flush=True)
        print("DUMP_DONE", flush=True)
        os._exit(0)

    bpy.app.timers.register(shoot, first_interval=3.0)


if __name__ == "__main__":
    main()
