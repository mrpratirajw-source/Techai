# SPDX-License-Identifier: GPL-3.0-or-later
"""Where does the 50 ms capture come from?

`capture_cost.py` measures the steady state and finds 2.5-5 ms. But a loaded run
-- a take recording, 100 Hz of pose, a viewer attached -- reported a single
`capture_ms` of 50.6 ms. That was the last instantaneous value rather than a
distribution, so it said something happened without saying how often.

This times **every** capture under exactly that load, by wrapping
`viewport.capture_camera_rgb` for the duration. Wrapping the module function
rather than sampling `cap.capture_ms` from a timer matters: the field is
overwritten per frame, so a poller sees whichever value it happened to land on
and cannot see a spike's frequency at all.

The 20 fps default currently rests on this spike being real. If it is rare and
bounded the default can go up; if it is regular, something contends and that is
worth knowing before more is built on this channel.

Interactive Blender only.

    blender scene.blend --python tools/viewport_lab/in_blender/capture_spike.py \\
        -- --out results/p10-capture-spike.json
"""

from __future__ import annotations

import json
import pathlib
import sys
import time

import bpy

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from take_contention import FakePhone, FrameSink, _addon  # noqa: E402

MEASURE_S = 20.0


def _pct(values, q):
    if not values:
        return None
    ordered = sorted(values)
    return round(ordered[min(len(ordered) - 1, int(len(ordered) * q))], 2)


def main() -> None:
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    out_path = (
        pathlib.Path(argv[argv.index("--out") + 1]) if "--out" in argv
        else pathlib.Path("capture-spike.json")
    )
    result = {"format": "pocketrig-capture-spike", "version": 1}
    st = {"samples": []}

    def begin():
        mods = _addon()
        vp = mods.get("viewport")
        if vp is None or "protocol" not in mods:
            print("SPIKE_ERROR add-on not found", flush=True)
            return None
        try:
            bpy.ops.pocketrig.connect()
        except Exception as exc:  # noqa: BLE001
            print(f"SPIKE_ERROR connect: {exc}", flush=True)
            return None
        state = mods["state"]
        srv = state.server
        if srv is None:
            print("SPIKE_ERROR no server", flush=True)
            return None

        # Wrap the real function. CameraCapture.tick looks it up as a module
        # global, so this is the code path that ships, timed from outside.
        original = vp.capture_camera_rgb
        samples = st["samples"]

        def timed(*args, **kwargs):
            t0 = time.perf_counter()
            try:
                return original(*args, **kwargs)
            finally:
                samples.append((time.perf_counter() - t0) * 1000.0)

        vp.capture_camera_rgb = timed
        st["restore"] = lambda: setattr(vp, "capture_camera_rgb", original)

        phone = FakePhone(mods["protocol"], srv.port, srv.token)
        phone.hello()
        time.sleep(0.4)
        phone.start_poses()
        phone.record_start()

        sink = FrameSink(srv.viewport_port, srv.token)
        sink.start()
        time.sleep(0.3)
        offered = (srv.viewport_video or {}).get("camera_sizes") or []
        size = tuple(offered[0]) if offered else None
        phone.viewport_camera(size)
        result["size"] = list(size) if size else None
        print(f"SPIKE loaded run at {size}, {MEASURE_S}s", flush=True)

        st.update(phone=phone, sink=sink, state=state, t0=time.perf_counter())
        bpy.app.timers.register(finish, first_interval=MEASURE_S)
        return None

    def finish():
        st["phone"].stop_poses()
        st["phone"].record_stop(time.monotonic_ns(), 0)
        st["sink"].stop()
        st["restore"]()

        vals = st["samples"]
        span = time.perf_counter() - st["t0"]
        result["n"] = len(vals)
        result["span_s"] = round(span, 1)
        result["captures_per_s"] = round(len(vals) / span, 1) if span else None
        for q, name in ((0.50, "p50"), (0.90, "p90"), (0.95, "p95"), (0.99, "p99")):
            result[f"ms_{name}"] = _pct(vals, q)
        result["ms_max"] = round(max(vals), 2) if vals else None
        result["ms_mean"] = round(sum(vals) / len(vals), 2) if vals else None
        # How often is it actually bad? A p95 hides whether 50 ms happens once a
        # minute or five times a second, and only the second is a problem.
        for limit in (10, 20, 50):
            over = [v for v in vals if v >= limit]
            result[f"over_{limit}ms_count"] = len(over)
            result[f"over_{limit}ms_pct"] = (
                round(len(over) / len(vals) * 100.0, 2) if vals else None
            )
        # The first captures at a new size allocate the offscreen and warm
        # caches; if the spike lives only there it is a startup cost, not
        # contention.
        result["first_5_ms"] = [round(v, 2) for v in vals[:5]]
        cap = st["state"].camera_capture
        result["capture_stats"] = cap.stats() if cap is not None else None

        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
        print("SPIKE_RESULT " + json.dumps(result), flush=True)
        print("SPIKE_DONE", flush=True)
        return None

    bpy.app.timers.register(begin, first_interval=3.0)


if __name__ == "__main__":
    main()
