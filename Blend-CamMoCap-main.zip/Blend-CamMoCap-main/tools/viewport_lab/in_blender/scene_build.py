# SPDX-License-Identifier: GPL-3.0-or-later
"""Builds the synthetic scene ladder inside Blender.

Runs happily under `--background` -- geometry construction needs no GPU, only
the capture does. That split is deliberate: scenes can be built and their
triangle counts verified in CI-ish conditions, and only the measurement itself
demands a real window.

The object-count rung uses **linked duplicates**: one mesh datablock shared by
every object. That isolates the axis being measured. Giving each object its own
mesh would vary memory and depsgraph cost at the same time as draw-call count,
and the pair `synth_1m` / `synth_1m_manyobj` would then differ in three ways
instead of one.
"""

from __future__ import annotations

import math
import sys
from pathlib import Path
from typing import Dict

import bpy

# Importable both as a package module and as a loose script inside Blender,
# which has no notion of this repo's layout.
_HERE = Path(__file__).resolve().parent
if str(_HERE.parent) not in sys.path:
    sys.path.insert(0, str(_HERE.parent))

from scenes import BY_ID, SceneSpec  # noqa: E402


def _clear() -> None:
    """Empty the file without operators.

    `bpy.ops.object.select_all` / `delete` need a proper context override and
    are the class of call this project has already been bitten by. Removing the
    datablocks directly works in every context, including a fresh
    `--factory-startup` with no window.
    """
    for coll in (
        bpy.data.objects,
        bpy.data.meshes,
        bpy.data.materials,
        bpy.data.lights,
        bpy.data.cameras,
    ):
        for item in list(coll):
            coll.remove(item, do_unlink=True)


def _grid_mesh(segments: int, name: str) -> bpy.types.Mesh:
    """One displaced-grid mesh datablock, built without touching the scene.

    `bmesh` rather than the primitive operator: operators need a context and
    link their result into the scene, and we want a bare datablock we can share
    across thousands of objects ourselves.

    The grid is then pushed out of plane. A flat card is not a scene: it has one
    normal, no self-occlusion and nothing for the depth buffer to do, so it
    would measure a best case that no real file resembles. The displacement is a
    fixed closed-form function of position -- deterministic, so two runs on two
    machines are comparing the same geometry, and free, because it is one
    vectorised numpy pass over the coordinate array.
    """
    import bmesh
    import numpy as np

    bm = bmesh.new()
    bmesh.ops.create_grid(
        bm, x_segments=max(1, segments), y_segments=max(1, segments), size=1.0
    )
    mesh = bpy.data.meshes.new(name)
    bm.to_mesh(mesh)
    bm.free()

    count = len(mesh.vertices)
    co = np.empty(count * 3, dtype=np.float32)
    mesh.vertices.foreach_get("co", co)
    co = co.reshape(count, 3)
    co[:, 2] = 0.35 * (
        np.sin(co[:, 0] * 6.0) * np.cos(co[:, 1] * 6.0)
        + 0.5 * np.sin(co[:, 0] * 17.0 + co[:, 1] * 11.0)
    )
    mesh.vertices.foreach_set("co", co.ravel())
    mesh.update()
    return mesh


def _triangle_count(mesh: bpy.types.Mesh) -> int:
    """Triangles in a mesh datablock, across Blender versions.

    `calc_loop_triangles()` was removed in 4.1 where `loop_triangles` became
    automatic; calling it on 4.5 raises, and not calling it on older builds
    yields zero. Ask for the attribute and only nudge it if it looks empty.
    """
    if not len(mesh.loop_triangles) and hasattr(mesh, "calc_loop_triangles"):
        mesh.calc_loop_triangles()
    return len(mesh.loop_triangles)


def build(spec: SceneSpec) -> Dict:
    """Build `spec` into the current file. Returns what was actually made."""
    _clear()
    scene = bpy.context.scene

    mesh = _grid_mesh(spec.segments, f"{spec.id}_mesh")
    tris_each = _triangle_count(mesh)

    # A square-ish grid so the objects occupy a compact volume. A long strip
    # would let frustum culling quietly drop most of them and the draw-call
    # measurement would be of whatever survived.
    side = max(1, math.ceil(math.sqrt(spec.object_count)))
    spacing = 2.2  # grid is 2.0 wide; a small gap keeps objects distinct
    for i in range(spec.object_count):
        obj = bpy.data.objects.new(f"{spec.id}_{i:05d}", mesh)
        x = (i % side) * spacing
        y = (i // side) * spacing
        obj.location = (x - side * spacing * 0.5, y - side * spacing * 0.5, 0.0)
        scene.collection.objects.link(obj)

    # A material, so MATERIAL_PREVIEW and RENDERED shading have something to do.
    # Without one those rungs measure a default grey and understate their cost.
    mat = bpy.data.materials.new(f"{spec.id}_mat")
    mat.use_nodes = True
    mesh.materials.append(mat)

    light_data = bpy.data.lights.new(f"{spec.id}_light", type="SUN")
    light = bpy.data.objects.new(f"{spec.id}_light", light_data)
    light.location = (10.0, -10.0, 20.0)
    scene.collection.objects.link(light)

    cam_data = bpy.data.cameras.new(f"{spec.id}_cam")
    cam = bpy.data.objects.new(f"{spec.id}_cam", cam_data)
    extent = max(4.0, side * spacing)
    cam.location = (extent, -extent, extent * 0.75)
    cam.rotation_euler = (math.radians(60.0), 0.0, math.radians(45.0))
    scene.collection.objects.link(cam)
    scene.camera = cam

    return {
        "scene": spec.id,
        "object_count": spec.object_count,
        "segments": spec.segments,
        "tris_per_object": tris_each,
        "tri_count_actual": tris_each * spec.object_count,
        "tri_target": spec.tri_target,
        "shares_one_mesh": True,
    }


def build_by_id(scene_id: str) -> Dict:
    if scene_id not in BY_ID:
        raise SystemExit(f"unknown scene id {scene_id!r}; have {sorted(BY_ID)}")
    return build(BY_ID[scene_id])


def _main() -> None:
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    import argparse

    ap = argparse.ArgumentParser(prog="scene_build")
    ap.add_argument("--scene", required=True)
    ap.add_argument("--save", default=None, help="write the built .blend here")
    args = ap.parse_args(argv)

    info = build_by_id(args.scene)
    if args.save:
        out = Path(args.save)
        out.parent.mkdir(parents=True, exist_ok=True)
        bpy.ops.wm.save_as_mainfile(filepath=str(out))
        info["saved"] = str(out)
    # Machine-readable single line, matching the LAB_METRICS idiom the motion
    # lab already uses for talking out of a Blender subprocess.
    import json

    print("SCENE_BUILT " + json.dumps(info))


if __name__ == "__main__":
    _main()
