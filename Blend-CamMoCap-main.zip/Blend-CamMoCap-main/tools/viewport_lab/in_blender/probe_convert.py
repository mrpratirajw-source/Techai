# SPDX-License-Identifier: GPL-3.0-or-later
"""How fast can a `gpu.types.Buffer` become bytes we can hand to an encoder?

Phase 0 measured readback at ~2 ms and the *conversion after it* at 10-15 ms,
which is far too slow to be a memcpy of a few megabytes. If that is real it
dominates the whole frame budget and the choice of conversion matters more than
the choice of capture path. If it is an artifact of asking numpy for a dtype it
then has to convert element-wise, it is nearly free and Phase 0's numbers were
pessimistic.

Either answer changes the design, so measure it rather than reason about it.
Interactive Blender only -- it needs a real GPU context.
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

import bpy
import gpu
import numpy as np

_HERE = Path(__file__).resolve().parent
for _p in (str(_HERE), str(_HERE.parent)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import scene_build  # noqa: E402


def _time(label, fn, buf, n=30):
    fn(buf)  # warm
    t = time.perf_counter()
    for _ in range(n):
        out = fn(buf)
    ms = (time.perf_counter() - t) / n * 1000.0
    return {"method": label, "ms": round(ms, 3), "bytes": len(out)}


def run():
    scene_build.build_by_id("synth_10k")
    width, height = 1280, 720
    results = {"width": width, "height": height, "methods": []}

    off = gpu.types.GPUOffScreen(width, height)
    area = next(
        (a for w in bpy.context.window_manager.windows
         for a in w.screen.areas if a.type == "VIEW_3D"),
        None,
    )
    if area is None:
        results["error"] = "no VIEW_3D"
        _emit(results)
        return
    region = next(r for r in area.regions if r.type == "WINDOW")
    space = area.spaces.active
    rv3d = region.data

    off.draw_view3d(
        bpy.context.scene, bpy.context.view_layer, space, region,
        rv3d.view_matrix, rv3d.window_matrix, do_color_management=False,
    )
    with off.bind():
        fb = gpu.state.active_framebuffer_get()
        buf = fb.read_color(0, 0, width, height, 4, 0, "UBYTE")

    results["buffer_type"] = type(buf).__name__
    results["buffer_dimensions"] = str(getattr(buf, "dimensions", None))

    # The candidates. The difference between them is entirely whether numpy is
    # allowed to reinterpret the existing memory or is forced to build new.
    results["methods"].append(_time(
        "np.asarray(buf, dtype=uint8).tobytes()",
        lambda b: np.asarray(b, dtype=np.uint8).tobytes(), buf))
    results["methods"].append(_time(
        "np.asarray(buf).tobytes()",
        lambda b: np.asarray(b).tobytes(), buf))
    results["methods"].append(_time(
        "bytes(buf)", lambda b: bytes(b), buf))
    try:
        results["methods"].append(_time(
            "np.frombuffer(buf, uint8).tobytes()",
            lambda b: np.frombuffer(b, dtype=np.uint8).tobytes(), buf))
    except Exception as exc:  # noqa: BLE001
        results["methods"].append({"method": "np.frombuffer", "error": str(exc)})
    try:
        results["methods"].append(_time(
            "memoryview(buf).tobytes()",
            lambda b: memoryview(b).tobytes(), buf))
    except Exception as exc:  # noqa: BLE001
        results["methods"].append({"method": "memoryview", "error": str(exc)})

    # RGBA -> RGB drops a quarter of the payload before it ever reaches an
    # encoder, so it is worth knowing whether the slice costs more than it saves.
    try:
        results["methods"].append(_time(
            "asarray->[:,:,:3] contiguous",
            lambda b: np.ascontiguousarray(
                np.asarray(b, dtype=np.uint8).reshape(height, width, 4)[:, :, :3]
            ).tobytes(), buf))
    except Exception as exc:  # noqa: BLE001
        results["methods"].append({"method": "rgb_slice", "error": str(exc)})

    # A plain numpy array of the same size, as the memcpy floor. If the buffer
    # methods are near this, conversion is not the problem.
    ref = np.zeros(height * width * 4, dtype=np.uint8)
    results["methods"].append(_time("REFERENCE ndarray.tobytes()",
                                    lambda _b: ref.tobytes(), buf))

    off.free()
    _emit(results)


def _emit(results):
    print("PROBE_CONVERT " + json.dumps(results))
    sys.stdout.flush()
    os._exit(0)


bpy.app.timers.register(run, first_interval=0.5)
