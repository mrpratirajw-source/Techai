# SPDX-License-Identifier: GPL-3.0-or-later
"""Viewport capture measurement. The only file here that touches `gpu`.

**Must run in an interactive Blender.** `gpu` drawing raises
`SystemError: GPU functions for drawing are not available in background mode`,
so none of this can go through the existing headless harness. A window opens,
the matrix runs unattended, JSON is written, the process exits. Nobody touches
anything.

Two capture paths, because they have completely different cost shapes and
measuring only one would produce a false verdict:

- **offscreen** -- `GPUOffScreen.draw_view3d()`. Draws the scene a *second* time
  into an offscreen buffer, then reads it back. Cost scales with the scene, but
  the resolution is ours to choose and the image has no gizmos or overlays.
- **framebuffer** -- a `POST_PIXEL` draw handler reading the framebuffer Blender
  *already* drew. No second draw at all, so on a heavy scene it should be far
  cheaper; but the size is whatever the user's viewport is, and the image
  contains their overlays.

The headline number is neither of their costs. It is
`host.viewport_fps.delta_pct`: how much Blender's own interactivity is lost
while capture runs. `read_color` is a synchronous GPU->CPU stall on the main
thread, and "capture costs 8 ms" means nothing next to "the operator's viewport
fell from 60 to 30 fps while they were orbiting". That is the kill-gate, and it
is measured first.
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import bpy
import gpu
from mathutils import Quaternion

# Blender runs this as a loose script with no package context, so both this
# directory (scene_build) and its parent (metrics_schema, scenes) have to be
# reachable. Adding only one of them is a startup crash into a window that then
# sits there forever, which is exactly what the deadline below also guards.
_HERE = Path(__file__).resolve().parent
for _p in (str(_HERE), str(_HERE.parent)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import metrics_schema as ms  # noqa: E402
import scene_build  # noqa: E402
import scenes as scene_defs  # noqa: E402


# --------------------------------------------------------------- viewport find

def find_view3d():
    """The first 3D viewport, as (area, region, space).

    Returns None rather than raising: a Blender opened with a non-default
    workspace legitimately has no VIEW_3D, and the run should say so in its
    results instead of dying with a traceback into a log nobody reads.
    """
    wm = bpy.context.window_manager
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type != "VIEW_3D":
                continue
            for region in area.regions:
                if region.type == "WINDOW":
                    return area, region, area.spaces.active
    return None


# ------------------------------------------------------------------ the run

def buffer_to_rgb_bytes(buf, width: int, height: int) -> bytes:
    """`gpu.types.Buffer` -> packed RGB bytes, by the fast route.

    Measured on an RTX 4070 at 720p (`probe_convert.py`): `bytes(buf)` 17.2 ms,
    `np.asarray(buf).tobytes()` 9.6 ms, this 2.2 ms -- while also producing 25%
    less data by dropping the alpha nobody downstream wants. A plain contiguous
    ndarray of the same size copies in 0.1 ms, so the gap is entirely the
    Buffer's non-C-contiguous layout: the naive paths gather it element-wise,
    and slicing into a fresh contiguous array does not.

    Getting this wrong spends a third to half of a 30 fps frame budget on a
    format choice, which is the difference between a viable capture and a dead
    one, so it is centralised here rather than repeated per call site.
    """
    import numpy as np

    arr = _as_rgba(buf, width, height)
    return np.ascontiguousarray(arr[::-1, :, :3]).tobytes()


def _as_rgba(buf, width, height):
    """A gpu.types.Buffer as a correct (h, w, 4) uint8 array.

    NEVER np.asarray here. A Buffer of dimensions (h, w, 4) exports strides of
    (1, h, h*w) through the buffer protocol -- transposed and channel-planar --
    where the memory behind it is interleaved RGBA rows with strides
    (w*4, 4, 1). numpy honours what it is told and reads every pixel from the
    wrong address, producing a scrambled image that still has the right shape
    and passes every dimension check.

    This shipped. The corpus this harness dumped was noise, and every
    bytes-per-frame and PSNR number measured off it was measured on noise --
    see the correction in viewport-lab-results.md.
    """
    import numpy as np

    buf.dimensions = width * height * 4
    return np.frombuffer(buf, dtype=np.uint8).reshape(height, width, 4)


class Bench:
    """A stage machine driven by one timer and one draw handler.

    The timer is the clock: it advances a scripted orbit, forces a redraw, and
    for the offscreen path does the capture. The draw handler is the *ruler*: it
    fires once per real viewport redraw, so the interval between its
    invocations is Blender's actual frame time -- with capture off, that is the
    baseline; with capture on, the difference is the damage.

    The orbit is scripted rather than performed. Nobody has to sit and drag the
    view, and a fixed angular step per frame means two runs are comparing the
    same motion.
    """

    def __init__(self, cfg: Dict[str, Any], out_path: Path) -> None:
        self.cfg = cfg
        self.out_path = out_path
        self.results = ms.new_results("phase0", {"scene": cfg.get("scene")})
        self.stages: List[Dict[str, Any]] = []
        self.stage_index = 0
        self.frames_per_stage = int(cfg.get("frames", 240))

        self.draw_times: List[float] = []
        self.draw_durations: List[float] = []
        self.capture_ms: Dict[str, List[float]] = {}
        self.last_draw: Optional[float] = None
        self.pre_view_at: Optional[float] = None
        self.pre_handler = None
        self.scaled_shape = None
        # The frame corpus is the point of the whole interactive run. Capture
        # can only be measured with a window open, but ENCODING can be measured
        # anywhere -- so dump raw frames once and let the codec ladder run
        # against them on the desktop, repeatedly, with no Blender in the loop.
        # Without this, every new encoder candidate would need another
        # interactive session and the numbers would not be comparable.
        self.corpus_dir: Optional[Path] = None
        self.corpus_frames = int(cfg.get("corpus_frames", 0))
        self.corpus_written = 0
        self.corpus_meta: Dict[str, Any] = {}
        self.offscreen: Optional[gpu.types.GPUOffScreen] = None
        self.handler = None
        self.errors: List[str] = []
        self.frame_bytes = 0
        # An unattended harness that opens a window must be incapable of sitting
        # there forever. If the viewport never redraws -- an unfocused window, a
        # workspace with no VIEW_3D, a driver that stalls -- the stage would
        # never fill and nothing would ever write results.
        self.deadline = time.perf_counter() + float(cfg.get("timeout_s", 240.0))

        view = find_view3d()
        if view is None:
            ms.note(self.results, "no VIEW_3D area found; nothing measured")
            self.area = self.region = self.space = None
        else:
            self.area, self.region, self.space = view

    # -------------------------------------------------------------- stages

    def plan(self, width: int, height: int, shading: str) -> None:
        """baseline first, then each capture path, so the delta has a referent."""
        self.plan_matrix([shading], list(scene_defs.CAPTURE_PATHS) + ["framebuffer_scaled"],
                         width, height)

    def plan_matrix(self, shadings, paths, width: int, height: int) -> None:
        """One baseline per shading, then every path under it.

        The baseline has to be re-taken per shading rather than once for the
        run: MATERIAL_PREVIEW and RENDERED draw completely different amounts of
        work, and charging a RENDERED capture against a SOLID baseline would
        attribute the shading cost to the capture.
        """
        self.stages = []
        for shading in shadings:
            common = {"width": width, "height": height, "shading": shading}
            self.stages.append(dict(common, path="baseline"))
            for path in paths:
                self.stages.append(dict(common, path=path))

    @property
    def stage(self) -> Optional[Dict[str, Any]]:
        if self.stage_index >= len(self.stages):
            return None
        return self.stages[self.stage_index]

    def _begin_stage(self) -> None:
        st = self.stage
        if st is None:
            return
        self.draw_times.clear()
        self.draw_durations.clear()
        self.capture_ms = {"draw": [], "readback": [], "to_bytes": [], "total": []}
        self.last_draw = None
        self.frame_bytes = 0
        if self.space is not None:
            try:
                self.space.shading.type = st["shading"]
            except TypeError as exc:
                # One unsupported enum value used to abort the entire matrix
                # from inside the timer, losing every stage after it. Skip the
                # stage, say so, keep measuring.
                st["skipped"] = f"{type(exc).__name__}: {exc}"
                self.errors.append(f"shading {st['shading']!r} unavailable: {exc}")
        self.corpus_dir = None
        self.corpus_written = 0
        self.scaled_shape = None  # or the next stage reports this one's shape
        if self.corpus_frames and st["path"] == self.cfg.get("corpus_path"):
            root = Path(self.cfg["corpus_root"])
            self.corpus_dir = root / f"{self.cfg.get('scene')}-{st['shading']}-{st['path']}"
            self.corpus_dir.mkdir(parents=True, exist_ok=True)
            self.corpus_meta = {
                "scene": self.cfg.get("scene"),
                "shading": st["shading"],
                "path": st["path"],
                "pixel_format": "RGB8",
                "requested": [st["width"], st["height"]],
            }
        self._free_offscreen()
        if st["path"] == "offscreen":
            try:
                self.offscreen = gpu.types.GPUOffScreen(st["width"], st["height"])
            except Exception as exc:  # noqa: BLE001
                self.errors.append(f"offscreen alloc failed: {type(exc).__name__}: {exc}")

    def _free_offscreen(self) -> None:
        if self.offscreen is not None:
            try:
                self.offscreen.free()
            except Exception:  # noqa: BLE001 - already gone is fine
                pass
            self.offscreen = None

    # ------------------------------------------------------------- capture

    def _capture_offscreen(self, st: Dict[str, Any]) -> None:
        """Path A: draw the scene again into our own buffer, then read it."""
        if self.offscreen is None or self.space is None:
            return
        rv3d = self.region.data
        t0 = time.perf_counter()
        self.offscreen.draw_view3d(
            bpy.context.scene,
            bpy.context.view_layer,
            self.space,
            self.region,
            rv3d.view_matrix,
            rv3d.window_matrix,
            do_color_management=False,
        )
        t1 = time.perf_counter()
        with self.offscreen.bind():
            fb = gpu.state.active_framebuffer_get()
            # UBYTE, never FLOAT: a float readback costs a numpy conversion of
            # ~10 ms at 720p before anything useful happens, which is a third of
            # a 30 fps budget spent on a format choice.
            buf = fb.read_color(0, 0, st["width"], st["height"], 4, 0, "UBYTE")
        t2 = time.perf_counter()
        payload = buffer_to_rgb_bytes(buf, st["width"], st["height"])
        t3 = time.perf_counter()

        self.frame_bytes = len(payload)
        self.capture_ms["draw"].append((t1 - t0) * 1000.0)
        self.capture_ms["readback"].append((t2 - t1) * 1000.0)
        self.capture_ms["to_bytes"].append((t3 - t2) * 1000.0)
        self.capture_ms["total"].append((t3 - t0) * 1000.0)

    def _capture_framebuffer(self) -> None:
        """Path B: read the frame Blender just drew. No second draw."""
        w = self.region.width
        h = self.region.height
        t1 = time.perf_counter()
        fb = gpu.state.active_framebuffer_get()
        buf = fb.read_color(0, 0, w, h, 4, 0, "UBYTE")
        t2 = time.perf_counter()
        payload = buffer_to_rgb_bytes(buf, w, h)
        t3 = time.perf_counter()

        self.frame_bytes = len(payload)
        self.capture_ms["draw"].append(0.0)  # by construction
        self.capture_ms["readback"].append((t2 - t1) * 1000.0)
        self.capture_ms["to_bytes"].append((t3 - t2) * 1000.0)
        self.capture_ms["total"].append((t3 - t1) * 1000.0)
        self._maybe_dump(payload)

    def _capture_framebuffer_scaled(self, st: Dict[str, Any]) -> None:
        """Path B, then decimate to the requested size on the CPU.

        Path B has no say in its own resolution -- it gets whatever the
        operator's viewport happens to be, which here is 1585x886 when 1280x720
        was asked for. Streaming a chosen resolution therefore needs a resample
        somewhere, and the `gpu` module offers no way to copy a region's
        framebuffer into a smaller texture, so it lands on the CPU.

        Nearest-neighbour by strided slicing, deliberately: it is a view plus one
        contiguous copy of the SMALLER array, so it costs less than the full-size
        copy it replaces. A filtered resample would look better and cost several
        times more, and this measurement is about whether the resolution knob is
        affordable at all.
        """
        import numpy as np

        w = self.region.width
        h = self.region.height
        t1 = time.perf_counter()
        fb = gpu.state.active_framebuffer_get()
        buf = fb.read_color(0, 0, w, h, 4, 0, "UBYTE")
        t2 = time.perf_counter()
        # Ceiling, not floor: 1585 // 1280 is 1, so a floor step never
        # decimated anything and this path silently measured the unscaled one.
        # Integer striding cannot hit an arbitrary target, so the honest rule is
        # "the nearest integer decimation at or below the target" -- 1585 wide
        # becomes 792, not 1280.
        #
        # ONE step for both axes. Choosing them independently halved a 1575x647
        # viewport to 787x647 -- correct by the letter of each target and a
        # visibly stretched picture, since the aspect no longer matches what the
        # operator is composing.
        step = max(
            1,
            -(-w // max(1, st["width"])),
            -(-h // max(1, st["height"])),
        )
        step_x = step_y = step
        arr = _as_rgba(buf, w, h)
        sub = np.ascontiguousarray(arr[::-step_y, ::step_x, :3])
        payload = sub.tobytes()
        t3 = time.perf_counter()

        self.frame_bytes = len(payload)
        # Read the shape off the array rather than recomputing it: strided
        # slicing rounds UP (1585 with step 2 gives 793 columns, not 792), so
        # the arithmetic version wrote a corpus sidecar that could not reshape
        # its own frames.
        self.scaled_shape = (sub.shape[0], sub.shape[1])
        self.capture_ms["draw"].append(0.0)
        self.capture_ms["readback"].append((t2 - t1) * 1000.0)
        self.capture_ms["to_bytes"].append((t3 - t2) * 1000.0)
        self.capture_ms["total"].append((t3 - t1) * 1000.0)
        self._maybe_dump(payload)

    def _maybe_dump(self, payload: bytes) -> None:
        """Write raw frames for the stage that asked for a corpus.

        Only one stage dumps -- consecutive frames of a moving view, which is
        what makes the inter-frame delta rungs of the codec ladder meaningful. A
        corpus of one repeated still frame would make delta compression look
        perfect and tell us nothing.
        """
        if self.corpus_dir is None or self.corpus_written >= self.corpus_frames:
            return
        # Skip the warm-up window here too, so the corpus is frames from the
        # steady state rather than from shader compilation.
        if len(self.draw_times) < ms.WARMUP_FRAMES:
            return
        path = self.corpus_dir / f"frame_{self.corpus_written:04d}.bin"
        path.write_bytes(payload)
        self.corpus_written += 1

    # ------------------------------------------------------------- hooks

    def on_pre_view(self) -> None:
        """Start of the 3D draw pass. Paired with `on_draw` to time it.

        The interval between redraws turned out to be useless on its own: it is
        pinned at exactly 30 fps even for a 10k-triangle scene, so it is a
        refresh cap rather than Blender's ceiling, and capture cost simply hides
        in the slack. The duration of the draw itself is not capped, so the
        honest kill-gate is how much capture adds to that.
        """
        self.pre_view_at = time.perf_counter()

    def on_draw(self) -> None:
        """Runs on every real viewport redraw. Never allowed to raise.

        An exception escaping a draw handler in Blender spams the console every
        frame and can leave the viewport in a broken state -- the same
        containment discipline the Android GL thread already uses.
        """
        try:
            now = time.perf_counter()
            if self.last_draw is not None:
                self.draw_times.append((now - self.last_draw) * 1000.0)
            self.last_draw = now
            if self.pre_view_at is not None:
                # Excludes our own capture below, which is accounted separately
                # so the two can be summed into an implied frame cost.
                self.draw_durations.append((now - self.pre_view_at) * 1000.0)
                self.pre_view_at = None
            st = self.stage
            if st is not None and st["path"] == "framebuffer":
                self._capture_framebuffer()
            elif st is not None and st["path"] == "framebuffer_scaled":
                self._capture_framebuffer_scaled(st)
        except Exception as exc:  # noqa: BLE001
            msg = f"draw handler: {type(exc).__name__}: {exc}"
            if msg not in self.errors:
                self.errors.append(msg)

    def on_timer(self) -> Optional[float]:
        try:
            st = self.stage
            if st is None:
                self.finish()
                return None

            if time.perf_counter() > self.deadline:
                self.errors.append(
                    f"deadline hit in stage {st['path']!r} after "
                    f"{len(self.draw_times)} redraws -- viewport may not be "
                    f"redrawing; results are partial"
                )
                self._record_stage()
                self.finish()
                return None

            # Scripted orbit. Rotating the view is what forces Blender to
            # genuinely redraw -- a static view lets it skip frames and the
            # "baseline fps" would be a measurement of doing nothing.
            if self.region is not None:
                rv3d = self.region.data
                rv3d.view_rotation = (
                    Quaternion((0.0, 0.0, 1.0), 0.012) @ rv3d.view_rotation
                )
                self.area.tag_redraw()

            if st["path"] == "offscreen":
                self._capture_offscreen(st)

            if st.get("skipped") or (
                len(self.draw_times) >= self.frames_per_stage + ms.WARMUP_FRAMES
            ):
                self._record_stage()
                self.stage_index += 1
                if self.stage is None:
                    self.finish()
                    return None
                self._begin_stage()
        except Exception as exc:  # noqa: BLE001
            self.errors.append(f"timer: {type(exc).__name__}: {exc}")
            self.finish()
            return None
        return 0.0  # as fast as the event loop will allow

    # ------------------------------------------------------------ results

    def _record_stage(self) -> None:
        st = self.stage
        if st is None:
            return
        if st.get("skipped"):
            ms.add_row(self.results, {
                "scene": self.cfg.get("scene"), "path": st["path"],
                "shading": st["shading"], "skipped": st["skipped"],
            })
            return
        # Discard the warm-up window: shader compilation, buffer allocation and
        # the GPU clocking up all land in the first frames and describe a
        # machine that stops existing after the first second.
        intervals = self.draw_times[ms.WARMUP_FRAMES:]
        durations = self.draw_durations[ms.WARMUP_FRAMES:]
        caps = {k: v[ms.WARMUP_FRAMES:] for k, v in self.capture_ms.items()}
        fps = (1000.0 / (sum(intervals) / len(intervals))) if intervals else 0.0
        draw_p50 = ms.summarize(durations)["p50"] if durations else 0.0
        cap_p50 = ms.summarize(caps["total"])["p50"] if caps.get("total") else 0.0
        implied_frame_ms = draw_p50 + cap_p50
        implied_fps = (1000.0 / implied_frame_ms) if implied_frame_ms > 0 else 0.0

        row: Dict[str, Any] = {
            "scene": self.cfg.get("scene"),
            "path": st["path"],
            "width": st["width"],
            "height": st["height"],
            "shading": st["shading"],
            "region_width": self.region.width if self.region else None,
            "region_height": self.region.height if self.region else None,
            "viewport_frame_ms": ms.summarize(intervals),
            "viewport_fps": round(fps, 2),
            "draw_duration_ms": ms.summarize(durations),
            "implied_frame_ms": round(implied_frame_ms, 4),
            "implied_fps": round(implied_fps, 2),
            "frame_bytes_raw": self.frame_bytes,
            "scaled_shape": list(self.scaled_shape) if self.scaled_shape else None,
        }
        if self.corpus_dir is not None and self.corpus_written:
            meta = dict(self.corpus_meta)
            # The corpus is useless without its geometry: a flat .bin of RGB8
            # cannot be reshaped without knowing what shape it was.
            if st["path"] == "offscreen":
                meta["width"], meta["height"] = st["width"], st["height"]
            elif self.scaled_shape:
                meta["height"], meta["width"] = self.scaled_shape
            else:
                meta["width"], meta["height"] = self.region.width, self.region.height
            meta["frames"] = self.corpus_written
            meta["frame_bytes"] = self.frame_bytes
            (self.corpus_dir / "corpus.json").write_text(
                json.dumps(meta, indent=2) + "\n", encoding="utf-8", newline="\n"
            )
            row["corpus"] = str(self.corpus_dir)
            row["corpus_frames"] = self.corpus_written
        if st["path"] != "baseline":
            for key, values in caps.items():
                if values:
                    row[f"capture_{key}_ms"] = ms.summarize(values)
        ms.add_row(self.results, row)

    def finish(self) -> None:
        self._free_offscreen()
        for attr in ("handler", "pre_handler"):
            h = getattr(self, attr, None)
            if h is not None:
                try:
                    bpy.types.SpaceView3D.draw_handler_remove(h, "WINDOW")
                except Exception:  # noqa: BLE001
                    pass
                setattr(self, attr, None)

        self._compute_verdict()
        for err in self.errors:
            ms.note(self.results, err)

        self.out_path.parent.mkdir(parents=True, exist_ok=True)
        self.out_path.write_text(
            json.dumps(self.results, indent=2) + "\n", encoding="utf-8", newline="\n"
        )
        print("VIEWPORT_LAB " + json.dumps({"out": str(self.out_path)}))
        sys.stdout.flush()
        # Interactive Blender will not quit on its own, and asking it to via
        # bpy.ops from a timer is exactly the call documented in bl/apply.py as
        # having hard-crashed the process. A benchmark harness has no reason to
        # be polite about exiting.
        os._exit(0)

    def _compute_verdict(self) -> None:
        rows = self.results.get("rows", [])
        baseline = next((r for r in rows if r["path"] == "baseline"), None)
        if baseline is None or not baseline.get("viewport_fps"):
            return
        base_fps = baseline["viewport_fps"]
        base_implied = baseline.get("implied_fps") or 0.0
        target_fps = float(self.cfg.get("target_fps", 30.0))
        verdicts = {}
        for row in rows:
            if row["path"] == "baseline":
                continue
            row["viewport_fps_delta_pct"] = round(
                (row["viewport_fps"] - base_fps) / base_fps * 100.0, 2
            )
            # The verdict comes from the IMPLIED rate. The observed one is
            # refresh-capped, so it would report a comfortable 0% for any
            # capture that fits in the slack and would say VIABLE about
            # something that has no headroom left at all.
            if base_implied > 0:
                row["implied_fps_delta_pct"] = round(
                    (row["implied_fps"] - base_implied) / base_implied * 100.0, 2
                )
            # The verdict: what share of a 30 fps frame does capture take on the
            # main thread? Encode, packetise and send all have to fit in what is
            # left, so this is the number the rest of the design spends.
            cap = row.get("capture_total_ms", {}).get("p50")
            if cap is not None:
                budget = ms.frame_budget_ms(target_fps)
                occupancy = cap / budget * 100.0
                row["capture_budget_pct"] = round(occupancy, 1)
                row["capture_budget_target_fps"] = target_fps
                row["headroom_ms"] = round(budget - cap, 2)
                row["verdict"] = ms.capture_verdict(occupancy)
                verdicts[row["path"]] = row["verdict"]
        self.results["baseline_viewport_fps"] = base_fps
        self.results["baseline_implied_fps"] = round(base_implied, 2)
        self.results["verdicts"] = verdicts
        if baseline["viewport_frame_ms"].get("min", 0) > 15.0:
            ms.note(
                self.results,
                "observed viewport fps is refresh-capped (a 10k-triangle scene "
                "also reports ~30), so an fps delta cannot discriminate here",
            )
        ms.note(
            self.results,
            "draw_duration_ms is CPU submission only (~1 ms for every scene in "
            "the ladder); the GPU runs asynchronously and the draw pass does not "
            "wait for it, while read_color does -- so it is a diagnostic, not a "
            "baseline to compare capture against",
        )


# ---------------------------------------------------------------------- main

def _evaluated_triangles() -> int:
    """Triangles the viewport actually draws, after modifiers.

    The evaluated count is the one that matters -- a scene whose source meshes
    are light can still be heavy once subdivision and arrays are applied, and
    the source count would understate what capture is competing with.
    """
    total = 0
    dg = bpy.context.evaluated_depsgraph_get()
    for ob in bpy.context.scene.objects:
        if ob.type != "MESH":
            continue
        try:
            ev = ob.evaluated_get(dg)
            mesh = ev.to_mesh()
            if mesh is not None:
                if not len(mesh.loop_triangles) and hasattr(mesh, "calc_loop_triangles"):
                    mesh.calc_loop_triangles()
                total += len(mesh.loop_triangles)
                ev.to_mesh_clear()
        except Exception:  # noqa: BLE001 - an unevaluable object is not fatal
            continue
    return total


def main() -> None:
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    import argparse

    ap = argparse.ArgumentParser(prog="capture_bench")
    ap.add_argument("--scene", default="synth_1m",
                    help="ladder id, or a label for --blend")
    ap.add_argument("--blend", default=None,
                    help="measure an already-opened real .blend instead of "
                         "building a synthetic rung")
    ap.add_argument("--out", required=True)
    ap.add_argument("--width", type=int, default=1280)
    ap.add_argument("--height", type=int, default=720)
    ap.add_argument("--shading", default=None,
                    help="single shading mode; omit to sweep --shadings")
    ap.add_argument("--shadings", default="SOLID,MATERIAL_PREVIEW")
    ap.add_argument("--paths", default="framebuffer,framebuffer_scaled,offscreen")
    ap.add_argument("--frames", type=int, default=240)
    ap.add_argument("--target-fps", type=float, default=30.0)
    ap.add_argument("--timeout", type=float, default=600.0)
    ap.add_argument("--corpus-root", default=None)
    ap.add_argument("--corpus-path", default="framebuffer_scaled")
    ap.add_argument("--corpus-frames", type=int, default=0)
    args = ap.parse_args(argv)

    if args.blend:
        # Blender already opened the file from the command line; do not touch
        # the scene. Fingerprint it so a row measured against the owner's file
        # can never be mistaken for a reproducible one -- nobody else has this
        # .blend, so no decision may rest on it alone.
        import hashlib

        blend = Path(args.blend)
        digest = hashlib.sha256(blend.read_bytes()).hexdigest()
        built = {
            "scene": args.scene,
            "source": "local-scene",
            "path": str(blend),
            "sha256": digest,
            "bytes": blend.stat().st_size,
            "object_count": len(bpy.context.scene.objects),
            "engine": bpy.context.scene.render.engine,
            "tri_count_actual": _evaluated_triangles(),
        }
    else:
        built = scene_build.build_by_id(args.scene)

    cfg = {
        "scene": args.scene,
        "frames": args.frames,
        "target_fps": args.target_fps,
        "timeout_s": args.timeout,
        "corpus_root": args.corpus_root,
        "corpus_path": args.corpus_path,
        "corpus_frames": args.corpus_frames if args.corpus_root else 0,
    }
    bench = Bench(cfg, Path(args.out))
    bench.results["scene_info"] = built
    shadings = [args.shading] if args.shading else [
        s.strip() for s in args.shadings.split(",") if s.strip()
    ]
    bench.plan_matrix(
        shadings,
        [p.strip() for p in args.paths.split(",") if p.strip()],
        args.width,
        args.height,
    )

    if bench.area is None:
        bench.finish()
        return

    bench.pre_handler = bpy.types.SpaceView3D.draw_handler_add(
        bench.on_pre_view, (), "WINDOW", "PRE_VIEW"
    )
    bench.handler = bpy.types.SpaceView3D.draw_handler_add(
        bench.on_draw, (), "WINDOW", "POST_PIXEL"
    )
    bench._begin_stage()
    bpy.app.timers.register(bench.on_timer, first_interval=0.5)


if __name__ == "__main__":
    main()
