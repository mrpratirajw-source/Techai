# SPDX-License-Identifier: GPL-3.0-or-later
"""Where does camera-mode capture actually spend its time?

`spec/viewport-channel.md` §1 claims resolution is nearly free, on the strength
of a probe that timed `draw_view3d` alone: 15.8 ms at 640x360 against 14.4 ms at
1280x720. But the shipping path reported `capture_ms` of 50.6 ms at 1158x798,
which is three times that and cannot be a draw cost if the draw is flat.

The difference is that `capture_ms` covers three things, and only one of them was
ever measured:

- **draw** -- `draw_view3d`, priced by scene rather than by pixels.
- **read** -- `read_color` off the offscreen, priced by pixels.
- **pack** -- flip, drop alpha, make contiguous, `tobytes`. Priced by pixels, and
  it copies the frame twice.

Splitting them says whether the size list needs changing or the packing does.

Interactive Blender only. Uses the shipped `pack_rgb` rather than a copy, so the
number is the one the add-on pays.

    blender scene.blend --python tools/viewport_lab/in_blender/capture_cost.py \\
        -- --out results/p9-capture-cost.json
"""

from __future__ import annotations

import json
import pathlib
import sys
import time

import bpy
import gpu

#: Frames per size. Enough for a p95 without making the sweep tedious.
FRAMES = 24
#: Discarded per size: the first draw at a new size allocates and warms caches.
WARMUP = 4


def _modules():
    out = {}
    for name, mod in list(sys.modules.items()):
        if "pocketrig" not in name:
            continue
        for tail in (".bl.viewport", ".core.viewport_stream"):
            if name.endswith(tail):
                out[tail.rsplit(".", 1)[1]] = mod
    return out


def _find_view3d():
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == "VIEW_3D":
                for region in area.regions:
                    if region.type == "WINDOW":
                        return area, region, area.spaces.active
    return None


def _percentile(values, q):
    if not values:
        return None
    ordered = sorted(values)
    idx = min(len(ordered) - 1, int(len(ordered) * q))
    return round(ordered[idx], 2)


def main() -> None:
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    out_path = (
        pathlib.Path(argv[argv.index("--out") + 1]) if "--out" in argv
        else pathlib.Path("capture-cost.json")
    )
    result = {"format": "pocketrig-capture-cost", "version": 1, "sizes": []}
    st = {}

    def begin():
        mods = _modules()
        vs = mods.get("viewport_stream")
        if vs is None:
            print("COST_ERROR add-on not found", flush=True)
            return None
        found = _find_view3d()
        if found is None:
            print("COST_ERROR no VIEW_3D", flush=True)
            return None
        area, region, space = found
        scene = bpy.context.scene
        if scene.camera is None:
            print("COST_ERROR no scene camera", flush=True)
            return None

        render = scene.render
        sizes = [tuple(s) for s in vs.camera_sizes(
            render.resolution_x, render.resolution_y
        )]
        # A small rung below the advertised list, to see the curve rather than
        # three points clustered at the top.
        sizes.append((480, max(2, int(round(480 * sizes[0][1] / sizes[0][0])) // 2 * 2)))
        result["render"] = [render.resolution_x, render.resolution_y]
        result["sizes_advertised"] = [list(s) for s in sizes[:-1]]
        print(f"COST render={result['render']} sizes={sizes}", flush=True)

        st.update(vs=vs, region=region, space=space, scene=scene,
                  sizes=sizes, index=0)
        bpy.app.timers.register(next_size, first_interval=0.5)
        return None

    def next_size():
        if st["index"] >= len(st["sizes"]):
            finish()
            return None
        w, h = st["sizes"][st["index"]]
        st["off"] = gpu.types.GPUOffScreen(w, h)
        st["draw"], st["read"], st["pack"], st["total"] = [], [], [], []
        st["n"] = 0
        print(f"COST measuring {w}x{h}", flush=True)
        bpy.app.timers.register(one_frame, first_interval=0.05)
        return None

    def one_frame():
        import numpy as np

        w, h = st["sizes"][st["index"]]
        vs, scene = st["vs"], st["scene"]
        off = st["off"]
        camera = scene.camera
        depsgraph = bpy.context.evaluated_depsgraph_get()
        camera_eval = camera.evaluated_get(depsgraph)

        t0 = time.perf_counter()
        off.draw_view3d(
            scene, bpy.context.view_layer, st["space"], st["region"],
            camera_eval.matrix_world.inverted(),
            camera_eval.calc_matrix_camera(depsgraph, x=w, y=h),
            do_color_management=True,
        )
        t1 = time.perf_counter()
        with off.bind():
            framebuffer = gpu.state.active_framebuffer_get()
            buffer = framebuffer.read_color(0, 0, w, h, 4, 0, "UBYTE")
            buffer.dimensions = w * h * 4
            rgba = np.frombuffer(buffer, dtype=np.uint8).reshape(h, w, 4).copy()
        t2 = time.perf_counter()
        vs.pack_rgb(rgba, 1)
        t3 = time.perf_counter()

        st["n"] += 1
        if st["n"] > WARMUP:
            st["draw"].append((t1 - t0) * 1000.0)
            st["read"].append((t2 - t1) * 1000.0)
            st["pack"].append((t3 - t2) * 1000.0)
            st["total"].append((t3 - t0) * 1000.0)

        if st["n"] >= FRAMES + WARMUP:
            row = {
                "size": [w, h],
                "megapixels": round(w * h / 1e6, 3),
                "n": len(st["total"]),
            }
            for key in ("draw", "read", "pack", "total"):
                row[f"{key}_ms_p50"] = _percentile(st[key], 0.50)
                row[f"{key}_ms_p95"] = _percentile(st[key], 0.95)
            result["sizes"].append(row)
            print("COST " + json.dumps(row), flush=True)
            st["off"].free()
            st["index"] += 1
            bpy.app.timers.register(next_size, first_interval=0.2)
            return None
        return 0.02

    def finish():
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
        print("COST_RESULT " + json.dumps(result), flush=True)
        print("COST_DONE", flush=True)

    bpy.app.timers.register(begin, first_interval=3.0)


main()
