# SPDX-License-Identifier: GPL-3.0-or-later
"""Wi-Fi transport measurement, and what a stream costs the pose path.

Runs against the real phone with **no app changes**: Android's shell ships
`nc`, so the phone can hold a TCP listener while the PC drives it over the same
Wi-Fi the product uses. That keeps Phase 3 independent of the phone-side bench,
which is a much larger piece of work.

Two questions, and the second is the one that matters:

1. Can the link carry the stream? A saturation run gives the ceiling; a *paced*
   run at the encoder's real frame size and rate says whether it keeps up
   without the sender ever blocking, which is the thing that actually matters.
2. **What does the stream cost everything else?** `spec/protocol.md` §10 gives
   the viewport its own socket, but a socket is not a radio: pose datagrams and
   viewport frames contend for the same air, the same phone NIC and the same
   CPU. If streaming degrades pose delivery, this feature regresses the product's
   core promise no matter how good the picture is.

What this deliberately does NOT measure: receive-side arrival timing. Nothing on
the phone timestamps anything yet, so frame-arrival jitter and glass-to-glass
belong to Phase 4/5 with the in-app bench. Send-side blocking plus an independent
latency probe is what can be known honestly from here.
"""

from __future__ import annotations

import argparse
import json
import re
import socket
import statistics
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

import metrics_schema as ms  # noqa: E402

_PING_MS = re.compile(rb"time[=<]\s*(\d+(?:\.\d+)?)\s*ms", re.I)


# ------------------------------------------------------------------ phone side

class PhoneListener:
    """A TCP sink on the phone, via `adb shell nc`.

    Context-managed because a leaked `nc` holds the port and every later run
    fails to bind with an error that looks like a network problem rather than a
    stale process.
    """

    def __init__(self, adb: str, serial: str, port: int) -> None:
        self.adb = adb
        self.serial = serial
        self.port = port
        self.proc: Optional[subprocess.Popen] = None

    def __enter__(self) -> "PhoneListener":
        self._kill_stale()
        self.proc = subprocess.Popen(
            [self.adb, "-s", self.serial, "shell", f"nc -l -p {self.port} > /dev/null"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        time.sleep(1.5)  # let the listener bind before anyone dials it
        return self

    def __exit__(self, *exc: Any) -> None:
        if self.proc is not None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.proc.kill()
        self._kill_stale()

    def _kill_stale(self) -> None:
        subprocess.run(
            [self.adb, "-s", self.serial, "shell", "pkill -f 'nc -l' || true"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False,
        )


# --------------------------------------------------------------- latency probe

class PingProbe:
    """ICMP round trip to the phone, sampled in a background thread.

    The stand-in for pose-path damage until the phone can timestamp for itself.
    It shares the radio, the phone's network stack and its CPU with the stream,
    so an RTT that inflates under load is the same air the POSE datagrams have to
    cross. It is a proxy and is labelled as one: ICMP may be prioritised or
    deprioritised differently from UDP by either endpoint.
    """

    def __init__(self, host: str) -> None:
        self.host = host
        self.samples: List[float] = []
        self.lost = 0
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                out = subprocess.run(
                    ["ping", "-n", "1", "-w", "1000", self.host],
                    capture_output=True, timeout=3,
                )
                match = _PING_MS.search(out.stdout)
                if match:
                    self.samples.append(float(match.group(1)))
                else:
                    self.lost += 1
            except Exception:  # noqa: BLE001 - a failed probe is a lost probe
                self.lost += 1
            self._stop.wait(0.1)

    def __enter__(self) -> "PingProbe":
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc: Any) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=5)

    def result(self) -> Dict[str, Any]:
        row = ms.summarize(self.samples)
        total = len(self.samples) + self.lost
        row["lost"] = self.lost
        row["loss_pct"] = round(self.lost / total * 100.0, 2) if total else None
        return row


# ------------------------------------------------------------------- transfers

def saturate(host: str, port: int, seconds: float) -> Dict[str, Any]:
    """Push as hard as the link allows. The ceiling, not the operating point."""
    payload = bytes(65536)
    sent = 0
    with socket.create_connection((host, port), timeout=10) as sock:
        start = time.perf_counter()
        while time.perf_counter() - start < seconds:
            sock.sendall(payload)
            sent += len(payload)
        elapsed = time.perf_counter() - start
    return {
        "mode": "saturate",
        "seconds": round(elapsed, 3),
        "bytes": sent,
        "goodput_mbps": round(sent * 8 / elapsed / 1e6, 2),
    }


def paced(host: str, port: int, seconds: float, frame_bytes: int, fps: float) -> Dict[str, Any]:
    """Send real-sized frames at a real rate, and watch for the sender blocking.

    The number that matters is `send_block_ms`: how long `sendall` took. On a
    link with headroom it is microseconds, because the frame fits in the socket
    buffer. When it starts taking a meaningful fraction of the frame interval,
    the link is the constraint and frames are about to queue -- which is latency
    the operator feels, arriving before any packet is actually lost.
    """
    payload = bytes(frame_bytes)
    interval = 1.0 / fps
    send_ms: List[float] = []
    late_ms: List[float] = []
    frames = 0
    with socket.create_connection((host, port), timeout=10) as sock:
        start = time.perf_counter()
        next_at = start
        while time.perf_counter() - start < seconds:
            now = time.perf_counter()
            if now < next_at:
                time.sleep(next_at - now)
            scheduled = next_at
            t0 = time.perf_counter()
            sock.sendall(payload)
            t1 = time.perf_counter()
            send_ms.append((t1 - t0) * 1000.0)
            # How far behind its slot this frame went out. Distinct from send
            # time: a sender can be late because the PREVIOUS frame blocked.
            late_ms.append(max(0.0, (t0 - scheduled) * 1000.0))
            frames += 1
            next_at += interval
            # Never burst to catch up. A stream that sprints after a stall
            # delivers a clump of stale frames, which is worse than skipping.
            if next_at < time.perf_counter():
                next_at = time.perf_counter() + interval
        elapsed = time.perf_counter() - start
    return {
        "mode": "paced",
        "seconds": round(elapsed, 3),
        "frames": frames,
        "frame_bytes": frame_bytes,
        "target_fps": fps,
        "achieved_fps": round(frames / elapsed, 2),
        "offered_mbps": round(frame_bytes * 8 * fps / 1e6, 2),
        "actual_mbps": round(frames * frame_bytes * 8 / elapsed / 1e6, 2),
        "send_block_ms": ms.summarize(send_ms),
        "late_ms": ms.summarize(late_ms),
    }


# ------------------------------------------------------------------------ run

def main() -> None:
    ap = argparse.ArgumentParser(prog="transport_bench")
    ap.add_argument("--host", required=True, help="phone IP on the Wi-Fi")
    ap.add_argument("--serial", required=True, help="adb device serial")
    ap.add_argument("--adb", default=None)
    ap.add_argument("--port", type=int, default=5001)
    ap.add_argument("--seconds", type=float, default=15.0)
    ap.add_argument("--frame-bytes", type=int, default=39100,
                    help="measured JPEG q75 frame at 793x443")
    ap.add_argument("--fps", type=float, default=30.0)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    adb = args.adb or str(
        Path.home() / "AppData/Local/Android/Sdk/platform-tools/adb.exe"
    )
    results = ms.new_results("phase3", {
        "phone_host": args.host,
        "serial": args.serial,
        "frame_bytes": args.frame_bytes,
        "target_fps": args.fps,
    })

    # Idle first. Without a quiet reference the loaded numbers mean nothing.
    with PingProbe(args.host) as probe:
        time.sleep(args.seconds)
    idle = probe.result()
    ms.add_row(results, {"case": "idle", "rtt_ms": idle})

    with PhoneListener(adb, args.serial, args.port):
        with PingProbe(args.host) as probe:
            row = paced(args.host, args.port, args.seconds, args.frame_bytes, args.fps)
        row["case"] = "paced_stream"
        row["rtt_ms"] = probe.result()
        ms.add_row(results, row)

    with PhoneListener(adb, args.serial, args.port):
        with PingProbe(args.host) as probe:
            row = saturate(args.host, args.port, args.seconds)
        row["case"] = "saturated"
        row["rtt_ms"] = probe.result()
        ms.add_row(results, row)

    # The comparison the whole phase exists for.
    by_case = {r["case"]: r for r in results["rows"]}
    base = by_case["idle"]["rtt_ms"].get("p95")
    for case in ("paced_stream", "saturated"):
        loaded = by_case[case]["rtt_ms"].get("p95")
        if base and loaded:
            by_case[case]["rtt_p95_delta_ms"] = round(loaded - base, 2)
            by_case[case]["rtt_p95_delta_pct"] = round((loaded - base) / base * 100.0, 1)

    ms.note(results, "ICMP RTT is a PROXY for pose-path damage: it shares the "
                     "radio, the phone's stack and its CPU, but may be queued "
                     "differently from UDP at either end. The real POSE-loss "
                     "measurement needs the phone-side bench.")
    ms.note(results, "Receive-side arrival timing is not measured here; nothing "
                     "on the phone timestamps yet. Send-side blocking is what "
                     "can be known honestly without app changes.")

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8", newline="\n")
    print("TRANSPORT_BENCH " + json.dumps({"out": str(out)}))


if __name__ == "__main__":
    main()
