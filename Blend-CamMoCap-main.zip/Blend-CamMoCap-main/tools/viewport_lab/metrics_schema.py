# SPDX-License-Identifier: GPL-3.0-or-later
"""Metric names, units, and the run context every result row carries.

One source of truth for keys, so the in-Blender capture script, the desktop
codec ladder and the report generator cannot drift into three spellings of the
same number.

**These are wall-clock, machine-dependent measurements.** They deliberately do
NOT use the `{value, tol}` shape that `tools/motion_lab/baselines/*.json` uses,
and they must never be fed to `run_lab.check_against`. Those baselines gate
deterministic simulated metrics, where a drift is a real regression; putting a
wall-clock number in that scheme turns the suite into a coin flip that fails on
a busy machine and passes on an idle one. This file's output is a *report*.
"""

from __future__ import annotations

import platform
import sys
from typing import Any, Dict, Iterable, List, Optional

SCHEMA = "pocketrig-viewport-lab"
SCHEMA_VERSION = 1

#: How many leading frames to throw away before recording anything. Shader
#: compilation, buffer allocation and the GPU clocking up all land here, and
#: including them reports a machine that does not exist after the first second.
WARMUP_FRAMES = 60


def summarize(samples: Iterable[float], unit: str = "ms") -> Dict[str, Any]:
    """A distribution, not a mean.

    p95 is the number that decides whether a stream feels broken; an average
    hides exactly the stalls that matter. `n` travels with it so a suspiciously
    clean result can be spotted as a short one.
    """
    values = sorted(float(v) for v in samples)
    if not values:
        return {"unit": unit, "n": 0}

    def pct(fraction: float) -> float:
        if len(values) == 1:
            return values[0]
        pos = fraction * (len(values) - 1)
        low = int(pos)
        high = min(low + 1, len(values) - 1)
        return values[low] + (values[high] - values[low]) * (pos - low)

    return {
        "unit": unit,
        "n": len(values),
        "min": round(values[0], 4),
        "p50": round(pct(0.50), 4),
        "p95": round(pct(0.95), 4),
        "max": round(values[-1], 4),
        "mean": round(sum(values) / len(values), 4),
    }


def run_context(extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Everything needed to know whether two runs are comparable.

    A viewport number without its GPU backend is not a result. Blender 5.x
    pushes Vulkan and 4.5 ships an OpenGL default, and readback throughput
    differs materially between them -- a report that omits which one ran
    invites someone to compare two machines that were never doing the same
    thing.
    """
    ctx: Dict[str, Any] = {
        "os": f"{platform.system()} {platform.release()}",
        "machine": platform.machine(),
        "cpu": platform.processor() or "unknown",
        "python": sys.version.split()[0],
    }
    try:  # numpy ships with Blender, but this file is also imported bare
        import numpy

        ctx["numpy"] = numpy.__version__
    except ImportError:
        ctx["numpy"] = None

    try:  # only meaningful inside Blender
        import bpy

        ctx["blender_version"] = bpy.app.version_string
        ctx["blender_background"] = bpy.app.background
    except ImportError:
        pass

    try:  # raises in background mode -- absence is itself informative
        import gpu

        ctx["gpu_backend"] = str(gpu.platform.backend_type_get())
        ctx["gpu_renderer"] = str(gpu.platform.renderer_get())
        ctx["gpu_vendor"] = str(gpu.platform.vendor_get())
    except Exception as exc:  # noqa: BLE001 - report why, do not crash the run
        ctx["gpu_backend"] = None
        ctx["gpu_error"] = f"{type(exc).__name__}: {exc}"

    if extra:
        ctx.update(extra)
    return ctx


def new_results(phase: str, extra_context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """An empty results document.

    `role` is stated in the file itself, copying the convention in
    `baselines/presentation_v1.json`, so a stray copy of this JSON cannot be
    mistaken for a regression target by whoever finds it next.
    """
    return {
        "format": SCHEMA,
        "version": SCHEMA_VERSION,
        "role": "wall-clock-measurement-not-a-regression-baseline",
        "phase": phase,
        "context": run_context(extra_context),
        "rows": [],
        "notes": [],
    }


def add_row(results: Dict[str, Any], row: Dict[str, Any]) -> None:
    results.setdefault("rows", []).append(row)


def note(results: Dict[str, Any], message: str) -> None:
    """Record something that shaped a number but is not itself a number.

    An unmeasured residual, a config that refused to run, a fallback that had to
    be taken. These belong in the artifact, not in someone's memory of the run.
    """
    results.setdefault("notes", []).append(message)


# --------------------------------------------------------------------- gates

#: Share of the frame budget that capture may occupy on Blender's main thread
#: before the verdict turns. Stated up front so it is not negotiated after
#: seeing numbers we happen to like.
#:
#: Occupancy rather than observed FPS, because observed FPS cannot answer the
#: question on this hardware: the viewport is refresh-capped at 30, so a
#: 10k-triangle scene and a 5M-triangle scene both report exactly 30 and any
#: capture that fits in the slack reports a comfortable 0% delta. Nor can the
#: PRE_VIEW/POST_PIXEL draw duration stand in for it -- that measures CPU
#: submission, which is ~1 ms for every scene in the ladder, because the GPU
#: runs asynchronously and the draw pass never waits for it. `read_color` DOES
#: wait, so comparing the two directly charges capture for the whole frame's GPU
#: work and calls everything DEAD.
#:
#: What is left, and what is honest, is: how much of the main thread does
#: capture take, against the budget of the rate we want to stream at. Everything
#: else in the frame -- encode, packetise, send -- has to fit in the remainder.
CAPTURE_BUDGET_DEAD_PCT = 60.0
CAPTURE_BUDGET_MARGINAL_PCT = 25.0


def capture_verdict(occupancy_pct: Optional[float]) -> str:
    if occupancy_pct is None:
        return "UNKNOWN"
    if occupancy_pct >= CAPTURE_BUDGET_DEAD_PCT:
        return "DEAD"
    if occupancy_pct >= CAPTURE_BUDGET_MARGINAL_PCT:
        return "MARGINAL"
    return "VIABLE"


def frame_budget_ms(fps: float) -> float:
    return 1000.0 / float(fps)


__all__: List[str] = [
    "SCHEMA",
    "SCHEMA_VERSION",
    "WARMUP_FRAMES",
    "summarize",
    "run_context",
    "new_results",
    "add_row",
    "note",
    "CAPTURE_BUDGET_DEAD_PCT",
    "CAPTURE_BUDGET_MARGINAL_PCT",
    "capture_verdict",
    "frame_budget_ms",
]
