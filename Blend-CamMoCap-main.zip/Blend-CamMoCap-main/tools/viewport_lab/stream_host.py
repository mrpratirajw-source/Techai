# SPDX-License-Identifier: GPL-3.0-or-later
"""Streams pre-encoded frames to the phone and measures the round trip.

Everything so far has been component costs -- capture, encode, link, decode --
and a sum of components is not a latency. This closes the loop: the host stamps
each frame with an ordinal and its own capture time, the phone echoes that
ordinal the instant it has *posted the frame to a surface*, and the host
subtracts.

**The echo crosses no clock boundary.** Both timestamps are taken by the same
machine on the same monotonic clock, so there is nothing to synchronise and no
assumption about symmetric delay. It over-counts by the uplink leg, which the
minimum PING/PONG RTT bounds from the other side -- so the true one-way figure
sits between `round_trip - rtt` and `round_trip`.

Frames are **pre-encoded before the run**. Encode cost was measured in phase 2
and including it here would fold a known number into an unknown one.

Wire format, deliberately close to what the real channel will need:

    magic 'PRVP' | u32 ordinal | u64 capture_ns | u32 payload_len | payload

Echo, one UDP datagram per presented frame:

    u32 ordinal | u64 phone_decoded_ns | u64 phone_posted_ns
"""

from __future__ import annotations

import argparse
import json
import socket
import struct
import sys
import threading
import time
from pathlib import Path
from typing import Any, Dict, List

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

import metrics_schema as ms  # noqa: E402

MAGIC = b"PRVP"
HEADER = struct.Struct("<4sIQI")
ECHO = struct.Struct("<IQQ")


def load_jpegs(path: Path, limit: int) -> List[bytes]:
    """Read the length-prefixed MJPEG file produced by make_phone_media."""
    blob = path.read_bytes()
    frames: List[bytes] = []
    offset = 0
    while offset + 4 <= len(blob) and len(frames) < limit:
        (length,) = struct.unpack_from("<I", blob, offset)
        offset += 4
        if length <= 0 or offset + length > len(blob):
            break
        frames.append(blob[offset:offset + length])
        offset += length
    return frames


class EchoCollector:
    """Receives presentation echoes and pairs them with send times."""

    def __init__(self, port: int) -> None:
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("0.0.0.0", port))
        self.sock.settimeout(0.5)
        self.sent_at: Dict[int, int] = {}
        self.samples: List[Dict[str, Any]] = []
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def start(self) -> None:
        self._thread.start()

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                data, _addr = self.sock.recvfrom(256)
            except socket.timeout:
                continue
            except OSError:
                break
            if len(data) < ECHO.size:
                continue
            ordinal, decoded_ns, posted_ns = ECHO.unpack_from(data, 0)
            now = time.perf_counter_ns()
            sent = self.sent_at.get(ordinal)
            if sent is None:
                continue
            self.samples.append({
                "ordinal": ordinal,
                "round_trip_ms": (now - sent) / 1e6,
                # The phone's own two stamps are on ITS clock, so only their
                # difference is meaningful here -- never their absolute value.
                "phone_decode_to_post_ms": (posted_ns - decoded_ns) / 1e6,
            })

    def stop(self) -> None:
        self._stop.set()
        self._thread.join(timeout=2)
        self.sock.close()


def run(args: argparse.Namespace) -> Dict[str, Any]:
    frames = load_jpegs(Path(args.media), args.limit)
    if not frames:
        raise SystemExit(f"no frames in {args.media}")

    collector = EchoCollector(args.echo_port)
    collector.start()

    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    listener.bind(("0.0.0.0", args.port))
    listener.listen(1)
    listener.settimeout(args.connect_timeout)
    print(f"waiting for the phone on :{args.port} …", flush=True)
    try:
        conn, addr = listener.accept()
    except socket.timeout:
        collector.stop()
        raise SystemExit("phone never connected")
    print(f"phone connected from {addr}", flush=True)

    # Nagle would coalesce small frames and add delay that is ours, not the
    # link's -- exactly the sort of self-inflicted latency this run exists to
    # rule out.
    conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

    interval = 1.0 / args.fps
    sent = 0
    start = time.perf_counter()
    next_at = start
    try:
        for index in range(args.frames):
            now = time.perf_counter()
            if now < next_at:
                time.sleep(next_at - now)
            payload = frames[index % len(frames)]
            capture_ns = time.perf_counter_ns()
            collector.sent_at[index] = capture_ns
            conn.sendall(HEADER.pack(MAGIC, index, capture_ns, len(payload)) + payload)
            sent += 1
            next_at += interval
            if next_at < time.perf_counter():
                next_at = time.perf_counter() + interval
    except (BrokenPipeError, ConnectionResetError):
        print("phone disconnected early", flush=True)
    finally:
        try:
            conn.close()
        except OSError:
            pass
        listener.close()

    # Echoes for the last frames are still in flight.
    time.sleep(1.5)
    collector.stop()

    elapsed = time.perf_counter() - start
    round_trips = [s["round_trip_ms"] for s in collector.samples]
    post_gaps = [s["phone_decode_to_post_ms"] for s in collector.samples]

    results = ms.new_results("phase5", {
        "media": str(args.media),
        "frames_sent": sent,
        "fps": args.fps,
        "bytes_per_frame": sum(len(f) for f in frames) // len(frames),
    })
    ms.add_row(results, {
        "case": "stream_echo",
        "frames_sent": sent,
        "echoes": len(collector.samples),
        "echo_pct": round(len(collector.samples) / max(1, sent) * 100.0, 1),
        "achieved_fps": round(sent / elapsed, 2) if elapsed else None,
        "round_trip_ms": ms.summarize(round_trips),
        "phone_decode_to_post_ms": ms.summarize(post_gaps),
    })
    ms.note(results, "round_trip_ms is capture -> phone posts to surface -> echo "
                     "back. It crosses no clock boundary, so it needs no clock "
                     "sync -- but it INCLUDES the uplink leg of the echo, so the "
                     "true one-way figure is between (round_trip - rtt) and "
                     "round_trip.")
    ms.note(results, "Frames are pre-encoded; encode cost is phase 2's number and "
                     "is deliberately not folded into this one.")
    ms.note(results, "Posting to a surface is not photons. The remaining hop is "
                     "SurfaceFlinger latch and panel scanout; see the "
                     "dumpsys SurfaceFlinger figures alongside this.")
    return results


def main() -> None:
    ap = argparse.ArgumentParser(prog="stream_host")
    ap.add_argument("--media", required=True, help="frames.mjpeg from make_phone_media")
    ap.add_argument("--out", required=True)
    ap.add_argument("--port", type=int, default=47900)
    ap.add_argument("--echo-port", type=int, default=47901)
    ap.add_argument("--fps", type=float, default=30.0)
    ap.add_argument("--frames", type=int, default=300)
    ap.add_argument("--limit", type=int, default=120)
    ap.add_argument("--connect-timeout", type=float, default=60.0)
    args = ap.parse_args()

    results = run(args)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8", newline="\n")
    print("STREAM_HOST " + json.dumps({"out": str(out)}))


if __name__ == "__main__":
    main()
