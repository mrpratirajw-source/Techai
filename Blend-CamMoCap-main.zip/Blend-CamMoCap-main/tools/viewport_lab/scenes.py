# SPDX-License-Identifier: GPL-3.0-or-later
"""The synthetic scene ladder the viewport measurements run against.

Deliberately `bpy`-free so the desktop orchestrator, the in-Blender builder and
the report generator all agree on the same definitions without importing
Blender. `scene_build.py` is the only thing that turns these into geometry.

Two axes, because they break the viewport in different ways:

- **Triangle count** is what people reach for first, and it is what costs the
  GPU per draw.
- **Object count** is what actually collapses interactive framerate. 5000 small
  objects submit 5000 draw calls and thrash the depsgraph; one 5M-triangle mesh
  submits one. A ladder that varies only triangles measures the easy axis and
  would report a comfortable number for a scene shape nobody works in.

`synth_1m_manyobj` exists to hold triangles constant against `synth_1m` and vary
only that second axis, so the two numbers are directly comparable.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Dict, List, Tuple

def grid_segments_for(tris_per_object: int) -> int:
    """Segments per side of a grid with `tris_per_object` triangles.

    A grid of n x n segments is exactly 2n^2 triangles, so the ladder can hit
    its targets to within a rounding step at any size. An icosphere was the
    obvious first choice, but subdivision only moves in 4x jumps: a "10k" rung
    landed on 20480 and both the 1M and 5M rungs collapsed onto the same 327680,
    which is a ladder that does not span what it claims to.

    The grid is displaced out of plane when it is built (see `scene_build`), so
    this buys exact counts without giving up real normals and overdraw.
    """
    return max(1, round((max(1, tris_per_object) / 2.0) ** 0.5))


def triangles_for_segments(segments: int) -> int:
    return 2 * segments * segments


@dataclass(frozen=True)
class SceneSpec:
    """One rung of the ladder.

    `tri_target` is nominal; the builder records the *actual* evaluated triangle
    count in the results, because the subdivision ladder is coarse and reporting
    the target instead of the truth would quietly overstate what was measured.
    """

    id: str
    tri_target: int
    object_count: int

    @property
    def tris_per_object(self) -> int:
        return max(1, self.tri_target // max(1, self.object_count))

    @property
    def segments(self) -> int:
        return grid_segments_for(self.tris_per_object)

    @property
    def tri_count_expected(self) -> int:
        return triangles_for_segments(self.segments) * self.object_count

    def to_dict(self) -> Dict:
        d = asdict(self)
        d["segments"] = self.segments
        d["tris_per_object"] = triangles_for_segments(self.segments)
        d["tri_count_expected"] = self.tri_count_expected
        return d


#: The committed ladder. Kept short on purpose: every rung multiplies the whole
#: matrix (paths x resolutions x shading), and a matrix nobody runs to the end
#: measures nothing.
LADDER: Tuple[SceneSpec, ...] = (
    SceneSpec("synth_10k", 10_000, 1),
    SceneSpec("synth_100k", 100_000, 1),
    SceneSpec("synth_1m", 1_000_000, 1),
    SceneSpec("synth_5m", 5_000_000, 1),
    # Same triangles as synth_1m, spread across many draw calls. The pair is the
    # measurement; either alone is an anecdote.
    SceneSpec("synth_1m_manyobj", 1_000_000, 5_000),
)

BY_ID: Dict[str, SceneSpec] = {s.id: s for s in LADDER}

#: Resolutions to capture at. 360p is in the list because it is the escape hatch
#: if latency turns out to be the binding constraint, and an escape hatch whose
#: cost was never measured is not an escape hatch.
RESOLUTIONS: Tuple[Tuple[int, int], ...] = (
    (640, 360),
    (854, 480),
    (1280, 720),
    (1920, 1080),
)

#: `RENDERED` is what an operator actually wants to see streamed; `SOLID` is the
#: cheap floor that isolates readback cost from draw cost.
#:
#: These are Blender's own enum values, which are WIREFRAME / SOLID / MATERIAL /
#: RENDERED -- the middle one is labelled "Material Preview" in the UI but is
#: `MATERIAL` on the API, and using the UI wording raises.
SHADING: Tuple[str, ...] = ("SOLID", "MATERIAL", "RENDERED")

#: The two capture mechanisms. See the plan: A pays for a second scene draw, B
#: pays only for readback but inherits the user's viewport size and overlays.
CAPTURE_PATHS: Tuple[str, ...] = ("offscreen", "framebuffer")


def phase0_plan() -> List[Dict]:
    """The kill-gate: one scene, one resolution, both paths.

    Phase 0 exists to answer a single question before any codec work happens --
    does synchronous readback wreck Blender's own interactivity. 1M triangles at
    720p is the midpoint of the ladder and the shape most likely to be real
    work, so it is the honest place to ask.
    """
    return [
        {
            "scene": "synth_1m",
            "width": 1280,
            "height": 720,
            "shading": "SOLID",
            "path": path,
        }
        for path in CAPTURE_PATHS
    ]
