# SPDX-License-Identifier: GPL-3.0-or-later
"""The encoder ladder, measured against a captured frame corpus.

Named `encoders`, not `codecs`: the latter is a stdlib module, and a file of that
name here shadows it for anything that tries to import it. It ran fine as a
script -- `__main__` never consults the name -- and failed the moment another
module wanted `Corpus` from it, which is the worst way for a naming collision to
show up.

Deliberately `bpy`-free and Blender-free. Capture can only be measured with a
window open; encoding can be measured anywhere, so it runs against the raw
frames Phase 1 dumped. That separation is what makes these numbers re-runnable
when a new candidate appears, and comparable between Blender's Python 3.11 and
whatever the desktop has.

Run it under **both** interpreters. Blender bundles its own Python and numpy,
and the add-on will encode inside that one; a number measured only on the
desktop interpreter does not transfer.

The rungs exist to answer one question honestly: is there a method that fits a
30 fps frame budget alongside a ~2.5 ms capture, at a bitrate a phone can
actually receive over Wi-Fi. "Send a still now and then" is not on the ladder --
that is not a video mode, and it is explicitly not what is wanted. A 30 fps
all-intra stream IS a video mode, and a good one for a viewfinder: no decoder
reorder delay and no error propagation.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

import metrics_schema as ms  # noqa: E402

try:
    import numpy as np
except ImportError:  # pragma: no cover - numpy ships with Blender
    np = None  # type: ignore


# --------------------------------------------------------------------- corpus

class Corpus:
    """Consecutive raw RGB8 frames of a moving view, plus their geometry."""

    def __init__(self, directory: Path) -> None:
        self.dir = Path(directory)
        meta_path = self.dir / "corpus.json"
        self.meta = json.loads(meta_path.read_text(encoding="utf-8"))
        self.width = int(self.meta["width"])
        self.height = int(self.meta["height"])
        self.paths = sorted(self.dir.glob("frame_*.bin"))

    def __len__(self) -> int:
        return len(self.paths)

    def frames(self, limit: Optional[int] = None) -> List["np.ndarray"]:
        """Load as (h, w, 3) uint8. Held in RAM so I/O never enters a timing."""
        out = []
        for path in self.paths[:limit]:
            buf = np.frombuffer(path.read_bytes(), dtype=np.uint8)
            out.append(buf.reshape(self.height, self.width, 3))
        return out


def psnr(a: "np.ndarray", b: "np.ndarray") -> float:
    """Peak signal-to-noise in dB; `inf` when a codec is lossless.

    Crude, and the right crudeness here: it cannot tell you whether a viewfinder
    image looks acceptable, but it does rank two lossy settings of the same codec
    and it catches an encoder that is quietly destroying the picture to hit a
    bitrate.
    """
    diff = a.astype(np.float64) - b.astype(np.float64)
    mse = float(np.mean(diff * diff))
    if mse <= 1e-12:
        return float("inf")
    return 10.0 * math.log10((255.0 ** 2) / mse)


# ----------------------------------------------------------------- the rungs

def rung_raw(frames):
    """Control. What capture hands over, uncompressed."""
    def encode(frame, prev):
        return frame.tobytes()
    return encode, None, True


def _zstd(level: int):
    import zstandard

    comp = zstandard.ZstdCompressor(level=level)

    def encode(frame, prev):
        return comp.compress(frame.tobytes())

    return encode


def rung_zstd(level: int):
    def build(frames):
        return _zstd(level), None, True
    return build


def rung_zstd_delta(level: int):
    """Frame difference, then zstd.

    A viewport that is not moving becomes almost nothing, which is the common
    case while an operator is thinking rather than orbiting. Lossless, so the
    picture is exact whenever it does arrive -- but the bitrate depends entirely
    on motion, so the corpus being a MOVING view is what stops this rung
    flattering itself.
    """
    import zstandard

    comp = zstandard.ZstdCompressor(level=level)

    def build(frames):
        def encode(frame, prev):
            if prev is None:
                return comp.compress(frame.tobytes())
            # Subtraction in uint8 wraps, which is exactly what is wanted: the
            # decoder adds it back and wraps identically, so this is lossless
            # and stays in one byte per channel.
            return comp.compress((frame - prev).tobytes())

        return encode, None, False  # not intra-only: needs the previous frame

    return build


def rung_yuv420_zstd(level: int):
    """Subsample chroma, then zstd.

    Human vision carries far less chroma resolution than luma, so 4:2:0 throws
    away half the data before the compressor sees it. This is the cheapest
    genuinely lossy step available with no dependency at all.
    """
    import zstandard

    comp = zstandard.ZstdCompressor(level=level)

    def build(frames):
        def encode(frame, prev):
            f = frame.astype(np.float32)
            r, g, b = f[:, :, 0], f[:, :, 1], f[:, :, 2]
            y = (0.299 * r + 0.587 * g + 0.114 * b)
            u = (-0.169 * r - 0.331 * g + 0.5 * b) + 128.0
            v = (0.5 * r - 0.419 * g - 0.081 * b) + 128.0
            packed = (
                y.astype(np.uint8).tobytes()
                + u[::2, ::2].astype(np.uint8).tobytes()
                + v[::2, ::2].astype(np.uint8).tobytes()
            )
            return comp.compress(packed)

        return encode, None, True

    return build


def rung_jpeg_simplejpeg(quality: int):
    def build(frames):
        import simplejpeg

        def encode(frame, prev):
            return simplejpeg.encode_jpeg(
                np.ascontiguousarray(frame), quality=quality, colorspace="RGB"
            )

        def decode(payload):
            return simplejpeg.decode_jpeg(payload, colorspace="RGB")

        return encode, decode, True

    return build


def rung_jpeg_pillow(quality: int):
    def build(frames):
        import io

        from PIL import Image

        def encode(frame, prev):
            bio = io.BytesIO()
            Image.fromarray(frame).save(bio, format="JPEG", quality=quality)
            return bio.getvalue()

        def decode(payload):
            return np.asarray(Image.open(io.BytesIO(payload)).convert("RGB"))

        return encode, decode, True

    return build


def rung_h264_pyav(bitrate_mbps: float, all_intra: bool, encoder: str = "libx264"):
    """H.264 through PyAV/FFmpeg.

    `all_intra` is the interesting axis, not the bitrate: a GOP compresses far
    better but every P-frame depends on its predecessor, so a lost packet
    corrupts everything until the next keyframe -- on a lossy Wi-Fi link, to a
    viewfinder, that is a worse failure than a bigger stream. All-intra also has
    no reorder delay at the decoder, which is latency that cannot be recovered
    later by any amount of tuning.
    """
    def build(frames):
        import av

        def encode_all(frame_list):
            import io

            buf = io.BytesIO()
            container = av.open(buf, mode="w", format="h264")
            # yuv420p subsamples chroma 2x1, so both dimensions must be even.
            # A 793x443 capture is odd on BOTH axes and x264 rejects it with a
            # bare external-library error that says nothing about why -- crop the
            # last row/column rather than pad, so no invented pixels enter the
            # measurement.
            h = frame_list[0].shape[0] & ~1
            w = frame_list[0].shape[1] & ~1
            stream = container.add_stream(encoder, rate=30)
            stream.width = w
            stream.height = h
            stream.pix_fmt = "yuv420p"
            stream.bit_rate = int(bitrate_mbps * 1_000_000)
            opts = {"tune": "zerolatency", "preset": "veryfast"}
            if all_intra:
                opts["x264-params"] = "keyint=1"
            stream.options = opts
            sizes = []
            for arr in frame_list:
                packet_bytes = 0
                vframe = av.VideoFrame.from_ndarray(
                    np.ascontiguousarray(arr[:h, :w]), format="rgb24"
                )
                for packet in stream.encode(vframe):
                    packet_bytes += packet.size
                sizes.append(packet_bytes)
            for packet in stream.encode():
                sizes[-1] += packet.size
            container.close()
            return sizes

        return None, None, all_intra, encode_all

    return build


#: name -> builder. Rungs whose dependency is missing are reported as
#: unavailable rather than skipped silently: "we could not test it" and "it was
#: no good" are different answers and the report must not conflate them.
LADDER: Dict[str, Callable] = {
    "raw": rung_raw,
    "zstd1": rung_zstd(1),
    "zstd3": rung_zstd(3),
    "zstd1_delta": rung_zstd_delta(1),
    "yuv420_zstd1": rung_yuv420_zstd(1),
    "jpeg_q75_simplejpeg": rung_jpeg_simplejpeg(75),
    "jpeg_q90_simplejpeg": rung_jpeg_simplejpeg(90),
    "jpeg_q75_pillow": rung_jpeg_pillow(75),
    "h264_8mbps_intra_x264": rung_h264_pyav(8.0, True, "libx264"),
    "h264_8mbps_gop_x264": rung_h264_pyav(8.0, False, "libx264"),
    # Hardware encoders. If one of these works it costs the CPU almost nothing,
    # which matters more than its compression: the whole constraint here is
    # Blender's main thread, not the link.
    "h264_8mbps_intra_nvenc": rung_h264_pyav(8.0, True, "h264_nvenc"),
    "h264_8mbps_gop_nvenc": rung_h264_pyav(8.0, False, "h264_nvenc"),
    "h264_8mbps_gop_mf": rung_h264_pyav(8.0, False, "h264_mf"),
}


#: Rungs that reproduce the input exactly. Stated explicitly rather than
#: inferred from "we did not decode it", because those are different facts and
#: conflating them made the report call H.264 lossless.
LOSSLESS = frozenset({"raw", "zstd1", "zstd3", "zstd1_delta"})


def measure(name: str, builder, frames, target_fps: float = 30.0) -> Dict[str, Any]:
    row: Dict[str, Any] = {"codec": name, "lossless": name in LOSSLESS}
    try:
        built = builder(frames)
    except ImportError as exc:
        row["available"] = False
        row["reason"] = f"{type(exc).__name__}: {exc}"
        return row
    except Exception as exc:  # noqa: BLE001
        row["available"] = False
        row["reason"] = f"build failed: {type(exc).__name__}: {exc}"
        return row

    row["available"] = True
    try:
        if len(built) == 4:  # whole-sequence encoders (video codecs)
            _, _, intra, encode_all = built
            t0 = time.perf_counter()
            sizes = encode_all(frames)
            elapsed_ms = (time.perf_counter() - t0) * 1000.0
            per_frame = [elapsed_ms / max(1, len(frames))] * len(frames)
            row["is_intra_only"] = intra
        else:
            encode, decode, intra = built
            row["is_intra_only"] = intra
            sizes, per_frame = [], []
            prev = None
            for frame in frames:
                t0 = time.perf_counter()
                payload = encode(frame, prev)
                per_frame.append((time.perf_counter() - t0) * 1000.0)
                sizes.append(len(payload))
                prev = frame
            if decode is not None:
                row["psnr_db"] = round(psnr(frames[0], decode(encode(frames[0], None))), 2)
            else:
                # No decoder wired for this rung. Distinct from lossless: an
                # unmeasured fidelity is not a perfect one.
                row["psnr_db"] = None
    except Exception as exc:  # noqa: BLE001
        row["available"] = False
        row["reason"] = f"encode failed: {type(exc).__name__}: {exc}"
        return row

    mean_bytes = sum(sizes) / len(sizes)
    row["encode_ms"] = ms.summarize(per_frame)
    row["bytes_per_frame"] = int(mean_bytes)
    row["bitrate_mbps"] = round(mean_bytes * 8 * target_fps / 1e6, 2)
    row["ratio_vs_raw"] = round(frames[0].nbytes / max(1.0, mean_bytes), 2)
    return row


def run(corpus_dir: Path, limit: int, target_fps: float) -> Dict[str, Any]:
    corpus = Corpus(corpus_dir)
    frames = corpus.frames(limit)
    results = ms.new_results("phase2", {
        "corpus": str(corpus_dir),
        "corpus_frames": len(frames),
        "width": corpus.width,
        "height": corpus.height,
        "interpreter": sys.executable,
    })
    results["corpus_meta"] = corpus.meta
    for name, builder in LADDER.items():
        ms.add_row(results, measure(name, builder, frames, target_fps))
    return results


def main() -> None:
    ap = argparse.ArgumentParser(prog="codecs")
    ap.add_argument("--corpus", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--limit", type=int, default=60)
    ap.add_argument("--target-fps", type=float, default=30.0)
    args = ap.parse_args()

    results = run(Path(args.corpus), args.limit, args.target_fps)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8", newline="\n")
    print("CODEC_LADDER " + json.dumps({"out": str(out)}))


if __name__ == "__main__":
    main()
