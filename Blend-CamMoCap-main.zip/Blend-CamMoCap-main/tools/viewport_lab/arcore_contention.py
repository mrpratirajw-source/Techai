# SPDX-License-Identifier: GPL-3.0-or-later
"""Does decoding a viewport stream cost ARCore its tracking?

The last big risk. Both viewport modes want the GPU and the CPU while ARCore is
tracking through its own `GLSurfaceView` in the same process. If tracking quality
moves, viewport streaming conflicts with the product's core promise, and no
amount of good picture quality would make that a trade worth taking.

Reuses the debug trace recorder that already exists rather than adding
instrumentation: it writes an `arcore_frame` event per ARCore frame with a
timestamp and a tracking state, and it takes operator markers. That is exactly
the measurement, so the only new thing here is the orchestration.

**Windows are interleaved, not blocked.** baseline, load, baseline, load. The
phone is on a desk in a room whose light and position drift, and a single
before/after comparison would charge any drift to the decoder. Alternating means
drift lands on both sides.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

_HERE = Path(__file__).resolve().parent
for _p in (str(_HERE), str(_HERE.parent)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import metrics_schema as ms  # noqa: E402


class Phone:
    def __init__(self, adb: str, serial: str) -> None:
        self.adb = adb
        self.serial = serial

    def shell(self, cmd: str, timeout: float = 30.0) -> str:
        out = subprocess.run(
            [self.adb, "-s", self.serial, "shell", cmd],
            capture_output=True, text=True, timeout=timeout,
        )
        return out.stdout

    def broadcast(self, action: str, *extras: str) -> str:
        return self.shell(f"am broadcast -a {action} " + " ".join(extras))

    def logcat_clear(self) -> None:
        subprocess.run([self.adb, "-s", self.serial, "logcat", "-c"], check=False)

    def logcat(self, tag: str) -> str:
        out = subprocess.run(
            [self.adb, "-s", self.serial, "logcat", "-d", "-s", tag],
            capture_output=True, text=True,
        )
        return out.stdout

    def pull(self, remote: str, local: Path) -> None:
        local.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(
            [self.adb, "-s", self.serial, "pull", remote, str(local)],
            capture_output=True, check=False,
        )


def wait_for_bench(phone: Phone, timeout: float) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        time.sleep(3)
        text = phone.logcat("ViewportBench")
        if "VIEWPORT_BENCH_DONE" in text or "VIEWPORT_BENCH_FAIL" in text:
            return True
    return False


def parse_trace(path: Path) -> Dict[str, Any]:
    """Split the trace into marker-delimited windows and describe each."""
    markers: List[Dict[str, Any]] = []
    frames: List[Dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        kind = row.get("kind")
        if kind == "marker":
            markers.append(row)
        elif kind == "arcore_frame":
            frames.append(row)

    windows: List[Dict[str, Any]] = []
    for index, marker in enumerate(markers):
        label = str(marker.get("label", "?"))
        start = marker.get("t") or marker.get("observed_ns") or marker.get("ns")
        end = None
        if index + 1 < len(markers):
            end = markers[index + 1].get("t") or markers[index + 1].get("observed_ns") \
                or markers[index + 1].get("ns")
        if start is None:
            continue
        inside = [
            f for f in frames
            if (f.get("observed_ns") or f.get("t") or 0) >= start
            and (end is None or (f.get("observed_ns") or f.get("t") or 0) < end)
        ]
        windows.append(summarize_window(label, inside, start, end))
    return {"markers": [m.get("label") for m in markers],
            "frames_total": len(frames), "windows": windows}


def summarize_window(label: str, frames: List[Dict[str, Any]],
                     start: int, end: Optional[int]) -> Dict[str, Any]:
    stamps = sorted(f.get("observed_ns") or f.get("t") or 0 for f in frames)
    intervals = [
        (b - a) / 1e6 for a, b in zip(stamps, stamps[1:]) if b > a
    ]
    # The trace writes `state` and `reason`, not `tracking_state`. Reading the
    # wrong key does not raise -- it yields "?" for every frame and a tidy
    # 0.0% tracking figure in BOTH windows, which reads as a real result rather
    # than a parse failure. That it was identical on both sides is what gave it
    # away; a plausible-looking difference would have gone straight into the
    # report.
    states: Dict[str, int] = {}
    reasons: Dict[str, int] = {}
    for f in frames:
        key = str(f.get("state", "?"))
        states[key] = states.get(key, 0) + 1
        why = str(f.get("reason", "?"))
        if why not in ("NONE", "?"):
            reasons[why] = reasons.get(why, 0) + 1
    duration_s = ((end or (stamps[-1] if stamps else start)) - start) / 1e9
    tracking = states.get("TRACKING", 0)
    return {
        "window": label,
        "frames": len(frames),
        "duration_s": round(duration_s, 2),
        "rate_hz": round(len(frames) / duration_s, 2) if duration_s > 0 else None,
        "interval_ms": ms.summarize(intervals),
        "tracking_states": states,
        "failure_reasons": reasons,
        "tracking_pct": round(tracking / len(frames) * 100.0, 1) if frames else None,
    }


def main() -> None:
    ap = argparse.ArgumentParser(prog="arcore_contention")
    ap.add_argument("--serial", required=True)
    ap.add_argument("--adb", default=None)
    ap.add_argument("--out", required=True)
    ap.add_argument("--window", type=float, default=12.0)
    ap.add_argument("--cycles", type=int, default=2)
    ap.add_argument("--limit", type=int, default=120, help="frames per decode run")
    ap.add_argument("--reparse", default=None,
                    help="re-analyse an existing .ptrace instead of measuring")
    args = ap.parse_args()

    if args.reparse:
        _emit(Path(args.reparse), Path(args.out), {"serial": "reparsed"}, "")
        return

    adb = args.adb or str(Path.home() / "AppData/Local/Android/Sdk/platform-tools/adb.exe")
    phone = Phone(adb, args.serial)

    phone.logcat_clear()
    phone.broadcast("dev.pocketrig.android.TRACE_START", "--es source arcore")
    time.sleep(2.0)

    # Let ARCore settle before the first window: its first seconds are warm-up
    # and would be charged to whichever window happened to catch them.
    phone.broadcast("dev.pocketrig.android.TRACE_MARK", "--es label WARMUP")
    time.sleep(args.window)

    for cycle in range(args.cycles):
        phone.broadcast("dev.pocketrig.android.TRACE_MARK", f"--es label BASE{cycle}")
        time.sleep(args.window)

        phone.logcat_clear()
        phone.broadcast("dev.pocketrig.android.TRACE_MARK", f"--es label LOAD{cycle}")
        phone.broadcast("dev.pocketrig.android.VIEWPORT_BENCH", f"--ei limit {args.limit}")
        if not wait_for_bench(phone, timeout=args.window * 6):
            print(f"warning: decode run {cycle} did not report completion")

    phone.broadcast("dev.pocketrig.android.TRACE_MARK", "--es label END")
    time.sleep(1.0)
    phone.broadcast("dev.pocketrig.android.TRACE_STOP")
    time.sleep(2.0)

    stopped = phone.logcat("ViewportBench")
    listing = phone.shell(
        "ls -t /storage/emulated/0/Android/data/dev.pocketrig.android/files/*.ptrace | head -1"
    ).strip()
    if not listing:
        raise SystemExit("no .ptrace file found; was TRACE_START accepted?")

    local = Path(args.out).with_suffix(".ptrace")
    phone.pull(listing, local)
    if not local.exists():
        raise SystemExit(f"could not pull {listing}")

    _emit(local, Path(args.out), {"serial": args.serial}, stopped)


def _emit(local: Path, out: Path, ctx: Dict[str, Any], stopped: str) -> None:
    parsed = parse_trace(local)
    results = ms.new_results("phase4b", dict(ctx, trace=str(local)))
    for window in parsed["windows"]:
        ms.add_row(results, window)

    # Pool the alternating windows so drift is shared rather than attributed.
    def pool(prefix: str) -> Dict[str, Any]:
        rows = [w for w in parsed["windows"] if w["window"].startswith(prefix)]
        frames = sum(r["frames"] for r in rows)
        secs = sum(r["duration_s"] for r in rows)
        p95 = [r["interval_ms"].get("p95") for r in rows if r["interval_ms"].get("p95")]
        tracking = [r["tracking_pct"] for r in rows if r["tracking_pct"] is not None]
        return {
            "windows": len(rows),
            "frames": frames,
            "rate_hz": round(frames / secs, 2) if secs else None,
            "interval_p95_ms": round(sum(p95) / len(p95), 2) if p95 else None,
            "tracking_pct": round(sum(tracking) / len(tracking), 1) if tracking else None,
        }

    base, load = pool("BASE"), pool("LOAD")
    verdict = {
        "baseline": base,
        "loaded": load,
        "rate_delta_hz": (
            round(load["rate_hz"] - base["rate_hz"], 2)
            if base["rate_hz"] and load["rate_hz"] else None
        ),
        "rate_delta_pct": (
            round((load["rate_hz"] - base["rate_hz"]) / base["rate_hz"] * 100.0, 1)
            if base["rate_hz"] and load["rate_hz"] else None
        ),
        "tracking_delta_pct": (
            round(load["tracking_pct"] - base["tracking_pct"], 1)
            if base["tracking_pct"] is not None and load["tracking_pct"] is not None else None
        ),
    }
    results["verdict"] = verdict
    results["frames_total"] = parsed["frames_total"]
    ms.note(results, "Windows alternate baseline/load so ambient drift in light "
                     "or position lands on both sides rather than being charged "
                     "to the decoder.")
    ms.note(results, "The decoder runs in the app's own process, which is the "
                     "contention that matters -- a separate process would not "
                     "share ARCore's GL context or its CPU the same way.")
    if "VIEWPORT_BENCH_FAIL" in stopped:
        ms.note(results, "at least one decode run reported failure; see logcat")

    out.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8", newline="\n")
    print("ARCORE_CONTENTION " + json.dumps({"out": str(out), "verdict": verdict}))


if __name__ == "__main__":
    main()
