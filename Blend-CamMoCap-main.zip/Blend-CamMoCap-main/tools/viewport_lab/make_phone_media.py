# SPDX-License-Identifier: GPL-3.0-or-later
"""Encode the captured corpus into what the phone bench will decode.

Two streams from the same frames, so the phone-side comparison is like for like:

- `frames.mjpeg` -- length-prefixed JPEGs, one per frame. This is what the
  recommended encoder produces, and on Android it is decoded per frame with no
  codec session at all.
- `frames.h264` -- an Annex-B elementary stream, all-intra. This is what needs
  `MediaCodec`, and therefore what carries the decoder-priming risk the whole
  phase exists to measure.

Both are pushed to the device and read by the debug-only bench. Real captured
content rather than synthetic noise, because JPEG and H.264 both compress a real
viewport very differently from random data, and a priming measurement on a
degenerate stream would not transfer.
"""

from __future__ import annotations

import argparse
import json
import struct
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np  # noqa: E402

from encoders import Corpus  # noqa: E402


def write_mjpeg(frames, out: Path, quality: int) -> dict:
    """Length-prefixed JPEGs: `u32 length` then the JPEG, repeated.

    Framing included on purpose -- the wire will need it too, and measuring a
    decoder against a file that has no frame boundaries would skip the part the
    real receiver has to do.
    """
    import simplejpeg

    total = 0
    with out.open("wb") as fh:
        for frame in frames:
            payload = simplejpeg.encode_jpeg(
                np.ascontiguousarray(frame), quality=quality, colorspace="RGB"
            )
            fh.write(struct.pack("<I", len(payload)))
            fh.write(payload)
            total += len(payload)
    return {
        "file": out.name,
        "frames": len(frames),
        "bytes": total,
        "bytes_per_frame": total // max(1, len(frames)),
        "framing": "u32le length prefix",
    }


def write_h264(frames, out: Path, bitrate_mbps: float, all_intra: bool) -> dict:
    """Annex-B elementary stream, which is what MediaCodec wants fed to it."""
    import av

    height = frames[0].shape[0] & ~1  # yuv420p needs even dimensions
    width = frames[0].shape[1] & ~1
    container = av.open(str(out), mode="w", format="h264")
    stream = container.add_stream("libx264", rate=30)
    stream.width = width
    stream.height = height
    stream.pix_fmt = "yuv420p"
    stream.bit_rate = int(bitrate_mbps * 1_000_000)
    opts = {"tune": "zerolatency", "preset": "veryfast"}
    if all_intra:
        opts["x264-params"] = "keyint=1"
    stream.options = opts

    for arr in frames:
        vframe = av.VideoFrame.from_ndarray(
            np.ascontiguousarray(arr[:height, :width]), format="rgb24"
        )
        for packet in stream.encode(vframe):
            container.mux(packet)
    for packet in stream.encode():
        container.mux(packet)
    container.close()
    return {
        "file": out.name,
        "frames": len(frames),
        "bytes": out.stat().st_size,
        "bytes_per_frame": out.stat().st_size // max(1, len(frames)),
        "width": width,
        "height": height,
        "all_intra": all_intra,
        "framing": "annex-b",
    }


def main() -> None:
    ap = argparse.ArgumentParser(prog="make_phone_media")
    ap.add_argument("--corpus", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--limit", type=int, default=120)
    ap.add_argument("--quality", type=int, default=75)
    args = ap.parse_args()

    corpus = Corpus(Path(args.corpus))
    frames = corpus.frames(args.limit)
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    manifest = {
        "source_corpus": str(args.corpus),
        "width": corpus.width,
        "height": corpus.height,
        "streams": [
            write_mjpeg(frames, out_dir / "frames.mjpeg", args.quality),
            write_h264(frames, out_dir / "frames_intra.h264", 8.0, True),
            write_h264(frames, out_dir / "frames_gop.h264", 8.0, False),
        ],
    }
    (out_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n"
    )
    print("PHONE_MEDIA " + json.dumps(manifest))


if __name__ == "__main__":
    main()
