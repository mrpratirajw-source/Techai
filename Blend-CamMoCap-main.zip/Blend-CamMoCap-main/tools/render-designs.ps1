# SPDX-License-Identifier: GPL-3.0-or-later
# Renders every phone screen at every device profile and rebuilds the contact
# sheet at .designs/index.html. No phone and no emulator involved: the real
# Compose UI is drawn on the JVM, so a design iteration is seconds, not a
# build-install-pick-up-the-phone cycle.
#
# .designs/ is gitignored on purpose — it is a working surface for reviewing
# and arguing about the UI, not a deliverable.
param(
    [switch]$SheetOnly  # skip rendering, just rebuild the HTML
)

$ErrorActionPreference = "Stop"
$repo = Split-Path -Parent $PSScriptRoot

if (-not $SheetOnly) {
    Write-Host "== rendering screens (no device needed) =="
    Push-Location (Join-Path $repo "android")
    try {
        # -Ppocketrig.designs opts the gallery back in (it is excluded from
        # ordinary test runs); the roborazzi flag is what makes it WRITE files
        # rather than silently no-op.
        # Matched on *Gallery* rather than on a class name. This filter named
        # ScreenGallery, which was renamed to TrayGallery and left the script
        # matching nothing -- and a renderer that renders nothing looks exactly
        # like one with no changes to show.
        # The -P arguments MUST stay quoted: PowerShell otherwise splits them on
        # the dot and hands Gradle a stray ".designs" as a task name.
        & ".\gradlew.bat" :app:testDebugUnitTest `
            "-Ppocketrig.designs" "-Proborazzi.test.record=true" `
            --tests "*Gallery*" --rerun-tasks
        if ($LASTEXITCODE -ne 0) { throw "render FAILED (exit $LASTEXITCODE)" }
    } finally {
        Pop-Location
    }
}

Write-Host "== building contact sheet =="
python (Join-Path $PSScriptRoot "build_design_sheet.py")
if ($LASTEXITCODE -ne 0) { throw "sheet build FAILED (exit $LASTEXITCODE)" }

$sheet = Join-Path $repo ".designs\index.html"
$count = (Get-ChildItem (Join-Path $repo ".designs\renders") -Filter *.png -Recurse).Count
Write-Host ""
Write-Host "$count renders -> $sheet"
Write-Host "Open it in a browser; calibrate once for true physical size."
