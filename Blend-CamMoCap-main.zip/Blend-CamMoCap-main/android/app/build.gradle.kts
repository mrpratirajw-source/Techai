// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("io.github.takahirom.roborazzi")
}

// Release signing comes from android/keystore.properties (never committed).
// Without it, release falls back to the debug key so `assembleRelease` always
// builds locally; Play uploads need the real keystore.
val keystoreProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

android {
    namespace = "dev.pocketrig.android"
    compileSdk = 35

    defaultConfig {
        applicationId = "dev.pocketrig.android"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
    }

    signingConfigs {
        if (keystoreProps.isNotEmpty()) {
            create("release") {
                storeFile = rootProject.file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
            signingConfig = signingConfigs.findByName("release")
                ?: signingConfigs.getByName("debug")
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true  // BuildConfig.DEBUG gates the Motion Lab trace tap
    }

    testOptions {
        // Robolectric needs the merged resources/manifest to inflate the theme.
        unitTests.isIncludeAndroidResources = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    implementation(project(":protocol"))

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.1")

    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    debugImplementation("androidx.compose.ui:ui-tooling")
    implementation("androidx.compose.ui:ui-tooling-preview")

    // QR scanning — fully OSS (Apache-2.0), no Play Services / ML Kit.
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
    implementation("com.google.zxing:core:3.5.3")

    // 6DOF pose source (ADR-0006). The SDK client library is Apache-2.0; the
    // runtime ("Google Play Services for AR") is a system service. Optional at
    // install time — see the manifest meta-data.
    implementation("com.google.ar:core:1.54.0")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.8.0")

    // Design-time screen rendering (see tools/render-designs.ps1). These never
    // ship: they are test-only, and the gallery is excluded from ordinary runs.
    testImplementation("org.robolectric:robolectric:4.15.1")
    testImplementation("io.github.takahirom.roborazzi:roborazzi:1.43.1")
    testImplementation("io.github.takahirom.roborazzi:roborazzi-compose:1.43.1")
    testImplementation(platform("androidx.compose:compose-bom:2024.12.01"))
    testImplementation("androidx.compose.ui:ui-test-junit4")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}

// The design gallery renders every screen at every device profile, which is far
// too slow to belong in the ordinary test run -- and it asserts nothing, it just
// draws. It runs only when explicitly recording designs.
tasks.withType<Test>().configureEach {
    // Absolute: a unit test's working directory is the module dir, so a
    // relative path silently lands the renders inside android/.
    systemProperty(
        "pocketrig.designDir",
        rootProject.file("../.designs/renders").absolutePath,
    )
    if (!project.hasProperty("pocketrig.designs")) {
        filter {
            excludeTestsMatching("dev.pocketrig.android.design.*")
            isFailOnNoMatchingTests = false
        }
    }
}
