// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.bench

import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.media.Image
import android.media.ImageReader
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import dev.pocketrig.protocol.AnnexB
import java.io.File
import java.nio.ByteBuffer
import org.json.JSONArray
import org.json.JSONObject

/**
 * Phone-side decode measurement. Debug builds only — see [installViewportBench].
 *
 * Answers the question that most threatens video mode: **how long before the
 * first decoded frame appears?** An H.264 decoder is allowed to hold several
 * frames before emitting anything, and if it does, the latency floor lands past
 * anything a viewfinder can use, no matter how fast the host is. That would
 * promote the 3D scene mode from "later" to "the answer".
 *
 * It measures the MJPEG path beside it, because the two are not the same kind of
 * thing. MJPEG has no codec session and no reorder window at all: every frame is
 * independent, so first-frame delay is by construction one frame. If H.264's
 * priming is real, that difference decides the encoder.
 *
 * No GL here. `ImageReader` gives the decoder a real hardware output surface
 * without an EGL context, which keeps this measuring the decoder rather than a
 * renderer written for the occasion. Blit cost is a separate, much smaller
 * unknown.
 */
internal object ViewportBench {

    private const val DEQUEUE_TIMEOUT_US = 10_000L
    private const val WARMUP_FRAMES = 10

    // ------------------------------------------------------------------ util

    private fun percentile(sorted: List<Double>, fraction: Double): Double {
        if (sorted.isEmpty()) return 0.0
        if (sorted.size == 1) return sorted[0]
        val pos = fraction * (sorted.size - 1)
        val low = pos.toInt()
        val high = minOf(low + 1, sorted.size - 1)
        return sorted[low] + (sorted[high] - sorted[low]) * (pos - low)
    }

    private fun summarize(values: List<Double>): JSONObject {
        val sorted = values.sorted()
        return JSONObject().apply {
            put("n", sorted.size)
            if (sorted.isNotEmpty()) {
                put("min", sorted.first())
                put("p50", percentile(sorted, 0.50))
                put("p95", percentile(sorted, 0.95))
                put("max", sorted.last())
                put("mean", sorted.average())
            }
        }
    }

    // ------------------------------------------------------------------ mjpeg

    /**
     * Decode length-prefixed JPEGs, one at a time, as the receiver would.
     *
     * `BitmapFactory` is the whole decoder: no session to configure, nothing to
     * prime, nothing to flush. That is the property being measured, not an
     * implementation shortcut.
     */
    fun runMjpeg(file: File, limit: Int): JSONObject {
        val bytes = file.readBytes()
        val frames = ArrayList<ByteArray>()
        var offset = 0
        while (offset + 4 <= bytes.size && frames.size < limit) {
            val length = ByteBuffer.wrap(bytes, offset, 4)
                .order(java.nio.ByteOrder.LITTLE_ENDIAN).int
            offset += 4
            if (length <= 0 || offset + length > bytes.size) break
            frames.add(bytes.copyOfRange(offset, offset + length))
            offset += length
        }

        val decodeMs = ArrayList<Double>()
        var firstFrameMs = 0.0
        var decoded = 0
        val opts = BitmapFactory.Options()

        for ((index, payload) in frames.withIndex()) {
            val t0 = SystemClock.elapsedRealtimeNanos()
            val bitmap = BitmapFactory.decodeByteArray(payload, 0, payload.size, opts)
            val elapsed = (SystemClock.elapsedRealtimeNanos() - t0) / 1e6
            if (bitmap != null) {
                decoded++
                bitmap.recycle()
            }
            if (index == 0) firstFrameMs = elapsed
            if (index >= WARMUP_FRAMES) decodeMs.add(elapsed)
        }

        return JSONObject().apply {
            put("codec", "mjpeg")
            put("frames_in", frames.size)
            put("frames_out", decoded)
            // One by construction: the first buffer in produces the first image
            // out. There is no session that could hold it back.
            put("first_output_delay_frames", 1)
            put("first_output_ms", firstFrameMs)
            put("decode_ms", summarize(decodeMs))
            put("hardware", false)
            put("codec_name", "BitmapFactory")
        }
    }

    // ------------------------------------------------------------------ h264

    /**
     * Decode an Annex-B stream and count how many units go in before one comes out.
     *
     * That count is the headline. Everything else here — per-frame dequeue time,
     * whether the codec is hardware, whether low-latency mode was accepted — is
     * context for it.
     */
    fun runH264(file: File, width: Int, height: Int, limit: Int, lowLatency: Boolean): JSONObject {
        val units = AnnexB.split(file.readBytes()).take(limit)
        val result = JSONObject().apply {
            put("codec", "h264")
            put("units", units.size)
            put("low_latency_requested", lowLatency)
        }
        if (units.isEmpty()) {
            result.put("error", "no access units parsed")
            return result
        }

        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height)
        var lowLatencyApplied = false
        if (lowLatency && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            format.setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
            lowLatencyApplied = true
        }

        val reader = ImageReader.newInstance(width, height, ImageFormat.YUV_420_888, 6)
        val thread = HandlerThread("bench-imagereader").apply { start() }
        val produced = ArrayList<Long>()
        reader.setOnImageAvailableListener({ r ->
            val image: Image? = try { r.acquireNextImage() } catch (_: Exception) { null }
            if (image != null) {
                synchronized(produced) { produced.add(SystemClock.elapsedRealtimeNanos()) }
                image.close()
            }
        }, Handler(thread.looper))

        val codec = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        val dequeueMs = ArrayList<Double>()
        var firstOutputAfterInputs = -1
        var inputs = 0
        var outputs = 0
        var firstInputAtNs = 0L
        var firstOutputAtNs = 0L
        // Read while the codec is alive: querying after release() throws, and
        // the whole inventory then reports "unknown", which loses the ability to
        // attribute an odd result to a specific decoder.
        var codecName = "unknown"
        var queuedAheadAtFirstOutput = 0

        try {
            codec.configure(format, reader.surface, null, 0)
            codec.start()
            codecName = try { codec.name } catch (_: Exception) { "unknown" }
            val info = MediaCodec.BufferInfo()
            var unitIndex = 0
            val deadline = SystemClock.elapsedRealtime() + 30_000

            while (SystemClock.elapsedRealtime() < deadline) {
                if (unitIndex < units.size) {
                    val inIndex = codec.dequeueInputBuffer(DEQUEUE_TIMEOUT_US)
                    if (inIndex >= 0) {
                        val buffer = codec.getInputBuffer(inIndex)!!
                        buffer.clear()
                        buffer.put(units[unitIndex].bytes)
                        codec.queueInputBuffer(
                            inIndex, 0, units[unitIndex].bytes.size,
                            unitIndex * 33_333L, 0,
                        )
                        if (unitIndex == 0) firstInputAtNs = SystemClock.elapsedRealtimeNanos()
                        unitIndex++
                        inputs++
                    }
                } else if (unitIndex == units.size) {
                    val inIndex = codec.dequeueInputBuffer(DEQUEUE_TIMEOUT_US)
                    if (inIndex >= 0) {
                        codec.queueInputBuffer(
                            inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM,
                        )
                        unitIndex++
                    }
                }

                val t0 = SystemClock.elapsedRealtimeNanos()
                val outIndex = codec.dequeueOutputBuffer(info, DEQUEUE_TIMEOUT_US)
                if (outIndex >= 0) {
                    val elapsed = (SystemClock.elapsedRealtimeNanos() - t0) / 1e6
                    if (outputs == 0) {
                        // How many units had been queued when the first picture
                        // came out. NOT the decoder's inherent latency: this loop
                        // queues input every iteration and only then polls for
                        // output, so a decoder that is merely busy for a few
                        // milliseconds accumulates queued frames that it never
                        // asked for. `first_output_ms` is the honest number;
                        // this one is an upper bound on pipeline depth.
                        firstOutputAfterInputs = inputs
                        firstOutputAtNs = SystemClock.elapsedRealtimeNanos()
                        queuedAheadAtFirstOutput = inputs - 1
                    }
                    outputs++
                    if (outputs > WARMUP_FRAMES) dequeueMs.add(elapsed)
                    codec.releaseOutputBuffer(outIndex, true)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                }
                if (outputs >= units.size) break
            }
        } catch (exc: Exception) {
            result.put("error", "${exc.javaClass.simpleName}: ${exc.message}")
        } finally {
            try { codec.stop() } catch (_: Exception) {}
            try { codec.release() } catch (_: Exception) {}
            try { reader.close() } catch (_: Exception) {}
            thread.quitSafely()
        }

        result.apply {
            put("frames_in", inputs)
            put("frames_out", outputs)
            put("first_output_delay_frames", firstOutputAfterInputs)
            put(
                "first_output_ms",
                if (firstOutputAtNs > 0 && firstInputAtNs > 0) {
                    (firstOutputAtNs - firstInputAtNs) / 1e6
                } else {
                    -1.0
                },
            )
            put("dequeue_ms", summarize(dequeueMs))
            put("low_latency_applied", lowLatencyApplied)
            put("codec_name", codecName)
            put("queued_ahead_at_first_output", queuedAheadAtFirstOutput)
            put("hardware", !codecName.startsWith("OMX.google") && !codecName.startsWith("c2.android"))
            put("images_rendered", synchronized(produced) { produced.size })
        }
        return result
    }

    // ------------------------------------------------------------------- run

    /** Run everything found in [mediaDir] and write one JSON blob to [out]. */
    fun runAll(mediaDir: File, out: File, limit: Int): File {
        val manifest = JSONObject(File(mediaDir, "manifest.json").readText())
        val width = manifest.getInt("width")
        val height = manifest.getInt("height")

        val results = JSONArray()
        val mjpeg = File(mediaDir, "frames.mjpeg")
        if (mjpeg.exists()) results.put(runMjpeg(mjpeg, limit))

        // Even dimensions: the encoder rounded down for yuv420p and the decoder
        // must be configured with what was actually encoded.
        for ((file, label) in listOf(
            File(mediaDir, "frames_intra.h264") to "intra",
            File(mediaDir, "frames_gop.h264") to "gop",
        )) {
            if (!file.exists()) continue
            for (lowLatency in listOf(true, false)) {
                val row = runH264(file, width and 1.inv(), height and 1.inv(), limit, lowLatency)
                row.put("stream", label)
                results.put(row)
            }
        }

        val doc = JSONObject().apply {
            put("format", "pocketrig-viewport-phone-bench")
            put("role", "wall-clock-measurement-not-a-regression-baseline")
            put("device", "${Build.MANUFACTURER} ${Build.MODEL}")
            put("android", Build.VERSION.RELEASE)
            put("sdk", Build.VERSION.SDK_INT)
            put("width", width)
            put("height", height)
            put("rows", results)
        }
        out.parentFile?.mkdirs()
        out.writeText(doc.toString(2))
        return out
    }

    /** Codec inventory, so an odd result can be attributed to a specific decoder. */
    fun decoderInventory(): JSONArray {
        val out = JSONArray()
        val list = android.media.MediaCodecList(android.media.MediaCodecList.REGULAR_CODECS)
        for (info in list.codecInfos) {
            if (info.isEncoder) continue
            if (!info.supportedTypes.any { it.equals("video/avc", true) }) continue
            val entry = JSONObject().apply {
                put("name", info.name)
                put("hardware_accelerated",
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) info.isHardwareAccelerated else null)
                put("software_only",
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) info.isSoftwareOnly else null)
            }
            try {
                val caps = info.getCapabilitiesForType("video/avc")
                entry.put(
                    "low_latency_supported",
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        caps.isFeatureSupported(MediaCodecInfo.CodecCapabilities.FEATURE_LowLatency)
                    } else {
                        null
                    },
                )
            } catch (_: Exception) {
            }
            out.put(entry)
        }
        return out
    }
}
