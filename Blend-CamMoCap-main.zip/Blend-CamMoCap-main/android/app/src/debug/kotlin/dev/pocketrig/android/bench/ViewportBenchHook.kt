// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.bench

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.io.File
import kotlin.concurrent.thread

/**
 * Installs the adb-triggered viewport bench. **Debug variant.**
 *
 * There is a matching no-op in `src/release/`, and `MainActivity` calls this
 * unconditionally — so the release build links an empty function and none of the
 * bench exists in the shipped APK. That is deliberately stronger than the
 * `BuildConfig.DEBUG` branch `TraceRecorder` uses: a debug branch still compiles
 * the bytecode into release and leaves it to R8 to notice. This is a lot more
 * code than a trace recorder, and it registers an exported receiver, so it earns
 * the source-set split rather than sharing the older pattern.
 *
 * Driven entirely from a workstation, matching `registerTraceReceiver`:
 *
 * ```
 * adb push <media> /sdcard/Android/data/dev.pocketrig.android/files/viewport_media/
 * adb shell am broadcast -a dev.pocketrig.android.VIEWPORT_BENCH --ei limit 120
 * adb shell am broadcast -a dev.pocketrig.android.VIEWPORT_CODECS
 * adb shell am broadcast -a dev.pocketrig.android.VIEWPORT_DROP
 * ```
 *
 * VIEWPORT_DROP kills the viewport connection and nothing else, which is the
 * only honest way to test the retry path: stopping the host rotates the session
 * token, so the whole session goes down and a different path runs instead.
 *
 * The phone lies on the desk untouched for all of it.
 */
fun installViewportBench(activity: Activity, onDropViewport: () -> Unit) {
    val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val ctx = context ?: return
            when (intent?.action) {
                "dev.pocketrig.android.VIEWPORT_BENCH" -> {
                    val limit = intent.getIntExtra("limit", 120)
                    val media = File(ctx.getExternalFilesDir(null), "viewport_media")
                    val out = File(ctx.getExternalFilesDir(null), "viewport-bench.json")
                    Toast.makeText(ctx, "viewport bench…", Toast.LENGTH_SHORT).show()
                    // Off the main thread: decoding 120 frames blocks for
                    // seconds, and an ANR mid-measurement would poison the
                    // numbers as well as the run.
                    thread(name = "viewport-bench") {
                        val message = try {
                            ViewportBench.runAll(media, out, limit)
                            "VIEWPORT_BENCH_DONE ${out.absolutePath}"
                        } catch (exc: Exception) {
                            "VIEWPORT_BENCH_FAIL ${exc.javaClass.simpleName}: ${exc.message}"
                        }
                        // logcat is the channel the orchestrator reads; a Toast
                        // is for whoever happens to be looking at the phone.
                        Log.i("ViewportBench", message)
                    }
                }

                "dev.pocketrig.android.VIEWPORT_DROP" -> {
                    Log.i("ViewportBench", "VIEWPORT_DROP requested")
                    onDropViewport()
                }

                "dev.pocketrig.android.VIEWPORT_CODECS" -> {
                    Log.i("ViewportBench", "VIEWPORT_CODECS " + ViewportBench.decoderInventory())
                }
            }
        }
    }
    val filter = IntentFilter().apply {
        addAction("dev.pocketrig.android.VIEWPORT_BENCH")
        addAction("dev.pocketrig.android.VIEWPORT_CODECS")
        addAction("dev.pocketrig.android.VIEWPORT_DROP")
    }
    ContextCompat.registerReceiver(activity, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
}
