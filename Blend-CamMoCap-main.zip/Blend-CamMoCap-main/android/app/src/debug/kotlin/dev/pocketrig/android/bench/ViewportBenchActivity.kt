// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.bench

import android.app.Activity
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowManager
import java.io.DataInputStream
import java.io.File
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.concurrent.thread
import org.json.JSONObject

/**
 * Receives a live viewport stream, puts it on the screen, and reports when.
 *
 * **Debug-only**, declared in `src/debug/AndroidManifest.xml`, so it does not
 * exist in a release build at all — not the class, not the manifest entry.
 *
 * Everything measured until now has been a component cost, and a sum of
 * components is not a latency. This closes the loop: the host stamps each frame
 * with an ordinal, and this echoes that ordinal back the instant the frame has
 * been posted to a surface. The host subtracts against its own clock, so nothing
 * has to be synchronised.
 *
 * A `SurfaceView` with `lockHardwareCanvas` rather than a GL renderer. The
 * question here is when a frame reaches the display, and this path genuinely
 * goes through SurfaceFlinger to the panel; writing a GL blit for the occasion
 * would add a renderer's worth of code and its own bugs between the measurement
 * and the answer. GL blit cost is a separate, much smaller unknown.
 *
 * Launched entirely from a workstation, no taps:
 *
 * ```
 * adb shell am start -n dev.pocketrig.android/.bench.ViewportBenchActivity \
 *     --es host 192.168.1.50 --ei port 47900 --ei echo 47901
 * ```
 */
class ViewportBenchActivity : Activity(), SurfaceHolder.Callback {

    private lateinit var surfaceView: SurfaceView
    @Volatile private var running = false
    @Volatile private var surfaceReady = false
    private var worker: Thread? = null

    private val decodeMs = ArrayList<Double>()
    private val postMs = ArrayList<Double>()
    private var received = 0
    private var presented = 0
    private var dropped = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        surfaceView = SurfaceView(this)
        surfaceView.holder.addCallback(this)
        setContentView(surfaceView)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        surfaceReady = true
        start()
    }

    override fun surfaceChanged(holder: SurfaceHolder, f: Int, w: Int, h: Int) = Unit

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        surfaceReady = false
    }

    override fun onDestroy() {
        running = false
        worker?.join(2000)
        super.onDestroy()
    }

    private fun start() {
        if (running) return
        val host = intent.getStringExtra("host") ?: run {
            Log.e(TAG, "STREAM_FAIL no --es host")
            finish()
            return
        }
        val port = intent.getIntExtra("port", 47900)
        val echoPort = intent.getIntExtra("echo", 47901)
        val maxFrames = intent.getIntExtra("frames", 100000)
        running = true
        worker = thread(name = "viewport-stream") { receive(host, port, echoPort, maxFrames) }
    }

    private fun receive(host: String, port: Int, echoPort: Int, maxFrames: Int) {
        val echoSocket = DatagramSocket()
        val echoAddress = InetAddress.getByName(host)
        val echoBuffer = ByteBuffer.allocate(20).order(ByteOrder.LITTLE_ENDIAN)
        val header = ByteArray(20)
        val opts = BitmapFactory.Options()

        try {
            Socket().use { socket ->
                socket.tcpNoDelay = true
                socket.connect(InetSocketAddress(host, port), 10_000)
                val input = DataInputStream(socket.getInputStream().buffered(1 shl 16))
                Log.i(TAG, "STREAM_CONNECTED $host:$port")

                while (running && presented < maxFrames) {
                    input.readFully(header)
                    val buf = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
                    val magic = ByteArray(4).also { buf.get(it) }
                    if (!magic.contentEquals(MAGIC)) {
                        Log.e(TAG, "STREAM_FAIL bad magic")
                        break
                    }
                    val ordinal = buf.int
                    buf.long // host capture time; the host pairs on ordinal
                    val length = buf.int
                    if (length <= 0 || length > MAX_PAYLOAD) {
                        Log.e(TAG, "STREAM_FAIL implausible payload $length")
                        break
                    }
                    val payload = ByteArray(length)
                    input.readFully(payload)
                    received++

                    val t0 = SystemClock.elapsedRealtimeNanos()
                    val bitmap = BitmapFactory.decodeByteArray(payload, 0, length, opts)
                    val t1 = SystemClock.elapsedRealtimeNanos()
                    if (bitmap == null || !surfaceReady) {
                        dropped++
                        continue
                    }

                    val holder = surfaceView.holder
                    val canvas = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        holder.lockHardwareCanvas()
                    } else {
                        holder.lockCanvas()
                    }
                    if (canvas == null) {
                        dropped++
                        bitmap.recycle()
                        continue
                    }
                    try {
                        canvas.drawColor(Color.BLACK)
                        canvas.drawBitmap(
                            bitmap,
                            null,
                            Rect(0, 0, canvas.width, canvas.height),
                            null,
                        )
                    } finally {
                        holder.unlockCanvasAndPost(canvas)
                    }
                    val t2 = SystemClock.elapsedRealtimeNanos()
                    bitmap.recycle()

                    decodeMs.add((t1 - t0) / 1e6)
                    postMs.add((t2 - t1) / 1e6)
                    presented++

                    // Echo the moment it is posted, not after any bookkeeping:
                    // anything between the post and this send is added to the
                    // host's round-trip figure and blamed on the link.
                    echoBuffer.clear()
                    echoBuffer.putInt(ordinal).putLong(t1).putLong(t2)
                    echoSocket.send(
                        DatagramPacket(echoBuffer.array(), 20, echoAddress, echoPort),
                    )
                }
            }
        } catch (exc: Exception) {
            Log.i(TAG, "STREAM_END ${exc.javaClass.simpleName}: ${exc.message}")
        } finally {
            echoSocket.close()
            writeResults()
            running = false
            runOnUiThread { finish() }
        }
    }

    private fun writeResults() {
        fun summarize(values: List<Double>): JSONObject {
            val sorted = values.sorted()
            return JSONObject().apply {
                put("n", sorted.size)
                if (sorted.isNotEmpty()) {
                    put("min", sorted.first())
                    put("p50", sorted[sorted.size / 2])
                    put("p95", sorted[(sorted.size * 95 / 100).coerceAtMost(sorted.size - 1)])
                    put("max", sorted.last())
                }
            }
        }
        val doc = JSONObject().apply {
            put("format", "pocketrig-viewport-stream-phone")
            put("device", "${Build.MANUFACTURER} ${Build.MODEL}")
            put("received", received)
            put("presented", presented)
            put("dropped", dropped)
            put("decode_ms", summarize(decodeMs))
            put("post_ms", summarize(postMs))
        }
        val out = File(getExternalFilesDir(null), "viewport-stream.json")
        out.writeText(doc.toString(2))
        Log.i(TAG, "STREAM_DONE ${out.absolutePath} presented=$presented dropped=$dropped")
    }

    private companion object {
        const val TAG = "ViewportBench"
        val MAGIC = byteArrayOf('P'.code.toByte(), 'R'.code.toByte(),
                                'V'.code.toByte(), 'P'.code.toByte())
        const val MAX_PAYLOAD = 8 * 1024 * 1024
    }
}
