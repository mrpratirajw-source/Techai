// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowCompat
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.ar.core.ArCoreApk
import dev.pocketrig.android.bench.installViewportBench
import dev.pocketrig.android.ui.PocketrigApp
import dev.pocketrig.android.ui.PocketrigTheme
import dev.pocketrig.android.ui.SixDofUi
import dev.pocketrig.protocol.Quaternion
import dev.pocketrig.protocol.MotionCorroboration
import dev.pocketrig.protocol.PoseSource
import dev.pocketrig.protocol.SessionState
import dev.pocketrig.protocol.TrackingIssue
import dev.pocketrig.protocol.TrackingQuality
import dev.pocketrig.protocol.Vec3
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/**
 * The one and only screen. All state lives in [SessionViewModel]; this
 * activity wires the pose pipelines to the lifecycle (game rotation vector
 * by default, ARCore while the 6DOF toggle is on — never both) and
 * translates session state into window-level side effects (keep-screen-on,
 * manually selected phone orientation).
 */
class MainActivity : ComponentActivity() {

    private val viewModel: SessionViewModel by viewModels()
    private var sensorPipeline: SensorPipeline? = null
    private var arPipeline: ArCorePipeline? = null
    private var imuTelemetryPipeline: ImuTelemetryPipeline? = null

    /** Physical corroboration of ARCore's translation; shipped, not debug-only. */
    private val motionCorroboration = MotionCorroboration()
    private var traceRecorder: TraceRecorder? = null
    private var traceReceiver: BroadcastReceiver? = null
    private var traceToneGenerator: ToneGenerator? = null
    private val traceCueHandler = Handler(Looper.getMainLooper())
    private var pendingTraceCue: Runnable? = null

    /** Which pipeline currently owns [SessionClient.updatePose] (ADR-0006). */
    private var activePoseSourceIsAr = false
    private var poseSourceStarted = false

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) toggleSixDof() // retry the flip now that we may proceed
    }

    /**
     * Hide the status and navigation bars, and keep them hidden.
     *
     * A viewfinder is a viewfinder: a notification bar over the top of the frame
     * is both a distraction and a lie about how much of the shot you can see.
     * BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE means a swipe still reveals them
     * briefly, so nothing is unreachable -- they just do not stay.
     *
     * Re-applied on every focus gain because Android restores the bars after a
     * dialog, a permission prompt or a lock/unlock, and setting this once in
     * onCreate leaves them back on screen the first time any of that happens.
     */
    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Motion Lab capture (debug builds only): adb-broadcast-toggled
        // acquisition/configuration/timing trace — zero UI.
        val recorder = if (BuildConfig.DEBUG) TraceRecorder(this) else null
        traceRecorder = recorder
        // Runs in every build: the detector needs independent physical evidence
        // to catch ARCore inventing translation while it cannot see.
        imuTelemetryPipeline = ImuTelemetryPipeline(this, recorder, motionCorroboration)
        if (recorder != null) {
            traceToneGenerator = try {
                ToneGenerator(AudioManager.STREAM_MUSIC, 90)
            } catch (_: RuntimeException) {
                null
            }
            registerTraceReceiver(recorder)
        }
        // One tap fans every pose out to the debug trace recorder AND the
        // offline recorder (the latter no-ops unless offline-recording). The
        // pipelines run whether connected or not, so offline capture works
        // with no PC in sight.
        val tap: (String, Quaternion, Long, Vec3?, TrackingQuality, TrackingIssue, Float) -> Unit =
            { source, q, ts, pos, quality, issue, focalMm ->
                recorder?.tap(source, q, ts, pos)
                viewModel.captureOfflinePose(q, ts, pos, quality, issue, focalMm)
            }
        val sensors = SensorPipeline(
            this,
            viewModel.client,
            tap = tap,
            onProtocolQuat = viewModel::onProtocolQuat,
        )
        sensorPipeline = sensors
        val ar = ArCorePipeline(
            this,
            viewModel.client,
            onError = { e ->
                runOnUiThread {
                    Toast.makeText(this, e.message ?: "ARCore error", Toast.LENGTH_SHORT).show()
                    viewModel.setSixDofEnabled(false)
                }
            },
            tap = tap,
            telemetry = recorder,
            corroboration = motionCorroboration,
            // Rotation keeps tracking through a visual loss. The rotation vector
            // needs no camera, so freezing orientation while ARCore is blind
            // only loses the operator's framing and dumps it back in one step.
            orientationSource = { sensors.latestProtocolQuaternion },
        )
        arPipeline = ar
        viewModel.setSixDofSupported(arcoreSupported(this))

        // Unconditional on purpose: the variant decides which implementation is
        // linked. src/release/ supplies an empty one, so the bench and its
        // exported receiver are absent from a shipped APK rather than merely
        // unreachable inside it.
        installViewportBench(this, viewModel.viewport::dropConnection)

        hideSystemBars()
        setContent {
            PocketrigTheme {
                PocketrigApp(
                    viewModel = viewModel,
                    sixDof = SixDofUi(
                        supported = viewModel.sixDofSupported,
                        enabled = viewModel.sixDofEnabled,
                        trackingStatus = ar.trackingStatus,
                        fastMotion = viewModel.fastMotion,
                        onToggle = ::toggleSixDof,
                        viewfinder = ar::view,
                    ),
                )
            }
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                combine(
                    viewModel.state,
                    viewModel.viewfinderActive,
                ) { state, viewfinder -> state to viewfinder }.collect { (state, viewfinder) ->
                    applyWindowSideEffects(state, viewfinder)
                }
            }
        }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.RESUMED) {
                combine(
                    viewModel.sixDofEnabled,
                    viewModel.viewfinderActive,
                ) { six, vf -> six && vf }.collect { arWanted -> applyPipelines(arWanted) }
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Display-oriented pose labels may change discontinuously here. Tell
        // Blender to preserve the visible camera against the next RAW rigid
        // pose; never misuse user RECENTER (which changes pause/Home).
        viewModel.client.requestFrameReset("display")
    }

    override fun onResume() {
        super.onResume()
        if (poseSourceStarted) viewModel.client.requestFrameReset("resume")
        applyPipelines(viewModel.sixDofEnabled.value && viewModel.viewfinderActive.value)
    }

    override fun onPause() {
        sensorPipeline?.stop()
        imuTelemetryPipeline?.stop()
        arPipeline?.pause()
        super.onPause()
    }

    override fun onDestroy() {
        traceReceiver?.let { unregisterReceiver(it) }
        traceRecorder?.stop()
        pendingTraceCue?.let(traceCueHandler::removeCallbacks)
        pendingTraceCue = null
        traceToneGenerator?.release()
        traceToneGenerator = null
        imuTelemetryPipeline?.stop()
        arPipeline?.destroy()
        super.onDestroy()
    }

    /**
     * Debug-only motion-trace capture control:
     *   adb shell am broadcast -a dev.pocketrig.android.TRACE_START
     *   adb shell am broadcast -a dev.pocketrig.android.TRACE_STOP
     *   adb shell am broadcast -a dev.pocketrig.android.TRACE_MARK --es label CLOSE
     *   adb shell am broadcast -a dev.pocketrig.android.POSE_MODE --es mode raw
     *   adb shell am broadcast -a dev.pocketrig.android.POSE_MODE --es mode anchor
     *   adb shell am broadcast -a dev.pocketrig.android.ARCORE_PROFILE --ei index 0 --es focus fixed
     * Exported on purpose (debug builds only) so the adb shell can reach it.
     */
    private fun registerTraceReceiver(recorder: TraceRecorder) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    "dev.pocketrig.android.TRACE_START" -> {
                        val src = traceSource(
                            intent.getStringExtra("source"),
                            activePoseSourceIsAr,
                        )
                        val path = recorder.start(src)
                        Toast.makeText(this@MainActivity, "trace → $path", Toast.LENGTH_SHORT).show()
                    }
                    "dev.pocketrig.android.TRACE_STOP" -> {
                        val path = recorder.stop()
                        Toast.makeText(this@MainActivity, "trace saved: $path", Toast.LENGTH_SHORT).show()
                    }
                    "dev.pocketrig.android.TRACE_MARK" -> {
                        val label = intent.getStringExtra("label")
                            ?.trim()
                            ?.take(32)
                            ?.takeIf { it.isNotEmpty() }
                            ?: "MARK"
                        recorder.marker(label)
                        playTraceCue(label)
                        Toast.makeText(this@MainActivity, label, Toast.LENGTH_SHORT).show()
                    }
                    "dev.pocketrig.android.POSE_MODE" -> {
                        val mode = ArCorePoseMode.parse(intent.getStringExtra("mode"))
                        val recording = viewModel.state.value is SessionState.Recording ||
                            viewModel.state.value is SessionState.Finalizing ||
                            viewModel.offlineRecording.value
                        val message = when {
                            mode == null -> "pose mode must be raw or anchor"
                            recording -> "finish recording before changing pose mode"
                            else -> {
                                arPipeline?.requestPoseMode(mode)
                                "6DOF experiment: ${mode.traceName}"
                            }
                        }
                        Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show()
                    }
                    "dev.pocketrig.android.ARCORE_PROFILE" -> {
                        val requestedIndex = intent.getIntExtra("index", -1).takeIf { it >= 0 }
                        val focus = ArCoreCameraExperiment.Focus.parse(
                            intent.getStringExtra("focus"),
                        )
                        val message = if (focus == null) {
                            "focus must be fixed or auto"
                        } else {
                            val experiment = ArCoreCameraExperiment(requestedIndex, focus)
                            arPipeline?.requestCameraExperiment(experiment)
                                ?: "ARCore experiment: ${experiment.traceName}"
                        }
                        Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction("dev.pocketrig.android.TRACE_START")
            addAction("dev.pocketrig.android.TRACE_STOP")
            addAction("dev.pocketrig.android.TRACE_MARK")
            addAction("dev.pocketrig.android.POSE_MODE")
            addAction("dev.pocketrig.android.ARCORE_PROFILE")
        }
        ContextCompat.registerReceiver(
            this, receiver, filter, ContextCompat.RECEIVER_EXPORTED,
        )
        traceReceiver = receiver
    }

    private fun playTraceCue(label: String) {
        pendingTraceCue?.let(traceCueHandler::removeCallbacks)
        pendingTraceCue = null
        val generator = traceToneGenerator ?: return
        generator.startTone(ToneGenerator.TONE_PROP_BEEP, TRACE_CUE_DURATION_MS)
        if (traceCueCount(label) == 2) {
            val second = Runnable {
                traceToneGenerator?.startTone(
                    ToneGenerator.TONE_PROP_BEEP,
                    TRACE_CUE_DURATION_MS,
                )
                pendingTraceCue = null
            }
            pendingTraceCue = second
            traceCueHandler.postDelayed(second, TRACE_CUE_SECOND_BEEP_DELAY_MS)
        }
    }

    private companion object {
        const val TRACE_CUE_DURATION_MS = 220
        const val TRACE_CUE_SECOND_BEEP_DELAY_MS = 420L
    }

    /**
     * Exactly one pose source runs at a time (ADR-0006). [arWanted] is 6DOF
     * enabled AND a viewfinder screen actually showing — so ARCore (and the
     * camera it holds) is released the moment we leave the viewfinder, e.g. on
     * the QR-scan screen, where the scanner needs the camera.
     */
    private fun applyPipelines(arWanted: Boolean) {
        if (!lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) return
        // Declare the authoritative source BEFORE touching either pipeline, so a
        // frame/sensor callback already running cannot land a pose from the
        // outgoing frame after the FRAME_RESET boundary. Without this, rapid
        // toggling made the host rebase against the frame it was leaving and the
        // inter-source yaw stuck instead of cancelling.
        viewModel.client.setActivePoseSource(
            if (arWanted) PoseSource.ARCORE else PoseSource.SENSOR,
        )
        if (poseSourceStarted && arWanted != activePoseSourceIsAr) {
            viewModel.client.requestFrameReset("source")
        }
        if (arWanted) {
            // Keep the rotation vector listening, but not feeding poses: ARCore
            // owns updatePose, and reads this only to continue rotation while it
            // cannot see. Switched in place — re-registering would re-establish
            // the sensor's arbitrary yaw reference on every toggle.
            sensorPipeline?.setFeedsPose(false)
            imuTelemetryPipeline?.start()
            arPipeline?.resume()
        } else {
            imuTelemetryPipeline?.stop()
            arPipeline?.pause()
            sensorPipeline?.setFeedsPose(true)
        }
        activePoseSourceIsAr = arWanted
        poseSourceStarted = true
    }

    /**
     * The 6DOF toggle's gate: camera permission, then ARCore installed, then
     * flip. Each missing prerequisite triggers its own flow and re-enters
     * here when satisfied.
     */
    private fun toggleSixDof() {
        if (viewModel.sixDofEnabled.value) {
            viewModel.setSixDofEnabled(false)
            return
        }
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.CAMERA,
        ) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            return
        }
        try {
            when (ArCoreApk.getInstance().requestInstall(this, true)) {
                ArCoreApk.InstallStatus.INSTALLED -> viewModel.setSixDofEnabled(true)
                ArCoreApk.InstallStatus.INSTALL_REQUESTED -> Unit // resumes post-install
            }
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "ARCore unavailable", Toast.LENGTH_SHORT).show()
        }
    }

    private fun applyWindowSideEffects(state: SessionState, viewfinderActive: Boolean) {
        // A virtual camera that dozes off mid-shot is not radically simple.
        // The offline viewfinder is disconnected by design, so session state
        // alone cannot decide this policy.
        val keepOn = shouldKeepScreenOn(state, viewfinderActive)
        if (keepOn) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }
}
