// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.pocketrig.android.ViewportClient
import kotlinx.coroutines.flow.StateFlow

/**
 * Blender's viewport, drawn over the camera passthrough.
 *
 * **Over, not instead of.** ARCore tracks through the passthrough surface, so a
 * layout that replaces it does not merely change the picture, it stops 6DOF
 * working — the same trap that made the 6DOF toggle appear to do nothing when
 * this screen was first written without a slot for that surface.
 *
 * [ContentScale.Fit] rather than `Crop`: this is an instrument for judging
 * framing, so showing less than the whole frame would be lying about the shot.
 * The letterbox is opaque for the same reason — a translucent one would let the
 * phone camera bleed in around the edges of Blender's frame and make it
 * genuinely hard to tell where one ends and the other begins.
 */
@Composable
internal fun ViewportOverlay(
    frames: StateFlow<ViewportClient.ViewportImage?>,
    onPresented: (ViewportClient.ViewportImage) -> Unit,
    modifier: Modifier = Modifier,
) {
    val frame by frames.collectAsStateWithLifecycle()
    val shown = frame ?: return

    // Reported from composition rather than from decode: the host wants to know
    // when the operator could SEE the frame, and one decoded then superseded
    // before a redraw never reached anyone's eye. Keyed on the ordinal so it
    // fires once per frame rather than on every recomposition.
    LaunchedEffect(shown.ordinal) { onPresented(shown) }

    ViewportImage(shown, modifier)
}

/**
 * The frame itself, kept upright however the phone is held.
 *
 * **The picture must not turn with the device.** `Frames.shotRotated` already
 * cancels the grip on the way out, so Blender's camera stays upright whichever
 * way the phone is held and the frame arrives world-upright in the render's
 * aspect — always, in Auto and under a lock alike. Drawing it glued to the
 * device therefore tips the picture over while the shot did not move.
 *
 * The orientation *lock* deliberately does not switch this off. It decides which
 * way up the Blender camera is, which is a property of the footage; this decides
 * which way up the picture is on the glass, which is a property of how you are
 * holding the thing. Tying them together would mean locking to landscape put
 * your viewfinder on its side the moment you tilted the phone — breaking the
 * instrument to express a preference about the recording.
 *
 * Which is the same rule the rest of this screen already follows: the dock does
 * not move, only its content turns. A streamed frame is content.
 *
 * [upright] and not [uprightInPlace], because the box is emphatically not square:
 * `rigRotate` re-measures with the axes swapped, so a landscape frame in a
 * portrait grip is fitted to the space it will actually occupy. A plain graphics
 * rotate would fit it to the unturned box first and then spin it into a hole a
 * third of the size.
 */
@Composable
internal fun ViewportImage(
    shown: ViewportClient.ViewportImage,
    modifier: Modifier = Modifier,
) {
    // The letterbox stays put and covers the whole region; only the picture
    // turns. Rotating the black with it would leave the corners unpainted.
    Box(modifier.fillMaxSize().background(Color.Black), Alignment.Center) {
        Image(
            bitmap = shown.image,
            contentDescription = null,
            modifier = Modifier.fillMaxSize().upright(),
            contentScale = ContentScale.Fit,
        )
    }
}
