// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import dev.pocketrig.protocol.ViewportFrame
import dev.pocketrig.protocol.ViewportFrameHeader
import java.io.BufferedInputStream
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Receives the host's viewport stream and decodes it for display.
 *
 * The pixel half of the viewport channel. It owns its **own TCP connection on
 * its own port** — never the pose socket, which is latest-wins UDP at 100 Hz and
 * must not queue behind a megabyte of pixels (`spec/viewport-channel.md` §2).
 * Control messages still travel on the session; only frames come through here.
 *
 * The receive loop is deliberately dumb about time. It reads as fast as the host
 * sends and keeps only the newest decoded frame, so a burst after a stall
 * catches up by discarding rather than by playing out stale pictures — the same
 * latest-wins rule the pose path lives by, for the same reason: a viewport frame
 * is state, not an event.
 */
class ViewportClient(
    private val scope: CoroutineScope,
    /** Told when a frame is on screen, for the host's latency figure (§5.2). */
    private val onPresented: (ordinal: Long, decodedNs: Long, presentedNs: Long) -> Unit,
) {

    /** The newest decoded frame, or null when nothing has arrived yet. */
    private val _frame = MutableStateFlow<ViewportImage?>(null)
    val frame: StateFlow<ViewportImage?> = _frame.asStateFlow()

    private val _status = MutableStateFlow<Status>(Status.Idle)
    val status: StateFlow<Status> = _status.asStateFlow()

    private val _stats = MutableStateFlow(Stats())
    val stats: StateFlow<Stats> = _stats.asStateFlow()

    private var job: Job? = null
    private var socket: Socket? = null
    private val running = AtomicBoolean(false)

    private val probed = java.util.concurrent.atomic.AtomicBoolean(false)

    /** Newest ordinal the UI reported drawing. -1 before anything is drawn. */
    @Volatile private var presentedOrdinal = -1L

    /** Arrival times over the last few seconds, for the achieved rate. */
    private val arrivals = ArrayDeque<Long>()

    sealed interface Status {
        data object Idle : Status
        data object Connecting : Status
        data object Streaming : Status

        /** Dropped, and trying again. [attempt] counts from 1. */
        data class Reconnecting(val reason: String, val attempt: Int) : Status

        /** Given up. Only reached when the caller stops us or the host says no. */
        data class Failed(val reason: String) : Status
    }

    /** A decoded frame plus what the header said about it. */
    data class ViewportImage(
        val image: ImageBitmap,
        val ordinal: Long,
        val width: Int,
        val height: Int,
        /** Phone clock, when decode finished. Only differences are meaningful. */
        val decodedNs: Long,
    )

    data class Stats(
        val framesReceived: Long = 0,
        /**
         * Frames the *host* produced that never reached us — dropped under its
         * backpressure rule or lost on the link. Derived from ordinal gaps,
         * which is why the ordinal counts frames produced rather than sent.
         */
        val framesMissed: Long = 0,
        /** Decoded but replaced before ever being drawn: we are behind. */
        val framesSuperseded: Long = 0,
        val decodeMs: Double = 0.0,
        val lastWidth: Int = 0,
        val lastHeight: Int = 0,
        /**
         * Frames actually arriving per second, over a short window.
         *
         * Measured here rather than taken from the requested rate, because the
         * two differ: the host's capture shares a thread with its operator's own
         * viewport redraw, so on a heavy scene a request for 20 fps arrives as
         * about 6. Without this the only symptom is a preview that feels wrong
         * with nothing saying why.
         */
        val fps: Double = 0.0,
    )

    // -------------------------------------------------------------------- API

    /**
     * Connect and start receiving. Safe to call when already running: the old
     * connection is torn down first, so a resize or quality change is just a
     * reconnect rather than a state machine.
     */
    fun start(host: String, port: Int, token: String) {
        stop()
        running.set(true)
        _status.value = Status.Connecting
        job = scope.launch(Dispatchers.IO) { connectLoop(host, port, token) }
    }

    fun stop() {
        running.set(false)
        // Close the socket before cancelling: a thread blocked in read() does
        // not notice cancellation, and closing under it is what unblocks it.
        try {
            socket?.close()
        } catch (_: Exception) {
        }
        socket = null
        job?.cancel()
        job = null
        _frame.value = null
        presentedOrdinal = -1L
        arrivals.clear()
        _status.value = Status.Idle
    }

    /**
     * Close the current connection and let the retry path pick it up.
     *
     * Named for what it does rather than for the test that needed it. The
     * reconnect path is the hardest thing here to exercise honestly -- killing
     * the host rotates the session token, which tears the whole session down and
     * exercises a different path entirely -- so being able to drop just this
     * socket is what makes the retry testable at all.
     */
    fun dropConnection() {
        val sock = socket ?: return
        Log.i(TAG, "dropConnection: closing the viewport socket on purpose")
        try {
            sock.close()
        } catch (_: Exception) {
        }
    }

    /**
     * Called by the UI once a frame has actually been drawn.
     *
     * Reported from the composition rather than from decode, because the number
     * the host wants is when the operator could *see* it — a frame decoded and
     * then superseded before a redraw never reached anyone's eye.
     */
    fun notePresented(image: ViewportImage) {
        presentedOrdinal = image.ordinal
        onPresented(image.ordinal, image.decodedNs, System.nanoTime())
    }

    // ------------------------------------------------------------------- loop

    /**
     * Connect, stream, and reconnect for as long as the caller wants frames.
     *
     * A viewport connection dies for ordinary reasons — the host restarts, Wi-Fi
     * blinks, a laptop lid closes — and none of them are decisions the operator
     * should have to make. Before this, a single drop left the stream dead until
     * the toggle was cycled, which in practice meant it stayed dead.
     *
     * The session is NOT retried here. If the pose session drops, the offer goes
     * null and the ViewModel tears this down; retrying a viewport socket against
     * a host we are no longer talking to would just be noise.
     */
    private suspend fun connectLoop(host: String, port: Int, token: String) {
        var attempt = 0
        while (running.get()) {
            val reason = receiveLoop(host, port, token)
            if (!running.get()) return
            attempt += 1
            _status.value = Status.Reconnecting(reason, attempt)
            Log.i(TAG, "reconnect attempt $attempt after: $reason")
            // Backoff, because the common failure is "the host is not there
            // yet" and hammering it helps nobody. Capped low: this is a LAN and
            // the operator is standing there waiting for a picture.
            val wait = minOf(
                RETRY_BASE_MS * (1L shl minOf(attempt - 1, 4)),
                RETRY_MAX_MS,
            )
            delay(wait)
        }
    }

    /** Stream until it ends. Returns why, so the caller can report it. */
    private suspend fun receiveLoop(host: String, port: Int, token: String): String {
        var expectedOrdinal = -1L
        try {
            val sock = Socket()
            sock.tcpNoDelay = true // frames are latency-sensitive; do not coalesce
            try {
                sock.connect(InetSocketAddress(host, port), CONNECT_TIMEOUT_MS)
            } catch (e: Exception) {
                // Diagnostic, not a retry. `nc` from this same phone reaches this
                // same port at the same moment while this call times out, so the
                // question is whether it is our socket setup or the connect
                // itself. A plain socket with a long timeout answers it.
                Log.w(TAG, "connect failed: ${e.javaClass.name}: ${e.message}")
                probeOnce(host, port)
                throw e
            }
            socket = sock

            // One newline-terminated token line, the same shape the take upload
            // uses. A wrong token gets no reply at all, just a closed socket.
            sock.getOutputStream().apply {
                write((token + "\n").toByteArray(Charsets.UTF_8))
                flush()
            }

            val input = BufferedInputStream(sock.getInputStream(), READ_BUFFER)
            _status.value = Status.Streaming
            Log.i(TAG, "streaming from $host:$port")
            // A connection that produced frames and then died is a different
            // event from one that never worked, and only the first should reset
            // the attempt counter -- otherwise a host that accepts and
            // immediately closes becomes a tight loop.
            var everStreamed = false

            while (running.get()) {
                val header = readHeader(input) ?: break
                val payload = ViewportFrame.readFully(input, header.payloadLen) ?: break

                var missed = 0L
                if (expectedOrdinal >= 0 && header.ordinal > expectedOrdinal) {
                    missed = header.ordinal - expectedOrdinal
                }
                expectedOrdinal = header.ordinal + 1

                decodeAndPublish(header, payload, missed)
                everStreamed = true
            }
            return if (everStreamed) "stream ended" else "host closed the connection"
        } catch (e: Exception) {
            return e.message ?: e.javaClass.simpleName
        } finally {
            try {
                socket?.close()
            } catch (_: Exception) {
            }
        }
    }

    /**
     * One plain connect, logged, to separate our setup from the network.
     *
     * No options, a generous timeout, and immediately closed. Runs at most once
     * per client so a retry loop cannot turn diagnosis into traffic.
     */
    private fun probeOnce(host: String, port: Int) {
        if (!probed.compareAndSet(false, true)) return
        try {
            val addr = java.net.InetAddress.getByName(host)
            Log.w(TAG, "probe: resolved $host -> $addr reachable=${addr.isReachable(2000)}")
        } catch (e: Exception) {
            Log.w(TAG, "probe: resolve failed ${e.javaClass.simpleName}: ${e.message}")
        }
        try {
            val plain = Socket()
            val t0 = System.nanoTime()
            plain.connect(InetSocketAddress(host, port), 12000)
            val ms = (System.nanoTime() - t0) / 1_000_000
            Log.w(TAG, "probe: plain connect SUCCEEDED in ${ms}ms -- our setup is the problem")
            plain.close()
        } catch (e: Exception) {
            Log.w(TAG, "probe: plain connect failed too ${e.javaClass.name}: ${e.message}")
        }
    }

    /**
     * Read one header, or null to close the connection.
     *
     * A malformed header is never skipped past. A desynchronised reader cannot
     * tell a payload byte from a header byte, so hunting for the next plausible
     * magic is guessing — and it produces a stream that looks like it is working
     * while showing garbage (§4).
     */
    private fun readHeader(input: InputStream): ViewportFrameHeader? {
        val bytes = ViewportFrame.readFully(input, ViewportFrame.HEADER_SIZE) ?: return null
        return ViewportFrame.parseHeader(bytes)
    }

    private fun decodeAndPublish(
        header: ViewportFrameHeader,
        payload: ByteArray,
        missed: Long,
    ) {
        val started = System.nanoTime()
        val bitmap: Bitmap = BitmapFactory.decodeByteArray(payload, 0, payload.size, DECODE_OPTS)
            ?: return // a corrupt frame is not fatal; the next one is independent
        val decodedNs = System.nanoTime()

        // Replacing a frame the UI never drew means decode is outrunning the
        // display. Counted against the *presented* ordinal rather than merely
        // "a frame was there", which would count every frame after the first.
        val standing = _frame.value
        val superseded = if (standing != null && standing.ordinal != presentedOrdinal) 1L else 0L

        // The header's dimensions, not the bitmap's: they should agree, and if
        // they ever do not the header is the channel's own truth.
        _frame.value = ViewportImage(
            image = bitmap.asImageBitmap(),
            ordinal = header.ordinal,
            width = header.width,
            height = header.height,
            decodedNs = decodedNs,
        )
        arrivals.addLast(decodedNs)
        val cutoff = decodedNs - RATE_WINDOW_NS
        while (arrivals.isNotEmpty() && arrivals.first() < cutoff) arrivals.removeFirst()
        val span = if (arrivals.size >= 2) arrivals.last() - arrivals.first() else 0L
        val rate = if (span > 0L) (arrivals.size - 1) * 1e9 / span else 0.0

        val prev = _stats.value
        _stats.value = prev.copy(
            framesReceived = prev.framesReceived + 1,
            framesMissed = prev.framesMissed + missed,
            framesSuperseded = prev.framesSuperseded + superseded,
            decodeMs = (decodedNs - started) / 1_000_000.0,
            lastWidth = header.width,
            lastHeight = header.height,
            fps = rate,
        )
    }

    private companion object {
        const val TAG = "ViewportClient"
        const val CONNECT_TIMEOUT_MS = 3000
        const val RETRY_BASE_MS = 400L
        const val RETRY_MAX_MS = 5000L

        /** Long enough to be steady, short enough to react to a scene change. */
        const val RATE_WINDOW_NS = 3_000_000_000L
        const val READ_BUFFER = 64 * 1024

        /**
         * ARGB_8888 rather than RGB_565: the halved memory is not worth banding
         * in an instrument used to judge framing, and this is one frame at a
         * time, not a gallery.
         */
        val DECODE_OPTS = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
    }
}
