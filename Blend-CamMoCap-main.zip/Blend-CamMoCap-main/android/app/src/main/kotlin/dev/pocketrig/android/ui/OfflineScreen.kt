// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.pocketrig.android.ui.v2.Attitude
import dev.pocketrig.android.ui.v2.OfflineActions
import dev.pocketrig.android.ui.v2.OfflineScreenV2
import dev.pocketrig.android.ui.v2.OfflineUiState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow

/**
 * The offline recording screen with its pipelines attached.
 *
 * [OfflineScreenV2] draws; this owns. The split is what lets the gallery render
 * every state -- rolling, degraded tracking, unnamed, unsupported 6DOF -- with no
 * ARCore session anywhere near it.
 */
@Composable
internal fun OfflineScreen(
    sixDof: SixDofUi,
    recording: Boolean,
    startedAtMs: Long?,
    savedCount: Int,
    attitude: StateFlow<Attitude?>,
    onStart: (String) -> Unit,
    onStop: () -> Unit,
    onBrowse: () -> Unit,
    onExit: () -> Unit,
    shotLocked: Boolean,
    onToggleShotLock: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val sixDofSupported by sixDof.supported.collectAsStateWithLifecycle()
    val sixDofEnabled by sixDof.enabled.collectAsStateWithLifecycle()
    val tracking by sixDof.trackingStatus.collectAsStateWithLifecycle()
    val fastMotion by sixDof.fastMotion.collectAsStateWithLifecycle()
    val attitudeNow by attitude.collectAsStateWithLifecycle()

    var name by rememberSaveable { mutableStateOf("") }
    var namingOpen by rememberSaveable { mutableStateOf(false) }

    // Same ticker as the connected screen, against the same kind of wall clock,
    // so the two never disagree about how long a take has been rolling.
    var elapsedLabel by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(startedAtMs) {
        val started = startedAtMs
        if (started == null) {
            elapsedLabel = null
            return@LaunchedEffect
        }
        while (true) {
            val secs = ((System.currentTimeMillis() - started) / 1000L).coerceAtLeast(0L)
            elapsedLabel = "%d:%02d".format(secs / 60, secs % 60)
            delay(1000)
        }
    }

    OfflineScreenV2(
        state = OfflineUiState(
            recording = recording,
            elapsedLabel = elapsedLabel,
            savedCount = savedCount,
            takeName = name,
            namingOpen = namingOpen,
            sixDofSupported = sixDofSupported,
            sixDofEnabled = sixDofEnabled,
            tracking = tracking,
            positionHeld = fastMotion,
            attitude = attitudeNow,
            shotLocked = shotLocked,
        ),
        actions = OfflineActions(
            onRecordToggle = {
                if (recording) {
                    onStop()
                    // Cleared only after a take is finished: the label belonged to
                    // that take, and carrying it onto the next one silently would
                    // give two different moves the same name.
                    name = ""
                } else {
                    onStart(name)
                }
            },
            onSetSixDof = { wanted -> if (wanted != sixDofEnabled) sixDof.onToggle() },
            onNameOpen = { namingOpen = true },
            onNameDismiss = { namingOpen = false },
            onTakeName = { name = it },
            onBrowseTakes = onBrowse,
            onExit = onExit,
            onToggleShotLock = onToggleShotLock,
        ),
        // In the tree only while 6DOF is on, matching the live screen: ARCore
        // tracks through this surface, so omitting it does not merely lose the
        // picture, it stops 6DOF working.
        viewfinder = if (sixDofEnabled) {
            {
                AndroidView(
                    factory = sixDof.viewfinder,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        } else {
            null
        },
        modifier = modifier,
    )
}
