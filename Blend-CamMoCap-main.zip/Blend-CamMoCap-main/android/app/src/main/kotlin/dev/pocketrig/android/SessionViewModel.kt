// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android

import android.app.Application
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import dev.pocketrig.android.ui.v2.Attitude
import dev.pocketrig.android.ui.v2.attitudeOf
import dev.pocketrig.android.ui.v2.shotRotationFor
import dev.pocketrig.protocol.CamParams
import dev.pocketrig.protocol.DEFAULT_SHAKE_HOLD_DPS
import dev.pocketrig.protocol.Quaternion
import dev.pocketrig.protocol.SessionClient
import dev.pocketrig.protocol.SessionEvent
import dev.pocketrig.protocol.SessionState
import dev.pocketrig.protocol.TakeInfo
import dev.pocketrig.protocol.ViewportOffer
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Thin bridge between [SessionClient] and the Compose UI: exposes the state
 * machine's flows and parses the two connection inputs (scanned QR URI and
 * manual address + code entry). Also owns pairing persistence: the last
 * successful pairing is stored and silently re-probed on the next launch, so
 * a relaunch against the same Blender session reaches Live with zero taps.
 */
class SessionViewModel(application: Application) : AndroidViewModel(application) {

    /** Shared durable store for disconnected and connected recordings. */
    val offlineRecorder = OfflineRecorder(application)

    /**
     * The client clock is `elapsedRealtimeNanos` — the same domain as
     * `SensorEvent.timestamp`, as the protocol requires (monotonic,
     * survives doze, never wall clock). The take sink persists each captured
     * offline take to external files (crash-safety + future offline import).
     */
    val client = SessionClient(
        nowNs = SystemClock::elapsedRealtimeNanos,
        takeStore = offlineRecorder,
    )

    val state: StateFlow<SessionState> get() = client.state
    val events: SharedFlow<SessionEvent> get() = client.events
    val libraryApplyId: StateFlow<String?> get() = client.libraryApplyId

    /** Offline recording + the browsable take library (spec §5.10/§5.11).
     * Takes are captured to files and moved to Blender EXPLICITLY — the phone
     * can push, Blender can pull; nothing transfers automatically. */
    /**
     * Which way up the SHOT is: "auto", "portrait" or "landscape".
     *
     * Auto by default, because the axes following how you hold the phone is what
     * anyone expects and it needs no decision up front. It is frozen while
     * recording by the same value that freezes the UI, so a take cannot change
     * its own axes halfway through.
     *
     * This is not the old Orientation setting in new clothes. That one rotated
     * the window and affected the shot only by accident; this one does nothing
     * else.
     */
    private val _shotOrientation = MutableStateFlow("auto")
    val shotOrientation: StateFlow<String> = _shotOrientation.asStateFlow()

    /** Physical rotation of the phone, pushed in from the UI's own sensor read. */
    private var deviceRotationDeg = 0

    /**
     * Lock the shot to the axis the phone is on now, or let it follow again.
     *
     * The quick version of the Adjust setting, for the moment it is actually
     * wanted: mid-framing, swinging the phone through a wide arc, when a flip to
     * the other axis would spin the shot. Recording already freezes rotation on
     * its own; this covers live preview, which is the rest of the time.
     */
    fun toggleShotLock() {
        // Locks to the axis the phone is on NOW, so the shot does not jump at
        // the moment of locking. Which of that axis's two grips is already
        // settled by the rotation being frozen where it stands.
        setShotOrientation(
            when {
                _shotOrientation.value != "auto" -> "auto"
                shotRotationFor("landscape", deviceRotationDeg) == deviceRotationDeg ->
                    "landscape"
                else -> "portrait"
            },
        )
    }

    fun setShotOrientation(mode: String) {
        _shotOrientation.value = mode
        applyShotRotation()
    }

    fun setDeviceRotation(deg: Int) {
        deviceRotationDeg = deg
        applyShotRotation()
    }

    private fun applyShotRotation() {
        client.shotRotationDeg =
            shotRotationFor(_shotOrientation.value, deviceRotationDeg)
    }

    private val _offlineRecording = MutableStateFlow(false)
    val offlineRecording: StateFlow<Boolean> = _offlineRecording.asStateFlow()

    /**
     * Wall clock at which the current offline take started; null when idle.
     *
     * Wall clock rather than the monotonic `startNs` the recorder writes, because
     * this exists only to drive the elapsed readout, and that is a subtraction
     * against `System.currentTimeMillis()`. It matches how the connected path
     * feeds the same readout (`RecordingState.startedAtWallMs`), so both screens
     * count time the same way. Nothing about the take file depends on it.
     */
    private val _offlineStartedAtMs = MutableStateFlow<Long?>(null)
    val offlineStartedAtMs: StateFlow<Long?> = _offlineStartedAtMs.asStateFlow()
    private val _library = MutableStateFlow(offlineRecorder.library())
    val library: StateFlow<List<TakeInfo>> = _library.asStateFlow()
    val offlineCount: StateFlow<Int> get() = _offlineCount
    private val _offlineCount = MutableStateFlow(offlineRecorder.count())

    /** App-level one-shot messages (uploads etc.) for a snackbar. */
    private val _appMessages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val appMessages: SharedFlow<String> = _appMessages.asSharedFlow()

    private fun refreshLibrary() {
        _library.value = offlineRecorder.library()
        _offlineCount.value = offlineRecorder.count()
    }

    fun startOfflineRecording(name: String) {
        val source = if (_sixDofEnabled.value) "arcore" else "sensor"
        if (offlineRecorder.start(source, SystemClock.elapsedRealtimeNanos(), name)) {
            _offlineRecording.value = true
            // Set only on success: a failed start that still armed the clock would
            // put a running timer on screen with nothing being written.
            _offlineStartedAtMs.value = System.currentTimeMillis()
        }
    }

    fun stopOfflineRecording() {
        offlineRecorder.stop(SystemClock.elapsedRealtimeNanos())
        _offlineRecording.value = false
        _offlineStartedAtMs.value = null
        refreshLibrary()
        if (client.takeUploadReady) pushTakeList() // keep Blender's list current
    }

    /** Feeds the pose pipelines into the offline recorder (no-op when idle). */
    fun captureOfflinePose(
        q: dev.pocketrig.protocol.Quaternion,
        tsNs: Long,
        pos: dev.pocketrig.protocol.Vec3?,
        quality: dev.pocketrig.protocol.TrackingQuality,
        issue: dev.pocketrig.protocol.TrackingIssue,
        focalLengthMm: Float = 0f,
    ) = offlineRecorder.capture(q, tsNs, pos, quality, issue, focalLengthMm)

    /** Apply one saved take to Blender. The protocol client pauses first and
     * keeps the operation locked until Blender confirms the bake. */
    fun uploadTake(id: String) {
        viewModelScope.launch {
            if (!client.takeUploadReady) {
                _appMessages.tryEmit("Connect to Blender first")
                return@launch
            }
            val ok = uploadOne(id)
            _appMessages.tryEmit(
                if (ok) "Applying in Blender…" else "Could not apply take",
            )
        }
    }

    private suspend fun uploadOne(id: String): Boolean {
        val source = offlineRecorder.uploadSource(id) ?: return false
        val ok = client.uploadSavedTake(source)
        if (ok) {
            offlineRecorder.markSent(id)
            refreshLibrary()
            pushTakeList()
        }
        return ok
    }

    fun renameTake(id: String, name: String) {
        offlineRecorder.rename(id, name)
        refreshLibrary()
        if (client.takeUploadReady) pushTakeList()
    }

    fun deleteTake(id: String) {
        offlineRecorder.delete(id)
        refreshLibrary()
        if (client.takeUploadReady) pushTakeList()
    }

    private fun pushTakeList() = client.sendTakeList(offlineRecorder.library())

    // 6DOF (ADR-0006). Supported is set once by the activity from ARCore's
    // availability check; enabled flips only through the activity's gate
    // (camera permission + ARCore install), never directly from the UI.
    private val _sixDofSupported = MutableStateFlow(false)
    val sixDofSupported: StateFlow<Boolean> = _sixDofSupported.asStateFlow()
    /**
     * Lens focal length in mm, or null while the lens is not being driven.
     *
     * Null is the default so connecting never reframes a shot the operator
     * already lit: the host leaves its own lens alone until the phone says
     * otherwise (spec 4.5).
     */
    private val _focalLengthMm = MutableStateFlow<Float?>(null)
    val focalLengthMm: StateFlow<Float?> = _focalLengthMm.asStateFlow()

    /**
     * Roll and pitch of the camera, for the viewfinder horizon.
     *
     * Null until a pose has been seen, and null again for a pose that cannot be
     * interpreted, because the horizon draws nothing for null. A level line from
     * no data would be a confident lie about the one thing it reports.
     */
    private val _attitude = MutableStateFlow<Attitude?>(null)
    // internal because Attitude is a UI type: the horizon's own model, not part
    // of this ViewModel's public surface.
    internal val attitude: StateFlow<Attitude?> = _attitude.asStateFlow()

    /**
     * Fed every protocol-frame orientation, whichever pipeline produced it.
     *
     * Deliberately separate from the pose path: this updates even while the phone
     * is NOT the active pose source, because the horizon reports where the phone
     * is pointing and that stays true whether or not anyone is listening. Wiring
     * it to the pose path instead would freeze the horizon exactly when 6DOF took
     * over, which is the frozen-badge failure again.
     */
    fun onProtocolQuat(q: Quaternion) {
        _attitude.value = attitudeOf(q)
    }

    /** Drive the host's lens. Pass null to hand it back to the operator. */
    fun setFocalLengthMm(mm: Float?) {
        _focalLengthMm.value = mm
        client.setFocalLengthMm(mm ?: 0f)
    }

    /**
     * Take the lens, starting from whatever the host currently has, or hand it
     * back if we already hold it.
     *
     * Adopting the host's value is the point: taking the lens is an act of
     * ownership, not a lens change, so the shot must look identical either side
     * of it (see [lensTakeoverMm]).
     */
    fun toggleLensOwnership() {
        if (_focalLengthMm.value != null) {
            setFocalLengthMm(null)
        } else {
            setFocalLengthMm(lensTakeoverMm(client.params.value?.hostLensMm))
        }
    }

    private val _sixDofEnabled = MutableStateFlow(false)
    val sixDofEnabled: StateFlow<Boolean> = _sixDofEnabled.asStateFlow()

    /** True while the phone is rotating fast enough that the host holds 6DOF
     * position (the shake-hold gate) — drives the "position held" cue. */
    val fastMotion: StateFlow<Boolean> get() = client.fastMotion

    // ------------------------------------------------------- viewport stream

    /**
     * Blender's viewport, streamed to the phone (`spec/viewport-channel.md`).
     *
     * The client owns its own TCP connection; the session only carries the two
     * control messages. Presentation is reported straight back through the
     * session so the host can compute latency against its own clock, crossing
     * no clock boundary.
     */
    val viewport = ViewportClient(
        scope = viewModelScope,
        onPresented = client::sendViewportStat,
    )

    /** What the host offers, or null when it cannot stream (older host). */
    val viewportOffer: StateFlow<ViewportOffer?> get() = client.viewport

    private val _viewportWanted = MutableStateFlow(false)

    /** Chosen size, or null to take the host's best that fits this screen. */
    private val _viewportSize = MutableStateFlow<Pair<Int, Int>?>(null)
    val viewportSize: StateFlow<Pair<Int, Int>?> = _viewportSize.asStateFlow()

    private val _viewportFps = MutableStateFlow(CAMERA_FPS)
    val viewportFps: StateFlow<Int> = _viewportFps.asStateFlow()

    private val _viewportQuality = MutableStateFlow(VIEWPORT_QUALITY)
    val viewportQuality: StateFlow<Int> = _viewportQuality.asStateFlow()

    private val _viewportOverlays = MutableStateFlow(VIEWPORT_OVERLAYS)
    val viewportOverlays: StateFlow<Boolean> = _viewportOverlays.asStateFlow()

    /** "light" | "balanced" | "smooth", or null when the operator picks. */
    private val _viewportProfile = MutableStateFlow<String?>(VIEWPORT_PROFILE)
    val viewportProfile: StateFlow<String?> = _viewportProfile.asStateFlow()

    /** The operator's intent, which outlives any one connection. */
    val viewportWanted: StateFlow<Boolean> = _viewportWanted.asStateFlow()

    /**
     * Turn the stream on or off.
     *
     * The size is chosen from what the host advertised, never invented: it
     * renders the camera at one of those and nothing else.
     */
    /**
     * Change what the stream costs.
     *
     * Reconfiguring is a fresh VIEWPORT_CONTROL and, for a size change, a fresh
     * connection -- frames already in flight carry the old size, which the
     * header makes harmless but the decoder would rather not see.
     */
    fun setViewportSize(size: Pair<Int, Int>) {
        if (_viewportSize.value == size) return
        _viewportSize.value = size
        prefs.edit()
            .putInt(KEY_VIEWPORT_W, size.first)
            .putInt(KEY_VIEWPORT_H, size.second)
            .apply()
        applyViewportIntent()
    }

    fun setViewportFps(fps: Int) {
        val clamped = fps.coerceIn(5, 30)
        if (_viewportFps.value == clamped) return
        _viewportFps.value = clamped
        prefs.edit().putInt(KEY_VIEWPORT_FPS, clamped).apply()
        // Rate and quality are settings on the existing stream, so they go as a
        // control message without disturbing the connection.
        sendViewportControlNow()
    }

    fun setViewportQuality(quality: Int) {
        val clamped = quality.coerceIn(40, 95)
        if (_viewportQuality.value == clamped) return
        _viewportQuality.value = clamped
        prefs.edit().putInt(KEY_VIEWPORT_QUALITY, clamped).apply()
        sendViewportControlNow()
    }

    fun setViewportProfile(profile: String?) {
        if (_viewportProfile.value == profile) return
        _viewportProfile.value = profile
        prefs.edit().putString(KEY_VIEWPORT_PROFILE, profile).apply()
        sendViewportControlNow()
    }

    fun setViewportOverlays(on: Boolean) {
        if (_viewportOverlays.value == on) return
        _viewportOverlays.value = on
        prefs.edit().putBoolean(KEY_VIEWPORT_OVERLAYS, on).apply()
        sendViewportControlNow()
    }

    fun toggleViewport() {
        val wanted = !_viewportWanted.value
        _viewportWanted.value = wanted
        prefs.edit().putBoolean(KEY_VIEWPORT, wanted).apply()
        applyViewportIntent()
    }

    private fun applyViewportIntent() {
        val offer = client.viewport.value
        val mode = offer?.bestMode
        if (!_viewportWanted.value || offer == null || mode == null) {
            viewport.stop()
            if (offer != null) client.sendViewportControl(mode = "off")
            return
        }
        // Bounded by what a phone screen can show, not by what the host can
        // send: pixels beyond the panel are link budget spent on nothing.
        val size = chosenSize(offer) ?: return
        val host = pendingHost ?: return
        val token = pendingToken ?: return
        sendViewportControlNow(offer, mode, size)
        viewport.start(host, offer.port, token)
    }

    /**
     * The operator's size if the host still offers it, else the best that fits
     * this screen.
     *
     * Checked against the offer every time rather than trusted: the list depends
     * on the scene's render aspect, so opening a different .blend can retire the
     * size that was chosen against the last one.
     */
    private fun chosenSize(offer: ViewportOffer): Pair<Int, Int>? {
        val wanted = _viewportSize.value
        if (wanted != null && wanted in offer.sizes) return wanted
        return offer.bestSizeWithin(VIEWPORT_MAX_W, VIEWPORT_MAX_H)
    }

    private fun sendViewportControlNow(
        offer: ViewportOffer? = client.viewport.value,
        mode: String? = offer?.bestMode,
        size: Pair<Int, Int>? = offer?.let { chosenSize(it) },
    ) {
        if (!_viewportWanted.value) return
        if (offer == null || mode == null || size == null) return
        val profile = _viewportProfile.value
        client.sendViewportControl(
            mode = mode,
            codec = "jpeg",
            // Under a profile the host owns the size, so we stop asserting one.
            // Sending it anyway would reset the controller's choice every time
            // the operator touched an unrelated setting.
            size = if (profile == null) size else null,
            // Clamped to what the host says it will accept, not to what it
            // can achieve -- the achievable rate is its viewport redraw rate,
            // which it reports separately and which moves with what the
            // operator is doing (viewport-channel.md §5.3).
            fps = if (profile == null) {
                minOf(offer.maxFps, _viewportFps.value).toDouble()
            } else {
                null
            },
            quality = _viewportQuality.value,
            overlays = _viewportOverlays.value,
            profile = profile,
        )
    }

    fun setSixDofSupported(supported: Boolean) {
        _sixDofSupported.value = supported
    }

    fun setSixDofEnabled(enabled: Boolean) {
        if (_sixDofEnabled.value == enabled) return
        _sixDofEnabled.value = enabled
        // MainActivity switches the actual pipeline and sends FRAME_RESET at
        // that boundary. A source change must not invoke user Re-center: doing
        // so exits pause/review and snaps the Blender camera Home.
    }

    private companion object {
        const val QR_SCHEME = "pocketrig"
        const val DEFAULT_PORT = 47800
        const val PREFS = "pocketrig"
        const val KEY_HOST = "last_host"
        const val KEY_PORT = "last_port"
        const val KEY_TOKEN = "last_token"
        const val KEY_SHAKE_HOLD = "shake_hold_dps"
        const val KEY_VIEWPORT = "viewport_enabled"
        const val KEY_VIEWPORT_W = "viewport_width"
        const val KEY_VIEWPORT_H = "viewport_height"
        const val KEY_VIEWPORT_FPS = "viewport_fps"
        const val KEY_VIEWPORT_QUALITY = "viewport_quality"
        const val KEY_VIEWPORT_OVERLAYS = "viewport_overlays"
        const val KEY_VIEWPORT_PROFILE = "viewport_profile"

        /** No point receiving more pixels than a phone panel can show. */
        const val VIEWPORT_MAX_W = 1280
        const val VIEWPORT_MAX_H = 720
        // 30, not the 20 it was. Measured across every size the host
        // advertises, asking for 20 costs the same share of Blender's main
        // thread as asking for 30 and returns a third fewer frames -- captures
        // spaced further apart each cost more, so the lower rate gives most of
        // its saving back. Detail is the control that actually saves the PC.
        const val CAMERA_FPS = 30
        const val VIEWPORT_QUALITY = 75
        // Off. A viewfinder shows the shot, and Blender's 3D cursor, grid and
        // relationship lines are not in it -- they covered 1.72% of the frame
        // on one real scene. The overlay pass costs nothing either way, so this
        // is a correctness default rather than a performance one, and the
        // operator can have them back for placing a camera against the floor.
        const val VIEWPORT_OVERLAYS = false
        // Balanced, and on by default. Resolution is the only control that
        // materially changes what the stream costs the PC, and what it costs
        // depends on the scene and the machine -- neither of which this phone
        // can see. Null hands it back to the operator.
        val VIEWPORT_PROFILE: String? = "balanced"
    }

    private val prefs =
        application.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // Params of the connect attempt in flight; persisted once it reaches Live.
    private var pendingHost: String? = null
    private var pendingPort = 0
    private var pendingToken: String? = null

    init {
        // The shake-hold setting belongs to the host while one is connected, but
        // the gate runs with no host at all: an offline take's rows carry the
        // EXCESSIVE_MOTION marks this same computation produces, and those decide
        // whether Blender treats that stretch as having valid position when the
        // take is finally applied. So keep the operator's last choice and use it
        // when nobody is telling us otherwise, rather than reverting to a default
        // they have already overridden.
        client.localShakeHoldDps = prefs
            .getFloat(KEY_SHAKE_HOLD, DEFAULT_SHAKE_HOLD_DPS.toFloat())
            .toDouble()
        viewModelScope.launch {
            client.params.collect { p ->
                val gate = p?.shakeHoldDps ?: return@collect
                if (gate != client.localShakeHoldDps) {
                    client.localShakeHoldDps = gate
                    prefs.edit().putFloat(KEY_SHAKE_HOLD, gate.toFloat()).apply()
                }
            }
        }
        viewModelScope.launch {
            var wasLive = false
            state.collect { s ->
                val live = s is SessionState.Live || s is SessionState.Recording ||
                    s is SessionState.Finalizing
                if (live && !wasLive) {
                    persistPairing()
                    // Show Blender our library right away; it can pull at will.
                    if (client.takeUploadReady) pushTakeList()
                }
                wasLive = live
            }
        }
        // Blender asked for the library (spec §5.11): answer with it.
        _viewportWanted.value = prefs.getBoolean(KEY_VIEWPORT, false)
        _viewportFps.value = prefs.getInt(KEY_VIEWPORT_FPS, CAMERA_FPS)
        _viewportQuality.value = prefs.getInt(KEY_VIEWPORT_QUALITY, VIEWPORT_QUALITY)
        _viewportOverlays.value =
            prefs.getBoolean(KEY_VIEWPORT_OVERLAYS, VIEWPORT_OVERLAYS)
        _viewportProfile.value =
            if (prefs.contains(KEY_VIEWPORT_PROFILE)) {
                prefs.getString(KEY_VIEWPORT_PROFILE, null)
            } else {
                VIEWPORT_PROFILE
            }
        val savedW = prefs.getInt(KEY_VIEWPORT_W, 0)
        val savedH = prefs.getInt(KEY_VIEWPORT_H, 0)
        if (savedW > 0 && savedH > 0) _viewportSize.value = savedW to savedH
        viewModelScope.launch {
            // Driven by the OFFER rather than by connection state: the port and
            // the size list only exist once WELCOME lands, and a disconnect
            // nulls it, which is exactly when the stream must be torn down.
            client.viewport.collect { applyViewportIntent() }
        }
        viewModelScope.launch { client.takeListRequests.collect { pushTakeList() } }
        viewModelScope.launch {
            client.events.collect { event ->
                if (event is SessionEvent.TakeSaved) {
                    refreshLibrary()
                    if (client.takeUploadReady) pushTakeList()
                }
            }
        }
        // Blender asked to pull a specific take: upload it.
        viewModelScope.launch {
            client.takePullRequests.collect { id -> uploadOne(id) }
        }
        // Silent reconnect probe: same Blender session -> Live with zero taps;
        // anything else fails invisibly and the UI stays Disconnected.
        val host = prefs.getString(KEY_HOST, null)
        val token = prefs.getString(KEY_TOKEN, null)
        val port = prefs.getInt(KEY_PORT, 0)
        if (host != null && token != null && port in 1..65535) {
            rememberPending(host, port, token)
            client.connect(host, port, token, deviceName(), silent = true)
        }
    }

    private fun rememberPending(host: String, port: Int, token: String) {
        pendingHost = host
        pendingPort = port
        pendingToken = token
    }

    private fun persistPairing() {
        val host = pendingHost ?: return
        val token = pendingToken ?: return
        prefs.edit()
            .putString(KEY_HOST, host)
            .putInt(KEY_PORT, pendingPort)
            .putString(KEY_TOKEN, token)
            .apply()
    }

    /**
     * Handles a scanned pairing QR: `pocketrig://connect?v=1&host=…&port=…&token=…&name=…`.
     * Returns false if the payload is not a valid pocketrig pairing URI.
     */
    fun connectFromQr(contents: String): Boolean {
        val uri = runCatching { Uri.parse(contents) }.getOrNull() ?: return false
        if (!uri.isHierarchical || uri.scheme != QR_SCHEME) return false
        val version = uri.getQueryParameter("v")?.toIntOrNull() ?: 1
        if (version != 1) return false
        val host = uri.getQueryParameter("host")?.takeIf { it.isNotBlank() } ?: return false
        val port = uri.getQueryParameter("port")?.toIntOrNull() ?: DEFAULT_PORT
        val token = uri.getQueryParameter("token")?.takeIf { it.isNotBlank() } ?: return false
        rememberPending(host, port, token)
        client.connect(host, port, token, deviceName())
        return true
    }

    /**
     * Handles manual entry: [address] as `ip:port` (port optional, defaults
     * to 47800) plus the 6-character [code] shown by the host. Returns false
     * on an unparseable address or empty code.
     */
    fun connectManually(address: String, code: String): Boolean {
        val trimmed = address.trim()
        val token = code.trim().uppercase()
        if (trimmed.isEmpty() || token.isEmpty()) return false
        val host: String
        val port: Int
        val colon = trimmed.lastIndexOf(':')
        if (colon >= 0) {
            host = trimmed.substring(0, colon).trim()
            port = trimmed.substring(colon + 1).trim().toIntOrNull() ?: return false
        } else {
            host = trimmed
            port = DEFAULT_PORT
        }
        if (host.isEmpty() || port !in 1..65535) return false
        rememberPending(host, port, token)
        client.connect(host, port, token, deviceName())
        return true
    }

    fun disconnect() = client.disconnect()
    fun startRecording() = client.startRecording()
    fun stopRecording() = client.stopRecording()
    fun dismissFinalizationFailure() = client.dismissFinalizationFailure()
    fun recenter() = client.recenter()

    /** Host-mirrored tuning values (spec 5.7); null until the host syncs. */
    val camParams: StateFlow<CamParams?> get() = client.params

    fun setParams(
        live: Double,
        record: Double,
        moveScale: Double,
        takeSource: String? = null,
        shakeHoldDps: Double? = null,
    ) = client.sendParams(
        live, record, moveScale, layout = null, takeSource = takeSource,
        shakeHoldDps = shakeHoldDps,
    )

    // Phone-local only: "locked" preserves the current screen orientation and
    // is the default. Portrait/landscape are explicit manual choices. None of
    // these changes Blender's render aspect. FRAME_RESET lets Blender absorb a
    // manual display-frame transition without user Re-center semantics.
    // True only while a screen that shows the ARCore viewfinder is up (the live
    // camera screen, or the offline-record screen). The activity uses this to
    // release the camera on the disconnected/scan screen — otherwise a paused
    // ARCore session keeps the camera and the QR scanner can't re-acquire it
    // (you had to restart the app to scan again).
    private val _viewfinderActive = MutableStateFlow(false)
    val viewfinderActive: StateFlow<Boolean> = _viewfinderActive.asStateFlow()

    fun setViewfinderActive(active: Boolean) {
        _viewfinderActive.value = active
    }

    /** Jump the Blender playhead to the scene start — the retake button. */
    fun seekToStart() = client.seekToStart()

    /** Host-mirrored pause state (spec 5.8). */
    val camPaused: StateFlow<Boolean> get() = client.paused

    fun setPaused(paused: Boolean) = client.sendPause(paused)

    private fun deviceName(): String {
        val model = Build.MODEL.orEmpty()
        val manufacturer = Build.MANUFACTURER.orEmpty()
        return when {
            model.startsWith(manufacturer, ignoreCase = true) -> model
            manufacturer.isBlank() -> model
            else -> "$manufacturer $model"
        }.ifBlank { "Android phone" }
    }

    override fun onCleared() {
        client.disconnect()
    }
}
