// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import dev.pocketrig.android.R
import dev.pocketrig.protocol.TrackingStatus

/** Everything the offline recording screen draws. */
internal data class OfflineUiState(
    val recording: Boolean = false,
    /** Ticking "m:ss" while rolling; null when idle. */
    val elapsedLabel: String? = null,
    /** Takes already on the phone. */
    val savedCount: Int = 0,
    /** The label this take will carry into the library and into Blender. */
    val takeName: String = "",
    /** The naming sheet is open. */
    val namingOpen: Boolean = false,
    val sixDofSupported: Boolean = true,
    val sixDofEnabled: Boolean = false,
    val tracking: TrackingStatus = TrackingStatus.UNKNOWN,
    val positionHeld: Boolean = false,
    val attitude: Attitude? = null,
    /** Shot axis locked rather than following the phone. */
    val shotLocked: Boolean = false,
)

internal data class OfflineActions(
    val onRecordToggle: () -> Unit = {},
    val onSetSixDof: (Boolean) -> Unit = {},
    val onNameOpen: () -> Unit = {},
    val onNameDismiss: () -> Unit = {},
    val onTakeName: (String) -> Unit = {},
    val onBrowseTakes: () -> Unit = {},
    val onExit: () -> Unit = {},
    val onToggleShotLock: () -> Unit = {},
)

/**
 * Recording with no PC in the loop.
 *
 * Built from the live screen's parts for the same reason the landing screen is:
 * this is the same job in the same grip, minus a host. The readout is in the same
 * corner and uses the same tracking badge function, the horizon is the same
 * instrument, the record button is the same landmark in the same place, and the
 * mode switch sits where it sits on the live screen. What changes is the two
 * corner chips: Done where Adjust lives, Takes where Takes always lives.
 *
 * The take's name floats above the dock, in the slot the lens readout occupies on
 * the live screen. That position means "value you adjust while composing", which
 * is exactly what a take label is -- and it keeps a text field off the
 * viewfinder, where the old screen put one permanently.
 */
@Composable
internal fun OfflineScreenV2(
    state: OfflineUiState,
    actions: OfflineActions = OfflineActions(),
    /** The ARCore passthrough. Load-bearing: 6DOF tracks through this surface. */
    viewfinder: (@Composable () -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    Box(modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Frame(state, Modifier.weight(1f).fillMaxWidth(), viewfinder) {
                Column(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .padding(
                            bottom = Rig.Space.lg,
                            start = Rig.Touch.edgeInset,
                            end = Rig.Touch.edgeInset,
                        ),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    NamePill(state, actions)
                }
                // Same rule as the live screen: the phone's top-start.
                offlineProblem(state)?.let { (text, tone) ->
                    ProblemBanner(
                        text,
                        tone,
                        Modifier
                            .align(Alignment.TopStart)
                            .padding(Rig.Touch.edgeInset),
                    )
                }
            }
            OfflineDock(state, actions)
        }

        if (state.namingOpen) {
            WorldSheetHost(onDismiss = actions.onNameDismiss) {
                NameSheet(state, actions)
            }
        }
    }
}

@Composable
private fun Frame(
    state: OfflineUiState,
    modifier: Modifier = Modifier,
    viewfinder: (@Composable () -> Unit)? = null,
    overlay: @Composable BoxScope.() -> Unit,
) {
    // Black only when there is nothing to show. In rotation-only mode there is no
    // camera at all, so the frame needs a floor to draw the horizon on; with the
    // ARCore surface present, painting black over it would hide the picture.
    Box(if (viewfinder == null) modifier.background(Color.Black) else modifier) {
        viewfinder?.invoke()
        AttitudeHorizon(state.attitude, Modifier.fillMaxSize())
        overlay()
    }
}

/**
 * Offline, elapsed, tracking and the library -- as square cells.
 *
 * The phone glyph carries "there is no PC in the loop", which used to be a pill
 * reading "Offline, saving to phone" across the top of every shot. Same claim, no
 * longer covering the frame to make it.
 */
@Composable
private fun offlineStatus(state: OfflineUiState): List<StatusItem> {
    val items = mutableListOf<StatusItem>()
    items += if (state.recording) {
        StatusItem(
            glyph = { GlyphRecordDot(it) },
            tone = Tone.BAD,
            text = state.elapsedLabel ?: "0:00",
            explain = stringResource(R.string.explain_recording_offline),
        )
    } else {
        StatusItem(
            glyph = { GlyphHostOff(it) },
            tone = Tone.WARN,
            explain = stringResource(R.string.explain_offline),
        )
    }
    if (state.sixDofEnabled) {
        val badge = trackingBadge(state.sixDofEnabled, state.tracking, state.positionHeld)
        items += StatusItem(
            glyph = { GlyphCube(it) },
            tone = badge?.tone ?: Tone.NEUTRAL,
            explain = badge?.let { stringResource(it.textRes) },
        )
    }
    return items
}

/** Same rule as the live screen: words only when there is something to do. */
@Composable
private fun offlineProblem(state: OfflineUiState): Pair<String, Tone>? {
    val badge = trackingBadge(state.sixDofEnabled, state.tracking, state.positionHeld)
        ?: return null
    if (badge.tone != Tone.WARN && badge.tone != Tone.BAD) return null
    return stringResource(badge.textRes) to badge.tone
}

/**
 * The take's label, floating over the frame above the dock.
 *
 * Tappable while idle, inert while rolling: the name is written into the take's
 * header at the moment recording starts, so offering to change it mid-take would
 * be offering something that cannot happen. It stays visible either way, because
 * knowing which take you are shooting is the point of naming it.
 */
@Composable
private fun NamePill(
    state: OfflineUiState,
    actions: OfflineActions,
    modifier: Modifier = Modifier,
) {
    val named = state.takeName.isNotBlank()
    val interaction = remember { MutableInteractionSource() }
    val shape = RoundedCornerShape(Rig.Radius.floating)
    // Deliberately NOT turned. It is the one piece of chrome that can be a
    // whole sentence, it sits over the middle of the frame, and turned on its
    // side it became a tall column of letters straight up through the shot. A
    // name is glanceable at any angle; the shot is not recoverable once covered.
    Box(
        modifier
            .background(Rig.Colors.floatFill, shape)
            .then(
                if (state.recording) {
                    Modifier
                } else {
                    Modifier.clickable(
                        interactionSource = interaction,
                        indication = null,
                        onClick = actions.onNameOpen,
                    )
                },
            )
            .padding(horizontal = Rig.Space.md, vertical = Rig.Space.sm),
    ) {
        Text(
            // A placeholder rather than an empty pill: the control has to say what
            // it is for before it has a value, or it reads as a rendering fault.
            text = if (named) {
                state.takeName
            } else {
                stringResource(R.string.take_unnamed)
            },
            color = if (named) Rig.Colors.onGlass else Rig.Colors.onGlassDim,
            fontSize = 14.sp,
            fontWeight = if (named) FontWeight.Medium else FontWeight.Normal,
            maxLines = 1,
            // Ellipsis, not a hard clip. Clipped, a long name simply looked like
            // a shorter name -- the same defect that made a 105mm lens read as
            // "10" on the zoom dial.
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.widthIn(max = 240.dp),
        )
    }
}

/**
 * Done, mode, Takes -- and the record button.
 *
 * Same skeleton as the live screen's dock, so the two are the same instrument
 * with different labels on two of its keys. Done takes Adjust's corner because
 * that is the corner for "leave what you are doing"; Takes never moves.
 */
@Composable
private fun OfflineDock(state: OfflineUiState, actions: OfflineActions) {
    GroundedDock(
        status = offlineStatus(state),
        // Offline shoots the same shot with the same axes, so it gets the same
        // lock. Leaving it off here was the half of the feature that was missing.
        trailing = {
            StripToggle(
                glyph = { GlyphLock(it, state.shotLocked) },
                description = stringResource(R.string.shot_lock),
                on = state.shotLocked,
                enabled = !state.recording,
                onClick = actions.onToggleShotLock,
            )
        },
    ) {
        RecordControl(state, actions)
        Spacer(Modifier.height(Rig.Space.md))
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            DoneChip(state, actions)
            ModeToggle(state, actions)
            TakesChip(state, actions)
        }
    }
}

@Composable
private fun RecordControl(state: OfflineUiState, actions: OfflineActions) =
    RecordButtonV2(
        recording = state.recording,
        // Never disabled: while a take rolls, this button IS the stop control.
        enabled = true,
        onClick = actions.onRecordToggle,
    )

@Composable
private fun DoneChip(state: OfflineUiState, actions: OfflineActions) = TrayChip(
    label = stringResource(R.string.done),
    glyph = { GlyphBack(it) },
    onClick = actions.onExit,
    // Locked mid-take rather than hidden. Leaving would abandon a take that is
    // being written, and a control that vanishes teaches nothing about why.
    enabled = !state.recording,
)

@Composable
private fun TakesChip(state: OfflineUiState, actions: OfflineActions) = TrayChip(
    // Just the word. The count is status, so it lives in the strip -- as a
    // chip label it was the one string that would not fit a square chip at a
    // large font, and "Takes · 3" truncated to "Takes ·".
    label = stringResource(R.string.takes),
    glyph = { GlyphStack(it) },
    onClick = actions.onBrowseTakes,
    enabled = state.savedCount > 0 && !state.recording,
)

/**
 * Rotation vs 6DOF, in the same place and the same shape as on the live screen.
 *
 * Locked mid-take for the same reason: switching pose source halfway through
 * would splice two kinds of motion into one take. Also locked, but still legibly
 * showing rotation, on a phone without ARCore -- the alternative is a control
 * that is simply absent on some devices and present on others.
 */
@Composable
private fun ModeToggle(state: OfflineUiState, actions: OfflineActions) = SegmentedToggle(
    options = listOf(
        { tint -> GlyphRotate(tint) },
        { tint -> GlyphCube(tint) },
    ),
    selectedIndex = if (state.sixDofEnabled) 1 else 0,
    onSelect = { actions.onSetSixDof(it == 1) },
    enabled = state.sixDofSupported && !state.recording,
)

/** Name the take before you roll. The label follows it into Blender. */
@Composable
private fun NameSheet(
    state: OfflineUiState,
    actions: OfflineActions,
    modifier: Modifier = Modifier,
) {
    ControlSurface(
        modifier.fillMaxWidth(),
        shape = RoundedCornerShape(
            topStart = Rig.Radius.grounded,
            topEnd = Rig.Radius.grounded,
        ),
        opaque = true,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = Rig.Space.xl, vertical = Rig.Space.lg),
        ) {
            SheetHandle()
            Spacer(Modifier.height(Rig.Space.lg))
            SectionLabel(stringResource(R.string.take_name_label))
            Spacer(Modifier.height(Rig.Space.xs))
            Note(stringResource(R.string.take_name_help))
            Spacer(Modifier.height(Rig.Space.md))
            RigField(
                value = state.takeName,
                onValue = actions.onTakeName,
                placeholder = stringResource(R.string.take_name_placeholder),
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Sentences,
                ),
            )
            Spacer(Modifier.height(Rig.Space.lg))
            RigButton(
                label = stringResource(R.string.done),
                onClick = actions.onNameDismiss,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}
