// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import dev.pocketrig.protocol.MotionCorroboration
import dev.pocketrig.protocol.Vec3

/**
 * Calibrated gyro/accelerometer feed running alongside ARCore.
 *
 * It never produces a camera pose and never changes ARCore state. It has two
 * consumers, both observational:
 *
 * - [corroboration], in **every** build: independent physical evidence of whether
 *   the phone is actually moving, so a tracker that dead-reckons while blind can
 *   be caught claiming translation that never happened.
 * - [telemetry], debug builds only: Motion Lab capture.
 *
 * It used to exist only in debug builds. The detector needs it in production,
 * which is the whole reason a shipped build can now tell an invented camera move
 * from a real one.
 */
internal class ImuTelemetryPipeline(
    context: Context,
    private val telemetry: TrackingTelemetry? = null,
    private val corroboration: MotionCorroboration? = null,
) : SensorEventListener {

    private companion object {
        /** 100 Hz requested for useful motion evidence without duplicating the pose feed. */
        const val SAMPLING_PERIOD_US = 10_000
    }

    private val sensorManager =
        context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    private val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private var thread: HandlerThread? = null

    fun start() {
        if (thread != null) return
        if (gyroscope == null && accelerometer == null) return
        val worker = HandlerThread("pocketrig-imu-telemetry").also { it.start() }
        val handler = Handler(worker.looper)
        gyroscope?.let {
            sensorManager.registerListener(this, it, SAMPLING_PERIOD_US, handler)
        }
        accelerometer?.let {
            sensorManager.registerListener(this, it, SAMPLING_PERIOD_US, handler)
        }
        thread = worker
    }

    fun stop() {
        sensorManager.unregisterListener(this)
        thread?.quitSafely()
        thread = null
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.values.size < 3) return
        val sensorName = when (event.sensor.type) {
            Sensor.TYPE_GYROSCOPE -> "gyroscope"
            Sensor.TYPE_ACCELEROMETER -> "accelerometer"
            else -> return
        }
        // Stamped with the sensor's own clock, the same domain as ARCore frame
        // timestamps, so the two streams are comparable without correction.
        val v = Vec3(event.values[0], event.values[1], event.values[2])
        if (event.sensor.type == Sensor.TYPE_GYROSCOPE) {
            corroboration?.onGyro(v, event.timestamp)
        } else {
            corroboration?.onAccel(v, event.timestamp)
        }
        telemetry?.onImuSample(
            ImuSampleTelemetry(
                observedNs = SystemClock.elapsedRealtimeNanos(),
                sensorNs = event.timestamp,
                sensor = sensorName,
                x = event.values[0],
                y = event.values[1],
                z = event.values[2],
                accuracy = event.accuracy,
            ),
        )
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}
