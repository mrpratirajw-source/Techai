// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.pocketrig.android.R

/**
 * One take, as the library needs to show it.
 *
 * A UI model rather than the protocol's `TakeInfo` on purpose: what the list
 * needs is "does this have position data", not "how many position samples", and
 * a design that reads wire fields directly ends up displaying wire fields.
 */
internal data class TakeRowUi(
    val id: String,
    val name: String,
    val durationLabel: String,
    /** True when the take carries position, i.e. applying it moves the camera. */
    val hasPosition: Boolean,
    /** Already uploaded to Blender at least once. */
    val sent: Boolean,
)

internal data class TakesUiState(
    val takes: List<TakeRowUi> = emptyList(),
    /** False when there is no Blender to apply to; Apply says why. */
    val connected: Boolean = true,
    /** id of a take currently uploading/baking, or null. */
    val applyingId: String? = null,
    /** Which row is expanded to show its actions. */
    val expandedId: String? = null,
    /** Current host position scale, so a 6DOF take can warn what it will apply at. */
    val positionScale: Float = 1f,
    /** id of the take being renamed, or null. Renaming happens in the row. */
    val renamingId: String? = null,
    /** The name being typed, before it is committed. */
    val renameDraft: String = "",
)

internal data class TakesActions(
    val onExpand: (String?) -> Unit = {},
    val onApply: (String) -> Unit = {},
    /** Open the rename field on this take. */
    val onRenameStart: (String) -> Unit = {},
    val onRenameDraft: (String) -> Unit = {},
    val onRenameCommit: () -> Unit = {},
    val onRenameCancel: () -> Unit = {},
    val onDelete: (String) -> Unit = {},
    val onDismiss: () -> Unit = {},
)

/**
 * The take library, as a sheet over the viewfinder.
 *
 * The list's job is to answer one question per row: *what will happen if I apply
 * this?* So each row leads with whether the take carries position, because that
 * is the difference between a camera that rotates and a camera that travels, and
 * it is not recoverable from a name or a duration.
 *
 * Only one row opens at a time. Every take has three actions and two of them are
 * destructive-ish, so showing fifteen buttons on a five-take list would make
 * Delete as prominent as Apply. Tapping a row commits to that take first.
 */
@Composable
internal fun TakesSheetV2(
    state: TakesUiState,
    actions: TakesActions = TakesActions(),
    modifier: Modifier = Modifier,
) {
    ControlSurface(
        modifier.fillMaxWidth(),
        shape = RoundedCornerShape(
            topStart = Rig.Radius.grounded,
            topEnd = Rig.Radius.grounded,
        ),
        opaque = true,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = Rig.Space.xl, vertical = Rig.Space.lg),
        ) {
            SheetHandle()
            Spacer(Modifier.height(Rig.Space.lg))
            Text(
                text = stringResource(R.string.takes_title, state.takes.size),
                color = Rig.Colors.onGlass,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(Rig.Space.md))

            if (state.takes.isEmpty()) {
                Text(
                    text = stringResource(R.string.no_takes_yet),
                    color = Rig.Colors.onGlassDim,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(vertical = Rig.Space.xl),
                )
            } else {
                // No height cap here: WorldSheetHost caps the sheet against the
                // WORLD height, the only measurement that means the same thing
                // however the phone is held.
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(Rig.Space.xs),
                ) {
                    items(state.takes, key = { it.id }) { take ->
                        TakeRow(
                            take = take,
                            expanded = take.id == state.expandedId,
                            applying = take.id == state.applyingId,
                            connected = state.connected,
                            positionScale = state.positionScale,
                            renaming = take.id == state.renamingId,
                            renameDraft = state.renameDraft,
                            actions = actions,
                        )
                    }
                }
            }
            Spacer(Modifier.height(Rig.Space.md))
        }
    }
}

@Composable
private fun TakeRow(
    take: TakeRowUi,
    expanded: Boolean,
    applying: Boolean,
    connected: Boolean,
    positionScale: Float,
    renaming: Boolean,
    renameDraft: String,
    actions: TakesActions,
) {
    val interaction = remember { MutableInteractionSource() }
    Column(
        Modifier
            .fillMaxWidth()
            .background(
                if (expanded) {
                    Rig.Colors.armed.copy(alpha = 0.10f)
                } else {
                    Color.White.copy(alpha = 0.035f)
                },
                RoundedCornerShape(Rig.Radius.chip),
            )
            .clickable(
                interactionSource = interaction,
                indication = null,
            ) { actions.onExpand(if (expanded) null else take.id) }
            .padding(horizontal = Rig.Space.md, vertical = Rig.Space.md),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = take.name,
                    color = Rig.Colors.onGlass,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Motion type leads, because it is the one fact that changes
                    // what applying the take does to the camera.
                    Text(
                        text = stringResource(
                            if (take.hasPosition) {
                                R.string.motion_6dof
                            } else {
                                R.string.motion_rotation
                            },
                        ),
                        color = if (take.hasPosition) {
                            Rig.Colors.armed
                        } else {
                            Rig.Colors.onGlassDim
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Meta(" · " + take.durationLabel)
                    if (take.sent) Meta(" · sent")
                }
            }
            if (applying) {
                Text(
                    text = stringResource(R.string.applying_take),
                    color = Rig.Colors.armed,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }

        if (expanded && !applying) {
            Spacer(Modifier.height(Rig.Space.md))
            // A 6DOF take bakes at whatever scale the host is set to now, not the
            // scale it was shot at. Saying so here is the only place an operator
            // could find that out before the camera moves further than expected.
            if (take.hasPosition) {
                Meta(stringResource(R.string.takes_apply_scale, positionScale))
                Spacer(Modifier.height(Rig.Space.sm))
            }
            if (renaming) {
                RigField(
                    value = renameDraft,
                    onValue = actions.onRenameDraft,
                    placeholder = take.name,
                )
                Spacer(Modifier.height(Rig.Space.sm))
                Row(horizontalArrangement = Arrangement.spacedBy(Rig.Space.sm)) {
                    RowAction(
                        label = stringResource(R.string.save),
                        primary = true,
                        modifier = Modifier.weight(1f),
                    ) { actions.onRenameCommit() }
                    RowAction(label = stringResource(R.string.cancel)) {
                        actions.onRenameCancel()
                    }
                }
            } else {
                // Apply keeps its words: it is the one action whose consequence is
                // worth spelling out, and "Apply" and "Apply again" are different
                // promises. Rename and Delete become icons because as three equal
                // buttons Delete carried the same weight as Apply, which is not
                // the weight it should have.
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(Rig.Space.sm),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RowAction(
                        label = stringResource(
                            if (take.sent) R.string.apply_again else R.string.apply_take,
                        ),
                        primary = true,
                        enabled = connected,
                        // Apply takes the room, so the two icons sit hard against
                        // the end and line up down the whole list however wide the
                        // Apply label happens to be.
                        modifier = Modifier.weight(1f),
                    ) { actions.onApply(take.id) }
                    IconAction(
                        glyph = { GlyphPencil(it) },
                        description = stringResource(R.string.rename),
                    ) { actions.onRenameStart(take.id) }
                    IconAction(
                        glyph = { GlyphTrash(it) },
                        description = stringResource(R.string.delete),
                        destructive = true,
                    ) { actions.onDelete(take.id) }
                }
            }
            if (!connected) {
                Spacer(Modifier.height(Rig.Space.sm))
                // Says why rather than just greying out. A disabled button with no
                // explanation is the same failure as a control that fades to
                // nothing: the operator is left guessing.
                Meta("Not connected. Takes stay on the phone until Blender is back.")
            }
        }
    }
}

@Composable
private fun Meta(text: String) = Text(
    text = text,
    color = Rig.Colors.onGlassDim,
    fontSize = 11.sp,
)

@Composable
private fun RowAction(
    label: String,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    destructive: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    val content = when {
        !enabled -> Rig.Colors.onGlassDisabled
        primary -> Color(0xFF06121F)
        destructive -> Rig.Colors.bad
        else -> Rig.Colors.onGlass
    }
    Box(
        modifier
            .background(
                when {
                    primary && enabled -> Rig.Colors.armed
                    primary -> Rig.Colors.armedDisabled
                    else -> Color.White.copy(alpha = 0.07f)
                },
                RoundedCornerShape(Rig.Radius.chip),
            )
            .then(
                if (enabled) {
                    Modifier.clickable(
                        interactionSource = interaction,
                        indication = null,
                        onClick = onClick,
                    )
                } else {
                    Modifier
                },
            )
            .padding(horizontal = Rig.Space.lg, vertical = Rig.Space.sm),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = content,
            fontSize = 12.sp,
            fontWeight = if (primary) FontWeight.SemiBold else FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/**
 * Rename and Delete: square, identical, at the end of the row.
 *
 * Square because that is the shape that survives the phone turning, and
 * identical in size so the two line up down the whole list however wide the
 * Apply button beside them ended up.
 */
@Composable
private fun IconAction(
    glyph: @Composable (Color) -> Unit,
    description: String,
    destructive: Boolean = false,
    onClick: () -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    Box(
        Modifier
            .size(Rig.Touch.touchTarget)
            .background(
                Color.White.copy(alpha = 0.07f),
                RoundedCornerShape(Rig.Radius.chip),
            )
            .clickable(
                interactionSource = interaction,
                indication = null,
                onClick = onClick,
            )
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.uprightInPlace()) {
            glyph(if (destructive) Rig.Colors.bad else Rig.Colors.onGlass)
        }
    }
}
