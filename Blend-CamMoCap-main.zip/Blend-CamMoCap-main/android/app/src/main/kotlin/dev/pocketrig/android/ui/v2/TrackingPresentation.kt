// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

import dev.pocketrig.android.R
import dev.pocketrig.protocol.TrackingIssue
import dev.pocketrig.protocol.TrackingQuality
import dev.pocketrig.protocol.TrackingStatus

/** How loudly a status reads. Maps to colour, nothing else. */
internal enum class Tone { LIVE, WARN, BAD, NEUTRAL }

/** What the tracking badge shows, or null for "show no badge". */
internal data class BadgeSpec(val textRes: Int, val tone: Tone)

/**
 * The tracking badge's entire content, as a pure function.
 *
 * This is deliberately not inline in the layout. The badge previously froze on
 * whatever it last displayed, because the single unconditional publish ended up
 * inside a branch — a bug that was invisible in any static design and needed a
 * specific state sequence to show up. A total function over the state cannot
 * have that failure: there is no path that returns "whatever it said before".
 *
 * [positionHeld] is the shake-hold gate (the host is holding position because
 * the phone is rotating too fast to trust). It outranks tracking quality,
 * because it is the thing actually affecting the shot right now.
 */
internal fun trackingBadge(
    sixDofEnabled: Boolean,
    status: TrackingStatus,
    positionHeld: Boolean,
): BadgeSpec? {
    // Rotation-only is a valid, complete way to use the app, not a degraded
    // 6DOF. It gets no badge at all rather than a reassuring green one.
    if (!sixDofEnabled) return null

    if (positionHeld) return BadgeSpec(R.string.position_held, Tone.WARN)

    return when (status.quality) {
        TrackingQuality.GOOD -> BadgeSpec(R.string.tracking_good, Tone.LIVE)
        TrackingQuality.RECOVERING ->
            BadgeSpec(R.string.tracking_recovering, Tone.WARN)
        TrackingQuality.WARMING -> BadgeSpec(R.string.sixdof_starting, Tone.NEUTRAL)
        TrackingQuality.UNKNOWN -> BadgeSpec(R.string.sixdof_starting, Tone.NEUTRAL)
        // Degraded and lost differ in tone, not in what the operator must DO,
        // so the issue text is what matters and is shared between them.
        TrackingQuality.DEGRADED -> BadgeSpec(issueText(status.issue), Tone.WARN)
        TrackingQuality.LOST -> BadgeSpec(issueText(status.issue), Tone.BAD)
    }
}

/**
 * Turns a tracking issue into an instruction.
 *
 * Every string names an action the operator can take. "Bad state" and "unknown"
 * are the exceptions — nothing useful can be said — so they report the effect on
 * the shot instead ("position held"), which is at least true and actionable in
 * the sense that the operator knows not to trust the move.
 */
private fun issueText(issue: TrackingIssue): Int = when (issue) {
    TrackingIssue.INSUFFICIENT_FEATURES -> R.string.tracking_needs_features
    TrackingIssue.INSUFFICIENT_LIGHT -> R.string.tracking_needs_light
    TrackingIssue.EXCESSIVE_MOTION -> R.string.position_held
    TrackingIssue.CAMERA_UNAVAILABLE -> R.string.tracking_camera_unavailable
    TrackingIssue.INITIALIZING -> R.string.sixdof_starting
    TrackingIssue.NONE, TrackingIssue.BAD_STATE, TrackingIssue.UNKNOWN ->
        R.string.tracking_unavailable
}
