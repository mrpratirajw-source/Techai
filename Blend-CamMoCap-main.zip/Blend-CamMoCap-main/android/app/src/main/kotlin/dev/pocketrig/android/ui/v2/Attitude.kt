// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

/**
 * Roll and pitch of the virtual camera, in degrees.
 *
 * Null means "not known" — the phone is not tracking, or the value has not been
 * wired up yet. The indicator draws nothing rather than a level horizon, because
 * a confident-looking level horizon that is actually stale is worse than an
 * empty frame: it is the badge-frozen bug in a new costume.
 */
internal data class Attitude(val rollDeg: Float, val pitchDeg: Float)

/**
 * A horizon line across the viewfinder that moves as the phone moves.
 *
 * This exists to answer the question the old UI left unanswered: *is it actually
 * tracking?* In rotation-only mode 60–70 % of the screen was empty black, which
 * gives an operator no feedback at all between "working perfectly" and
 * "completely frozen". A horizon that visibly responds is continuous proof of
 * life, and doubles as the levelling aid a camera operator wants anyway.
 *
 * Drawn deliberately quietly: it must never compete with the scene being framed,
 * so it is a thin, low-alpha line plus small pitch ticks, and no numbers unless
 * the camera is meaningfully off level.
 */
@Composable
internal fun AttitudeHorizon(
    attitude: Attitude?,
    modifier: Modifier = Modifier,
) {
    if (attitude == null) return
    // Corrected for how the phone is held: raw roll makes a level shot draw a
    // vertical line the moment the phone is turned sideways. See displayRollDeg.
    val roll = displayRollDeg(attitude.rollDeg, LocalDeviceRotation.current)
    Box(modifier) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            // Everything scales off the SHORT edge. Using width made the line
            // grow with the screen, so in landscape it stretched into a long
            // stray diagonal instead of reading as a horizon.
            val unit = size.minDimension
            // Pitch shifts the horizon vertically; the scale is arbitrary but
            // must be gentle, or small hand movements make it thrash.
            val pitchPx = (attitude.pitchDeg / 45f) * (unit / 4f)
            val rad = Math.toRadians(roll.toDouble())
            val dx = cos(rad).toFloat()
            val dy = sin(rad).toFloat()
            val half = unit * 0.30f

            val mid = Offset(cx, cy + pitchPx)
            val a = Offset(mid.x - dx * half, mid.y - dy * half)
            val b = Offset(mid.x + dx * half, mid.y + dy * half)

            // Gap in the middle so the horizon never hides the exact centre of
            // frame, which is what the operator is aiming with.
            val gap = unit * 0.07f
            // Each stroke is drawn twice: a wider dark line, then the light one
            // over it. Rendering against a stand-in camera image showed the
            // single light stroke disappearing completely over a blown-out
            // highlight -- an instrument that vanishes exactly when the scene is
            // bright is worse than no instrument, because its absence looks like
            // tracking having stopped.
            fun horizonStroke(from: Offset, to: Offset) {
                drawLine(
                    color = Rig.Colors.instrumentShadow,
                    start = from,
                    end = to,
                    strokeWidth = 3.5.dp.toPx(),
                    cap = StrokeCap.Round,
                )
                drawLine(
                    color = Rig.Colors.horizon,
                    start = from,
                    end = to,
                    strokeWidth = 1.5.dp.toPx(),
                    cap = StrokeCap.Round,
                )
            }
            horizonStroke(a, Offset(mid.x - dx * gap, mid.y - dy * gap))
            horizonStroke(Offset(mid.x + dx * gap, mid.y + dy * gap), b)

            // End caps turned toward centre, so the line reads as a deliberate
            // instrument rather than a stray mark on the viewfinder.
            val cap = unit * 0.035f
            for (end in listOf(a to 1f, b to -1f)) {
                val (p, sign) = end
                horizonStroke(
                    p,
                    Offset(p.x + dy * cap * sign, p.y - dx * cap * sign),
                )
            }

            // Fixed centre reticle — the aim point, which does NOT move with the
            // horizon, so the two together read as "camera vs world".
            val tick = 9.dp.toPx()
            for (pair in listOf(
                Offset(cx - tick, cy) to Offset(cx + tick, cy),
                Offset(cx, cy - tick) to Offset(cx, cy + tick),
            )) {
                drawLine(
                    color = Rig.Colors.instrumentShadow,
                    start = pair.first,
                    end = pair.second,
                    strokeWidth = 3.dp.toPx(),
                    cap = StrokeCap.Round,
                )
                drawLine(
                    color = Rig.Colors.reticle,
                    start = pair.first,
                    end = pair.second,
                    strokeWidth = 1.dp.toPx(),
                )
            }
        }
    }
}
