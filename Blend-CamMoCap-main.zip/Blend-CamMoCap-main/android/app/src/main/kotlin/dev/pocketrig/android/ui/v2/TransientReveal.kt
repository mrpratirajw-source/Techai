// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

/**
 * How long the zoom dial stays open after the last touch of it.
 *
 * Long enough to change your mind and adjust again without the ruler vanishing
 * mid-thought; short enough that it is gone by the time you have framed the shot.
 */
internal const val LENS_DIAL_HOLD_MS = 2_500L

/**
 * How long the host name stays visible after connecting or being tapped.
 *
 * It answers "did I pair with the right machine?", which is a question asked once.
 * Long enough to read a machine name, then gone.
 */
internal const val HOST_NAME_HOLD_MS = 3_000L

/**
 * Is a transient reveal still active?
 *
 * One rule for both the zoom dial and the host name, because they are the same
 * rule: something appeared at a moment, and it should disappear a while later.
 * Written as a pure function of the clock rather than as a coroutine that flips a
 * flag, for two reasons. A timer that owns visibility can be cancelled, restarted
 * or leaked into an inconsistent state, and none of that is inspectable; and a
 * timer cannot be tested without waiting. This can be checked at every instant
 * that matters in microseconds.
 *
 * [sinceMs] is when the reveal was last triggered, on a monotonic clock, or null
 * if it never was.
 */
internal fun revealActive(
    sinceMs: Long?,
    nowMs: Long,
    holdMs: Long,
): Boolean {
    if (sinceMs == null) return false
    if (holdMs <= 0L) return false
    val elapsed = nowMs - sinceMs
    // A non-positive elapsed means the clock disagrees with itself: the event
    // reads as being in the future. Treat that as "just happened" rather than
    // "long over", so a glitching clock cannot yank a control out from under a
    // finger that is still on it.
    if (elapsed <= 0L) return true
    return elapsed < holdMs
}
