// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
// Operator extensions behind the `by` delegate syntax. They are never named in
// the body, so an unused-import sweep will happily delete them; the compiler is
// the only thing that notices.
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.viewinterop.AndroidView
import dev.pocketrig.android.R
import dev.pocketrig.android.SessionViewModel
import dev.pocketrig.protocol.DEFAULT_SHAKE_HOLD_DPS
import dev.pocketrig.protocol.FinalizationStage
import dev.pocketrig.protocol.SessionEvent
import dev.pocketrig.protocol.SessionState
import android.os.SystemClock
import dev.pocketrig.android.ViewportClient
import dev.pocketrig.android.ui.v2.ViewportOverlay
import dev.pocketrig.android.ui.v2.AdjustActions
import dev.pocketrig.android.ui.v2.AdjustSheetV2
import dev.pocketrig.android.ui.v2.AdjustUiState
import dev.pocketrig.android.ui.v2.CameraActions
import dev.pocketrig.android.ui.v2.CameraScreenV2
import dev.pocketrig.android.ui.v2.CameraUiState
import dev.pocketrig.android.ui.v2.HOST_NAME_HOLD_MS
import dev.pocketrig.android.ui.v2.LocalDeviceRotation
import dev.pocketrig.android.ui.v2.WorldSheetHost
import dev.pocketrig.android.ui.v2.rememberDeviceRotation
import dev.pocketrig.android.ui.v2.revealActive
import dev.pocketrig.protocol.TrackingStatus
import java.util.Locale
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * Everything the UI needs from the 6DOF feature (ADR-0006), owned and gated
 * by MainActivity: the toggle goes through [onToggle] (permission + ARCore
 * install checks live there), and [viewfinder] supplies the ARCore camera
 * passthrough view shown behind the camera screen while enabled.
 */
class SixDofUi(
    val supported: StateFlow<Boolean>,
    val enabled: StateFlow<Boolean>,
    val trackingStatus: StateFlow<TrackingStatus>,
    val fastMotion: StateFlow<Boolean>,
    val onToggle: () -> Unit,
    val viewfinder: (android.content.Context) -> android.view.View,
)

/**
 * The whole app: one screen whose content follows [SessionState].
 * Disconnected → Connecting → Live ↔ Recording; reconnection is a badge on
 * Live/Recording, never a different place.
 */
@Composable
fun PocketrigApp(viewModel: SessionViewModel, sixDof: SixDofUi? = null) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val camParams by viewModel.camParams.collectAsStateWithLifecycle()
    val viewportOffer by viewModel.viewportOffer.collectAsStateWithLifecycle()
    val viewportWanted by viewModel.viewportWanted.collectAsStateWithLifecycle()
    val viewportStatus by viewModel.viewport.status.collectAsStateWithLifecycle()
    val viewportStats by viewModel.viewport.stats.collectAsStateWithLifecycle()
    val viewportSize by viewModel.viewportSize.collectAsStateWithLifecycle()
    val viewportFps by viewModel.viewportFps.collectAsStateWithLifecycle()
    val viewportQuality by viewModel.viewportQuality.collectAsStateWithLifecycle()
    val viewportOverlays by viewModel.viewportOverlays.collectAsStateWithLifecycle()
    val viewportProfile by viewModel.viewportProfile.collectAsStateWithLifecycle()
    val camPaused by viewModel.camPaused.collectAsStateWithLifecycle()
    val offlineRecording by viewModel.offlineRecording.collectAsStateWithLifecycle()
    val offlineStartedAtMs by viewModel.offlineStartedAtMs.collectAsStateWithLifecycle()
    val offlineCount by viewModel.offlineCount.collectAsStateWithLifecycle()
    val library by viewModel.library.collectAsStateWithLifecycle()
    val libraryApplyId by viewModel.libraryApplyId.collectAsStateWithLifecycle()
    val focalMm by viewModel.focalLengthMm.collectAsStateWithLifecycle()
    val applyingTakeName = libraryApplyId?.let { id ->
        library.firstOrNull { it.id == id }?.name ?: "take"
    }
    // Apply is only offered while LIVE, never mid-recording (applying a
    // take mid-take would collide with the take in progress on the host).
    val canApply = state is SessionState.Live && libraryApplyId == null
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val notify: (String) -> Unit = remember(scope, snackbar) {
        { message -> scope.launch { snackbar.showSnackbar(message) } }
    }
    // Visual confirmation keeps Re-center legible without physically vibrating
    // the phone during ARCore acquisition.
    val onRecenter: () -> Unit = {
        viewModel.recenter()
        notify(context.getString(R.string.recentered))
    }

    LaunchedEffect(viewModel) {
        viewModel.events.collect { event ->
            val message = when (event) {
                is SessionEvent.Baked ->
                    context.getString(
                        R.string.baked_toast,
                        event.frames,
                        formatFps(event.fps),
                        context.getString(
                            if (event.source == "offline") R.string.src_offline
                            else R.string.src_live,
                        ),
                    )

                is SessionEvent.ConnectFailed ->
                    context.getString(R.string.connect_failed)

                is SessionEvent.HostError -> when (event.code) {
                    "bad_token" -> context.getString(R.string.error_bad_token)
                    "busy" -> context.getString(R.string.error_busy)
                    "version_unsupported" -> context.getString(R.string.error_version)
                    "apply_failed" -> context.getString(R.string.error_apply, event.message)
                    "bake_failed" -> context.getString(R.string.error_apply, event.message)
                    "record_rejected" -> context.getString(R.string.error_record_rejected)
                    else -> context.getString(R.string.error_generic, event.code)
                }

                is SessionEvent.TakeSaved -> context.getString(R.string.take_saved_phone)

                is SessionEvent.TakeTransferFailed ->
                    context.getString(R.string.take_transfer_failed)
            }
            snackbar.showSnackbar(message)
        }
    }
    LaunchedEffect(viewModel) {
        viewModel.appMessages.collect { snackbar.showSnackbar(it) }
    }

    // The whole app follows the phone, whatever auto-rotate says, and freezes
    // while recording -- a 6DOF move swings the phone through whole quadrants,
    // and chrome spinning mid-take is exactly the distraction a take does not
    // need. This replaces the Orientation setting entirely.
    val shotOrientation by viewModel.shotOrientation.collectAsStateWithLifecycle()
    // The lock freezes exactly what recording freezes: this one value, which
    // drives BOTH the chrome's turning and the shot's axis correction. Holding
    // only the correction was the bug -- the shot stopped following while the UI
    // carried on turning, so tapping Lock looked like it had done nothing.
    val deviceRotation = rememberDeviceRotation(
        frozen = state is SessionState.Recording ||
            offlineRecording ||
            shotOrientation != "auto",
    )
    // The pose axes follow the same value the chrome does, so the shot and the
    // UI can never disagree about which way is up -- and freezing it while
    // recording freezes both at once.
    LaunchedEffect(deviceRotation) { viewModel.setDeviceRotation(deviceRotation) }
    CompositionLocalProvider(LocalDeviceRotation provides deviceRotation) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            // Offline record + takes drawer are nav states (not session
            // states): reachable from Disconnected (and the drawer from the
            // camera too). Takes move to Blender explicitly — never auto.
            var offlineScreen by rememberSaveable { mutableStateOf(false) }
            var takesDrawer by rememberSaveable { mutableStateOf(false) }

            // Tell the activity when a viewfinder screen is up, so it can release
            // the camera on the scan screen (fixes the QR scanner not re-scanning
            // because a paused ARCore session still held the camera).
            LaunchedEffect(state, offlineScreen) {
                viewModel.setViewfinderActive(
                    state is SessionState.Live ||
                        state is SessionState.Recording ||
                        state is SessionState.Finalizing ||
                        (state is SessionState.Disconnected && offlineScreen),
                )
            }

            when (val s = state) {
                is SessionState.Disconnected ->
                    if (offlineScreen && sixDof != null) {
                        OfflineScreen(
                            sixDof = sixDof,
                            recording = offlineRecording,
                            startedAtMs = offlineStartedAtMs,
                            savedCount = offlineCount,
                            attitude = viewModel.attitude,
                            onStart = viewModel::startOfflineRecording,
                            onStop = viewModel::stopOfflineRecording,
                            onBrowse = { takesDrawer = true },
                            onExit = {
                                if (offlineRecording) viewModel.stopOfflineRecording()
                                offlineScreen = false
                            },
                            shotLocked = shotOrientation != "auto",
                            onToggleShotLock = viewModel::toggleShotLock,
                        )
                    } else {
                        LandingScreen(
                            onQr = viewModel::connectFromQr,
                            onManual = viewModel::connectManually,
                            savedCount = offlineCount,
                            onRecordOffline = { offlineScreen = true },
                            onBrowse = { takesDrawer = true },
                        )
                    }

                is SessionState.Connecting -> ConnectingScreen(
                    onCancel = viewModel::disconnect,
                )

                // Live and Recording MUST share one call site: sibling `when`
                // branches are separate Compose subtrees, and switching them
                // disposes the AndroidView holding the ARCore GLSurfaceView —
                // the surface teardown stalled the pose stream at every record
                // start/stop (frozen camera, then a jump when it recovered
                // with the guards frozen). One call site = the viewfinder
                // never leaves the tree.
                is SessionState.Live, is SessionState.Recording, is SessionState.Finalizing -> {
                    val recording = s as? SessionState.Recording
                    val live = s as? SessionState.Live
                    val finalizing = s as? SessionState.Finalizing
                    val attitude by viewModel.attitude.collectAsStateWithLifecycle()
                    val sixDofOn = sixDof?.enabled?.collectAsStateWithLifecycle()?.value == true
                    val tracking = sixDof?.trackingStatus?.collectAsStateWithLifecycle()?.value
                        ?: TrackingStatus.UNKNOWN
                    val held = sixDof?.fastMotion?.collectAsStateWithLifecycle()?.value == true

                    var adjustSheet by rememberSaveable { mutableStateOf(false) }

                    // Only one transient reveal is left: the host name. The
                    // zoom dial used to auto-hide, but it is always on screen now,
                    // so there is nothing to time.
                    var hostShownAt by remember {
                        mutableStateOf<Long?>(SystemClock.elapsedRealtime())
                    }
                    var showHost by remember { mutableStateOf(true) }
                    LaunchedEffect(hostShownAt) {
                        if (hostShownAt == null) return@LaunchedEffect
                        while (
                            revealActive(
                                hostShownAt,
                                SystemClock.elapsedRealtime(),
                                HOST_NAME_HOLD_MS,
                            )
                        ) {
                            delay(150)
                        }
                        showHost = false
                    }

                    // Elapsed time ticks once a second, and only while rolling.
                    var elapsedLabel by remember { mutableStateOf<String?>(null) }
                    LaunchedEffect(recording?.startedAtWallMs) {
                        val started = recording?.startedAtWallMs
                        if (started == null) {
                            elapsedLabel = null
                            return@LaunchedEffect
                        }
                        while (true) {
                            val secs = ((System.currentTimeMillis() - started) / 1000L)
                                .coerceAtLeast(0L)
                            elapsedLabel = "%d:%02d".format(secs / 60, secs % 60)
                            delay(1000)
                        }
                    }

                    Box(Modifier.fillMaxSize()) {
                        CameraScreenV2(
                            state = CameraUiState(
                                serverName = recording?.serverName
                                    ?: finalizing?.serverName ?: live!!.serverName,
                                rttMs = recording?.rttMs ?: finalizing?.rttMs ?: live!!.rttMs,
                                reconnecting = recording?.reconnecting
                                    ?: finalizing?.reconnecting ?: live!!.reconnecting,
                                recording = recording != null,
                                paused = camPaused,
                                elapsedLabel = elapsedLabel,
                                showHost = showHost,
                                sixDofEnabled = sixDofOn,
                                tracking = tracking,
                                positionHeld = held,
                                shotLocked = shotOrientation != "auto",
                                focalMm = focalMm,
                                hostLensMm = camParams?.hostLensMm?.toFloat(),
                                attitude = attitude,
                                finalization = finalizing?.stage,
                                finalizationProgress = finalizing?.progress,
                            ),
                            actions = CameraActions(
                                onRecordToggle = if (recording != null) {
                                    viewModel::stopRecording
                                } else {
                                    viewModel::startRecording
                                },
                                onRecenter = onRecenter,
                                onPauseToggle = { viewModel.setPaused(!camPaused) },
                                // sixDof exposes a bare toggle, so only act when the
                                // requested mode differs from the current one --
                                // otherwise tapping the segment you are already in
                                // would switch you out of it.
                                onSetSixDof = { want ->
                                    if (want != sixDofOn) sixDof?.onToggle?.invoke()
                                },
                                onFocalMm = viewModel::setFocalLengthMm,
                                // Taking the lens adopts Blender's own value, so
                                // the act of taking it never reframes the shot
                                // (spec 4.5 / 5.7). That is the whole reason the
                                // host reports lens_mm at all.
                                onToggleLensOwnership = viewModel::toggleLensOwnership,
                                onAdjust = { adjustSheet = true },
                                onTakes = { takesDrawer = true },
                                onToggleShotLock = viewModel::toggleShotLock,
                                onSeekStart = viewModel::seekToStart,
                                onTapStatus = {
                                    showHost = true
                                    hostShownAt = SystemClock.elapsedRealtime()
                                },
                            ),
                            // Both go in this one slot, in this order. ARCore
                            // tracks through the passthrough surface, so it has
                            // to be in the tree whenever 6DOF is on -- without
                            // it the toggle appeared to do nothing -- and the
                            // Blender frame therefore draws OVER it rather than
                            // in place of it.
                            viewfinder = if (sixDof != null && sixDofOn) {
                                {
                                    AndroidView(
                                        factory = sixDof.viewfinder,
                                        modifier = Modifier.fillMaxSize(),
                                    )
                                    ViewportOverlay(
                                        frames = viewModel.viewport.frame,
                                        onPresented = viewModel.viewport::notePresented,
                                    )
                                }
                            } else {
                                {
                                    ViewportOverlay(
                                        frames = viewModel.viewport.frame,
                                        onPresented = viewModel.viewport::notePresented,
                                    )
                                }
                            },
                        )

                        // Kept from the old screen rather than redesigned: these are
                        // the only feedback during an upload and bake, and dropping
                        // them to swap the layout would be a regression.
                        if (finalizing != null) {
                            FinalizationBadge(
                                stage = finalizing.stage,
                                progress = finalizing.progress,
                                failure = finalizing.failure,
                                onContinue = viewModel::dismissFinalizationFailure,
                                modifier = Modifier.align(Alignment.Center),
                            )
                        }
                        applyingTakeName?.let {
                            ApplyBadge(
                                text = stringResource(R.string.applying_take_to_camera, it),
                                modifier = Modifier.align(Alignment.Center),
                            )
                        }

                        if (adjustSheet) {
                            // PARAMS is one mirrored set, so every control has to
                            // resend the values it did not touch. Spelling that
                            // out per call site meant each new value had to be
                            // added in four places, and the one that got missed
                            // would be silently reset by moving an unrelated
                            // slider. Defaults make "unchanged" the default.
                            fun push(
                                live: Double = camParams?.liveSmoothing ?: 0.3,
                                record: Double = camParams?.recordSmoothing ?: 0.15,
                                scale: Double = camParams?.moveScale ?: 1.0,
                                source: String? = camParams?.takeSource,
                                shakeHold: Double? = camParams?.shakeHoldDps,
                            ) = viewModel.setParams(live, record, scale, source, shakeHold)

                            WorldSheetHost(
                                onDismiss = { adjustSheet = false },
                            ) {
                                AdjustSheetV2(
                                    state = AdjustUiState(
                                        liveSmoothing = camParams?.liveSmoothing?.toFloat() ?: 0.3f,
                                        recordSmoothing = camParams?.recordSmoothing?.toFloat() ?: 0.15f,
                                        positionScale = camParams?.moveScale?.toFloat() ?: 1f,
                                        takeSource = camParams?.takeSource ?: "offline",
                                        shotOrientation = shotOrientation,
                                        shakeHoldDps = camParams?.shakeHoldDps?.toFloat()
                                            ?: DEFAULT_SHAKE_HOLD_DPS.toFloat(),
                                        viewportOn = viewportWanted,
                                        viewportAvailable = viewportOffer?.bestMode != null,
                                        viewportNote = viewportNote(viewportStatus, viewportStats),
                                        viewportSizes = viewportOffer?.sizes ?: emptyList(),
                                        viewportSize = viewportSize
                                            ?: viewportOffer?.bestSizeWithin(1280, 720),
                                        viewportFps = viewportFps,
                                        viewportMaxFps =
                                            camParams?.viewportMaxFps?.roundToInt(),
                                        viewportQuality = viewportQuality,
                                        viewportOverlays = viewportOverlays,
                                        viewportProfile = viewportProfile,
                                        // Off the frames, not off the request:
                                        // under a preset we never asked for a
                                        // size, so this is the only place the
                                        // truth exists on this side.
                                        viewportChosenSize = viewportStats
                                            .takeIf { it.lastWidth > 0 }
                                            ?.let { it.lastWidth to it.lastHeight },
                                        locked = recording != null,
                                    ),
                                    actions = AdjustActions(
                                        onLiveSmoothing = { v -> push(live = v.toDouble()) },
                                        onRecordSmoothing = { v -> push(record = v.toDouble()) },
                                        onPositionScale = { v -> push(scale = v.toDouble()) },
                                        onTakeSource = { src -> push(source = src) },
                                        onShakeHoldDps = { v -> push(shakeHold = v.toDouble()) },
                                        onShotOrientation = viewModel::setShotOrientation,
                                        onToggleViewport = viewModel::toggleViewport,
                                        onViewportSize = viewModel::setViewportSize,
                                        onViewportFps = viewModel::setViewportFps,
                                        onViewportQuality = viewModel::setViewportQuality,
                                        onViewportOverlays =
                                            viewModel::setViewportOverlays,
                                        onViewportProfile =
                                            viewModel::setViewportProfile,
                                        onDismiss = { adjustSheet = false },
                                    ),
                                )
                            }
                        }
                    }
                }
            }

            if (takesDrawer) {
                TakesScreen(
                    takes = library,
                    connected = canApply,
                    applyingId = libraryApplyId,
                    positionScale = camParams?.moveScale,
                    onApply = viewModel::uploadTake,
                    onRename = viewModel::renameTake,
                    onDelete = viewModel::deleteTake,
                    onDismiss = { takesDrawer = false },
                )
            }
        }
    }
    }
}

private fun formatFps(fps: Double): String =
    if (fps > 0 && fps == floor(fps)) {
        fps.toInt().toString()
    } else {
        String.format(Locale.US, "%.2f", fps)
    }

@Composable
private fun FinalizationBadge(
    stage: FinalizationStage,
    progress: Float?,
    failure: String?,
    onContinue: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val base = when (stage) {
        FinalizationStage.SAVING -> stringResource(R.string.take_saving)
        FinalizationStage.TRANSFERRING -> stringResource(R.string.take_transferring)
        FinalizationStage.BAKING -> stringResource(R.string.take_baking)
        FinalizationStage.FAILED -> failure ?: stringResource(R.string.take_failed)
    }
    val label = if (stage == FinalizationStage.TRANSFERRING && progress != null) {
        "$base ${(progress * 100).toInt().coerceIn(0, 100)}%"
    } else {
        base
    }
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(22.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.92f))
            .padding(horizontal = 18.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (stage != FinalizationStage.FAILED) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp,
                )
                Spacer(Modifier.width(10.dp))
            }
            Text(label, fontWeight = FontWeight.SemiBold)
        }
        if (stage == FinalizationStage.FAILED) {
            Text(
                stringResource(R.string.take_failed_saved),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 12.sp,
            )
            TextButton(onClick = onContinue) {
                Text(stringResource(R.string.continue_label))
            }
        }
    }
}

@Composable
private fun ApplyBadge(text: String, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(22.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.92f))
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
        Spacer(Modifier.width(10.dp))
        Text(text, fontWeight = FontWeight.SemiBold)
    }
}

// ----------------------------------------------------------------- Connecting

@Composable
internal fun ConnectingScreen(onCancel: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        CircularProgressIndicator(
            modifier = Modifier.size(28.dp),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            strokeWidth = 2.dp,
        )
        Spacer(Modifier.height(20.dp))
        Text(
            text = stringResource(R.string.looking_for_blender),
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 16.sp,
        )
        Spacer(Modifier.height(28.dp))
        TextButton(onClick = onCancel) {
            Text(
                text = stringResource(R.string.cancel),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 14.sp,
            )
        }
    }
}

/**
 * The line under the viewport toggle, or null when there is nothing to say.
 *
 * Silent while streaming: a working stream is its own status, and a permanent
 * "connected" line is noise on a sheet the operator opens mid-shoot.
 */
@Composable
private fun viewportNote(
    status: ViewportClient.Status,
    stats: ViewportClient.Stats,
): String? = when (status) {
    is ViewportClient.Status.Connecting -> stringResource(R.string.viewport_connecting)
    is ViewportClient.Status.Reconnecting ->
        stringResource(R.string.viewport_retrying, status.attempt)
    is ViewportClient.Status.Failed -> stringResource(R.string.viewport_failed, status.reason)
    // Streaming reports its size, and its drops only when there are any. A
    // permanent "0 dropped" is noise on a sheet opened mid-shoot; a number that
    // appears when the link starts struggling is the whole point of counting.
    is ViewportClient.Status.Streaming -> when {
        stats.lastWidth <= 0 -> null
        stats.framesMissed > 0 -> stringResource(
            R.string.viewport_live_drops,
            stats.lastWidth, stats.lastHeight, stats.fps, stats.framesMissed,
        )
        else -> stringResource(
            R.string.viewport_live, stats.lastWidth, stats.lastHeight, stats.fps,
        )
    }
    else -> null
}
