// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.pocketrig.android.R
import dev.pocketrig.protocol.FinalizationStage
import dev.pocketrig.protocol.TrackingStatus

/**
 * Everything the camera screen draws, in one value.
 *
 * State lives in a single data class on purpose. The design rule is that a state
 * which is not rendered does not exist, and that is only enforceable if the set
 * of states is a thing you can enumerate and iterate. Every UI bug this project
 * shipped was a state the design had never been looked at in.
 */
internal data class CameraUiState(
    val serverName: String = "Blender",
    val rttMs: Long? = null,
    val reconnecting: Boolean = false,
    val recording: Boolean = false,
    val paused: Boolean = false,
    val elapsedLabel: String? = null,
    /**
     * Reveal the host name. It answers "did I pair with the right machine?",
     * which is a question exactly once: on connect, or when the operator asks by
     * tapping. Showing it permanently spends the top of the frame on a constant,
     * and constants are noise.
     */
    val showHost: Boolean = false,
    val sixDofEnabled: Boolean = false,
    val tracking: TrackingStatus = TrackingStatus.UNKNOWN,
    val positionHeld: Boolean = false,
    /** Shot axis locked rather than following the phone. */
    val shotLocked: Boolean = false,
    /** null = the lens belongs to Blender (spec 4.5). */
    val focalMm: Float? = null,
    /** Blender's own lens, mirrored through PARAMS `lens_mm` (spec 5.7). */
    val hostLensMm: Float? = null,
    val attitude: Attitude? = null,
    val finalization: FinalizationStage? = null,
    val finalizationProgress: Float? = null,
)

/** Callbacks, separated from state so a render needs no behaviour at all. */
internal data class CameraActions(
    val onRecordToggle: () -> Unit = {},
    val onRecenter: () -> Unit = {},
    val onPauseToggle: () -> Unit = {},
    val onSetSixDof: (Boolean) -> Unit = {},
    val onFocalMm: (Float) -> Unit = {},
    /** Take the lens from Blender, or hand it back (spec 4.5). */
    val onToggleLensOwnership: () -> Unit = {},
    val onLensSettled: () -> Unit = {},
    val onAdjust: () -> Unit = {},
    val onTakes: () -> Unit = {},
    val onToggleShotLock: () -> Unit = {},
    val onSeekStart: () -> Unit = {},
    val onTapStatus: () -> Unit = {},
)

/**
 * The redesigned live/recording screen.
 *
 * **Two regions, not a full-bleed frame with chrome floating on top.** The
 * viewfinder gets its own box and the dock gets its own. This is not cosmetic:
 * instruments centre on the *viewfinder*, and an earlier version that ran the
 * frame edge to edge put the level indicator visibly off-centre from the picture
 * the operator was actually composing.
 *
 * **One layout. The phone turns; the dock does not.** There is no landscape
 * variant any more. The dock is on the phone's bottom edge always, so the record
 * button, Adjust and Takes never move an inch however the phone is held -- only
 * the content of each control turns, to stay upright (see [LocalDeviceRotation]).
 *
 * The landscape variant this replaces pinned the dock to the *screen's* end edge
 * rather than to the phone. Turned one way the corner controls landed correctly;
 * turned the other way the whole dock jumped to the opposite edge of the device
 * and the corners mirrored. Deleting the second layout deleted the problem.
 */
@Composable
internal fun CameraScreenV2(
    state: CameraUiState,
    actions: CameraActions = CameraActions(),
    /**
     * The camera passthrough, drawn behind everything in the viewfinder region.
     *
     * Not decoration: ARCore tracks through this surface, so a layout that omits
     * it does not merely lose the picture, it stops 6DOF working at all. The
     * first version of this screen had no slot for it, and enabling 6DOF on the
     * device did nothing at all as a result.
     */
    viewfinder: (@Composable () -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier.fillMaxSize().lensPinchAll(state, actions),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Viewfinder(
            state,
            Modifier.weight(1f).fillMaxWidth(),
            viewfinder = viewfinder,
        ) {
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(
                        bottom = Rig.Space.lg,
                        start = Rig.Touch.edgeInset,
                        end = Rig.Touch.edgeInset,
                    ),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                ZoomWidget(state, actions)
            }
            // Pinned to the PHONE's top-start, like everything else, with only
            // its content turning. It was anchored to the world's top-left, which
            // moved it to a different physical corner at every rotation -- and at
            // half a turn it landed squarely on the zoom dial. Chasing whichever
            // world corner happens to be free cannot work, because that changes
            // with the rotation AND with the screen. The phone's top is the one
            // place that is always the opposite end from the dock, so it can
            // never collide with the zoom widget or the name pill.
            cameraProblem(state)?.let { (text, tone) ->
                ProblemBanner(
                    text,
                    tone,
                    Modifier
                        .align(Alignment.TopStart)
                        .padding(Rig.Touch.edgeInset),
                )
            }
        }
        Dock(state, actions)
    }
}

/** Pinch anywhere on the frame. Inactive until the phone owns the lens, so a
 * pinch can never silently seize it from Blender (spec 4.5). */
@Composable
private fun Modifier.lensPinchAll(
    state: CameraUiState,
    actions: CameraActions,
): Modifier = lensPinch(
    focalMm = state.focalMm,
    onFocalMm = actions.onFocalMm,
)

/**
 * The frame being composed: camera image, instruments, zoom widget.
 *
 * Instruments centre on THIS box rather than on the screen, which is the entire
 * reason it exists as its own region.
 */
@Composable
private fun Viewfinder(
    state: CameraUiState,
    modifier: Modifier = Modifier,
    viewfinder: (@Composable () -> Unit)? = null,
    overlay: @Composable BoxScope.() -> Unit,
) {
    Box(modifier) {
        // Behind everything: the instruments read over the picture, not beside it.
        viewfinder?.invoke()
        AttitudeHorizon(state.attitude, Modifier.fillMaxSize())
        // Nothing else over the frame. The readout moved into the dock, where it
        // covers no part of the shot being composed.
        overlay()
    }
}

@Composable
private fun ZoomWidget(
    state: CameraUiState,
    actions: CameraActions,
    modifier: Modifier = Modifier,
) = LensZoomWidget(
    focalMm = state.focalMm,
    hostLensMm = state.hostLensMm,
    onFocalMm = actions.onFocalMm,
    onToggleLensOwnership = actions.onToggleLensOwnership,
    onSettled = actions.onLensSettled,
    modifier = modifier,
)

/**
 * All the controls, in one grounded slab beside the frame.
 *
 * Same content, same order, both orientations. Transport is nearest the frame and
 * the between-shots group furthest from it, so the record button lands under the
 * thumb either way and Adjust/Takes stay in the far corners.
 */
@Composable
private fun Dock(state: CameraUiState, actions: CameraActions) {
    GroundedDock(
        status = cameraStatus(state),
        // Jump Blender's playhead back to the top -- the retake. It lives at the
        // readout row's other end because it acts on the HOST rather than on
        // this phone, which is the one thing none of the dock's other controls
        // do, and it should not sit among them looking like they do.
        leading = {
            StripAction(
                glyph = { GlyphToStart(it) },
                description = stringResource(R.string.to_start),
                // Not mid-take: the playhead is where the take is being written.
                enabled = state.finalization == null && !state.recording,
                onClick = actions.onSeekStart,
            )
        },
        // The axis lock rides at the readout row's end rather than among the
        // press-me controls: it is a property of the whole screen, closer to a
        // status than to an action, and the settings row's corners belong to
        // Adjust and Takes.
        trailing = {
            StripToggle(
                glyph = { GlyphLock(it, state.shotLocked) },
                description = stringResource(R.string.shot_lock),
                on = state.shotLocked,
                // Recording freezes the axis on its own, so offering the control
                // there would promise a change that cannot happen.
                enabled = state.finalization == null && !state.recording,
                onClick = actions.onToggleShotLock,
            )
        },
    ) {
        TransportRow(state, actions)
        Spacer(Modifier.height(Rig.Space.md))
        SettingsRow(state, actions)
    }
}

/**
 * What the link and the tracking are doing, as square cells.
 *
 * Icons carry the health; the exact round-trip time does not need to be on screen
 * at all times, and spelling it out is what made the old pill wide enough to sit
 * across the corner of every shot. Colour says fine / worth watching / bad, which
 * is the whole of what the operator does with that number in practice.
 *
 * Tracking is silent while it is going well: a green cube, no words. "Position
 * tracking" was a sentence spent saying nothing needs doing.
 */
@Composable
private fun cameraStatus(state: CameraUiState): List<StatusItem> {
    val items = mutableListOf<StatusItem>()
    if (state.recording) {
        items += StatusItem(
            glyph = { GlyphRecordDot(it) },
            tone = Tone.BAD,
            text = state.elapsedLabel ?: "0:00",
            explain = stringResource(R.string.explain_recording),
        )
    }
    items += StatusItem(
        glyph = { GlyphLink(it) },
        tone = when {
            state.reconnecting -> Tone.WARN
            state.rttMs == null -> Tone.NEUTRAL
            state.rttMs <= 60 -> Tone.LIVE
            state.rttMs <= 150 -> Tone.WARN
            else -> Tone.BAD
        },
        // The round-trip figure lives here now. Dropping it from the strip made
        // the chrome quiet; putting it behind a tap means it is still knowable
        // when a shot feels laggy and the operator wants a number.
        explain = when {
            state.reconnecting -> stringResource(R.string.explain_link_lost)
            state.rttMs == null -> stringResource(R.string.explain_link_unknown)
            else -> stringResource(R.string.explain_link, state.rttMs.toInt())
        },
    )
    if (state.sixDofEnabled) {
        val badge = trackingBadge(state.sixDofEnabled, state.tracking, state.positionHeld)
        items += StatusItem(
            glyph = { GlyphCube(it) },
            tone = badge?.tone ?: Tone.NEUTRAL,
            explain = badge?.let { stringResource(it.textRes) },
        )
    }
    return items
}

/**
 * The tracking instruction, in words, only when there is one to act on.
 *
 * Null while tracking is fine, so the frame stays clear. This is the half of the
 * old badge that could not survive being shrunk to an icon -- "Point at a detailed
 * surface" is an instruction, and an amber cube does not give it.
 */
@Composable
private fun cameraProblem(state: CameraUiState): Pair<String, Tone>? {
    if (state.reconnecting) return stringResource(R.string.reconnecting) to Tone.WARN
    val badge = trackingBadge(state.sixDofEnabled, state.tracking, state.positionHeld)
        ?: return null
    if (badge.tone != Tone.WARN && badge.tone != Tone.BAD) return null
    return stringResource(badge.textRes) to badge.tone
}

/** Re-centre, record, pause. Transport, grouped, record always centred. */
@Composable
private fun TransportRow(state: CameraUiState, actions: CameraActions) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(Rig.Space.xl),
    ) {
        RecenterChip(state, actions)
        RecordButtonV2(
            recording = state.recording,
            // Recording MUST NOT disable this: while a take rolls, this button
            // IS the stop control. Gating it on a general "busy" flag that
            // included recording is what made manual stop impossible.
            enabled = state.finalization == null,
            onClick = actions.onRecordToggle,
        )
        PauseChip(state, actions)
    }
}

/**
 * Adjust and Takes in the far corners, tracking mode between them.
 *
 * These are the controls reached for *between* shots, so the corners are exactly
 * right: easy to hit, never near the record button.
 *
 * There is no Lens button. Ownership of the lens is answered by the zoom widget's
 * own leading segment, so a dedicated toggle would be a whole control spent on a
 * question something else already shows.
 */
@Composable
private fun SettingsRow(state: CameraUiState, actions: CameraActions) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        TrayChip(
            label = stringResource(R.string.adjust),
            glyph = { GlyphSliders(it) },
            onClick = actions.onAdjust,
            enabled = state.finalization == null,
        )
        TrackingModeToggle(state, actions)
        TrayChip(
            label = stringResource(R.string.takes),
            glyph = { GlyphStack(it) },
            onClick = actions.onTakes,
            enabled = state.finalization == null,
        )
    }
}

/**
 * Rotation vs 6DOF.
 *
 * A mode, not a setting: it changes what the app does, the way photo-vs-video
 * does in a camera app. Both icons stay visible so the operator can see the
 * current mode *and* the alternative, which a lone "6DOF" toggle never did.
 *
 * A row in **both** orientations. It was briefly stacked in landscape, which
 * broke the rule the whole layout rests on: positions change between
 * orientations, content does not. A control that changes its own shape when the
 * phone turns has to be re-read each time, which is exactly what rotating the
 * layout was rejected for.
 */
@Composable
private fun TrackingModeToggle(
    state: CameraUiState,
    actions: CameraActions,
) = SegmentedToggle(
    options = listOf(
        { tint -> GlyphRotate(tint) },
        { tint -> GlyphCube(tint) },
    ),
    selectedIndex = if (state.sixDofEnabled) 1 else 0,
    onSelect = { actions.onSetSixDof(it == 1) },
    // Locked during finalization and mid-take: switching pose source in the
    // middle of a recording would splice two kinds of motion into one take.
    enabled = state.finalization == null && !state.recording,
)

@Composable
private fun RecenterChip(state: CameraUiState, actions: CameraActions) = TrayChip(
    label = stringResource(R.string.recenter),
    glyph = { GlyphCrosshair(it) },
    onClick = actions.onRecenter,
    enabled = state.finalization == null && !state.paused,
)

@Composable
private fun PauseChip(state: CameraUiState, actions: CameraActions) = TrayChip(
    label = stringResource(if (state.paused) R.string.go_live else R.string.pause),
    glyph = { if (state.paused) GlyphPlay(it) else GlyphPause(it) },
    onClick = actions.onPauseToggle,
    armed = state.paused,
    enabled = !state.recording && state.finalization == null,
)

// RecordButtonV2 lives in Surfaces.kt: the landing screen starts offline takes
// with the same landmark, and one drawing of it is the point.
