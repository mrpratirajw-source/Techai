// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android

import android.app.Activity
import android.content.Context
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.os.Build
import android.view.Surface
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Anchor
import com.google.ar.core.CameraConfig
import com.google.ar.core.CameraConfigFilter
import com.google.ar.core.Config
import com.google.ar.core.Coordinates2d
import com.google.ar.core.Frame
import com.google.ar.core.ImageMetadata
import com.google.ar.core.Pose
import com.google.ar.core.Session
import com.google.ar.core.TrackingState
import com.google.ar.core.exceptions.CameraNotAvailableException
import com.google.ar.core.exceptions.MetadataNotFoundException
import com.google.ar.core.exceptions.NotYetAvailableException
import android.os.SystemClock
import dev.pocketrig.protocol.MotionCorroboration
import dev.pocketrig.protocol.Quaternion
import dev.pocketrig.protocol.RigidPose
import dev.pocketrig.protocol.SessionClient
import dev.pocketrig.protocol.SixDofFrame
import dev.pocketrig.protocol.SixDofFramePolicy
import dev.pocketrig.protocol.SixDofOutcome
import dev.pocketrig.protocol.TrackingIssue
import dev.pocketrig.protocol.TrackingQuality
import dev.pocketrig.protocol.TrackingStatus
import dev.pocketrig.protocol.Vec3
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * The 6DOF pose source (ADR-0006): an ARCore session whose camera passthrough
 * doubles as the viewfinder. While tracking, every ARCore frame's
 * displayOrientedPose is converted ([Frames.arcoreToProtocol]) and fed to
 * [SessionClient.updatePose] with position — the same latest-wins 100 Hz
 * ticker ships it. A hysteretic quality state withholds position while ARCore
 * is warming, degraded, lost, or recovering, so the host never treats those
 * frames as trustworthy continuous translation.
 *
 * Owns a [GLSurfaceView] (created lazily by [view]) because ARCore requires a
 * GL texture to render into; the render loop is also the pose pump.
 */
internal class ArCorePipeline(
    private val activity: Activity,
    private val client: SessionClient,
    private val onError: (Exception) -> Unit,
    /** Optional Motion Lab capture tap (debug tooling); sees every pose. */
    private val tap: ((String, Quaternion, Long, Vec3?, TrackingQuality, TrackingIssue, Float) -> Unit)? = null,
    /** Optional acquisition telemetry sink; debug builds pass the trace recorder. */
    private val telemetry: TrackingTelemetry? = null,
    /**
     * Latest inertial orientation in the protocol frame. Used only to continue
     * ROTATION while ARCore cannot see; it never contributes position, and it is
     * never sent on its own. Null disables the continuation and rotation holds
     * still through a loss, as it did before.
     */
    private val orientationSource: (() -> Quaternion?)? = null,
    /**
     * Independent physical evidence of whether the phone is actually moving.
     * ARCore reports TRACKING with no failure reason while it cannot see and
     * dead-reckons meanwhile; this is what lets a shipped build tell an invented
     * camera move from a real one.
     */
    private val corroboration: MotionCorroboration? = null,
) : GLSurfaceView.Renderer {

    // The per-frame decision lives in SixDofFramePolicy, which is pure and
    // unit-tested. This class is reduced to ARCore/GL I/O plus publishing what
    // the policy decides -- the split exists because four consecutive defects
    // shipped from logic that was inlined here, where nothing could test it.
    private val policy = SixDofFramePolicy(corroboration = corroboration)
    private val _trackingStatus = MutableStateFlow(TrackingStatus.UNKNOWN)

    /** Honest, hysteretic acquisition state for UI and POSE metadata. */
    val trackingStatus: StateFlow<TrackingStatus> = _trackingStatus.asStateFlow()


    private var session: Session? = null
    // Anchor is created with translation only: its axes stay aligned with the
    // ARCore gravity/world frame instead of inheriting the phone's initial grip.
    private var sessionAnchor: Anchor? = null
    private var anchorGeneration = 0
    private var activePoseMode = ArCorePoseMode.RAW
    @Volatile private var requestedPoseMode = ArCorePoseMode.RAW
    private var cameraExperiment = ArCoreCameraExperiment()
    private var glView: GLSurfaceView? = null

    @Volatile
    private var running = false

    /** Selects the Q1.1 debug experiment. Applied atomically on the GL thread. */
    fun requestPoseMode(mode: ArCorePoseMode) {
        requestedPoseMode = mode
    }

    /**
     * Select an acquisition profile only while ARCore is stopped. Deliberately
     * refusing hot reconfiguration avoids camera-driver churn and frame jumps.
     * Returns a user-facing error, or null when accepted.
     */
    fun requestCameraExperiment(experiment: ArCoreCameraExperiment): String? {
        if (running) return "leave the 6DOF viewfinder before changing camera profile"
        if (experiment.inventoryIndex != null && experiment.inventoryIndex < 0) {
            return "camera configuration index must be zero or greater"
        }
        cameraExperiment = experiment
        releaseAnchor()
        try {
            session?.close()
        } catch (_: Exception) {
            // A stopped experiment session may already have been released.
        }
        session = null
        return null
    }

    // ---- GL state (touched only on the GL thread) -------------------------
    private var textureId = 0
    private var program = 0
    private var positionAttrib = 0
    private var texCoordAttrib = 0
    private var geometryDirty = true
    private var appliedRotation = -1
    private var viewWidth = 1
    private var viewHeight = 1

    /** Fullscreen quad in NDC (triangle strip). */
    private val quadCoords: FloatBuffer = floatBufferOf(
        -1f, -1f, +1f, -1f, -1f, +1f, +1f, +1f,
    )
    private val texCoords: FloatBuffer =
        ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()

    /** The viewfinder view (create-once). Insert behind the Compose overlay. */
    fun view(context: Context): GLSurfaceView = glView ?: GLSurfaceView(context).apply {
        setEGLContextClientVersion(2)
        preserveEGLContextOnPause = true
        setRenderer(this@ArCorePipeline)
        renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        glView = this
    }

    /**
     * Creates (first time) and resumes the ARCore session. Requires the
     * CAMERA permission and ARCore installed — the caller (MainActivity)
     * gates on both before flipping the 6DOF toggle.
     */
    fun resume() {
        if (running) return
        try {
            val s = session ?: Session(activity).also { created ->
                val experiment = cameraExperiment
                val allConfigs = created.getSupportedCameraConfigs(CameraConfigFilter(created))
                telemetry?.onArCoreConfigInventory(
                    ArCoreConfigInventoryTelemetry(
                        observedNs = SystemClock.elapsedRealtimeNanos(),
                        configs = allConfigs.map { it.toTelemetry() },
                    ),
                )
                // Deterministic camera: 30 fps, no depth sensor. Avoids configs
                // that run 60 fps (hotter, worse tracking) or engage extra
                // sensors, and keeps the chosen config stable for the session.
                val selected = if (experiment.inventoryIndex != null) {
                    allConfigs.getOrNull(experiment.inventoryIndex)
                        ?: throw IllegalArgumentException(
                            "ARCore camera configuration ${experiment.inventoryIndex} is not supported",
                        )
                } else {
                    val filter = CameraConfigFilter(created)
                        .setTargetFps(java.util.EnumSet.of(CameraConfig.TargetFps.TARGET_FPS_30))
                        .setDepthSensorUsage(
                            java.util.EnumSet.of(CameraConfig.DepthSensorUsage.DO_NOT_USE),
                        )
                    created.getSupportedCameraConfigs(filter).firstOrNull()
                }
                selected?.let { created.cameraConfig = it }
                val sessionConfig = Config(created).apply {
                    // Pose is all we need: skip the scene-understanding cost.
                    planeFindingMode = Config.PlaneFindingMode.DISABLED
                    lightEstimationMode = Config.LightEstimationMode.DISABLED
                    // ARCore's own guidance: FIXED focus for tracking.
                    // Autofocus hunts, blurring the tracked features and
                    // wobbling the lens geometry — every focus/lens event
                    // risked a user-visible pose pop.
                    focusMode = when (experiment.focus) {
                        ArCoreCameraExperiment.Focus.FIXED -> Config.FocusMode.FIXED
                        ArCoreCameraExperiment.Focus.AUTO -> Config.FocusMode.AUTO
                    }
                }
                created.configure(sessionConfig)
                val active = created.cameraConfig
                telemetry?.onArCoreConfig(
                    ArCoreConfigTelemetry(
                        observedNs = SystemClock.elapsedRealtimeNanos(),
                        cameraId = active.cameraId,
                        fpsLower = active.fpsRange.lower,
                        fpsUpper = active.fpsRange.upper,
                        cpuWidth = active.imageSize.width,
                        cpuHeight = active.imageSize.height,
                        textureWidth = active.textureSize.width,
                        textureHeight = active.textureSize.height,
                        depthSensorUsage = active.depthSensorUsage.name,
                        stereoCameraUsage = active.stereoCameraUsage.name,
                        focusMode = sessionConfig.focusMode.name,
                        imageStabilization = sessionConfig.imageStabilizationMode.name,
                        inventoryIndex = allConfigs.indexOfFirst {
                            it.toTelemetry() == active.toTelemetry()
                        }.takeIf { it >= 0 },
                        experimentProfile = experiment.traceName,
                    ),
                )
                session = created
            }
            s.resume()
            running = true
            geometryDirty = true
            // Warm-up starts at the first tracked frame, not at Session.resume().
            _trackingStatus.value = policy.onTrackerStarted()
            glView?.onResume()
        } catch (e: Exception) {
            running = false
            onError(e)
        }
    }

    /** Pauses the session and the GL loop (camera is released). */
    fun pause() {
        if (!running && session == null) return
        running = false
        glView?.onPause()
        try {
            session?.pause()
        } catch (_: Exception) {
            // Pausing a dead session is not an error worth surfacing.
        }
        _trackingStatus.value = policy.onTrackerStopped()
    }

    fun destroy() {
        pause()
        releaseAnchor()
        session?.close()
        session = null
    }

    // ------------------------------------------------------------- renderer

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        val tex = IntArray(1)
        GLES20.glGenTextures(1, tex, 0)
        textureId = tex[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId)
        GLES20.glTexParameteri(
            GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR,
        )
        GLES20.glTexParameteri(
            GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR,
        )
        program = buildProgram()
        positionAttrib = GLES20.glGetAttribLocation(program, "a_Position")
        texCoordAttrib = GLES20.glGetAttribLocation(program, "a_TexCoord")
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        viewWidth = width
        viewHeight = height
        geometryDirty = true
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        val s = session ?: return
        if (!running) return

        // Recheck the rotation every frame: onSurfaceChanged misses 180°
        // flips entirely (no resize) and lags 90° changes until the resize.
        val rotation = displayRotation()
        if (geometryDirty || rotation != appliedRotation) {
            s.setDisplayGeometry(rotation, viewWidth, viewHeight)
            appliedRotation = rotation
            geometryDirty = false
        }
        s.setCameraTextureName(textureId)
        val frame = try {
            s.update()
        } catch (_: CameraNotAvailableException) {
            // Keep sending an explicit rotation-only hold. Otherwise the
            // 100 Hz network loop would repeat the last GOOD positional POSE
            // while the camera is unavailable and both UIs would lie.
            val nowNs = SystemClock.elapsedRealtimeNanos()
            applyOutcome(
                policy.onFrame(
                    SixDofFrame(
                        tracking = false,
                        failureReason = TrackingIssue.CAMERA_UNAVAILABLE.name,
                        pose = null,
                        frameTimestampNs = nowNs,
                        observedNs = nowNs,
                        sensorOrientation = orientationSource?.invoke(),
                    ),
                ),
            )
            return // transient (camera briefly held elsewhere): try next frame
        } catch (e: Exception) {
            // ARCore can throw FatalException (and friends) from update() —
            // e.g. when a record-start orientation lock perturbs the camera
            // surface. An uncaught exception on the GL thread KILLS THE
            // PROCESS (field crash, dropbox-verified). Shut 6DOF down
            // cleanly instead; the sensor pipeline takes over.
            running = false
            onError(e)
            return
        }

        if (frame.hasDisplayGeometryChanged()) {
            frame.transformCoordinates2d(
                Coordinates2d.OPENGL_NORMALIZED_DEVICE_COORDINATES, quadCoords,
                Coordinates2d.TEXTURE_NORMALIZED, texCoords,
            )
            quadCoords.rewind()
        }
        drawBackground()

        val camera = frame.camera
        val observedNs = SystemClock.elapsedRealtimeNanos()
        val trackingState = camera.trackingState
        val failureReason = camera.trackingFailureReason
        val tracking = trackingState == TrackingState.TRACKING
        val cameraPose = if (tracking) camera.pose else null
        val displayPose = if (tracking) camera.displayOrientedPose else null

        // A mode change is a pose-frame boundary. Reset both the local feed and
        // the host's offsets before the first pose in the new frame is allowed
        // through; this preserves the currently visible Blender camera.
        if (activePoseMode != requestedPoseMode) {
            activePoseMode = requestedPoseMode
            releaseAnchor()
            policy.onSelectedFrameChanged()
            client.requestFrameReset("anchor_mode")
        }

        // RAW creates no anchor at all, keeping the reference/shipping path
        // behaviorally untouched. In candidate mode a stopped anchor is not
        // replaced silently: it invalidates position instead of changing the
        // emitted frame underneath an active session.
        if (activePoseMode == ArCorePoseMode.ANCHOR_RELATIVE &&
            tracking && cameraPose != null && sessionAnchor == null
        ) {
            try {
                sessionAnchor = s.createAnchor(Pose.makeTranslation(cameraPose.translation))
                anchorGeneration += 1
            } catch (_: Exception) {
                // Anchor telemetry/experiment is non-critical to raw tracking.
                sessionAnchor = null
            }
        }

        val anchor = sessionAnchor
        val anchorState = anchor?.trackingState
        val anchorPose = if (anchorState == TrackingState.TRACKING) anchor.pose else null
        val anchorRigid = anchorPose?.toRigidPose()
        val cameraRigid = cameraPose?.toRigidPose()
        val displayRigid = displayPose?.toRigidPose()
        val relativeCamera = if (anchorRigid != null && cameraRigid != null) {
            cameraRigid.relativeTo(anchorRigid)
        } else {
            null
        }
        val relativeDisplay = if (anchorRigid != null && displayRigid != null) {
            displayRigid.relativeTo(anchorRigid)
        } else {
            null
        }
        // Camera metadata is diagnostic-only and queried only in debug builds,
        // where a telemetry sink exists. Every key is optional on Android; a
        // missing/not-yet-ready value must never disturb pose delivery.
        val cameraMetadata = if (telemetry != null) frame.cameraMetadataOrNull() else null
        val featurePoints = if (telemetry != null) frame.featurePointsOrNull() else null
        telemetry?.onArCoreFrame(
            ArCoreFrameTelemetry(
                observedNs = observedNs,
                frameNs = frame.timestamp,
                trackingState = trackingState.name,
                failureReason = failureReason.name,
                cameraQ = cameraPose?.toHamiltonQuaternion(),
                cameraP = cameraPose?.toVec3(),
                displayQ = displayPose?.toHamiltonQuaternion(),
                displayP = displayPose?.toVec3(),
                poseMode = activePoseMode.traceName,
                anchorGeneration = if (anchor != null) anchorGeneration else null,
                anchorState = anchorState?.name ?: "UNAVAILABLE",
                anchorQ = anchorRigid?.q,
                anchorP = anchorRigid?.p,
                relativeCameraQ = relativeCamera?.q,
                relativeCameraP = relativeCamera?.p,
                relativeDisplayQ = relativeDisplay?.q,
                relativeDisplayP = relativeDisplay?.p,
                afState = cameraMetadata?.afState,
                aeState = cameraMetadata?.aeState,
                focusDistanceDiopters = cameraMetadata?.focusDistanceDiopters,
                exposureTimeNs = cameraMetadata?.exposureTimeNs,
                sensitivityIso = cameraMetadata?.sensitivityIso,
                featurePoints = featurePoints?.first,
                featureConfidenceMean = featurePoints?.second,
            ),
        )
        // Frame timestamps share the elapsedRealtimeNanos time base, the same
        // domain as the sensor path — recording math stays valid. While lost,
        // the feed keeps the stream alive rotation-only (spec §4.1) so the
        // host re-anchors instead of jumping on recovery.
        val selectedPose = when (activePoseMode) {
            ArCorePoseMode.RAW -> displayRigid
            ArCorePoseMode.ANCHOR_RELATIVE -> relativeDisplay
        }
        // frame.timestamp is also the estimator's source clock; fall back to
        // arrival time if the tracker gives none, since a zero timestamp on the
        // wire is worse than a slightly late one.
        val qualityTimeNs = frame.timestamp.takeIf { it > 0L } ?: observedNs
        applyOutcome(
            policy.onFrame(
                SixDofFrame(
                    tracking = tracking,
                    failureReason = failureReason.name,
                    pose = selectedPose,
                    frameTimestampNs = qualityTimeNs,
                    observedNs = observedNs,
                    sensorOrientation = orientationSource?.invoke(),
                ),
            ),
        )
    }

    /**
     * Publish and transmit one frame's decision.
     *
     * The status is published here and nowhere else, so no future branch can skip
     * it: doing exactly that froze the phone's badge on its last value while the
     * wire stayed correct, so the host looked right and the phone lied.
     */
    private fun applyOutcome(outcome: SixDofOutcome) {
        _trackingStatus.value = outcome.status
        emitPoseUpdate(outcome.pose)
        // Coming back from a blind run changes the visual world reference. The
        // sender re-expresses it into the frame it is already emitting, so the host
        // sees no discontinuity and needs no notification. Deliberately NOT
        // requestFrameReset: that gates the pose stream until the host ACKs, and
        // tracking dips in and out constantly in a handheld shot, so paying a
        // round-trip per recovery makes the live preview hitch for nothing.
        if (outcome.crossedReferenceBoundary) {
            client.requestFrameAlignment()
        }
    }

    private fun emitPoseUpdate(update: dev.pocketrig.protocol.PoseUpdate?) {
        if (update == null) return
        // Tagged: a frame callback already in flight when 6DOF is switched off
        // must not land an ARCore-frame pose after the boundary.
        val captured = client.updatePose(
            update.q, update.timestampNs, update.pos, update.quality, update.issue,
            source = dev.pocketrig.protocol.PoseSource.ARCORE,
        ) ?: return
        tap?.invoke(
            "arcore", captured.q, captured.timestampNs, captured.pos,
            captured.quality, captured.issue, captured.focalLengthMm,
        )
    }

    private fun drawBackground() {
        texCoords.rewind()
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glUseProgram(program)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId)
        GLES20.glVertexAttribPointer(positionAttrib, 2, GLES20.GL_FLOAT, false, 0, quadCoords)
        GLES20.glVertexAttribPointer(texCoordAttrib, 2, GLES20.GL_FLOAT, false, 0, texCoords)
        GLES20.glEnableVertexAttribArray(positionAttrib)
        GLES20.glEnableVertexAttribArray(texCoordAttrib)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(positionAttrib)
        GLES20.glDisableVertexAttribArray(texCoordAttrib)
    }

    private fun releaseAnchor() {
        try {
            sessionAnchor?.detach()
        } catch (_: Exception) {
            // A closing/dead ARCore session needs no further cleanup.
        }
        sessionAnchor = null
    }

    private fun buildProgram(): Int {
        val vertex = compileShader(
            GLES20.GL_VERTEX_SHADER,
            """
            attribute vec4 a_Position;
            attribute vec2 a_TexCoord;
            varying vec2 v_TexCoord;
            void main() {
               gl_Position = a_Position;
               v_TexCoord = a_TexCoord;
            }
            """,
        )
        val fragment = compileShader(
            GLES20.GL_FRAGMENT_SHADER,
            """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            varying vec2 v_TexCoord;
            uniform samplerExternalOES sTexture;
            void main() {
                gl_FragColor = texture2D(sTexture, v_TexCoord);
            }
            """,
        )
        return GLES20.glCreateProgram().also {
            GLES20.glAttachShader(it, vertex)
            GLES20.glAttachShader(it, fragment)
            GLES20.glLinkProgram(it)
        }
    }

    private fun compileShader(type: Int, source: String): Int =
        GLES20.glCreateShader(type).also {
            GLES20.glShaderSource(it, source)
            GLES20.glCompileShader(it)
        }

    private fun displayRotation(): Int = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        activity.display?.rotation ?: Surface.ROTATION_0
    } else {
        @Suppress("DEPRECATION")
        activity.windowManager.defaultDisplay.rotation
    }

    private companion object {
        data class CameraMetadataSample(
            val afState: Int?,
            val aeState: Int?,
            val focusDistanceDiopters: Float?,
            val exposureTimeNs: Long?,
            val sensitivityIso: Int?,
        )

        /**
         * Feature-point counts for this frame, or null if unavailable.
         *
         * The point cloud is a native resource and must be released, so this is
         * acquired only when a telemetry sink is listening (debug tooling), like
         * the camera metadata below. `confidence` is the 4th float per point.
         */
        fun Frame.featurePointsOrNull(): Pair<Int, Float>? = try {
            acquirePointCloud().use { cloud ->
                val buf = cloud.points
                val total = buf.remaining() / 4
                var sum = 0.0
                var i = buf.position()
                while (i + 3 < buf.limit()) {
                    sum += buf.get(i + 3) // 4th float per point is confidence
                    i += 4
                }
                total to if (total > 0) (sum / total).toFloat() else 0f
            }
        } catch (_: NotYetAvailableException) {
            null
        } catch (_: Exception) {
            // Observational only: never let a diagnostic disturb tracking.
            null
        }

        fun Frame.cameraMetadataOrNull(): CameraMetadataSample? = try {
            val metadata = imageMetadata
            CameraMetadataSample(
                afState = metadata.byteOrNull(ImageMetadata.CONTROL_AF_STATE),
                aeState = metadata.byteOrNull(ImageMetadata.CONTROL_AE_STATE),
                focusDistanceDiopters = metadata
                    .floatOrNull(ImageMetadata.LENS_FOCUS_DISTANCE)
                    ?.takeIf { it.isFinite() },
                exposureTimeNs = metadata.longOrNull(ImageMetadata.SENSOR_EXPOSURE_TIME),
                sensitivityIso = metadata.intOrNull(ImageMetadata.SENSOR_SENSITIVITY),
            )
        } catch (_: NotYetAvailableException) {
            null
        } catch (_: Exception) {
            // Telemetry must remain observational even if a vendor returns an
            // unexpected metadata error.
            null
        }

        fun ImageMetadata.byteOrNull(key: Int): Int? = try {
            getByte(key).toInt()
        } catch (_: MetadataNotFoundException) {
            null
        }

        fun ImageMetadata.intOrNull(key: Int): Int? = try {
            getInt(key)
        } catch (_: MetadataNotFoundException) {
            null
        }

        fun ImageMetadata.longOrNull(key: Int): Long? = try {
            getLong(key)
        } catch (_: MetadataNotFoundException) {
            null
        }

        fun ImageMetadata.floatOrNull(key: Int): Float? = try {
            getFloat(key)
        } catch (_: MetadataNotFoundException) {
            null
        }

        fun com.google.ar.core.Pose.toHamiltonQuaternion(): Quaternion =
            Quaternion(qw().toDouble(), qx().toDouble(), qy().toDouble(), qz().toDouble())

        fun com.google.ar.core.Pose.toVec3(): Vec3 = Vec3(tx(), ty(), tz())

        fun com.google.ar.core.Pose.toRigidPose(): RigidPose =
            RigidPose(toHamiltonQuaternion(), toVec3())

        fun CameraConfig.toTelemetry(): ArCoreCameraConfigTelemetry =
            ArCoreCameraConfigTelemetry(
                cameraId = cameraId,
                fpsLower = fpsRange.lower,
                fpsUpper = fpsRange.upper,
                cpuWidth = imageSize.width,
                cpuHeight = imageSize.height,
                textureWidth = textureSize.width,
                textureHeight = textureSize.height,
                depthSensorUsage = depthSensorUsage.name,
                stereoCameraUsage = stereoCameraUsage.name,
            )

        fun floatBufferOf(vararg values: Float): FloatBuffer =
            ByteBuffer.allocateDirect(values.size * 4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer()
                .put(values)
                .apply { rewind() }
    }
}

/** True when this device can run ARCore at all (may improve after a check). */
fun arcoreSupported(context: Context): Boolean =
    ArCoreApk.getInstance().checkAvailability(context).isSupported
