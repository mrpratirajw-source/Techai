// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android

/**
 * Debug experiment boundary for Q1.1. RAW is the shipping reference path;
 * ANCHOR_RELATIVE may be selected through adb for paired evidence collection.
 */
internal enum class ArCorePoseMode(val traceName: String) {
    RAW("raw"),
    ANCHOR_RELATIVE("anchor_relative");

    companion object {
        fun parse(value: String?): ArCorePoseMode? = when (value?.lowercase()) {
            "raw" -> RAW
            "anchor", "anchor_relative" -> ANCHOR_RELATIVE
            else -> null
        }
    }
}
