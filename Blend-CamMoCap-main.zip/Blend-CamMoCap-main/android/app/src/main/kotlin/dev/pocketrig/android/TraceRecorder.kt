// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android

import android.content.Context
import android.os.Build
import android.os.SystemClock
import dev.pocketrig.protocol.Quaternion
import dev.pocketrig.protocol.Vec3
import java.io.BufferedWriter
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Motion Lab capture: writes acquisition, quality, timing, and protocol-pose
 * events to a versioned `.ptrace` JSONL file for `adb pull`. Debug-tooling
 * only, driven by adb broadcasts from
 * MainActivity — zero UI, the One-Button Law never sees it.
 *
 * File lands in getExternalFilesDir so no permissions are needed:
 *   /sdcard/Android/data/dev.pocketrig.android/files/trace-*.ptrace
 */
internal class TraceRecorder(private val context: Context) : TrackingTelemetry {

    private var writer: BufferedWriter? = null
    private var file: File? = null
    private val lock = Any()
    private var latestArCoreConfig: ArCoreConfigTelemetry? = null
    private var latestArCoreConfigInventory: ArCoreConfigInventoryTelemetry? = null
    private var lastTracking: Pair<String, String>? = null
    @Volatile private var acceptingSamples = false

    /** Called from the pose pipelines on their own threads. Cheap when idle. */
    fun tap(source: String, q: Quaternion, timestampNs: Long, pos: Vec3?) {
        synchronized(lock) {
            writeLineLocked(
                MotionTraceJson.pose(
                    source = source,
                    q = q,
                    sourceNs = timestampNs,
                    observedNs = SystemClock.elapsedRealtimeNanos(),
                    pos = pos,
                ),
            )
        }
    }

    override fun onArCoreConfig(config: ArCoreConfigTelemetry) {
        synchronized(lock) {
            latestArCoreConfig = config
            writeLineLocked(MotionTraceJson.arCoreConfig(config))
        }
    }

    override fun onArCoreConfigInventory(inventory: ArCoreConfigInventoryTelemetry) {
        synchronized(lock) {
            latestArCoreConfigInventory = inventory
            writeLineLocked(MotionTraceJson.arCoreConfigInventory(inventory))
        }
    }

    override fun onArCoreFrame(frame: ArCoreFrameTelemetry) {
        synchronized(lock) {
            val key = frame.trackingState to frame.failureReason
            if (key != lastTracking) {
                writeLineLocked(MotionTraceJson.tracking(frame))
                lastTracking = key
            }
            writeLineLocked(MotionTraceJson.arCoreFrame(frame))
        }
    }

    override fun onImuSample(sample: ImuSampleTelemetry) {
        if (!acceptingSamples) return
        synchronized(lock) {
            writeLineLocked(MotionTraceJson.imu(sample))
        }
    }

    /** Adds a timestamped operator cue to an active debug trace. */
    fun marker(label: String) {
        synchronized(lock) {
            writeLineLocked(
                MotionTraceJson.marker(SystemClock.elapsedRealtimeNanos(), label),
            )
        }
    }

    /** Starts a new capture file; returns its path. */
    fun start(source: String): String {
        synchronized(lock) {
            stopLocked()
            val startedNs = SystemClock.elapsedRealtimeNanos()
            val stamp = SimpleDateFormat("yyyyMMdd-HHmmss-SSS", Locale.US).format(Date())
            val f = File(context.getExternalFilesDir(null), "trace-$stamp.ptrace")
            val w = f.bufferedWriter()
            w.write(
                MotionTraceJson.header(
                    MotionTraceHeader(
                        source = source,
                        manufacturer = Build.MANUFACTURER,
                        model = Build.MODEL,
                        sdkInt = Build.VERSION.SDK_INT,
                        appId = BuildConfig.APPLICATION_ID,
                        versionName = BuildConfig.VERSION_NAME,
                        versionCode = BuildConfig.VERSION_CODE,
                        debug = BuildConfig.DEBUG,
                        startedNs = startedNs,
                    ),
                ) + "\n",
            )
            writer = w
            file = f
            acceptingSamples = true
            lastTracking = null
            if (source == "arcore") {
                writeLineLocked(
                    latestArCoreConfigInventory?.let(MotionTraceJson::arCoreConfigInventory),
                )
                writeLineLocked(latestArCoreConfig?.let(MotionTraceJson::arCoreConfig))
            }
            return f.absolutePath
        }
    }

    /** Flushes and closes the capture; returns the finished file's path. */
    fun stop(): String? {
        synchronized(lock) {
            val path = file?.absolutePath
            stopLocked()
            return path
        }
    }

    private fun stopLocked() {
        acceptingSamples = false
        try {
            writer?.flush()
            writer?.close()
        } catch (_: IOException) {
            // Diagnostics must never crash or change the tracking path.
        }
        writer = null
        file = null
        lastTracking = null
    }

    private fun writeLineLocked(line: String?) {
        val w = writer ?: return
        if (line == null) return
        try {
            w.write(line)
            w.newLine()
        } catch (_: IOException) {
            stopLocked()
        }
    }
}
