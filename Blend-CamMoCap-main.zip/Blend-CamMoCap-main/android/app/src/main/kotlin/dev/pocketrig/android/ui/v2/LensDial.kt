// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt

/** Standard focal lengths, the values that get labelled ticks on the dial. */
internal val LENS_STOPS = listOf(14, 18, 24, 28, 35, 50, 65, 85, 105, 135, 200)

private val MIN_MM = LENS_STOPS.first().toFloat()
private val MAX_MM = LENS_STOPS.last().toFloat()

/**
 * Position of a focal length on the dial, 0..1.
 *
 * Logarithmic, because equal travel should change the *angle of view* by an equal
 * ratio — that is how focal lengths read to the eye, and how every camera zoom
 * behaves. Linear would waste most of the dial between 135 and 200 mm.
 */
internal fun lensFraction(mm: Float): Float {
    val lo = ln(MIN_MM)
    val hi = ln(MAX_MM)
    return ((ln(mm.coerceIn(MIN_MM, MAX_MM)) - lo) / (hi - lo))
}

/** Inverse of [lensFraction]. */
internal fun lensFromFraction(f: Float): Float {
    val lo = ln(MIN_MM)
    val hi = ln(MAX_MM)
    return exp(lo + (hi - lo) * f.coerceIn(0f, 1f))
}

/**
 * Multiplies a focal length by a pinch scale factor.
 *
 * Pinch is inherently multiplicative and focal length is logarithmic, so a pinch
 * maps onto zoom directly with no curve fitting: spreading your fingers 20 %
 * lengthens the lens 20 %. Clamped to the dial's travel so a hard pinch cannot
 * throw the value somewhere unreachable by the dial.
 */
internal fun pinchToFocalMm(currentMm: Float, scaleFactor: Float): Float {
    if (!scaleFactor.isFinite() || scaleFactor <= 0f) return currentMm
    return (currentMm * scaleFactor).coerceIn(MIN_MM, MAX_MM)
}

/**
 * Snaps to a standard focal length when close enough to one.
 *
 * Detents are what make a camera zoom feel deliberate rather than slippery, but
 * they must not fight a operator aiming for an intermediate value — so the pull
 * is a small fraction of dial travel, not a magnet across the whole gap.
 */
internal fun snapLensMm(mm: Float, pullFraction: Float = 0.006f): Float {
    val f = lensFraction(mm)
    val nearest = LENS_STOPS.minBy { abs(lensFraction(it.toFloat()) - f) }
    return if (abs(lensFraction(nearest.toFloat()) - f) <= pullFraction) {
        nearest.toFloat()
    } else {
        mm
    }
}

/**
 * A camera-style zoom dial: a ruler that slides under a fixed centre mark.
 *
 * Deliberately not the old vertical rail. A rail with a travelling thumb tells
 * you where the thumb is; a dial that moves under a fixed index tells you where
 * *the lens* is, with the neighbouring stops visible on either side. It is also
 * how every camera app does it, so it needs no learning.
 *
 * Appears only while the lens is being adjusted — see [CameraScreenV2] — so it
 * costs no screen space at rest.
 */
@Composable
internal fun LensDial(
    focalMm: Float,
    onFocalMm: (Float) -> Unit,
    onSettled: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    // The gesture lambda is built once, so a directly captured focalMm would
    // freeze at its first value and every drag would compute from stale state.
    // That exact bug shipped in the old lens rail: it snapped back on every
    // touch and was unusable.
    val current by rememberUpdatedState(focalMm)
    // Only the numbers turn. The ruler itself stays fixed to the phone, beside
    // the shutter, exactly like every other control -- there is no longer a
    // second layout for it to have a second axis in.
    val labelRotation = contentRotationFor(LocalDeviceRotation.current)

    Column(
        modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        // No value readout here: LensZoomWidget owns it, floating above the
        // control. Drawing it in both places printed the focal length twice.
        Box(
            Modifier
                .fillMaxWidth()
                .height(46.dp)
                // Ticks are laid out well beyond the visible window, so without a
                // clip they spilled outside the pill and faded in mid-air.
                .clip(RoundedCornerShape(Rig.Radius.floating))
                .pointerInput(Unit) {
                    // Full dial travel is ~1.7 of the ruler's own length, which
                    // gives fine control without putting the ends out of reach.
                    //
                    // MINUS: ticks are drawn at (fraction - here), so a larger
                    // `here` slides them toward the origin. Adding the drag moved
                    // the ruler against the finger.
                    detectHorizontalDragGestures(
                        onDragEnd = { onFocalMm(snapLensMm(current)); onSettled() },
                        onDragCancel = { onSettled() },
                    ) { _, dragAmount ->
                        onFocalMm(
                            lensFromFraction(
                                lensFraction(current) - dragAmount / (size.width * 1.7f),
                            ),
                        )
                    }
                },
        ) {
            DialTicks(focalMm, labelRotation)
        }
    }
}

/**
 * The ruler: labelled standard stops, minor ticks between them, fixed index.
 *
 * The stops carry numbers because "50 mm" is a value a camera operator thinks
 * in — an unlabelled ruler would say only "more" and "less", which is exactly
 * the failing of the rail this replaces.
 */
@Composable
private fun DialTicks(focalMm: Float, labelRotation: Int) {
    val measurer = rememberTextMeasurer()
    Canvas(Modifier.fillMaxSize()) {
        val cx = size.width / 2f
        val span = size.width * 1.7f
        val here = lensFraction(focalMm)
        val baseline = size.height * 0.52f

        // Minor ticks first, so labelled stops draw over them. Evenly spaced in
        // dial space, which is what gives the sense of continuous travel.
        val minorCount = 60
        for (i in 0..minorCount) {
            val f = i / minorCount.toFloat()
            val x = cx + (f - here) * span
            if (x < 0f || x > size.width) continue
            drawLine(
                color = Rig.Colors.horizonGrid,
                start = Offset(x, baseline - size.height * 0.14f),
                end = Offset(x, baseline),
                strokeWidth = 1.dp.toPx(),
            )
        }

        val quarter = labelRotation == 90 || labelRotation == 270
        for (stop in LENS_STOPS) {
            val x = cx + (lensFraction(stop.toFloat()) - here) * span
            if (x < -60f || x > size.width + 60f) continue
            val near = abs(x - cx) < 6.dp.toPx()
            val color = if (near) Rig.Colors.armed else Rig.Colors.onGlassDim
            drawLine(
                color = color,
                start = Offset(x, baseline - size.height * 0.30f),
                end = Offset(x, baseline),
                strokeWidth = if (near) 2.dp.toPx() else 1.5.dp.toPx(),
                cap = StrokeCap.Round,
            )
            val laid = measurer.measure(
                text = AnnotatedString("$stop"),
                style = TextStyle(
                    color = color,
                    fontSize = 10.sp,
                    fontWeight = if (near) FontWeight.SemiBold else FontWeight.Normal,
                ),
            )
            // The label turns with everything else so it reads upright to the
            // operator, but it turns about its OWN centre, so it stays on the tick
            // it belongs to. An earlier version rotated about a shared pivot and
            // every number drifted off its mark.
            val halfW = laid.size.width / 2f
            val halfH = laid.size.height / 2f
            // Sideways, a label's footprint along the ruler is its height.
            val halfAlong = if (quarter) halfH else halfW
            // No overhang tolerance: an 8px allowance let a label start drawing
            // and then get cut by the clip, so 105 rendered as 10. A label either
            // fits whole or is not drawn.
            if (x - halfAlong < 0f || x + halfAlong > size.width) continue
            val top = baseline + 4.dp.toPx()
            rotate(degrees = labelRotation.toFloat(), pivot = Offset(x, top + halfH)) {
                drawText(laid, topLeft = Offset(x - halfW, top))
            }
        }

        // Fixed index. The lens moves under it; it does not move.
        drawLine(
            color = Rig.Colors.armed,
            start = Offset(cx, baseline - size.height * 0.44f),
            end = Offset(cx, baseline + size.height * 0.06f),
            strokeWidth = 2.5.dp.toPx(),
            cap = StrokeCap.Round,
        )
    }
}

/**
 * Pinch-to-zoom over the whole viewfinder.
 *
 * The gesture every camera app has, and the one an operator will try first. Only
 * active once the phone owns the lens — pinching must not silently seize the
 * lens from Blender, for the same reason opening the control must not (spec 4.5).
 *
 * There is no reveal callback and no end callback: the dial is always on screen,
 * so nothing needs showing, and `detectTransformGestures` offers no gesture-end
 * hook, so detent snapping stays on the dial's own drag-end where a clean release
 * edge does exist.
 */
@Composable
internal fun Modifier.lensPinch(
    focalMm: Float?,
    onFocalMm: (Float) -> Unit,
): Modifier {
    // Every value the gesture touches goes through rememberUpdatedState. The
    // gesture lambda is created once and lives for the whole composition, so a
    // directly captured focalMm would be frozen at its first value -- which is
    // precisely the bug that made the old lens rail snap back on every drag.
    // Reading the live value each frame also means accumulation is handled by
    // state rather than by a local that could drift from it.
    val current by rememberUpdatedState(focalMm)
    val emit by rememberUpdatedState(onFocalMm)
    return this.pointerInput(Unit) {
        detectTransformGestures(panZoomLock = true) { _, _, zoom, _ ->
            val now = current ?: return@detectTransformGestures
            if (zoom != 1f) emit(pinchToFocalMm(now, zoom))
        }
    }
}
