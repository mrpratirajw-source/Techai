// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android

/** Debug-only acquisition profile. It is never persisted or exposed as product UI. */
internal data class ArCoreCameraExperiment(
    val inventoryIndex: Int? = null,
    val focus: Focus = Focus.FIXED,
) {
    enum class Focus(val traceName: String) {
        FIXED("FIXED"),
        AUTO("AUTO");

        companion object {
            fun parse(value: String?): Focus? = when (value?.lowercase()) {
                null, "fixed" -> FIXED
                "auto" -> AUTO
                else -> null
            }
        }
    }

    val traceName: String
        get() = if (inventoryIndex == null) {
            "default_${focus.traceName.lowercase()}"
        } else {
            "config_${inventoryIndex}_${focus.traceName.lowercase()}"
        }
}
