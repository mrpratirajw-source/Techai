// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import dev.pocketrig.android.ui.v2.TakeRowUi
import dev.pocketrig.android.ui.v2.TakesActions
import dev.pocketrig.android.ui.v2.TakesSheetV2
import dev.pocketrig.android.ui.v2.TakesUiState
import dev.pocketrig.android.ui.v2.WorldSheetHost
import dev.pocketrig.protocol.TakeInfo

/**
 * The take library, with its state and its model mapping attached.
 *
 * [TakesSheetV2] draws; this owns. The sheet speaks [TakeRowUi] rather than the
 * protocol's [TakeInfo] deliberately: what a row needs to say is "applying this
 * moves the camera", not "this take has 412 position samples". A list built
 * straight from wire fields ends up displaying wire fields.
 */
@Composable
internal fun TakesScreen(
    takes: List<TakeInfo>,
    connected: Boolean,
    applyingId: String?,
    positionScale: Double?,
    onApply: (String) -> Unit,
    onRename: (String, String) -> Unit,
    onDelete: (String) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var expandedId by remember { mutableStateOf<String?>(null) }
    var renamingId by remember { mutableStateOf<String?>(null) }
    var renameDraft by remember { mutableStateOf("") }

    val rows = remember(takes) { takes.map(::toRow) }

    WorldSheetHost(onDismiss = onDismiss, modifier = modifier) {
        TakesSheetV2(
            state = TakesUiState(
                takes = rows,
                connected = connected,
                applyingId = applyingId,
                expandedId = expandedId,
                positionScale = positionScale?.toFloat() ?: 1f,
                renamingId = renamingId,
                renameDraft = renameDraft,
            ),
            actions = TakesActions(
                onExpand = {
                    expandedId = it
                    // Collapsing a row abandons a rename in progress rather than
                    // leaving it armed on a row nobody can see.
                    renamingId = null
                },
                onApply = { id ->
                    onDismiss()
                    onApply(id)
                },
                onRenameStart = { id ->
                    renamingId = id
                    // Seeded with the current name: renaming is almost always an
                    // edit, and starting from empty makes the operator retype a
                    // name they only wanted to adjust.
                    renameDraft = rows.firstOrNull { it.id == id }?.name.orEmpty()
                },
                onRenameDraft = { renameDraft = it },
                onRenameCommit = {
                    val id = renamingId
                    // Blank is a no-op, not a way to erase a take's name: a take
                    // called nothing at all is unfindable in the library.
                    if (id != null && renameDraft.isNotBlank()) {
                        onRename(id, renameDraft.trim())
                    }
                    renamingId = null
                },
                onRenameCancel = { renamingId = null },
                onDelete = onDelete,
                onDismiss = onDismiss,
            ),
        )
    }
}

/**
 * Wire model to row model.
 *
 * `positionSamples` is -1 when an older peer never advertised the capability, so
 * "has position" is strictly greater than zero -- treating -1 as truthy would
 * promise a camera move that the take cannot deliver.
 */
private fun toRow(t: TakeInfo) = TakeRowUi(
    id = t.id,
    name = t.name,
    durationLabel = formatDuration(t.durationS),
    hasPosition = t.positionSamples > 0,
    sent = t.sent,
)

/** m:ss, the same shape as the elapsed readout while recording. */
internal fun formatDuration(seconds: Double): String {
    val total = seconds.coerceAtLeast(0.0).toLong()
    return "%d:%02d".format(total / 60, total % 60)
}
