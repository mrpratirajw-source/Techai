// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import android.widget.Toast
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * The matte panel every control group sits on.
 *
 * Flat dark fill and a hairline edge — the housing of a field monitor, not
 * frosted glass. Deliberately unglossy: chrome that draws the eye is chrome
 * competing with the shot the operator is composing. It also means there is no
 * blur, so there is no API-31 fork and every phone renders identically.
 *
 * Its job is contrast: the backdrop is a live camera image nobody controls, and
 * the old UI's grey-on-transparent text vanished over anything bright.
 */
@Composable
internal fun ControlSurface(
    modifier: Modifier = Modifier,
    shape: RoundedCornerShape = RoundedCornerShape(Rig.Radius.grounded),
    /** Sheets are read, not looked through: see [Rig.Colors.sheetFill]. */
    opaque: Boolean = false,
    content: @Composable () -> Unit,
) {
    Box(
        modifier
            .background(
                if (opaque) Rig.Colors.sheetFill else Rig.Colors.trayFill,
                shape,
            )
            .border(1.dp, Rig.Colors.trayBorder, shape),
    ) {
        content()
    }
}

/**
 * One control in the tray: a glyph over a short label.
 *
 * A fixed-size box, not text that happens to be clickable. The old UI used bare
 * `Text` with `clickable`, so the hit area was whatever the glyphs happened to
 * measure — which is exactly how a larger system font turned neighbouring
 * controls into overlapping ones. [Rig.Touch.touchTarget] holds at every font
 * scale.
 *
 * [armed] marks a toggle that is currently ON (6DOF engaged, lens driven). It
 * tints rather than fills, so an armed control never competes with the record
 * button for attention.
 */
@Composable
internal fun TrayChip(
    label: String,
    glyph: @Composable (Color) -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    armed: Boolean = false,
    enabled: Boolean = true,
    /**
     * A bigger chip, for a screen whose dock holds only a few things.
     *
     * The landing dock has three actions where the live dock has six, so at the
     * live screen's size they sat marooned in a mostly empty slab. Scale follows
     * how much there is to do.
     */
    large: Boolean = false,
    /** Fills the chip, marking the one action a screen is mainly for. */
    filled: Boolean = false,
) {
    // A disabled chip stays readable: see Rig.Colors.onGlassDisabled. Pause is
    // locked for the whole length of a take, and "Pause" needs to still say Pause
    // rather than dissolve into the panel.
    val tint = when {
        !enabled -> Rig.Colors.onGlassDisabled
        armed -> Rig.Colors.armed
        else -> Rig.Colors.onGlass
    }
    val interaction = remember { MutableInteractionSource() }
    // The box is square and FIXED, and the content turns inside it. That is the
    // whole trick: a square has the same room along the label's reading direction
    // at every quarter turn, so nothing reflows, the chip cannot change size, and
    // the dock cannot change size with it.
    val shape = RoundedCornerShape(if (large) Rig.Radius.grounded else Rig.Radius.chip)
    Box(
        modifier
            .size(if (large) Rig.Touch.chipPrimary else Rig.Touch.chip)
            // An armed toggle gets a filled shape, not just a colour: colour
            // alone is a weak signal over a live camera image, and it is the one
            // cue a colour-blind operator may not get at all.
            .background(
                when {
                    filled -> Rig.Colors.floatFill
                    armed -> Rig.Colors.armed.copy(alpha = 0.16f)
                    else -> Color.Transparent
                },
                shape,
            )
            .then(if (filled) Modifier.border(1.dp, Rig.Colors.trayBorder, shape) else Modifier)
            .then(
                if (enabled) {
                    // No ripple: a light box flashing over the viewfinder is
                    // worse feedback than the tint change itself.
                    Modifier.clickable(
                        interactionSource = interaction,
                        indication = null,
                        onClick = onClick,
                    )
                } else {
                    Modifier
                },
            ),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.uprightInPlace(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            // Scaled rather than redrawn: the glyph set is one size by design,
            // and a 17dp mark adrift in a 92dp box reads as an accident.
            if (large) {
                Box(Modifier.scale(1.6f)) { glyph(tint) }
                Spacer(Modifier.height(Rig.Space.md))
            } else {
                glyph(tint)
            }
            Text(
                text = label,
                color = tint,
                fontSize = if (large) Rig.Type.status else Rig.Type.chipLabel,
                fontWeight = if (armed) FontWeight.SemiBold else FontWeight.Medium,
                textAlign = TextAlign.Center,
                maxLines = 1,
                // Ellipsis, so a label that outgrows its chip says so instead of
                // silently becoming a shorter, wrong word.
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 2.dp),
            )
        }
    }
}

// ------------------------------------------------------------- Status readouts

/** The coloured state dot every readout leads with. */
@Composable
internal fun Dot(color: Color) =
    Box(Modifier.size(7.dp).background(color, CircleShape))

@Composable
internal fun StatusLabel(text: String, weight: FontWeight = FontWeight.Medium) = Text(
    text = text,
    color = Rig.Colors.onGlass,
    fontSize = Rig.Type.status,
    fontWeight = weight,
    maxLines = 1,
    overflow = TextOverflow.Ellipsis,
)

/**
 * A squared readout block: coloured dot, then whatever it is reporting.
 *
 * Shared by the live screen and the landing screen deliberately. Both answer
 * "what is the link doing right now" in the same corner of the frame, and two
 * implementations of one readout is how the two screens drift into looking like
 * two apps.
 */
@Composable
internal fun StatusPill(
    dot: Color,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    ControlSurface(
        modifier.upright(),
        shape = RoundedCornerShape(Rig.Radius.badge),
    ) {
        Row(
            Modifier.padding(horizontal = Rig.Space.sm, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Dot(dot)
            Spacer(Modifier.width(Rig.Space.sm))
            content()
        }
    }
}

/**
 * One thing the instrument is reporting: a glyph, a tone, and words if needed.
 *
 * [text] is null for a state that an icon already says. That is the whole point
 * of the strip: "tracking is fine" was a pill reading "Position tracking" sitting
 * over the frame permanently, and a small green mark says the same thing without
 * covering the shot. Words are spent only on states the operator must act on.
 */
internal data class StatusItem(
    val glyph: @Composable (Color) -> Unit,
    val tone: Tone,
    val text: String? = null,
    /**
     * What this cell means, shown as a toast when it is tapped.
     *
     * Icons are compact but they are not self-explanatory, and an amber phone
     * teaches nobody anything on its own. Tapping is where the words went: the
     * full sentence AND the reason for the colour, including the numbers the
     * strip itself no longer has room to print.
     */
    val explain: String? = null,
)

internal fun Tone.color(): Color = when (this) {
    Tone.LIVE -> Rig.Colors.live
    Tone.WARN -> Rig.Colors.warn
    Tone.BAD -> Rig.Colors.bad
    Tone.NEUTRAL -> Rig.Colors.onGlassDim
}

/**
 * The instrument's readout, along the top of the dock.
 *
 * It used to be pills floating over the top-left of the frame, which put the
 * app's own chrome on top of the thing the operator was composing -- and the
 * worst offenders were the widest.
 *
 * Every cell is a SQUARE that turns in place, which is what makes the strip
 * rotation-proof: no cell reflows, so the strip cannot change height, so the dock
 * cannot change height. That constrains what may live here to a glyph and at most
 * a few characters. Anything longer -- a tracking instruction, an error -- is not
 * a readout and belongs on the frame, where [ProblemBanner] puts it.
 */
@Composable
internal fun StatusStrip(items: List<StatusItem>, modifier: Modifier = Modifier) {
    Row(
        modifier.height(Rig.Touch.statusCell),
        horizontalArrangement = Arrangement.spacedBy(Rig.Space.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val context = LocalContext.current
        for (item in items) {
            val interaction = remember(item.explain) { MutableInteractionSource() }
            Box(
                Modifier
                    .size(Rig.Touch.statusCell)
                    .then(
                        if (item.explain != null) {
                            Modifier.clickable(
                                interactionSource = interaction,
                                indication = null,
                            ) {
                                Toast.makeText(
                                    context,
                                    item.explain,
                                    Toast.LENGTH_SHORT,
                                ).show()
                            }
                        } else {
                            Modifier
                        },
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    Modifier.uprightInPlace(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    item.glyph(item.tone.color())
                    item.text?.let {
                        Text(
                            text = it,
                            color = item.tone.color(),
                            fontSize = Rig.Type.chipLabel,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
    }
}

/**
 * The one thing worth covering part of the frame for.
 *
 * Permanent status moved into the dock precisely so it would stop obstructing the
 * shot. This is the exception, and it earns it by being conditional: it appears
 * only when something needs doing about it -- tracking has degraded, a code was
 * rejected -- and it says what to do in words, which is exactly what a 36dp cell
 * cannot carry.
 */
@Composable
internal fun ProblemBanner(
    text: String,
    tone: Tone,
    modifier: Modifier = Modifier,
) {
    StatusPill(dot = tone.color(), modifier = modifier) { StatusLabel(text) }
}

/**
 * A small square toggle for the dock's readout row.
 *
 * Sized like a status cell rather than a tray chip: it belongs to the row of
 * things the instrument is reporting, not to the row of things you press
 * between shots, and it has to fit the strip's height.
 */
@Composable
internal fun StripToggle(
    glyph: @Composable (Color) -> Unit,
    description: String,
    on: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    val tint = when {
        !enabled -> Rig.Colors.onGlassDisabled
        on -> Rig.Colors.armed
        else -> Rig.Colors.onGlassDim
    }
    Box(
        Modifier
            .size(Rig.Touch.statusCell)
            .background(
                if (on) Rig.Colors.armed.copy(alpha = 0.16f) else Color.Transparent,
                RoundedCornerShape(Rig.Radius.chip),
            )
            .then(
                if (enabled) {
                    Modifier.clickable(
                        interactionSource = interaction,
                        indication = null,
                        onClick = onClick,
                    )
                } else {
                    Modifier
                },
            )
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.uprightInPlace()) { glyph(tint) }
    }
}

/** A one-shot action in the readout row. Same size as a toggle, no on state. */
@Composable
internal fun StripAction(
    glyph: @Composable (Color) -> Unit,
    description: String,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    Box(
        Modifier
            .size(Rig.Touch.statusCell)
            .then(
                if (enabled) {
                    Modifier.clickable(
                        interactionSource = interaction,
                        indication = null,
                        onClick = onClick,
                    )
                } else {
                    Modifier
                },
            )
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.uprightInPlace()) {
            glyph(if (enabled) Rig.Colors.onGlassDim else Rig.Colors.onGlassDisabled)
        }
    }
}

/**
 * The dock: same size on every screen, in every grip.
 *
 * One composable rather than three so that is true by construction. The landing,
 * offline and connected screens hold different controls, and when each wrapped
 * its own content the dock visibly resized as the app moved between them --
 * which reads as the instrument rebuilding itself rather than as one instrument
 * doing different jobs.
 */
@Composable
internal fun GroundedDock(
    status: List<StatusItem>,
    modifier: Modifier = Modifier,
    /** Sits at the readout row's start. */
    leading: (@Composable () -> Unit)? = null,
    /** Sits at the readout row's end: a toggle about the whole screen. */
    trailing: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    ControlSurface(
        modifier.fillMaxWidth().height(Rig.Touch.dock),
        // Square. A rounded dock reads as a card resting on the screen; the dock
        // is part of the instrument, and running it flush into the corners says so.
        shape = RoundedCornerShape(0.dp),
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = Rig.Space.lg, vertical = Rig.Space.md),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // The readout centred, and anything trailing pinned to the end.
            // A Box rather than a Row so the strip stays centred on the dock
            // whether or not there is a trailing control beside it.
            Box(Modifier.fillMaxWidth()) {
                StatusStrip(status, Modifier.align(Alignment.Center))
                leading?.let {
                    Box(Modifier.align(Alignment.CenterStart)) { it() }
                }
                trailing?.let {
                    Box(Modifier.align(Alignment.CenterEnd)) { it() }
                }
            }
            Spacer(Modifier.height(Rig.Space.xs))
            // Centred in whatever is left, so a caption appearing under the
            // record button cannot shove the rows around.
            Column(
                Modifier.fillMaxWidth().weight(1f),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
                content = content,
            )
        }
    }
}

/**
 * A sheet, standing upright in the world rather than on the phone.
 *
 * Everything else in the UI is pinned to the device and only its content turns.
 * Sheets are the exception, and have to be: they carry paragraphs, and a
 * paragraph rotated glyph-by-glyph is unreadable. So the whole panel turns and
 * anchors to the bottom of what the operator is actually looking at.
 *
 * Inside, the rotation is reset to zero. Controls in here have already been
 * turned by the panel around them, and would otherwise turn twice.
 */
@Composable
internal fun WorldSheetHost(
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val device = LocalDeviceRotation.current
    val interaction = remember { MutableInteractionSource() }
    Box(
        modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f))
            .clickable(
                interactionSource = interaction,
                indication = null,
                onClick = onDismiss,
            ),
        contentAlignment = worldBottomAlignment(device),
    ) {
        Box(Modifier.upright()) {
            CompositionLocalProvider(LocalDeviceRotation provides 0) {
                // Capped against the WORLD's height, which is this box's own
                // constraint after the turn -- not the screen's height, which is
                // the phone's long edge and means something different depending
                // on how it is held.
                BoxWithConstraints(contentAlignment = Alignment.BottomCenter) {
                    Box(
                        Modifier
                            .heightIn(max = maxHeight * 0.82f)
                            // Capped WIDTH too, which only bites when the world is
                            // wide -- a sheet spanning a sideways phone puts its
                            // controls a hand-span apart and reads as a page, not
                            // a sheet. In portrait the cap is above the screen
                            // width and does nothing, so a bottom sheet still runs
                            // edge to edge where that is right.
                            .widthIn(max = 520.dp),
                    ) { content() }
                }
            }
        }
    }
}

// ------------------------------------------------------------------- Landmarks

/**
 * The one fixed landmark in the app.
 *
 * It changes appearance between idle and recording but never position, so the
 * operator's thumb can find it without looking. Disabled reads visibly different
 * from armed: the old button rendered as a pressable stop square that silently
 * ignored taps.
 *
 * Lives here rather than on the live screen because the landing screen has a
 * record button too — offline recording starts before there is any Blender to
 * talk to. Two drawings of the same landmark would be two landmarks.
 */
@Composable
internal fun RecordButtonV2(
    recording: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interaction = remember { MutableInteractionSource() }
    val fill = if (enabled) Rig.Colors.record else Rig.Colors.record.copy(alpha = 0.30f)
    Box(
        modifier
            .size(Rig.Touch.recordButton)
            .border(
                width = 2.dp,
                color = Color.White.copy(alpha = if (enabled) 0.92f else 0.35f),
                shape = CircleShape,
            )
            .clickable(
                interactionSource = interaction,
                indication = null,
                enabled = enabled,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .size(if (recording) 26.dp else 50.dp)
                .background(
                    fill,
                    if (recording) RoundedCornerShape(5.dp) else CircleShape,
                ),
        )
    }
}

/**
 * A committing action, filled so it reads as the one thing to press.
 *
 * Material's Button brings its own elevation, ripple and colour roles, none of
 * which match the rest of this UI — the same reason the Adjust sheet draws its
 * own slider. Dark text on the armed blue, so it inverts the way a filled
 * segment does.
 */
@Composable
internal fun RigButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    val interaction = remember { MutableInteractionSource() }
    Box(
        modifier
            .defaultMinSize(minHeight = 42.dp)
            .background(
                if (enabled) Rig.Colors.armed else Rig.Colors.armedDisabled,
                RoundedCornerShape(Rig.Radius.chip),
            )
            .clickable(
                interactionSource = interaction,
                indication = null,
                enabled = enabled,
                onClick = onClick,
            )
            .padding(horizontal = Rig.Space.lg, vertical = Rig.Space.sm),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            // Dark on the fill, the same inversion the segmented switch uses.
            color = if (enabled) Color(0xFF06121F) else Rig.Colors.onGlass,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

// ---------------------------------------------------------- Sheet furniture

/** Drag affordance. A sheet is dismissible by dragging, so it must look it. */
@Composable
internal fun SheetHandle() = Box(Modifier.fillMaxWidth(), Alignment.Center) {
    Box(
        Modifier
            .width(36.dp)
            .height(4.dp)
            .background(Rig.Colors.onGlassDim.copy(alpha = 0.5f), CircleShape),
    )
}

@Composable
internal fun SectionLabel(text: String) = Text(
    text = text.uppercase(),
    color = Rig.Colors.onGlassDim,
    fontSize = 10.sp,
    fontWeight = FontWeight.SemiBold,
    letterSpacing = 1.2.sp,
)

@Composable
internal fun Note(text: String) = Text(
    text = text,
    color = Rig.Colors.onGlassDim,
    fontSize = 11.5.sp,
    lineHeight = 15.sp,
)

/**
 * A labelled text field in the app's own language.
 *
 * Material's OutlinedTextField carries a floating label, its own focus colours
 * and a container the rest of this UI does not use anywhere. The field is a
 * labelled box with a caret in it, so it is built from the same pieces as
 * everything else: the segment track as fill, the tray hairline as its edge.
 */
@Composable
internal fun RigField(
    value: String,
    onValue: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    /**
     * Null when the surrounding section already names the field.
     *
     * Two fields in one sheet need telling apart, so Address and Code carry
     * labels. A lone field under a heading that already says "Take name" would
     * print the words twice.
     */
    label: String? = null,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
) {
    val shape = RoundedCornerShape(Rig.Radius.chip)
    Column(modifier) {
        if (label != null) {
            SectionLabel(label)
            Spacer(Modifier.height(Rig.Space.xs))
        }
        Box(
            Modifier
                .fillMaxWidth()
                .defaultMinSize(minHeight = Rig.Touch.touchTarget)
                .background(Rig.Colors.segmentTrack, shape)
                .border(1.dp, Rig.Colors.trayBorder, shape)
                .padding(horizontal = Rig.Space.md, vertical = Rig.Space.md),
            contentAlignment = Alignment.CenterStart,
        ) {
            // The placeholder sits behind the field rather than inside it, so an
            // empty field still shows the shape of what it wants.
            if (value.isEmpty()) {
                Text(
                    text = placeholder,
                    color = Rig.Colors.onGlassDisabled,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            BasicTextField(
                value = value,
                onValueChange = onValue,
                textStyle = TextStyle(color = Rig.Colors.onGlass, fontSize = 14.sp),
                cursorBrush = SolidColor(Rig.Colors.armed),
                singleLine = true,
                keyboardOptions = keyboardOptions,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}
