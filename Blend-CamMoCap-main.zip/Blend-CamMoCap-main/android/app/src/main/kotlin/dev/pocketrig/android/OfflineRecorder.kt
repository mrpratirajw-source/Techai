// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android

import android.content.Context
import dev.pocketrig.protocol.PoseUpdate
import dev.pocketrig.protocol.appendTakeRow
import dev.pocketrig.protocol.encodeTakeHeader
import dev.pocketrig.protocol.Quaternion
import dev.pocketrig.protocol.ConnectedTakeStore
import dev.pocketrig.protocol.TakeInfo
import dev.pocketrig.protocol.TakeUploadSource
import dev.pocketrig.protocol.TrackingIssue
import dev.pocketrig.protocol.TrackingQuality
import dev.pocketrig.protocol.Vec3
import java.io.BufferedWriter
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import org.json.JSONObject

/** A take parsed back from disk, ready to upload (spec §5.10 / §5.11). */
data class ParsedTake(
    val startNs: Long,
    val endNs: Long,
    val name: String,
    val source: String,
    val samples: List<PoseUpdate>,
)

/**
 * Records takes to `.take` files on disk (spec §5.10 format) and owns the take
 * library the user browses on the phone and Blender browses over §5.11. Rows
 * stream to disk as they arrive (a crash mid-take still leaves a valid file);
 * `stop()` finalizes the header with end_ns / sample_count so the library reads
 * only the first line. Delivery is tracked in prefs (an id set), so a take
 * stays browsable and re-uploadable after being sent.
 */
class OfflineRecorder(context: Context) : ConnectedTakeStore {

    private val dir = File(context.getExternalFilesDir(null), "offline_takes").apply { mkdirs() }
    private val prefs = context.getSharedPreferences("pocketrig_takes", Context.MODE_PRIVATE)
    private data class MotionStamp(val length: Long, val modified: Long, val positions: Int)
    private val motionCache = HashMap<String, MotionStamp>()
    private val lock = Any()

    private var writer: BufferedWriter? = null
    private var partialFile: File? = null
    private var finalFile: File? = null
    private var transactionId: String? = null
    private var takeName = ""
    private var takeSource = "sensor"
    private var startNs = 0L
    private var lastNs = 0L
    private var count = 0
    private var positionCount = 0

    init {
        migrateLegacyConnectedTakes()
        recoverInterruptedTakes()
    }

    val isRecording: Boolean get() = writer != null


    /** Opens a new take. [name] is the user's label (blank -> auto). */
    fun start(source: String, startNs: Long, name: String): Boolean {
        val id = "take-${UUID.randomUUID()}.take"
        return startInternal(source, startNs, name, id, transactionId = null)
    }

    private fun startInternal(
        source: String,
        startNs: Long,
        name: String,
        id: String,
        transactionId: String?,
    ): Boolean {
        synchronized(lock) {
            if (writer != null) return false
            val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
            val f = safeTakeFile(id) ?: return false
            val partial = File(dir, "${f.name}.partial")
            takeName = name.ifBlank { "Take $stamp" }
            takeSource = source
            this.startNs = startNs
            lastNs = startNs
            this.transactionId = transactionId
            count = 0
            positionCount = 0
            val w = partial.bufferedWriter()
            w.write(
                header(
                    source, takeName, startNs, endNs = null, count = null,
                    transactionId = transactionId,
                ),
            )
            w.flush()
            writer = w
            partialFile = partial
            finalFile = f
            return true
        }
    }

    /**
     * The SAME header writer the upload body uses -- this was a second
     * hand-written copy, the structure that already cost a recorded zoom in the
     * row format. `token`/`id` are upload-only and stay null here.
     */
    private fun header(
        source: String,
        name: String,
        startNs: Long,
        endNs: Long?,
        count: Int?,
        positionCount: Int? = null,
        transactionId: String? = null,
    ): String = encodeTakeHeader(
        startNs = startNs,
        endNs = endNs,
        sampleCount = count,
        token = null,
        name = name,
        source = source,
        transactionId = transactionId,
        positionCount = positionCount,
    ).decodeToString()

    /** Appends one sample. Cheap no-op when not recording (pipeline tap). */
    fun capture(
        q: Quaternion,
        timestampNs: Long,
        pos: Vec3?,
        quality: TrackingQuality = TrackingQuality.UNKNOWN,
        issue: TrackingIssue = TrackingIssue.NONE,
        focalLengthMm: Float = 0f,
    ) {
        synchronized(lock) {
            val w = writer ?: return
            // The SAME row writer the upload body uses. This was a second
            // hand-written copy of the format and the two drifted: focal length
            // was added there and missed here, so a recorded zoom reached the
            // wire but never the file that actually becomes the take.
            val sb = StringBuilder(120)
            appendTakeRow(
                sb,
                PoseUpdate(q, timestampNs, pos, quality, issue, focalLengthMm),
            )
            w.write(sb.toString())
            count++
            if (pos != null && (quality == TrackingQuality.UNKNOWN || quality == TrackingQuality.GOOD)) {
                positionCount++
            }
            lastNs = timestampNs
            if (count % 30 == 0) w.flush()
        }
    }

    /** Closes and finalizes the take; returns its file (null if empty). */
    fun stop(endNs: Long): File? {
        synchronized(lock) {
            val w = writer ?: return null
            w.flush()
            w.close()
            val partial = partialFile
            val destination = finalFile
            writer = null
            partialFile = null
            finalFile = null
            if (partial == null || destination == null || count == 0) {
                partial?.delete()
                transactionId = null
                return null
            }
            val finalized = finalizePartial(
                partial,
                destination,
                takeSource,
                takeName,
                startNs,
                endNs,
                count,
                positionCount,
                transactionId,
            )
            transactionId = null
            return if (finalized) destination else null
        }
    }

    override fun beginConnectedTake(
        takeId: String,
        startNs: Long,
        source: String,
    ): Boolean = startInternal(
        source = source,
        startNs = startNs,
        name = "",
        id = "take-$takeId.take",
        transactionId = takeId,
    )

    override fun finishConnectedTake(takeId: String, endNs: Long): TakeUploadSource? {
        synchronized(lock) {
            if (transactionId != takeId) return null
        }
        val f = stop(endNs) ?: return null
        return uploadSource(f.name)
    }

    override fun abortConnectedTake(takeId: String): TakeUploadSource? {
        synchronized(lock) {
            if (transactionId != takeId) return null
        }
        val f = stop(lastNs) ?: return null
        return uploadSource(f.name)
    }

    private fun safeTakeFile(id: String): File? {
        if (!id.endsWith(".take") || id != File(id).name) return null
        return File(dir, id)
    }

    private fun finalizePartial(
        partial: File,
        destination: File,
        source: String,
        name: String,
        startNs: Long,
        endNs: Long,
        count: Int,
        positionCount: Int,
        transactionId: String?,
    ): Boolean = runCatching {
        val tmp = File(dir, ".${destination.name}.${UUID.randomUUID()}.tmp")
        FileOutputStream(tmp).use { stream ->
            val out = BufferedWriter(OutputStreamWriter(stream, Charsets.UTF_8))
            partial.bufferedReader().use { input ->
                input.readLine() // replace the incomplete header
                out.write(
                    header(
                        source, name, startNs, endNs, count,
                        positionCount = positionCount,
                        transactionId = transactionId,
                    ),
                )
                while (true) {
                    val row = input.readLine() ?: break
                    if (row.isNotBlank()) {
                        out.write(row)
                        out.write("\n")
                    }
                }
            }
            out.flush()
            stream.fd.sync()
        }
        try {
            Files.move(
                tmp.toPath(), destination.toPath(),
                StandardCopyOption.ATOMIC_MOVE,
                StandardCopyOption.REPLACE_EXISTING,
            )
        } catch (_: AtomicMoveNotSupportedException) {
            Files.move(
                tmp.toPath(), destination.toPath(),
                StandardCopyOption.REPLACE_EXISTING,
            )
        }
        partial.delete()
    }.isSuccess

    /** Recover flushed rows from a process/session interruption. */
    private fun recoverInterruptedTakes() {
        val partials = dir.listFiles { f -> f.name.endsWith(".take.partial") }
            ?: return
        for (partial in partials) {
            runCatching {
                val first = partial.bufferedReader().use { it.readLine() } ?: return@runCatching
                val h = JSONObject(first)
                var rows = 0
                var positions = 0
                var last = h.optLong("start_ns", 0L)
                partial.bufferedReader().use { input ->
                    input.readLine()
                    while (true) {
                        val line = input.readLine() ?: break
                        if (line.isBlank()) continue
                        val row = JSONObject(line)
                        last = row.getLong("t")
                        val quality = row.optString("quality", "unknown")
                        if (row.has("p") && (quality == "unknown" || quality == "good")) {
                            positions++
                        }
                        rows++
                    }
                }
                if (rows == 0) return@runCatching
                val destination = safeTakeFile(partial.name.removeSuffix(".partial"))
                    ?: return@runCatching
                finalizePartial(
                    partial = partial,
                    destination = destination,
                    source = h.optString("source", "sensor"),
                    name = h.optString("name", destination.name),
                    startNs = h.optLong("start_ns", last),
                    endNs = last,
                    count = rows,
                    positionCount = positions,
                    transactionId = if (h.has("take_id")) h.getString("take_id") else null,
                )
            }
        }
    }

    /** Older builds saved connected takes beside, rather than inside, the
     * browsable library. Move those valid files forward without overwriting. */
    private fun migrateLegacyConnectedTakes() {
        val root = dir.parentFile ?: return
        val legacy = root.listFiles { f -> f.isFile && f.name.endsWith(".take") }
            ?: return
        for (old in legacy) {
            runCatching {
                val original = safeTakeFile(old.name) ?: return@runCatching
                val destination = if (!original.exists()) {
                    original
                } else {
                    File(dir, "take-${UUID.randomUUID()}.take")
                }
                Files.move(old.toPath(), destination.toPath())
            }
        }
    }

    fun uploadSource(id: String): TakeUploadSource? = runCatching {
        val f = safeTakeFile(id)?.takeIf { it.isFile } ?: return null
        val h = JSONObject(f.bufferedReader().use { it.readLine() ?: return null })
        TakeUploadSource(
            id = f.name,
            name = h.optString("name", f.name),
            source = h.optString("source", "sensor"),
            startNs = h.getLong("start_ns"),
            endNs = h.getLong("end_ns"),
            sampleCount = h.getInt("sample_count"),
            byteCount = f.length(),
            openFile = { f.inputStream() },
        )
    }.getOrNull()

    // ----------------------------------------------------------- library

    private fun sentIds(): MutableSet<String> =
        prefs.getStringSet("sent", emptySet())!!.toMutableSet()

    fun markSent(id: String) {
        prefs.edit().putStringSet("sent", sentIds().apply { add(id) }).apply()
    }

    private fun files(): List<File> =
        (dir.listFiles { f -> f.name.endsWith(".take") } ?: emptyArray())
            .sortedByDescending { it.lastModified() }

    fun count(): Int = files().size

    /** The library as TakeInfo (spec §5.11). Motion capability is cached after
     * the first row scan; ordinary refreshes only read headers. */
    fun library(): List<TakeInfo> {
        val sent = sentIds()
        return files().mapNotNull { f ->
            runCatching {
                val h = JSONObject(f.bufferedReader().use { it.readLine() ?: "{}" })
                val start = h.optLong("start_ns", 0)
                val end = h.optLong("end_ns", start)
                TakeInfo(
                    id = f.name,
                    name = h.optString("name", f.name),
                    durationS = (end - start).coerceAtLeast(0) / 1e9,
                    source = h.optString("source", "sensor"),
                    samples = h.optInt("sample_count", 0),
                    sent = f.name in sent,
                    positionSamples = if (h.has("position_samples")) {
                        h.optInt("position_samples", 0)
                    } else {
                        validPositionSamples(f)
                    },
                )
            }.getOrNull()
        }
    }

    /** Determine capability from actual rows, not the historical source label.
     * Old builds could label an ARCore file "sensor" when Record was tapped
     * during a temporary quality hold even though position rows were present. */
    private fun validPositionSamples(f: File): Int {
        val cached = motionCache[f.name]
        if (cached != null && cached.length == f.length() && cached.modified == f.lastModified()) {
            return cached.positions
        }
        val positions = runCatching {
            var count = 0
            f.bufferedReader().use { input ->
                input.readLine() // header
                while (true) {
                    val line = input.readLine() ?: break
                    if (line.isBlank()) continue
                    val row = JSONObject(line)
                    val quality = row.optString("quality", "unknown")
                    if (row.has("p") && (quality == "unknown" || quality == "good")) count++
                }
            }
            count
        }.getOrDefault(0)
        motionCache[f.name] = MotionStamp(f.length(), f.lastModified(), positions)
        return positions
    }

    fun rename(id: String, newName: String): Boolean = synchronized(lock) {
        val f = safeTakeFile(id)?.takeIf { it.isFile } ?: return false
        runCatching {
            val tmp = File(dir, ".${f.name}.${UUID.randomUUID()}.tmp")
            val h = JSONObject(f.bufferedReader().use { it.readLine() ?: return false })
            h.put("name", newName)
            FileOutputStream(tmp).use { stream ->
                val out = BufferedWriter(OutputStreamWriter(stream, Charsets.UTF_8))
                f.bufferedReader().use { input ->
                    input.readLine()
                    out.write(h.toString()); out.write("\n")
                    while (true) {
                        val row = input.readLine() ?: break
                        out.write(row); out.write("\n")
                    }
                }
                out.flush()
                stream.fd.sync()
            }
            try {
                Files.move(
                    tmp.toPath(), f.toPath(), StandardCopyOption.ATOMIC_MOVE,
                    StandardCopyOption.REPLACE_EXISTING,
                )
            } catch (_: AtomicMoveNotSupportedException) {
                Files.move(tmp.toPath(), f.toPath(), StandardCopyOption.REPLACE_EXISTING)
            }
        }.isSuccess
    }

    fun delete(id: String): Boolean {
        prefs.edit().putStringSet("sent", sentIds().apply { remove(id) }).apply()
        motionCache.remove(id)
        return safeTakeFile(id)?.delete() == true
    }

    /** Reads a take back into samples for upload (by library id / filename). */
    fun parse(id: String): ParsedTake? = runCatching {
        val f = safeTakeFile(id)?.takeIf { it.isFile } ?: return null
        val samples = ArrayList<PoseUpdate>()
        var firstT = Long.MAX_VALUE
        var lastT = Long.MIN_VALUE
        lateinit var header: JSONObject
        f.bufferedReader().use { input ->
            header = JSONObject(input.readLine() ?: return null)
            while (true) {
                val line = input.readLine() ?: break
                if (line.isBlank()) continue
                val row = JSONObject(line)
                val t = row.getLong("t")
                val q = row.getJSONArray("q")
                val p = if (row.has("p")) row.getJSONArray("p") else null
                samples.add(
                    PoseUpdate(
                        Quaternion(q.getDouble(0), q.getDouble(1), q.getDouble(2), q.getDouble(3)),
                        t,
                        p?.let { Vec3(it.getDouble(0).toFloat(), it.getDouble(1).toFloat(), it.getDouble(2).toFloat()) },
                        TrackingQuality.fromWireName(
                            if (row.has("quality")) row.getString("quality") else null,
                        ),
                        TrackingIssue.fromWireName(
                            if (row.has("issue")) row.getString("issue") else null,
                        ),
                        if (row.has("f")) row.getDouble("f").toFloat() else 0f,
                    ),
                )
                if (t < firstT) firstT = t
                if (t > lastT) lastT = t
            }
        }
        if (samples.isEmpty()) return null
        ParsedTake(
            startNs = if (header.has("start_ns")) header.getLong("start_ns") else firstT,
            endNs = if (header.has("end_ns")) header.getLong("end_ns") else lastT,
            name = header.optString("name", id),
            source = header.optString("source", "sensor"),
            samples = samples,
        )
    }.getOrNull()
}
