// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

import dev.pocketrig.protocol.Quaternion
import kotlin.math.asin
import kotlin.math.atan2

/**
 * Roll and pitch of the camera, from the pose it is already sending.
 *
 * Extracted as a pure function so the horizon can be verified without a phone,
 * a screen, or a render. The indicator itself was designed and reviewed long
 * before this existed; what was missing was any way to get real numbers into it,
 * and guessing at Euler conventions in the middle of a composable is how a
 * horizon ends up confidently level while the phone is tilted.
 *
 * Conventions, per spec §3: the protocol camera frame is +X right, +Y up, −Z
 * forward, and the protocol world is Z-up. [q] rotates camera-space vectors into
 * world space.
 *
 * - **pitch** is the elevation of the forward axis. Positive means aimed above
 *   the horizon, which is the direction an operator would call "up".
 * - **roll** is rotation about the forward axis. Positive means the right-hand
 *   side of the frame has dropped, so the drawn horizon tilts the way the phone
 *   physically tilted rather than mirroring it.
 *
 * Returns null for a non-finite or degenerate quaternion. That matters: the
 * horizon draws nothing for null, and drawing a level line from a bad pose would
 * be a confident lie about the one thing this indicator exists to report.
 */
internal fun attitudeOf(q: Quaternion): Attitude? {
    val n = q.w * q.w + q.x * q.x + q.y * q.y + q.z * q.z
    if (!n.isFinite() || n < 1e-9) return null

    val forward = rotate(q, 0.0, 0.0, -1.0)
    val up = rotate(q, 0.0, 1.0, 0.0)
    val right = rotate(q, 1.0, 0.0, 0.0)

    val pitch = Math.toDegrees(asin(forward.third.coerceIn(-1.0, 1.0)))
    // atan2 of the world-Z components of right and up: level gives (0, 1) and so
    // zero, and it stays well-conditioned looking straight up or down, which a
    // naive Euler decomposition does not.
    val roll = -Math.toDegrees(atan2(right.third, up.third))

    if (!pitch.isFinite() || !roll.isFinite()) return null
    return Attitude(rollDeg = roll.toFloat(), pitchDeg = pitch.toFloat())
}

/** v' = q v q*, on a normalised copy so an unnormalised pose cannot scale it. */
private fun rotate(
    q: Quaternion,
    vx: Double,
    vy: Double,
    vz: Double,
): Triple<Double, Double, Double> {
    val n = kotlin.math.sqrt(q.w * q.w + q.x * q.x + q.y * q.y + q.z * q.z)
    val w = q.w / n
    val x = q.x / n
    val y = q.y / n
    val z = q.z / n

    // t = 2 * (qv × v), then v' = v + w*t + qv × t
    val tx = 2.0 * (y * vz - z * vy)
    val ty = 2.0 * (z * vx - x * vz)
    val tz = 2.0 * (x * vy - y * vx)
    return Triple(
        vx + w * tx + (y * tz - z * ty),
        vy + w * ty + (z * tx - x * tz),
        vz + w * tz + (x * ty - y * tx),
    )
}
