// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * A two-or-more-way mode switch, one segment filled.
 *
 * Used for tracking mode (rotation vs 6DOF), which is a **mode**, not a setting:
 * it changes what the app does, the way photo-vs-video does in a camera app, and
 * it gets switched between shots rather than configured once.
 *
 * A segmented switch rather than a single toggle for a specific reason: a lone
 * "6DOF" chip shows its own state but never says what the alternative is, so an
 * operator cannot tell what tapping it would do. Both labels visible means the
 * current mode and the available one are always legible at a glance.
 *
 * Deliberately not put inside the Adjust sheet. Adjust locks while recording, and
 * a mode that gets changed between takes must not live behind a lock.
 */
@Composable
internal fun SegmentedToggle(
    /**
     * One glyph per segment. Icons rather than words: "Rotation" and "6DOF" set
     * in a readable size made the pill wider than the record button and pulled
     * the eye away from it. A mode switch has to be legible, not loud.
     */
    options: List<@Composable (Color) -> Unit>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    val segments: List<@Composable () -> Unit> = options.mapIndexed { i, icon ->
        {
            val active = i == selectedIndex
            val interaction = remember(i) { MutableInteractionSource() }
            Box(
                Modifier
                    .defaultMinSize(minWidth = 34.dp, minHeight = 32.dp)
                    .background(
                        when {
                            active && enabled -> Rig.Colors.armed
                            // Locked but still filled: which mode is selected is
                            // information the operator needs during a take, and
                            // it was fading almost to nothing.
                            active -> Rig.Colors.armedDisabled
                            else -> Color.Transparent
                        },
                        RoundedCornerShape(Rig.Radius.floating),
                    )
                    .then(
                        if (enabled && !active) {
                            Modifier.clickable(
                                interactionSource = interaction,
                                indication = null,
                            ) { onSelect(i) }
                        } else {
                            Modifier
                        },
                    )
                    .padding(horizontal = Rig.Space.xs, vertical = Rig.Space.xs),
                contentAlignment = Alignment.Center,
            ) {
                // Dark glyph on the filled segment: the fill is the signal, so
                // the icon has to invert with it rather than stay light and lose
                // contrast against its own highlight.
                icon(
                    when {
                        // On the filled segment the glyph inverts to dark, and
                        // stays dark when locked -- a muted fill still needs dark
                        // content on it, not a ghost.
                        active && enabled -> Color(0xFF06121F)
                        active -> Rig.Colors.onGlass
                        enabled -> Rig.Colors.onGlass
                        else -> Rig.Colors.onGlassDisabled
                    },
                )
            }
        }
    }

    Box(
        // Deliberately NOT upright(): a rotation arrow and a cube read the same
        // at any angle, and turning the pill restacked it into a column that
        // changed the dock's shape for no gain.
        modifier.background(
            Rig.Colors.segmentTrack,
            RoundedCornerShape(Rig.Radius.floating),
        ),
    ) {
        // Always a row. See TrackingModeToggle for why there is no stacked form.
        Row(
            Modifier.padding(2.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) { segments.forEach { it() } }
    }
}
