// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

import android.hardware.SensorManager
import android.view.OrientationEventListener
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Constraints

/**
 * How the phone is being held, in degrees clockwise from its natural portrait.
 *
 * **The layout never changes; only content turns.** The app is pinned to portrait
 * so the dock is always on the phone's bottom edge and the record button never
 * moves an inch, whichever way the phone is held. What rotates is the content of
 * each control, so labels and glyphs stay upright to the operator.
 *
 * That replaces a responsive landscape layout whose dock was pinned to the
 * *screen's* end edge rather than to the phone. Turn the phone one way and Adjust
 * and Takes landed on their correct physical corners; turn it the other way and
 * the whole dock moved to the opposite edge of the device and the corners
 * mirrored. Position that depends on which direction you turned is position
 * nobody can learn.
 *
 * It also replaces the Orientation setting, which offered "Locked / Portrait /
 * Landscape" as though it affected the shot. It never did -- it is phone-local
 * and never reaches the protocol -- and it was disabled mid-take, which is the
 * one moment a lock is actually wanted. Freezing rotation while recording gives
 * that for free and needs no control at all.
 */
internal val LocalDeviceRotation = compositionLocalOf { 0 }

/**
 * Snap a continuous device angle to one of the four uprights, with hysteresis.
 *
 * [angleDeg] is [OrientationEventListener]'s reading: 0 when the phone is in its
 * natural position and increasing clockwise, or negative when it cannot tell
 * (lying flat, which is exactly when a naive nearest-quadrant rule flaps between
 * two answers several times a second).
 *
 * The margin is what stops that flapping. A quadrant is only left once the phone
 * is [marginDeg] PAST the halfway point, so an operator holding the phone near 45
 * degrees gets one stable answer rather than a strobing UI.
 */
internal fun quantizeDeviceRotation(
    angleDeg: Int,
    current: Int,
    marginDeg: Int = 15,
): Int {
    // Unknown: keep whatever we had. Returning 0 here would snap the UI upright
    // every time the phone was laid on a table.
    if (angleDeg < 0) return current
    val nearest = (((angleDeg + 45) / 90) % 4) * 90
    if (nearest == current) return current
    return if (angularDistanceDeg(angleDeg, current) > 45 + marginDeg) nearest else current
}

/** Shortest angle between two bearings, 0..180. */
internal fun angularDistanceDeg(a: Int, b: Int): Int {
    val d = ((a - b) % 360 + 360) % 360
    return if (d > 180) 360 - d else d
}

/** Degrees content must turn to stay upright while the phone is at [deviceRotation]. */
internal fun contentRotationFor(deviceRotation: Int): Int =
    ((360 - deviceRotation) % 360 + 360) % 360

/**
 * Roll to *draw*, once the way the phone is held is accounted for.
 *
 * [attitudeOf] reports roll about the camera's forward axis, so simply holding
 * the phone sideways is a 90 degree roll -- true, and useless as an instrument:
 * a level shot would draw a vertical "horizon". Subtracting how the phone is held
 * makes the line answer the question the operator is actually asking, which is
 * whether the SHOT is level, not whether the phone is.
 */
internal fun displayRollDeg(rollDeg: Float, deviceRotation: Int): Float {
    val d = (rollDeg - deviceRotation) % 360f
    return when {
        d > 180f -> d - 360f
        d <= -180f -> d + 360f
        else -> d
    }
}

/**
 * Where the world's bottom edge is, in the phone's own coordinates.
 *
 * Used to anchor sheets. Everything else is pinned to the device and stays put,
 * but a sheet full of paragraphs has to rise from the bottom of what the operator
 * sees, or it arrives sideways.
 */
internal fun worldBottomAlignment(deviceRotation: Int): Alignment =
    when (((deviceRotation % 360) + 360) % 360) {
        90 -> Alignment.CenterEnd
        180 -> Alignment.TopCenter
        270 -> Alignment.CenterStart
        else -> Alignment.BottomCenter
    }

/**
 * The shot's rotation, given the lock and how the phone is actually held.
 *
 * A lock constrains the AXIS, not the quarter turn. Both portrait and landscape
 * have two grips a hundred and eighty degrees apart, and pinning "landscape" to
 * one of them made the setting demand the phone be flipped end for end to match
 * a choice the operator never made. Which of the two is nobody's business but
 * the person holding it -- a phone gets turned the other way for cable
 * clearance, for a strap, or because that is the hand that is free.
 *
 * So a lock picks whichever of its two rotations the phone is nearest. It still
 * does the job it exists for: portrait cannot become landscape mid-shot.
 */
internal fun shotRotationFor(mode: String, deviceRotation: Int): Int {
    val d = ((deviceRotation % 360) + 360) % 360
    return when (mode) {
        "portrait" -> nearerOf(d, 0, 180)
        "landscape" -> nearerOf(d, 90, 270)
        else -> d
    }
}

/** Ties go to [a], which is the more common grip of each pair. */
private fun nearerOf(deg: Int, a: Int, b: Int): Int =
    if (angularDistanceDeg(deg, a) <= angularDistanceDeg(deg, b)) a else b

/**
 * Turn this content by [degrees], reporting the turned size to the parent.
 *
 * A plain `Modifier.rotate` keeps the original box, so a rotated label overflows
 * its own chip. This measures with swapped constraints and reports swapped
 * dimensions, so a rotated control occupies the space it actually covers and its
 * touch target rotates with it.
 */
internal fun Modifier.rigRotate(degrees: Int): Modifier {
    val d = ((degrees % 360) + 360) % 360
    if (d == 0) return this
    return layout { measurable, constraints ->
        val quarter = d == 90 || d == 270
        val inner = if (quarter) {
            Constraints(
                minWidth = constraints.minHeight,
                maxWidth = constraints.maxHeight,
                minHeight = constraints.minWidth,
                maxHeight = constraints.maxWidth,
            )
        } else {
            constraints
        }
        val placeable = measurable.measure(inner)
        val w = if (quarter) placeable.height else placeable.width
        val h = if (quarter) placeable.width else placeable.height
        layout(w, h) {
            placeable.placeWithLayer(
                x = (w - placeable.width) / 2,
                y = (h - placeable.height) / 2,
            ) { rotationZ = d.toFloat() }
        }
    }
}

/**
 * Keep this control's content upright, re-measuring it for the turn.
 *
 * Only for content whose box is genuinely non-square and free to change shape --
 * a sheet, a readout pill floating over the frame. NOT for anything inside a
 * bounded row: [rigRotate] hands the child the parent's constraints with the axes
 * swapped, so a fixed-size control in a height-limited row gets its width clamped
 * to the row's height and collapses. That is what turned the dock's chips into
 * slivers with their labels broken into single letters.
 */
@Composable
internal fun Modifier.upright(): Modifier =
    rigRotate(contentRotationFor(LocalDeviceRotation.current))

/**
 * Keep this content upright *within the box it already has*.
 *
 * A pure graphics turn: no re-measuring, no constraint swapping, so the parent's
 * layout is untouched. Correct precisely when the box is SQUARE, because then the
 * content has the same room along its reading direction whichever way it is
 * turned -- which is why tray chips are square. A label that fits upright fits
 * sideways, so nothing reflows and the dock cannot change size.
 */
@Composable
internal fun Modifier.uprightInPlace(): Modifier =
    rotate(contentRotationFor(LocalDeviceRotation.current).toFloat())

/**
 * Follow the phone, whatever the system's auto-rotate setting says.
 *
 * Reading the sensor directly is the point: auto-rotate off is a reasonable thing
 * to want for the rest of the phone and a terrible thing to inflict on a
 * viewfinder, where the operator turns the device constantly and the chrome has
 * to stay readable.
 *
 * [frozen] holds the last value. Recording sets it, because a 6DOF move swings
 * the phone through whole quadrants and chrome spinning mid-take is exactly the
 * distraction a take does not need.
 */
@Composable
internal fun rememberDeviceRotation(frozen: Boolean = false): Int {
    val context = LocalContext.current
    var rotation by remember { mutableStateOf(0) }
    val hold by rememberUpdatedState(frozen)
    DisposableEffect(context) {
        val listener = object : OrientationEventListener(
            context,
            SensorManager.SENSOR_DELAY_UI,
        ) {
            override fun onOrientationChanged(orientation: Int) {
                if (hold) return
                rotation = quantizeDeviceRotation(orientation, rotation)
            }
        }
        if (listener.canDetectOrientation()) listener.enable()
        onDispose { listener.disable() }
    }
    return rotation
}
