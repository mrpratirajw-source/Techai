// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * The measurements and colours the redesigned UI is built from.
 *
 * Centralised for one specific reason: the previous UI set spacing and colour
 * ad hoc at each call site, and the result was seven controls that all looked
 * the same weight while sitting at seven unrelated distances from the edge.
 * A layout cannot be consistent if every position is an independent decision.
 */
internal object Rig {

    /** 4dp base step. Every gap in the UI is one of these. */
    object Space {
        val xs: Dp = 4.dp
        val sm: Dp = 8.dp
        val md: Dp = 12.dp
        val lg: Dp = 16.dp
        val xl: Dp = 24.dp
        val xxl: Dp = 32.dp
    }

    /**
     * Corner radii are small and squared, not pill-shaped.
     *
     * Fully rounded pills read as floating chips dropped onto the screen. The
     * chrome should feel like part of the instrument — grounded to an edge, with
     * corners that turn rather than curl.
     */
    object Radius {
        val chip: Dp = 10.dp
        /** Status readout and other small squared blocks. */
        val badge: Dp = 9.dp
        /**
         * The bar anchored to a screen edge. Only the corners facing INTO the
         * screen are rounded; the ones on the edge stay square, which is what
         * makes it read as attached rather than placed.
         */
        val grounded: Dp = 18.dp
        /**
         * Transient controls that float over the frame. These DO get a full
         * pill, precisely because they are not attached to anything: rounding
         * is what distinguishes "hovering, will leave" from "part of the
         * housing".
         */
        val floating: Dp = 999.dp
    }

    /**
     * Ergonomic floors, not suggestions.
     *
     * [touchTarget] is Android's 48dp minimum and applies at every font scale —
     * the current UI relies on text size for its hit area, which is why a large
     * system font made controls collide.
     *
     * [edgeInset] keeps content off curved panels and the gesture bar. The
     * current UI puts labels flush against the screen edge.
     */
    object Touch {
        val touchTarget: Dp = 48.dp
        val edgeInset: Dp = 12.dp
        /**
          * Diameter of the record button. The one fixed landmark on screen.
          *
          * ~14% of a phone's short edge, matching the camera app this is modelled
          * on. It was 68dp, which read as oversized rather than as prominent.
          */
        val recordButton: Dp = 58.dp

        /**
         * Tray chips are SQUARE.
         *
         * Not cosmetic: a chip turns with the phone, and a rectangular one reports
         * a different box at each quarter turn, so the row it sits in changed
         * height every time the phone was turned. Square is rotation-invariant by
         * construction rather than by a tuned constant.
         */
        val chip: Dp = 64.dp

        /**
         * The one chip on a screen that is the main thing to do.
         *
         * Bigger and filled, so a row of equal chips has an obvious centre. Still
         * SQUARE for the same reason every other one is -- it has to turn with the
         * phone without changing the dock's height.
         */
        val chipPrimary: Dp = 92.dp

        /**
         * The dock's height. One number, every screen, every rotation.
         *
         * Fixed rather than wrapped, for two reasons that turned out to be the
         * same reason. Wrapped, the dock changed height when the phone turned
         * (its contents re-measured), and it changed height between the landing,
         * offline and connected screens (they hold different controls). Both read
         * as the instrument resizing itself underneath the operator.
         *
         * Sized for the worst case: the status strip, a row of turned chips, and
         * a second row of turned chips, at the largest font scale.
         */
        val dock: Dp = 208.dp

        /**
         * One readout cell. Square, for the same reason chips are: it turns with
         * the phone, and only a square keeps the same room at every quarter turn.
         */
        val statusCell: Dp = 36.dp
    }

    object Type {
        val chipLabel = 10.sp
        val status = 12.5.sp
        val badge = 13.sp
        val readout = 12.sp
        /**
         * The focal length above the dial.
         *
         * Larger than the ticks it sits over, because it is the value being set
         * rather than a scale marking -- but only just. At 18sp it was the biggest
         * text in the app outside a sheet title, which is a strange rank for a
         * readout on a control you are already looking at.
         */
        val lensReadout = 14.sp
        val title = 16.sp
    }

    /**
     * Colours are defined against a **live camera image**, not a black page.
     * That is the constraint the old UI ignored: grey-on-black text is
     * unreadable the moment the viewfinder shows a bright wall.
     *
     * The look is **matte**, not glass: a flat, dark, slightly translucent panel
     * like the housing on a field monitor. No blur, no gloss, no gradient. That
     * is a deliberate rejection of frosted glass, which draws attention to the
     * chrome instead of the shot — and, usefully, it also removes the API-31
     * blur fork, so every phone gets exactly the same look.
     */
    object Colors {
        /** Tray/chip fill: matte charcoal, barely translucent. */
        val trayFill = Color(0xFF0F1114).copy(alpha = 0.88f)
        /**
         * A sheet's fill: effectively opaque.
         *
         * The tray is slightly translucent so the frame stays visible through it,
         * which is right for a control you use WHILE composing. A sheet is the
         * opposite: it is read, it carries body text, and at tray opacity the
         * screen behind it showed straight through the paragraphs.
         */
        val sheetFill = Color(0xFF0D0F12).copy(alpha = 0.985f)
        /** Hairline separating the tray from the scene. Almost subliminal. */
        val trayBorder = Color.White.copy(alpha = 0.07f)
        /** Fill for a transient control floating over the frame. Lighter and
         * more transparent than the grounded chrome, so it reads as hovering. */
        val floatFill = Color(0xFF2A2D33).copy(alpha = 0.80f)
        /** Track behind a segmented switch, so unselected segments read as
         * part of one control rather than as separate buttons. */
        val segmentTrack = Color(0xFF23262C).copy(alpha = 0.85f)
        /** Scrim under the top status row, strongest at the very edge. */
        val topScrim = Color.Black.copy(alpha = 0.55f)

        val onGlass = Color(0xFFF2F4F7)
        val onGlassDim = Color(0xFFA8B0BC)
        /**
         * A control that cannot be used right now.
         *
         * Deliberately still READABLE. Fading a control to near-invisible does
         * not communicate "temporarily unavailable", it communicates "broken" or
         * "failed to draw" -- and the operator still needs to know what the
         * control is and what state it is in. Only the affordance dims; the
         * information does not.
         */
        val onGlassDisabled = Color(0xFF7C8492)
        /** An armed toggle that is locked: still legibly armed, visibly inert. */
        val armedDisabled = Color(0xFF2F5C8C)

        /** Armed/recording. Deliberately the only saturated red in the UI. */
        val record = Color(0xFFFF3B30)
        /** Connected and tracking. */
        val live = Color(0xFF32D74B)
        /** Degraded but usable — the operator should act, nothing is broken. */
        val warn = Color(0xFFFFD60A)
        /** Tracking lost / failed. */
        val bad = Color(0xFFFF453A)
        /** An enabled toggle's tint (6DOF on, lens driven). */
        val armed = Color(0xFF4EA1FF)

        val horizon = Color.White.copy(alpha = 0.85f)
        /** Reticle: quieter than the horizon, it is a reference not a reading. */
        val reticle = Color.White.copy(alpha = 0.60f)
        /**
         * Drawn under every viewfinder instrument stroke.
         *
         * Overlay line art on a camera image has no guaranteed background, so a
         * single light stroke is a coin toss. A dark underlay makes contrast the
         * instrument's own property rather than the scene's.
         */
        val instrumentShadow = Color.Black.copy(alpha = 0.45f)
        val horizonGrid = Color.White.copy(alpha = 0.14f)
    }
}
