// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android

import dev.pocketrig.protocol.Quaternion
import dev.pocketrig.protocol.Vec3

/** Debug-only observations from the tracking acquisition boundary. */
internal interface TrackingTelemetry {
    fun onArCoreConfigInventory(inventory: ArCoreConfigInventoryTelemetry)
    fun onArCoreConfig(config: ArCoreConfigTelemetry)
    fun onArCoreFrame(frame: ArCoreFrameTelemetry)
    fun onImuSample(sample: ImuSampleTelemetry)
}

internal fun traceCueCount(label: String): Int =
    if (label.equals("CLOSE", ignoreCase = true)) 2 else 1

/** Resolve an optional debug override against the pose source actually running. */
internal fun traceSource(explicit: String?, activePoseSourceIsAr: Boolean): String =
    explicit
        ?.trim()
        ?.lowercase()
        ?.takeIf { it == "arcore" || it == "sensor" }
        ?: if (activePoseSourceIsAr) "arcore" else "sensor"

internal data class MotionTraceHeader(
    val source: String,
    val manufacturer: String,
    val model: String,
    val sdkInt: Int,
    val appId: String,
    val versionName: String,
    val versionCode: Int,
    val debug: Boolean,
    val startedNs: Long,
)

internal data class ArCoreConfigTelemetry(
    val observedNs: Long,
    val cameraId: String,
    val fpsLower: Int,
    val fpsUpper: Int,
    val cpuWidth: Int,
    val cpuHeight: Int,
    val textureWidth: Int,
    val textureHeight: Int,
    val depthSensorUsage: String,
    val stereoCameraUsage: String,
    val focusMode: String,
    val imageStabilization: String,
    val inventoryIndex: Int? = null,
    val experimentProfile: String = "default_fixed",
)

internal data class ArCoreCameraConfigTelemetry(
    val cameraId: String,
    val fpsLower: Int,
    val fpsUpper: Int,
    val cpuWidth: Int,
    val cpuHeight: Int,
    val textureWidth: Int,
    val textureHeight: Int,
    val depthSensorUsage: String,
    val stereoCameraUsage: String,
)

internal data class ArCoreConfigInventoryTelemetry(
    val observedNs: Long,
    val configs: List<ArCoreCameraConfigTelemetry>,
)

internal data class ArCoreFrameTelemetry(
    val observedNs: Long,
    val frameNs: Long,
    val trackingState: String,
    val failureReason: String,
    val cameraQ: Quaternion? = null,
    val cameraP: Vec3? = null,
    val displayQ: Quaternion? = null,
    val displayP: Vec3? = null,
    val poseMode: String = ArCorePoseMode.RAW.traceName,
    val anchorGeneration: Int? = null,
    val anchorState: String = "UNAVAILABLE",
    val anchorQ: Quaternion? = null,
    val anchorP: Vec3? = null,
    val relativeCameraQ: Quaternion? = null,
    val relativeCameraP: Vec3? = null,
    val relativeDisplayQ: Quaternion? = null,
    val relativeDisplayP: Vec3? = null,
    val afState: Int? = null,
    val aeState: Int? = null,
    val focusDistanceDiopters: Float? = null,
    val exposureTimeNs: Long? = null,
    val sensitivityIso: Int? = null,
    /**
     * Tracked feature points in this frame's point cloud, and their mean
     * confidence. This is the most direct available answer to "is the tracker
     * actually seeing anything", which `trackingState` does not give: ARCore
     * reported healthy TRACKING for 5.2 s with the lens covered while
     * dead-reckoning 6.18 cm of motion that never happened.
     *
     * Deliberately recorded as a count and a mean rather than a count above some
     * confidence threshold: the distribution is not yet known (a first device
     * capture of a static, well-lit scene had ~102 points and not one above
     * 0.5), so choosing a cutoff now would bake in a guess. Observational only.
     */
    val featurePoints: Int? = null,
    val featureConfidenceMean: Float? = null,
)

internal data class ImuSampleTelemetry(
    val observedNs: Long,
    val sensorNs: Long,
    val sensor: String,
    val x: Float,
    val y: Float,
    val z: Float,
    val accuracy: Int,
)

/**
 * Small dependency-free JSONL encoder for debug motion traces.
 *
 * Returning null for a pose/frame with non-finite numeric data prevents invalid JSON
 * from entering a baseline artifact. The live tracking path is never allowed to fail
 * because diagnostics encountered a bad value.
 */
internal object MotionTraceJson {
    const val FORMAT = "pocketrig-motion-trace"
    const val VERSION = 1

    fun header(value: MotionTraceHeader): String = buildString(320) {
        append('{')
        field("format", FORMAT)
        commaField("version", VERSION)
        commaField("source", value.source)
        append(",\"device\":{")
        field("manufacturer", value.manufacturer)
        commaField("model", value.model)
        commaField("sdk_int", value.sdkInt)
        append('}')
        append(",\"app\":{")
        field("id", value.appId)
        commaField("version_name", value.versionName)
        commaField("version_code", value.versionCode)
        commaField("debug", value.debug)
        append('}')
        commaField("timebase", "elapsed_realtime_ns")
        commaField("started_ns", value.startedNs)
        append('}')
    }

    fun pose(
        source: String,
        q: Quaternion,
        sourceNs: Long,
        observedNs: Long,
        pos: Vec3?,
    ): String? {
        if (!q.isFinite() || pos?.isFinite() == false) return null
        return buildString(240) {
            append('{')
            field("kind", "pose")
            commaField("observed_ns", observedNs)
            commaField("source_ns", sourceNs)
            commaField("source", source)
            commaQuat("q", q)
            if (pos != null) commaVec3("p", pos)
            append('}')
        }
    }

    fun arCoreConfig(value: ArCoreConfigTelemetry): String = buildString(320) {
        append('{')
        field("kind", "arcore_config")
        commaField("observed_ns", value.observedNs)
        commaField("camera_id", value.cameraId)
        commaIntPair("fps_range", value.fpsLower, value.fpsUpper)
        commaIntPair("cpu_size", value.cpuWidth, value.cpuHeight)
        commaIntPair("texture_size", value.textureWidth, value.textureHeight)
        commaField("depth_sensor_usage", value.depthSensorUsage)
        commaField("stereo_camera_usage", value.stereoCameraUsage)
        commaField("focus_mode", value.focusMode)
        commaField("image_stabilization", value.imageStabilization)
        value.inventoryIndex?.let { commaField("inventory_index", it) }
        commaField("experiment_profile", value.experimentProfile)
        append('}')
    }

    fun arCoreConfigInventory(value: ArCoreConfigInventoryTelemetry): String = buildString(1024) {
        append('{')
        field("kind", "arcore_config_inventory")
        commaField("observed_ns", value.observedNs)
        append(",\"configs\":[")
        value.configs.forEachIndexed { index, config ->
            if (index > 0) append(',')
            append('{')
            field("index", index)
            commaField("camera_id", config.cameraId)
            commaIntPair("fps_range", config.fpsLower, config.fpsUpper)
            commaIntPair("cpu_size", config.cpuWidth, config.cpuHeight)
            commaIntPair("texture_size", config.textureWidth, config.textureHeight)
            commaField("depth_sensor_usage", config.depthSensorUsage)
            commaField("stereo_camera_usage", config.stereoCameraUsage)
            append('}')
        }
        append("]}")
    }

    fun tracking(value: ArCoreFrameTelemetry): String = buildString(180) {
        append('{')
        field("kind", "tracking")
        commaField("observed_ns", value.observedNs)
        commaField("frame_ns", value.frameNs)
        commaField("state", value.trackingState)
        commaField("reason", value.failureReason)
        append('}')
    }

    fun marker(observedNs: Long, label: String): String = buildString(96) {
        append('{')
        field("kind", "marker")
        commaField("observed_ns", observedNs)
        commaField("label", label)
        append('}')
    }

    fun imu(value: ImuSampleTelemetry): String? {
        if (!value.x.isFinite() || !value.y.isFinite() || !value.z.isFinite()) return null
        return buildString(180) {
            append('{')
            field("kind", "imu")
            commaField("observed_ns", value.observedNs)
            commaField("sensor_ns", value.sensorNs)
            commaField("sensor", value.sensor)
            append(",\"v\":[").append(value.x).append(',').append(value.y).append(',')
                .append(value.z).append(']')
            commaField("accuracy", value.accuracy)
            append('}')
        }
    }

    fun arCoreFrame(value: ArCoreFrameTelemetry): String? {
        val pairs = listOf(
            value.cameraQ to value.cameraP,
            value.displayQ to value.displayP,
            value.anchorQ to value.anchorP,
            value.relativeCameraQ to value.relativeCameraP,
            value.relativeDisplayQ to value.relativeDisplayP,
        )
        if (pairs.any { (q, p) -> q?.isFinite() == false || p?.isFinite() == false }) return null
        return buildString(420) {
            append('{')
            field("kind", "arcore_frame")
            commaField("observed_ns", value.observedNs)
            commaField("frame_ns", value.frameNs)
            commaField("state", value.trackingState)
            commaField("reason", value.failureReason)
            commaField("pose_mode", value.poseMode)
            value.anchorGeneration?.let { commaField("anchor_generation", it) }
            commaField("anchor_state", value.anchorState)
            value.cameraQ?.let { commaQuat("camera_q", it) }
            value.cameraP?.let { commaVec3("camera_p", it) }
            value.displayQ?.let { commaQuat("display_q", it) }
            value.displayP?.let { commaVec3("display_p", it) }
            value.anchorQ?.let { commaQuat("anchor_q", it) }
            value.anchorP?.let { commaVec3("anchor_p", it) }
            value.relativeCameraQ?.let { commaQuat("relative_camera_q", it) }
            value.relativeCameraP?.let { commaVec3("relative_camera_p", it) }
            value.relativeDisplayQ?.let { commaQuat("relative_display_q", it) }
            value.relativeDisplayP?.let { commaVec3("relative_display_p", it) }
            value.afState?.let { commaField("af_state", it) }
            value.aeState?.let { commaField("ae_state", it) }
            value.focusDistanceDiopters
                ?.takeIf { it.isFinite() }
                ?.let { commaField("focus_distance_diopters", it) }
            value.exposureTimeNs?.let { commaField("exposure_time_ns", it) }
            value.sensitivityIso?.let { commaField("sensitivity_iso", it) }
            value.featurePoints?.let { commaField("feature_points", it) }
            value.featureConfidenceMean
                ?.takeIf { it.isFinite() }
                ?.let { commaField("feature_confidence_mean", it) }
            append('}')
        }
    }

    private fun Quaternion.isFinite(): Boolean =
        w.isFinite() && x.isFinite() && y.isFinite() && z.isFinite()

    private fun Vec3.isFinite(): Boolean = x.isFinite() && y.isFinite() && z.isFinite()

    private fun StringBuilder.field(name: String, value: String) {
        appendQuoted(name)
        append(':')
        appendQuoted(value)
    }

    private fun StringBuilder.field(name: String, value: Number) {
        appendQuoted(name)
        append(':').append(value)
    }

    private fun StringBuilder.commaField(name: String, value: String) {
        append(',')
        field(name, value)
    }

    private fun StringBuilder.commaField(name: String, value: Number) {
        append(',')
        appendQuoted(name)
        append(':').append(value)
    }

    private fun StringBuilder.commaField(name: String, value: Boolean) {
        append(',')
        appendQuoted(name)
        append(':').append(value)
    }

    private fun StringBuilder.commaIntPair(name: String, first: Int, second: Int) {
        append(',')
        appendQuoted(name)
        append(":[").append(first).append(',').append(second).append(']')
    }

    private fun StringBuilder.commaQuat(name: String, q: Quaternion) {
        append(',')
        appendQuoted(name)
        append(":[").append(q.w).append(',').append(q.x).append(',')
            .append(q.y).append(',').append(q.z).append(']')
    }

    private fun StringBuilder.commaVec3(name: String, p: Vec3) {
        append(',')
        appendQuoted(name)
        append(":[").append(p.x).append(',').append(p.y).append(',').append(p.z).append(']')
    }

    private fun StringBuilder.appendQuoted(value: String) {
        append('"')
        for (c in value) {
            when (c) {
                '"' -> append("\\\"")
                '\\' -> append("\\\\")
                '\b' -> append("\\b")
                '\u000c' -> append("\\f")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                '\t' -> append("\\t")
                else -> if (c.code < 0x20) {
                    append("\\u").append(c.code.toString(16).padStart(4, '0'))
                } else {
                    append(c)
                }
            }
        }
        append('"')
    }
}
