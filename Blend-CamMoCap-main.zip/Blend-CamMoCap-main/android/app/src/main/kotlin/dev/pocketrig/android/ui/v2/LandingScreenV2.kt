// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.pocketrig.android.R

/** Everything the landing screen draws. */
internal data class LandingUiState(
    /** Takes already on the phone, waiting to be applied. */
    val savedCount: Int = 0,
    /** Camera permission granted, so the scanner can run. */
    val cameraReady: Boolean = true,
    /**
     * The camera was permitted but would not open.
     *
     * A separate state from [cameraReady] because the fix is different: there is
     * nothing to grant, so offering a permission button would be a dead end. Its
     * failure mode if unrendered is the worst kind -- a scan frame over a black
     * rectangle, looking like a scanner that is about to work.
     */
    val cameraError: String? = null,
    /**
     * Whether the phone is on Wi-Fi at all; null when we could not tell.
     *
     * Pairing fails most often because the phone is on mobile data and Blender
     * is on the LAN, and nothing in the old flow said so until the connection
     * timed out. This is knowable before the operator does anything, so it is
     * said before they do anything.
     */
    val onWifi: Boolean? = null,
    /** Manual address entry revealed, as a sheet over the scanner. */
    val manualOpen: Boolean = false,
    val address: String = "",
    val code: String = "",
    val error: String? = null,
)

internal data class LandingActions(
    val onManualToggle: () -> Unit = {},
    val onManualDismiss: () -> Unit = {},
    val onAddress: (String) -> Unit = {},
    val onCode: (String) -> Unit = {},
    val onConnect: () -> Unit = {},
    val onRequestCamera: () -> Unit = {},
    val onRetryCamera: () -> Unit = {},
    val onRecordOffline: () -> Unit = {},
    val onBrowseTakes: () -> Unit = {},
)

/**
 * The first screen: point the camera at the QR code in Blender.
 *
 * **Structurally the live screen.** Same two regions, same status readout in the
 * same corner, same grounded dock with the record button at its centre and the
 * between-things controls in its corners. That is not reuse for its own sake: at
 * the moment of connecting, this screen becomes the live screen, and every part
 * that stays put across that change is a part the operator does not have to
 * re-find. Manual entry occupies Adjust's corner, Takes stays exactly where Takes
 * always is, and the empty middle of the bottom row is where the tracking-mode
 * switch will appear.
 *
 * **The scanner is the screen.** No start-scanning step and no landing copy: the
 * camera is already looking, and the one instruction sits under the frame it is
 * talking about rather than pinned to an edge some distance away.
 *
 * **Recording offline is a first-class action, not a footnote.** It used to be
 * grey text below the fold. It is the whole no-PC workflow, it starts a take, and
 * the app already has one control that means "start a take" — so it uses that
 * control, in the place that control always lives.
 */
@Composable
internal fun LandingScreenV2(
    state: LandingUiState,
    actions: LandingActions = LandingActions(),
    /** The QR camera preview, drawn behind the frame. Null renders the empty box. */
    scanner: (@Composable () -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    Box(modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            ScanRegion(state, actions, Modifier.weight(1f).fillMaxWidth(), scanner)
            LandingDock(state, actions)
        }

        // Manual entry was state the screen carried but never drew: `manualOpen`
        // existed, the link toggled it, and nothing appeared. A state that is not
        // rendered does not exist.
        if (state.manualOpen) {
            WorldSheetHost(onDismiss = actions.onManualDismiss) {
                ManualEntrySheet(state, actions)
            }
        }
    }
}

/**
 * The camera, the target, and what to do with it.
 *
 * The instruction lives in the same centred column as the frame, so the gap
 * between them is one number instead of two orientations' worth of guesswork. It
 * used to be anchored to the bottom of the region, which put it a third of a
 * screen away in portrait and directly on top of the frame in landscape.
 */
@Composable
private fun ScanRegion(
    state: LandingUiState,
    actions: LandingActions,
    modifier: Modifier = Modifier,
    scanner: (@Composable () -> Unit)? = null,
) {
    val scanning = state.cameraReady && state.cameraError == null
    Box(modifier.background(Color.Black)) {
        if (scanning) scanner?.invoke()

        BoxWithConstraints(
            Modifier.fillMaxSize().padding(Rig.Space.xl),
            contentAlignment = Alignment.Center,
        ) {
            if (scanning) {
                // Square, because a QR code is. Sized off the SHORT side of the
                // region so it stays a target rather than becoming a border, and
                // capped so a tablet does not get a half-metre of brackets.
                val side = (minOf(maxWidth, maxHeight) * 0.74f).coerceIn(140.dp, 300.dp)
                ScanFrame(Modifier.size(side))
            } else if (state.cameraReady) {
                // Permitted but unopenable. Nothing to grant, so the action is a
                // retry -- most often it succeeds, because the thing holding the
                // camera was our own ARCore session on its way out.
                CameraBlocked(
                    message = state.cameraError.orEmpty(),
                    actionLabel = stringResource(R.string.try_again),
                    onAction = actions.onRetryCamera,
                )
            } else {
                CameraBlocked(
                    message = stringResource(R.string.camera_permission_needed),
                    actionLabel = stringResource(R.string.allow_camera),
                    onAction = actions.onRequestCamera,
                )
            }
        }

        if (scanning) {
            // The instruction sits along whichever edge is currently DOWN, and
            // reads across it. Turned on the spot under the frame it became a
            // column of letters dangling off the phone's bottom, which is nowhere
            // in particular once the phone is sideways.
            val device = LocalDeviceRotation.current
            Box(
                Modifier.fillMaxSize().padding(Rig.Space.xl),
                contentAlignment = worldBottomAlignment(device),
            ) {
                Box(Modifier.upright()) {
                    // Reset inside: the block above has already turned, and the
                    // pills would otherwise turn a second time.
                    CompositionLocalProvider(LocalDeviceRotation provides 0) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            ControlSurface(
                                shape = RoundedCornerShape(Rig.Radius.badge),
                            ) {
                                Text(
                                    text = stringResource(R.string.scan_prompt),
                                    color = Rig.Colors.onGlass,
                                    fontSize = Rig.Type.status,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(
                                        horizontal = Rig.Space.md,
                                        vertical = Rig.Space.sm,
                                    ),
                                )
                            }
                            // The error belongs where the eye already is, under
                            // the instruction it contradicts.
                            state.error?.let {
                                Spacer(Modifier.height(Rig.Space.sm))
                                ErrorPill(it, maxWidth = 320.dp)
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * What went wrong, in full.
 *
 * Deliberately NOT [StatusLabel]: that clamps to one line, which is right for a
 * readout whose text is a known short string and wrong for an error, which is
 * the one message on screen that has to survive being read. "That QR code isn't
 * a pocketrig pairing code" rendered as "That QR code isn't a pocketrig".
 */
@Composable
private fun ErrorPill(text: String, maxWidth: androidx.compose.ui.unit.Dp) {
    StatusPill(dot = Rig.Colors.bad, modifier = Modifier.widthIn(max = maxWidth)) {
        Text(
            text = text,
            color = Rig.Colors.onGlass,
            fontSize = Rig.Type.status,
            lineHeight = 17.sp,
        )
    }
}

/**
 * Only what is wrong, and only when something is.
 *
 * "Not connected" is gone: this is the pairing screen, so it said nothing the
 * screen did not already say by existing. What is left is the one thing that is
 * knowable in advance and actually causes failures.
 */
@Composable
private fun landingStatus(state: LandingUiState): List<StatusItem> {
    val items = mutableListOf<StatusItem>()
    if (state.onWifi == false) {
        items += StatusItem(
            glyph = { GlyphWifiOff(it) },
            tone = Tone.WARN,
            explain = stringResource(R.string.explain_no_wifi),
        )
    }
    return items
}

/**
 * The target: a soft square with four hard corners.
 *
 * Both are needed. The corners alone were four marks floating in space with no
 * shape between them, and a full box alone reads as a cut-out that demands the
 * code be positioned precisely. The outline says "roughly here"; the corners say
 * "this is a target".
 *
 * Every stroke is drawn twice, dark underneath and light on top, for the same
 * reason the horizon is: the backdrop is a camera image nobody controls, and a
 * single white line over a bright monitor is invisible exactly when it is needed.
 */
@Composable
private fun ScanFrame(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val r = 22.dp.toPx()
        // Short. At 17% the four brackets plus the corner radius covered most of
        // each edge, so the target read as one rounded rectangle with notches cut
        // out of it rather than as four corners.
        val arm = size.minDimension * 0.10f
        val outline = 1.dp.toPx()
        val mark = 2.5.dp.toPx()
        // How much wider the dark underlay is drawn than the stroke it backs.
        // Kept tight: at 2.5dp the pair read as one puffy grey line over a white
        // monitor rather than as a white mark with a shadow behind it.
        val halo = 1.5.dp.toPx()

        // Faint full outline: the shape of the target.
        drawRoundRect(
            color = Rig.Colors.instrumentShadow,
            cornerRadius = CornerRadius(r, r),
            style = Stroke(outline + halo),
        )
        drawRoundRect(
            color = Color.White.copy(alpha = 0.34f),
            cornerRadius = CornerRadius(r, r),
            style = Stroke(outline),
        )

        // Four brackets, following the same rounded path so they sit on the
        // outline rather than beside it.
        val corners = listOf(-1f to -1f, 1f to -1f, -1f to 1f, 1f to 1f)
        for ((sx, sy) in corners) {
            val path = cornerPath(sx, sy, r, arm)
            drawPath(
                path,
                Rig.Colors.instrumentShadow,
                style = Stroke(mark + halo, cap = StrokeCap.Round, join = StrokeJoin.Round),
            )
            drawPath(
                path,
                Rig.Colors.horizon,
                style = Stroke(mark, cap = StrokeCap.Round, join = StrokeJoin.Round),
            )
        }
    }
}

/** One rounded corner bracket: along one edge, round the corner, down the other. */
private fun DrawScope.cornerPath(sx: Float, sy: Float, r: Float, arm: Float): Path {
    val x0 = if (sx < 0f) 0f else size.width
    val y0 = if (sy < 0f) 0f else size.height
    return Path().apply {
        moveTo(x0 - sx * (r + arm), y0)
        lineTo(x0 - sx * r, y0)
        quadraticTo(x0, y0, x0, y0 - sy * r)
        lineTo(x0, y0 - sy * (r + arm))
    }
}

/**
 * No camera, so no target.
 *
 * The old version left the frame on screen and swapped the caption, which drew a
 * scanner that could not scan. If there is nothing to aim, there is nothing to
 * aim at: the frame goes, and its place is taken by the reason and the fix.
 */
@Composable
private fun CameraBlocked(
    message: String,
    actionLabel: String,
    onAction: () -> Unit,
) {
    // Turned as ONE panel: it is a paragraph plus a button, and the pieces would
    // scatter if each turned on its own. Nothing inside carries upright().
    ControlSurface(Modifier.upright().widthIn(max = 320.dp)) {
        Column(
            Modifier.padding(Rig.Space.xl),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = message,
                color = Rig.Colors.onGlass,
                fontSize = 13.sp,
                lineHeight = 18.sp,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(Rig.Space.md))
            RigButton(label = actionLabel, onClick = onAction)
            Spacer(Modifier.height(Rig.Space.sm))
            // Manual is always the way out of both of these, so it is named even
            // when the retry is the more likely fix.
            Note(stringResource(R.string.or_enter_manually))
        }
    }
}

/**
 * The same dock as the live screen, holding what there is to do before pairing.
 *
 * Record offline takes the record button's slot because it *is* the record
 * button: it starts a take. Giving it a text chip here and a red circle one
 * screen later would be two vocabularies for one action, and it would leave the
 * most prominent position in the app filled with a hyperlink, which is what it
 * used to be.
 *
 * The middle of the bottom row is deliberately empty. That is where the
 * tracking-mode switch sits once connected, so the dock does not reshuffle at
 * the moment of connecting -- Manual's corner becomes Adjust's corner, Takes
 * never moves, and the mode switch simply appears in the gap.
 */
@Composable
private fun LandingDock(state: LandingUiState, actions: LandingActions) {
    GroundedDock(status = landingStatus(state)) {
        // One row of three equal chips. There is no primary slot here because
        // there is no primary button: the thing you came to do is scan, and the
        // camera is already doing it. Everything in the dock is an alternative.
        //
        // The record landmark used to sit in the middle of this row, which was a
        // lie -- tapping it opens the offline screen, it does not start a take.
        // The one control drawn as a red disc has to mean "rolling now"
        // everywhere, or it means nothing anywhere.
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            ManualChip(actions)
            TrayChip(
                label = stringResource(R.string.record_offline_short),
                glyph = { GlyphRecordDot(it) },
                onClick = actions.onRecordOffline,
                large = true,
                // The only filled chip on the screen. Prominent without borrowing
                // the red disc, which means "rolling now" and would be a lie here.
                filled = true,
            )
            TakesChip(state, actions)
        }
    }
}

@Composable
private fun ManualChip(actions: LandingActions) = TrayChip(
    label = stringResource(R.string.manual_entry),
    glyph = { GlyphKeyboard(it) },
    onClick = actions.onManualToggle,
    large = true,
)

@Composable
private fun TakesChip(state: LandingUiState, actions: LandingActions) = TrayChip(
    // The count only shows when there is one. "Takes · 0" is a worse way of
    // saying "Takes" and it makes the label change width for no information.
    // Just the word. The count is status, so it lives in the strip -- as a
    // chip label it was the one string that would not fit a square chip at a
    // large font, and "Takes · 3" truncated to "Takes ·".
    label = stringResource(R.string.takes),
    glyph = { GlyphStack(it) },
    onClick = actions.onBrowseTakes,
    // Nothing to browse yet is a fact worth showing rather than a button worth
    // hiding: a control that appears later is a control nobody knows exists.
    enabled = state.savedCount > 0,
    large = true,
)

/**
 * Address and code by hand, as a sheet.
 *
 * A sheet rather than an inline reveal because it is read and typed into, and
 * because inline it pushed the dock around as it opened. Same furniture as the
 * Adjust sheet: handle, section labels, notes, one committing button.
 */
@Composable
private fun ManualEntrySheet(
    state: LandingUiState,
    actions: LandingActions,
    modifier: Modifier = Modifier,
) {
    ControlSurface(
        modifier.fillMaxWidth(),
        shape = RoundedCornerShape(
            topStart = Rig.Radius.grounded,
            topEnd = Rig.Radius.grounded,
        ),
        opaque = true,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                // Measured against the device, like the Adjust sheet: with a
                // keyboard up on a landscape phone there is very little room.
                // No height cap here: WorldSheetHost caps against the WORLD's
                // height, the only measurement that means the same thing
                // however the phone is held.
                .padding(horizontal = Rig.Space.xl, vertical = Rig.Space.lg),
        ) {
            // Only the FORM scrolls. Connect is pinned below it, because on a
            // landscape phone the whole sheet scrolled and the one button that
            // finishes the job sat clipped against the bottom edge. A committing
            // action that has to be scrolled to is a committing action people
            // conclude is missing.
            //
            // fill = false so a short form still makes a short sheet, rather than
            // the weight stretching it to the cap in portrait.
            Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())) {
                SheetHandle()
                Spacer(Modifier.height(Rig.Space.lg))
                SectionLabel(stringResource(R.string.enter_manually))
                Spacer(Modifier.height(Rig.Space.xs))
                Note(stringResource(R.string.manual_entry_help))
                Spacer(Modifier.height(Rig.Space.md))

                RigField(
                    label = stringResource(R.string.address_label),
                    value = state.address,
                    onValue = actions.onAddress,
                    placeholder = stringResource(R.string.address_placeholder),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                )
                Spacer(Modifier.height(Rig.Space.md))
                RigField(
                    label = stringResource(R.string.code_label),
                    value = state.code,
                    onValue = { actions.onCode(it.uppercase()) },
                    placeholder = stringResource(R.string.code_placeholder),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Characters,
                        keyboardType = KeyboardType.Ascii,
                    ),
                )

                state.error?.let {
                    Spacer(Modifier.height(Rig.Space.md))
                    Text(
                        text = it,
                        color = Rig.Colors.bad,
                        fontSize = 12.5.sp,
                        lineHeight = 17.sp,
                    )
                }
            }

            Spacer(Modifier.height(Rig.Space.lg))
            RigButton(
                label = stringResource(R.string.connect),
                onClick = actions.onConnect,
                modifier = Modifier.fillMaxWidth(),
                // Nothing to connect to without an address. Disabled rather than
                // absent, so the shape of the form does not change as it is filled.
                enabled = state.address.isNotBlank(),
            )
        }
    }
}
