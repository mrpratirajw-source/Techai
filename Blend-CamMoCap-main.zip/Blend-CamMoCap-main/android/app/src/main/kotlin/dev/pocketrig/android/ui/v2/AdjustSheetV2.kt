// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.pocketrig.android.R
import dev.pocketrig.protocol.DEFAULT_SHAKE_HOLD_DPS

/** The mirrored session settings, as one value. */
internal data class AdjustUiState(
    val liveSmoothing: Float = 0.30f,
    val recordSmoothing: Float = 0.15f,
    val positionScale: Float = 1.0f,
    /** "offline" | "live" — what a finished take bakes from (spec 5.7). */
    val takeSource: String = "offline",
    /** "auto" | "portrait" | "landscape" -- which way up the SHOT is. */
    val shotOrientation: String = "auto",
    /**
     * Angular speed above which Blender holds position, or 0 for off (spec 5.7).
     *
     * Blender's value, not ours: the cue on the viewfinder has to describe what
     * the host is actually doing.
     */
    val shakeHoldDps: Float = DEFAULT_SHAKE_HOLD_DPS.toFloat(),
    /** The operator wants Blender's viewport on the phone. */
    val viewportOn: Boolean = false,
    /** The host advertised a viewport stream. False on an older host. */
    val viewportAvailable: Boolean = false,
    /** Non-null while the stream is trying or has failed, for the note. */
    val viewportNote: String? = null,
    /** Sizes the host offers, largest first. Empty until WELCOME lands. */
    val viewportSizes: List<Pair<Int, Int>> = emptyList(),
    val viewportSize: Pair<Int, Int>? = null,
    val viewportFps: Int = 20,
    /**
     * The rate the host has measured its own event loop reaching, or null.
     *
     * Shown rather than enforced. It moves with what the operator is doing on
     * the PC, so clamping the control to it would lock the phone out of a
     * higher rate the moment Blender got quicker.
     */
    val viewportMaxFps: Int? = null,
    val viewportQuality: Int = 75,
    val viewportOverlays: Boolean = false,
    /** "light" | "balanced" | "smooth", or null when the operator picks. */
    val viewportProfile: String? = "balanced",
    /** What the host is actually rendering, from the frames themselves. */
    val viewportChosenSize: Pair<Int, Int>? = null,
    /** The host has run out of sizes to give up. */
    val viewportAtFloor: Boolean = false,
    /** Locked while a take is rolling: these change what the take records. */
    val locked: Boolean = false,
)

internal data class AdjustActions(
    val onLiveSmoothing: (Float) -> Unit = {},
    val onRecordSmoothing: (Float) -> Unit = {},
    val onPositionScale: (Float) -> Unit = {},
    val onTakeSource: (String) -> Unit = {},
    val onShotOrientation: (String) -> Unit = {},
    val onShakeHoldDps: (Float) -> Unit = {},
    val onToggleViewport: () -> Unit = {},
    val onViewportSize: (Pair<Int, Int>) -> Unit = {},
    val onViewportFps: (Int) -> Unit = {},
    val onViewportQuality: (Int) -> Unit = {},
    val onViewportOverlays: (Boolean) -> Unit = {},
    val onViewportProfile: (String?) -> Unit = {},
    val onDismiss: () -> Unit = {},
)

/** Above the relocalization guard the gate could never fire first (spec 5.7). */
internal const val SHAKE_HOLD_MAX_DPS = 1200f

/**
 * The settings sheet, grounded to the bottom edge like the dock it opens from.
 *
 * Deliberately a *sheet*, not a screen: none of these are things an operator
 * comes to the app to do, they are adjustments made in passing, and the
 * viewfinder should stay visible behind them so a smoothing change can be judged
 * against the actual shot rather than remembered.
 *
 * Grouped by what each setting affects, and each group says so, because
 * "smoothing" alone does not tell you that one value shapes the live preview
 * while the other shapes the file you keep. That distinction is the single most
 * confusing thing about this panel and it is worth spending a line of text on.
 */
@Composable
internal fun AdjustSheetV2(
    state: AdjustUiState,
    actions: AdjustActions = AdjustActions(),
    modifier: Modifier = Modifier,
) {
    ControlSurface(
        modifier.fillMaxWidth(),
        shape = RoundedCornerShape(
            topStart = Rig.Radius.grounded,
            topEnd = Rig.Radius.grounded,
        ),
        opaque = true,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                // No height cap here: WorldSheetHost caps against the WORLD's
                // height, the only measurement that means the same thing
                // however the phone is held.
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Rig.Space.xl, vertical = Rig.Space.lg),
        ) {
            SheetHandle()
            Spacer(Modifier.height(Rig.Space.lg))

            SectionLabel(stringResource(R.string.adjust))
            Spacer(Modifier.height(Rig.Space.sm))

            // Smoothing: two values that are easy to confuse, so each is named by
            // what it affects rather than by when it applies.
            ParamRow(
                label = stringResource(R.string.live_smoothing),
                note = "Shapes the preview only. The take is unaffected.",
                value = state.liveSmoothing,
                onValue = actions.onLiveSmoothing,
                enabled = !state.locked,
                display = { "${(it * 100).toInt()}%" },
            )
            ParamRow(
                label = stringResource(R.string.record_smoothing),
                note = "Shapes the keyframes Blender bakes.",
                value = state.recordSmoothing,
                onValue = actions.onRecordSmoothing,
                enabled = !state.locked,
                display = { "${(it * 100).toInt()}%" },
            )
            ParamRow(
                label = stringResource(R.string.position_scale),
                note = stringResource(R.string.position_scale_help),
                value = state.positionScale,
                onValue = actions.onPositionScale,
                enabled = !state.locked,
                // Logarithmic over the spec's full legal range. It was linear
                // 0.1-10, which could not express a host sitting at 25x: the
                // thumb pinned at the end and touching it would have silently
                // dropped the operator's setting to 10. Log also puts 1.0x in the
                // middle, where the value you most often want should be.
                range = 0.1f..100f,
                logarithmic = true,
                display = { "%.1f×".format(it) },
            )

            Spacer(Modifier.height(Rig.Space.lg))
            SectionLabel(stringResource(R.string.take_from))
            Spacer(Modifier.height(Rig.Space.xs))
            Note(
                "Offline is the phone's own full-rate recording, uploaded after " +
                    "the cut, so Wi-Fi glitches only ever hit the preview.",
            )
            Spacer(Modifier.height(Rig.Space.sm))
            LabelledSegments(
                options = listOf(
                    stringResource(R.string.take_offline),
                    stringResource(R.string.take_live),
                ),
                selectedIndex = if (state.takeSource == "live") 1 else 0,
                onSelect = { actions.onTakeSource(if (it == 1) "live" else "offline") },
                // Locked mid-take: changing the source of a take already rolling
                // would decide, halfway through, which recording gets kept.
                enabled = !state.locked,
            )

            Spacer(Modifier.height(Rig.Space.lg))
            SectionLabel(stringResource(R.string.viewport))
            Spacer(Modifier.height(Rig.Space.xs))
            Note(stringResource(R.string.viewport_help))
            Spacer(Modifier.height(Rig.Space.sm))
            LabelledSegments(
                options = listOf(
                    stringResource(R.string.viewport_on),
                    stringResource(R.string.viewport_off),
                ),
                selectedIndex = if (state.viewportOn) 0 else 1,
                onSelect = { index ->
                    if ((index == 0) != state.viewportOn) actions.onToggleViewport()
                },
                // Greyed rather than hidden when the host is too old: a control
                // that vanishes reads as a bug in the phone, where one that is
                // present and explains itself points at the actual cause.
                enabled = state.viewportAvailable,
            )
            if (!state.viewportAvailable) {
                Spacer(Modifier.height(Rig.Space.xs))
                Note(stringResource(R.string.viewport_unavailable))
            } else if (state.viewportNote != null) {
                Spacer(Modifier.height(Rig.Space.xs))
                Note(state.viewportNote)
            }
            // Only while it is on. Three controls for a stream that is switched
            // off is a sheet arguing with itself.
            if (state.viewportOn && state.viewportAvailable) {
                // Effort first, because under a preset it replaces the two
                // controls below it. Three named intents and an escape hatch
                // beat three numbers whose units only the host understands.
                val presets = listOf("light", "balanced", "smooth", null)
                Spacer(Modifier.height(Rig.Space.sm))
                SectionLabel(stringResource(R.string.viewport_quality_preset))
                Spacer(Modifier.height(Rig.Space.xs))
                Note(stringResource(R.string.viewport_quality_preset_help))
                Spacer(Modifier.height(Rig.Space.sm))
                LabelledSegments(
                    options = listOf(
                        stringResource(R.string.viewport_preset_light),
                        stringResource(R.string.viewport_preset_balanced),
                        stringResource(R.string.viewport_preset_smooth),
                        stringResource(R.string.viewport_preset_manual),
                    ),
                    selectedIndex = presets.indexOf(state.viewportProfile)
                        .coerceAtLeast(0),
                    onSelect = { actions.onViewportProfile(presets[it]) },
                )
                if (state.viewportProfile != null) {
                    // What it chose, not what it was asked for. The size comes
                    // off the frames themselves, so this cannot drift from what
                    // is actually on screen.
                    Spacer(Modifier.height(Rig.Space.xs))
                    if (state.viewportAtFloor) {
                        Note(stringResource(R.string.viewport_preset_floor))
                    } else if (state.viewportChosenSize != null) {
                        Note(
                            stringResource(
                                R.string.viewport_preset_chosen,
                                state.viewportChosenSize.first,
                                state.viewportChosenSize.second,
                            ),
                        )
                    }
                }
                if (state.viewportProfile == null && state.viewportSizes.size > 1) {
                    Spacer(Modifier.height(Rig.Space.sm))
                    SectionLabel(stringResource(R.string.viewport_size))
                    Spacer(Modifier.height(Rig.Space.xs))
                    Note(stringResource(R.string.viewport_size_help))
                    Spacer(Modifier.height(Rig.Space.sm))
                    // Segments, not a slider: these are the only sizes the host
                    // will render, so a continuous control would promise values
                    // it has to snap away from.
                    LabelledSegments(
                        options = state.viewportSizes.map { "${it.second}p" },
                        selectedIndex = state.viewportSizes
                            .indexOf(state.viewportSize).coerceAtLeast(0),
                        onSelect = { actions.onViewportSize(state.viewportSizes[it]) },
                    )
                }
                val fpsNote = stringResource(R.string.viewport_fps_help)
                val ceiling = state.viewportMaxFps
                if (state.viewportProfile == null) ParamRow(
                    label = stringResource(R.string.viewport_fps),
                    // One line, not two. Both halves are short sentences now,
                    // and a note that grows a line when the host happens to
                    // have measured itself makes the sheet jump under the
                    // operator's thumb for no reason they can see.
                    note = if (ceiling != null) {
                        fpsNote + " " +
                            stringResource(R.string.viewport_fps_ceiling, ceiling)
                    } else {
                        fpsNote
                    },
                    value = state.viewportFps.toFloat(),
                    onValue = { actions.onViewportFps(it.toInt()) },
                    enabled = true,
                    // Linear from 5: this is a frame rate compared against a
                    // budget, not a multiplier, so equal travel is equal fps.
                    range = 5f..30f,
                    display = { "${it.toInt()} fps" },
                )
                Spacer(Modifier.height(Rig.Space.sm))
                SectionLabel(stringResource(R.string.viewport_overlays))
                Spacer(Modifier.height(Rig.Space.xs))
                Note(stringResource(R.string.viewport_overlays_help))
                Spacer(Modifier.height(Rig.Space.sm))
                LabelledSegments(
                    options = listOf(
                        stringResource(R.string.viewport_overlays_hide),
                        stringResource(R.string.viewport_overlays_show),
                    ),
                    selectedIndex = if (state.viewportOverlays) 1 else 0,
                    onSelect = { actions.onViewportOverlays(it == 1) },
                )
                ParamRow(
                    label = stringResource(R.string.viewport_quality),
                    note = stringResource(R.string.viewport_quality_help),
                    value = state.viewportQuality.toFloat(),
                    onValue = { actions.onViewportQuality(it.toInt()) },
                    enabled = true,
                    range = 40f..95f,
                    display = { "${it.toInt()}" },
                )
            }

            Spacer(Modifier.height(Rig.Space.lg))
            SectionLabel(stringResource(R.string.shake_hold))
            Spacer(Modifier.height(Rig.Space.xs))
            Note(stringResource(R.string.shake_hold_help))
            Spacer(Modifier.height(Rig.Space.sm))
            // On/off is its own control rather than the far-left end of the
            // slider. Off is a decision, not an extreme setting, and a value a
            // stray drag can leave at 5 deg/s -- holding constantly -- is not
            // the same thing as one that is switched off.
            LabelledSegments(
                options = listOf(
                    stringResource(R.string.shake_hold_on),
                    stringResource(R.string.shake_hold_off),
                ),
                selectedIndex = if (state.shakeHoldDps <= 0f) 1 else 0,
                onSelect = { index ->
                    actions.onShakeHoldDps(
                        if (index == 1) 0f else DEFAULT_SHAKE_HOLD_DPS.toFloat(),
                    )
                },
                enabled = !state.locked,
            )
            if (state.shakeHoldDps > 0f) {
                ParamRow(
                    label = stringResource(R.string.shake_hold_threshold),
                    note = stringResource(R.string.shake_hold_threshold_help),
                    value = state.shakeHoldDps,
                    onValue = actions.onShakeHoldDps,
                    enabled = !state.locked,
                    // Linear: this is an angular speed compared against a
                    // measured one, not a multiplier, so equal travel should be
                    // equal deg/s. Starts above zero because zero is the
                    // segment's job.
                    range = 100f..SHAKE_HOLD_MAX_DPS,
                    display = { "${it.toInt()}°/s" },
                )
            }

            Spacer(Modifier.height(Rig.Space.lg))
            SectionLabel(stringResource(R.string.shot_orientation))
            Spacer(Modifier.height(Rig.Space.xs))
            Note(stringResource(R.string.shot_orientation_help))
            Spacer(Modifier.height(Rig.Space.sm))
            LabelledSegments(
                options = listOf(
                    stringResource(R.string.shot_auto),
                    stringResource(R.string.portrait),
                    stringResource(R.string.landscape),
                ),
                selectedIndex = when (state.shotOrientation) {
                    "portrait" -> 1
                    "landscape" -> 2
                    else -> 0
                },
                onSelect = {
                    actions.onShotOrientation(
                        when (it) {
                            1 -> "portrait"
                            2 -> "landscape"
                            else -> "auto"
                        },
                    )
                },
                // Locked mid-take: the axes a take was shot on cannot change
                // halfway through it.
                enabled = !state.locked,
            )

            Spacer(Modifier.height(Rig.Space.lg))
        }
    }
}

// SheetHandle, SectionLabel and Note live in Surfaces.kt: the manual-address
// sheet on the landing screen is built from the same furniture.

/**
 * One slider with its name, its current value, and what it affects.
 *
 * The value is shown as a number rather than left to the thumb's position: an
 * operator asked to reproduce a look on another shoot needs a figure to write
 * down, and a thumb halfway along a track is not one.
 */
@Composable
private fun ParamRow(
    label: String,
    note: String,
    value: Float,
    onValue: (Float) -> Unit,
    enabled: Boolean,
    range: ClosedFloatingPointRange<Float> = 0f..1f,
    /** Equal travel = equal ratio. For a multiplier, that is the honest scale. */
    logarithmic: Boolean = false,
    display: (Float) -> String,
) {
    Column(Modifier.padding(vertical = Rig.Space.sm)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = label,
                color = if (enabled) Rig.Colors.onGlass else Rig.Colors.onGlassDisabled,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f),
            )
            Text(
                text = display(value),
                color = if (enabled) Rig.Colors.armed else Rig.Colors.onGlassDisabled,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
            )
        }
        Note(note)
        Spacer(Modifier.height(Rig.Space.sm))
        RigSlider(value, range, enabled, logarithmic, onValue)
    }
}

/**
 * A track with a dot on it, and nothing else.
 *
 * Material's Slider carries its own visual language and its own thumb metrics,
 * which match nothing else in this UI. The whole control is a line, a filled
 * portion and a handle, so it is drawn directly and stays in the design system.
 */
@Composable
private fun RigSlider(
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    enabled: Boolean,
    logarithmic: Boolean,
    onValue: (Float) -> Unit,
) {
    fun toFraction(v: Float): Float = if (logarithmic) {
        val lo = kotlin.math.ln(range.start)
        val hi = kotlin.math.ln(range.endInclusive)
        ((kotlin.math.ln(v.coerceIn(range.start, range.endInclusive)) - lo) /
            (hi - lo)).coerceIn(0f, 1f)
    } else {
        ((v - range.start) / (range.endInclusive - range.start)).coerceIn(0f, 1f)
    }

    fun fromFraction(f: Float): Float = if (logarithmic) {
        val lo = kotlin.math.ln(range.start)
        val hi = kotlin.math.ln(range.endInclusive)
        kotlin.math.exp(lo + (hi - lo) * f.coerceIn(0f, 1f))
    } else {
        range.start + f.coerceIn(0f, 1f) * (range.endInclusive - range.start)
    }

    val fraction = toFraction(value)
    val live by rememberUpdatedState(fraction)
    val track = if (enabled) Rig.Colors.armed else Rig.Colors.onGlassDisabled
    Box(
        Modifier
            .fillMaxWidth()
            // 44dp of grab height around a 4dp line: the line is what you read,
            // the box is what you hit.
            .height(44.dp)
            .then(
                if (enabled) {
                    Modifier.pointerInput(Unit) {
                        detectHorizontalDragGestures { change, _ ->
                            val f = (change.position.x / size.width).coerceIn(0f, 1f)
                            onValue(fromFraction(f))
                        }
                    }
                } else {
                    Modifier
                },
            ),
        contentAlignment = Alignment.CenterStart,
    ) {
        Canvas(Modifier.fillMaxWidth().height(44.dp)) {
            val cy = size.height / 2f
            val h = 4.dp.toPx()
            val r = 8.dp.toPx()
            // Inset by the handle radius so the handle never overhangs the track.
            val x0 = r
            val x1 = size.width - r
            drawLine(
                color = Rig.Colors.onGlassDim.copy(alpha = 0.22f),
                start = Offset(x0, cy),
                end = Offset(x1, cy),
                strokeWidth = h,
                cap = StrokeCap.Round,
            )
            val at = x0 + (x1 - x0) * live
            drawLine(
                color = track,
                start = Offset(x0, cy),
                end = Offset(at, cy),
                strokeWidth = h,
                cap = StrokeCap.Round,
            )
            drawCircle(Color.White, r, Offset(at, cy))
            drawCircle(track, r * 0.45f, Offset(at, cy))
        }
    }
}

/**
 * A segmented switch with words rather than glyphs.
 *
 * The opposite choice from the viewfinder's mode switch, on purpose: out there
 * space is scarce and the control is glanced at mid-shot, so icons win. In here
 * there is room, the reader is stopped and reading, and "Offline" versus "Live"
 * is not a distinction any icon would carry.
 */
@Composable
private fun LabelledSegments(
    options: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    enabled: Boolean = true,
) = SegmentedToggle(
    options = options.map<String, @Composable (Color) -> Unit> { label ->
        { tint ->
            Text(
                text = label,
                color = tint,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    },
    selectedIndex = selectedIndex,
    onSelect = onSelect,
    enabled = enabled,
)
