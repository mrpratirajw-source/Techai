// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.core.content.ContextCompat
import dev.pocketrig.android.R
import dev.pocketrig.android.ui.v2.LandingActions
import dev.pocketrig.android.ui.v2.LandingScreenV2
import dev.pocketrig.android.ui.v2.LandingUiState

/**
 * The landing screen with its state and its camera attached.
 *
 * [LandingScreenV2] draws; this owns. Keeping the two apart is what lets the
 * design gallery render every state of the screen — including the ones that only
 * happen when a permission is denied or a code is rejected — without a camera,
 * a permission dialog or a view model anywhere in sight.
 */
@Composable
internal fun LandingScreen(
    /** Returns false if the payload is not a pocketrig pairing code. */
    onQr: (String) -> Boolean,
    /** Returns false if the address could not be parsed. */
    onManual: (String, String) -> Boolean,
    savedCount: Int,
    onRecordOffline: () -> Unit,
    onBrowse: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current

    var manualOpen by rememberSaveable { mutableStateOf(false) }
    var address by rememberSaveable { mutableStateOf("") }
    var code by rememberSaveable { mutableStateOf("") }
    // Not saved: an error describes the last attempt, and a rotation is not an
    // attempt. Restoring it would accuse the operator of a mistake they made
    // before the screen turned.
    var error by remember { mutableStateOf<String?>(null) }
    var cameraError by remember { mutableStateOf<String?>(null) }
    // Bumped to retry: a new key builds a new BarcodeView, which is the only way
    // to make it try the camera again after a failed open.
    var scannerAttempt by remember { mutableStateOf(0) }

    var cameraGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED,
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        cameraGranted = granted
        // A denial is not an error about the code, so it does not go in the error
        // slot: the panel that replaces the frame already explains it, and it
        // stays on screen until the permission is actually granted.
    }

    val invalidQr = stringResource(R.string.invalid_qr)
    val invalidAddress = stringResource(R.string.invalid_address)
    val cameraBusy = stringResource(R.string.camera_busy)

    LandingScreenV2(
        state = LandingUiState(
            savedCount = savedCount,
            cameraReady = cameraGranted,
            cameraError = cameraError,
            onWifi = rememberOnLocalNetwork(),
            manualOpen = manualOpen,
            address = address,
            code = code,
            error = error,
        ),
        actions = LandingActions(
            onManualToggle = { manualOpen = !manualOpen; error = null },
            onManualDismiss = { manualOpen = false; error = null },
            onAddress = { address = it; error = null },
            onCode = { code = it; error = null },
            onConnect = { if (!onManual(address, code)) error = invalidAddress },
            onRequestCamera = {
                permissionLauncher.launch(Manifest.permission.CAMERA)
            },
            onRetryCamera = { cameraError = null; scannerAttempt++ },
            onRecordOffline = onRecordOffline,
            onBrowseTakes = onBrowse,
        ),
        scanner = if (cameraGranted) {
            {
                key(scannerAttempt) {
                    QrScannerView(
                        onCode = { payload ->
                            val ok = onQr(payload)
                            // Reported in place, under the frame that read it,
                            // rather than as a snackbar over the bottom of the
                            // screen where the dock is.
                            error = if (ok) null else invalidQr
                            ok
                        },
                        onCameraError = { cameraError = cameraBusy },
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
        } else {
            null
        },
        modifier = modifier,
    )
}
