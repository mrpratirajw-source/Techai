// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Near-black stage the camera UI sits on. */
val Night = Color(0xFF0E0E10)

/** The one accent: record red. */
val RecordRed = Color(0xFFFF3B30)

/** Live-link green (status dot only). */
val LiveGreen = Color(0xFF30D158)

/** Reconnecting amber (status dot only). */
val ReconnectAmber = Color(0xFFFFB020)

private val Ink = Color(0xFFF5F5F7)
private val InkDim = Color(0xFF8E8E93)

/**
 * pocketrig is dark in day and night — a viewfinder, not a form. One scheme,
 * used regardless of [isSystemInDarkTheme].
 */
private val PocketrigColors = darkColorScheme(
    primary = RecordRed,
    onPrimary = Color.White,
    secondary = InkDim,
    onSecondary = Night,
    background = Night,
    onBackground = Ink,
    surface = Color(0xFF16161A),
    onSurface = Ink,
    surfaceVariant = Color(0xFF1C1C21),
    onSurfaceVariant = InkDim,
    outline = Color(0xFF2A2A30),
    error = RecordRed,
    onError = Color.White,
)

@Composable
fun PocketrigTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = PocketrigColors,
        content = content,
    )
}
