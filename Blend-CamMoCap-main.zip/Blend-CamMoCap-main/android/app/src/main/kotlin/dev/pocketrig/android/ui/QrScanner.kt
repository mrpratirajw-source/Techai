// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui

import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.google.zxing.BarcodeFormat
import com.google.zxing.ResultPoint
import com.journeyapps.barcodescanner.BarcodeCallback
import com.journeyapps.barcodescanner.BarcodeResult
import com.journeyapps.barcodescanner.BarcodeView
import com.journeyapps.barcodescanner.CameraPreview
import com.journeyapps.barcodescanner.DefaultDecoderFactory

/**
 * The pairing scanner, running inside the landing screen.
 *
 * It used to be zxing's own full-screen activity, launched by a button. That
 * meant the first thing anyone saw was a plain page with a button on it, and the
 * second thing was a completely different app's chrome — and the landing screen
 * had no camera image at all, which is why it read as a black void with a reticle
 * floating in it.
 *
 * `BarcodeView` is the embeddable half of the same library, so this costs no new
 * dependency: same decoder, same formats, just hosted in our own layout.
 *
 * **The camera is exclusive.** ARCore must not hold it while this is on screen or
 * the preview never starts; that is why PocketrigApp keeps `viewfinderActive`
 * false for the whole of the landing screen.
 */
@Composable
internal fun QrScannerView(
    /** Returns true if the payload was a pairing code, which stops the scanner. */
    onCode: (String) -> Boolean,
    /**
     * The camera could not be opened at all.
     *
     * Reported rather than swallowed, because the failure mode is a black
     * rectangle with a scan frame drawn over it -- a scanner that looks like it
     * is working and never will. The likeliest cause is the handoff from ARCore:
     * `Session.pause()` releases the camera, but not always before the next
     * `open` reaches the driver.
     */
    onCameraError: (Exception?) -> Unit,
    modifier: Modifier = Modifier,
) {
    val handler by rememberUpdatedState(onCode)
    val failed by rememberUpdatedState(onCameraError)
    val lifecycleOwner = LocalLifecycleOwner.current

    // Whether the host activity is resumed. The camera must be released the
    // moment it is not, or returning to the app finds a dead preview.
    var resumed by remember { mutableStateOf(false) }
    // Set once a code is accepted, so the decoder does not keep firing at a
    // screen that is already on its way out.
    val stopped = remember { mutableStateOf(false) }
    // The last payload we rejected. Without this, holding a non-pocketrig QR code
    // in frame reports the same error many times a second.
    val rejected = remember { mutableStateOf<String?>(null) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> resumed = true
                Lifecycle.Event.ON_PAUSE -> resumed = false
                else -> Unit
            }
        }
        // addObserver syncs the observer to the current state, so this also
        // covers the case where the screen appears while already resumed.
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            BarcodeView(ctx).apply {
                decoderFactory = DefaultDecoderFactory(listOf(BarcodeFormat.QR_CODE))
                addStateListener(
                    object : CameraPreview.StateListener {
                        override fun previewSized() = Unit
                        override fun previewStarted() = Unit
                        override fun previewStopped() = Unit
                        override fun cameraClosed() = Unit
                        override fun cameraError(error: Exception?) = failed(error)
                    },
                )
                decodeContinuous(
                    object : BarcodeCallback {
                        override fun barcodeResult(result: BarcodeResult) {
                            val text = result.text ?: return
                            if (stopped.value || text == rejected.value) return
                            if (handler(text)) {
                                stopped.value = true
                            } else {
                                rejected.value = text
                            }
                        }

                        override fun possibleResultPoints(resultPoints: List<ResultPoint>) = Unit
                    },
                )
            }
        },
        // Resume/pause from `update` rather than from the lifecycle callback
        // directly: the callback can fire before the view exists, and a scanner
        // that missed its own resume is a black rectangle with no error.
        update = { view ->
            if (resumed && !stopped.value) view.resume() else view.pause()
        },
        onRelease = { it.pause() },
    )
}

/**
 * Whether the phone is on a local network at all; null if we cannot tell.
 *
 * The commonest way pairing fails is that the phone is on mobile data while
 * Blender is on the LAN, and the old flow said nothing until the connection
 * timed out. This is knowable up front and needs no runtime permission, so the
 * landing screen says it before the operator tries.
 *
 * Ethernet counts: a phone tethered into the same network can reach the host
 * perfectly well, and calling that "not on Wi-Fi" would be a false alarm.
 */
@Composable
internal fun rememberOnLocalNetwork(): Boolean? {
    val context = LocalContext.current
    var onWifi by remember { mutableStateOf<Boolean?>(null) }

    DisposableEffect(context) {
        val cm = context.getSystemService(ConnectivityManager::class.java)
        val callback = if (cm == null) {
            null
        } else {
            fun sample() {
                onWifi = runCatching {
                    val caps = cm.activeNetwork?.let(cm::getNetworkCapabilities)
                    caps != null && (
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
                        )
                }.getOrNull()
            }
            sample()
            object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) = sample()
                override fun onLost(network: Network) = sample()
                override fun onCapabilitiesChanged(
                    network: Network,
                    caps: NetworkCapabilities,
                ) = sample()
            }.also { runCatching { cm.registerDefaultNetworkCallback(it) } }
        }
        onDispose {
            if (cm != null && callback != null) {
                runCatching { cm.unregisterNetworkCallback(callback) }
            }
        }
    }
    return onWifi
}
