// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android

import android.app.Activity
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import dev.pocketrig.protocol.Frames
import dev.pocketrig.protocol.PoseSource
import dev.pocketrig.protocol.Quaternion
import dev.pocketrig.protocol.SessionClient
import dev.pocketrig.protocol.TrackingIssue
import dev.pocketrig.protocol.TrackingQuality

/**
 * Streams the game rotation vector into the session client.
 *
 * Every sensor event: `getQuaternionFromVector` (which fills its output array
 * as `[w, x, y, z]` — already the protocol component order) → [Quaternion] →
 * [Frames.sensorToProtocol] with the current display rotation →
 * [SessionClient.updatePose] stamped with the raw `SensorEvent.timestamp`
 * (elapsedRealtimeNanos domain, matching the client's clock).
 *
 * Events are delivered on a dedicated handler thread so the 200 Hz stream
 * never contends with UI work; `updatePose` is thread-safe by contract.
 */
class SensorPipeline(
    private val activity: Activity,
    private val client: SessionClient,
    /** Optional Motion Lab capture tap (debug tooling); sees every pose. */
    private val tap: ((String, Quaternion, Long, dev.pocketrig.protocol.Vec3?, TrackingQuality, TrackingIssue, Float) -> Unit)? = null,
    /**
     * Every protocol-frame orientation, for the viewfinder horizon.
     *
     * Called whether or not this pipeline is feeding the session, because the
     * horizon reports where the phone is pointing and that is true regardless of
     * who is driving the camera. Not routed through the Motion Lab [tap], which
     * is debug-gated and would leave the horizon dark in release builds.
     */
    private val onProtocolQuat: ((Quaternion) -> Unit)? = null,
) : SensorEventListener {

    private companion object {
        /** 5 ms sampling — 200 Hz requested, comfortably above the 100 Hz send rate. */
        const val SAMPLING_PERIOD_US = 5_000
    }

    private val sensorManager =
        activity.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val sensor: Sensor? =
        sensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)

    private var thread: HandlerThread? = null
    private val quat = FloatArray(4)

    @Volatile
    private var feedsPose = true

    /**
     * The most recent protocol-frame orientation, whether or not this pipeline
     * is the active pose source. [ArCorePipeline] reads it to continue rotation
     * inertially while ARCore cannot see (see [dev.pocketrig.protocol.SixDofFeed]).
     */
    @Volatile
    var latestProtocolQuaternion: Quaternion? = null
        private set

    /**
     * Registers the listener; call from `onResume`.
     *
     * With [feedsPose] false the rotation vector is still read and published to
     * [latestProtocolQuaternion], but nothing is sent to the session. That mode
     * runs *alongside* ARCore: the "exactly one pose source" rule (ADR-0006) is
     * about who calls `updatePose`, and in this mode nobody does. The inertial
     * telemetry pipeline already runs concurrently on the same principle.
     */
    fun start(feedsPose: Boolean = true) {
        this.feedsPose = feedsPose
        val s = sensor ?: return
        if (thread != null) return
        val t = HandlerThread("pocketrig-sensor").also { it.start() }
        thread = t
        sensorManager.registerListener(this, s, SAMPLING_PERIOD_US, Handler(t.looper))
    }

    /**
     * Switch between feeding the session and observing only, **without**
     * unregistering.
     *
     * The game rotation vector establishes its arbitrary yaw reference when the
     * sensor is activated, so unregistering and re-registering across a 6DOF
     * toggle risks silently re-anchoring the world frame the host is composing
     * against. Nothing about changing who consumes the samples requires
     * dropping the registration, so don't.
     */
    fun setFeedsPose(feedsPose: Boolean) {
        this.feedsPose = feedsPose
        if (thread == null) start(feedsPose)
    }

    /** Unregisters and stops the sensor thread; call from `onPause`. */
    fun stop() {
        sensorManager.unregisterListener(this)
        thread?.quitSafely()
        thread = null
    }

    override fun onSensorChanged(event: SensorEvent) {
        SensorManager.getQuaternionFromVector(quat, event.values)
        val qSensor = Quaternion(quat[0], quat[1], quat[2], quat[3])
        val qProtocol = Frames.sensorToProtocol(qSensor, displayRotation())
        latestProtocolQuaternion = qProtocol
        onProtocolQuat?.invoke(qProtocol)
        if (!feedsPose) return
        // Tagged, so a pose from this pipeline is dropped if ARCore has become
        // the authoritative source since this callback started.
        val captured = client.updatePose(
            qProtocol, event.timestamp, source = PoseSource.SENSOR,
        ) ?: return
        tap?.invoke(
            "sensor", captured.q, captured.timestampNs, captured.pos,
            captured.quality, captured.issue, captured.focalLengthMm,
        )
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    /**
     * Current display rotation as a `Surface.ROTATION_*` value. Uses the
     * modern `Context.getDisplay()` on API 30+, the deprecated
     * `Display.getRotation()` via the window manager below that.
     */
    private fun displayRotation(): Int = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        activity.display?.rotation ?: Surface.ROTATION_0
    } else {
        @Suppress("DEPRECATION")
        activity.windowManager.defaultDisplay.rotation
    }
}
