// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android

import dev.pocketrig.protocol.SessionState

/** Keep every camera viewfinder awake, including disconnected offline capture. */
internal fun shouldKeepScreenOn(state: SessionState, viewfinderActive: Boolean): Boolean =
    viewfinderActive || state is SessionState.Live || state is SessionState.Recording ||
        state is SessionState.Finalizing

/**
 * Whether the record control accepts a press.
 *
 * Recording MUST NOT disable it: while a take is rolling, this button *is* the
 * stop control. Gating it on a general "busy" flag that included `recording`
 * left the button rendering as a stop square that could not be pressed, so the
 * only way to end a take was the host's scene-end auto-stop.
 *
 * Finalization and an in-flight Apply do block it — neither can accept a new
 * take, and neither has anything to stop.
 */
internal fun recordControlEnabled(
    finalizing: Boolean,
    applying: Boolean,
): Boolean = !finalizing && !applying

/**
 * Neutral lens used only when the host never told us what it is set to.
 *
 * Reaching this is already the bad case — see [lensTakeoverMm].
 */
internal const val LENS_FALLBACK_MM = 35f

/**
 * The focal length to adopt when the operator takes the lens.
 *
 * Taking the lens must not *change* it. The rail used to hand the phone a flat
 * 35 mm, so merely opening the control reframed the shot — destructive, and
 * exactly what spec 4.5's "0.0 means not driving" rule exists to prevent on
 * connect. So start from the host's reported value (spec 5.7 `lens_mm`) and
 * make the first pose we send agree with what the host already has.
 *
 * The host's value is deliberately **not** clamped into the rail's travel: a
 * host sitting at 300 mm with a rail that stops at 200 would be reframed to 200
 * by the act of opening the control, which is the bug again. The rail shows the
 * thumb pinned at its end while the label reads the truth, and only a drag
 * changes anything. Implausible values (spec 4.5's 1–5000 mm) fall back rather
 * than drive the host somewhere absurd.
 */
internal fun lensTakeoverMm(hostLensMm: Double?): Float {
    val mm = hostLensMm ?: return LENS_FALLBACK_MM
    if (!mm.isFinite() || mm < 1.0 || mm > 5000.0) return LENS_FALLBACK_MM
    return mm.toFloat()
}
