// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/**
 * The tray icons, drawn rather than shipped.
 *
 * Vector drawables or an icon font would both add a dependency and a place for
 * the design to drift from the code; these are ~10 lines each and scale exactly.
 * The old UI had no icons at all, which is a large part of why nothing on screen
 * read as a control.
 *
 * All of them are line art on a 20dp box with a 1.6dp stroke, so the tray reads
 * as one set instead of a collection.
 */
private val GLYPH = 17.dp
private const val STROKE_DP = 1.5f

@Composable
private fun glyph(tint: Color, draw: androidx.compose.ui.graphics.drawscope.DrawScope.(Float) -> Unit) {
    Canvas(Modifier.size(GLYPH)) { draw(STROKE_DP * density) }
}

/** 6DOF: a cube, i.e. movement through space rather than just rotation. */
@Composable
internal fun GlyphCube(tint: Color) = glyph(tint) { w ->
    val s = size.minDimension
    val i = s * 0.20f
    val box = Size(s * 0.52f, s * 0.52f)
    // Back face, then front face, joined at one corner: enough to read as 3D.
    drawRect(tint, Offset(i * 1.6f, i * 0.6f), box, style = Stroke(w))
    drawRect(tint, Offset(i * 0.6f, i * 1.6f), box, style = Stroke(w))
    drawLine(tint, Offset(i * 0.6f, i * 1.6f), Offset(i * 1.6f, i * 0.6f), w)
    drawLine(
        tint,
        Offset(i * 0.6f + box.width, i * 1.6f + box.height),
        Offset(i * 1.6f + box.width, i * 0.6f + box.height),
        w,
    )
}

/** Lens: concentric circles, an aperture seen head-on. */
@Composable
internal fun GlyphLens(tint: Color) = glyph(tint) { w ->
    val c = Offset(size.width / 2f, size.height / 2f)
    drawCircle(tint, size.minDimension * 0.40f, c, style = Stroke(w))
    drawCircle(tint, size.minDimension * 0.17f, c, style = Stroke(w))
}

/** Adjust: two sliders at different positions. */
@Composable
internal fun GlyphSliders(tint: Color) = glyph(tint) { w ->
    val s = size.minDimension
    for ((idx, frac) in listOf(0.34f, 0.66f).withIndex()) {
        val y = s * frac
        drawLine(tint, Offset(s * 0.14f, y), Offset(s * 0.86f, y), w, StrokeCap.Round)
        val knobX = if (idx == 0) s * 0.66f else s * 0.36f
        drawCircle(tint, s * 0.11f, Offset(knobX, y))
    }
}

/** Takes: a stack of clips. */
@Composable
internal fun GlyphStack(tint: Color) = glyph(tint) { w ->
    val s = size.minDimension
    drawRect(
        tint,
        Offset(s * 0.16f, s * 0.30f),
        Size(s * 0.68f, s * 0.44f),
        style = Stroke(w),
    )
    drawLine(tint, Offset(s * 0.26f, s * 0.20f), Offset(s * 0.74f, s * 0.20f), w, StrokeCap.Round)
    drawLine(tint, Offset(s * 0.34f, s * 0.11f), Offset(s * 0.66f, s * 0.11f), w, StrokeCap.Round)
}

/** Re-centre: a reticle. Snapping the current framing to neutral. */
@Composable
internal fun GlyphCrosshair(tint: Color) = glyph(tint) { w ->
    val s = size.minDimension
    val c = Offset(s / 2f, s / 2f)
    drawCircle(tint, s * 0.30f, c, style = Stroke(w))
    for (a in 0..3) {
        val dx = if (a % 2 == 0) 1f else 0f
        val dy = if (a % 2 == 0) 0f else 1f
        val sign = if (a < 2) 1f else -1f
        drawLine(
            tint,
            Offset(c.x + dx * sign * s * 0.30f, c.y + dy * sign * s * 0.30f),
            Offset(c.x + dx * sign * s * 0.46f, c.y + dy * sign * s * 0.46f),
            w,
            StrokeCap.Round,
        )
    }
}

/** Pause. */
@Composable
internal fun GlyphPause(tint: Color) = glyph(tint) { w ->
    val s = size.minDimension
    drawLine(tint, Offset(s * 0.38f, s * 0.22f), Offset(s * 0.38f, s * 0.78f), w * 1.5f, StrokeCap.Round)
    drawLine(tint, Offset(s * 0.62f, s * 0.22f), Offset(s * 0.62f, s * 0.78f), w * 1.5f, StrokeCap.Round)
}

/** Go live. */
@Composable
internal fun GlyphPlay(tint: Color) = glyph(tint) { _ ->
    val s = size.minDimension
    drawPath(
        Path().apply {
            moveTo(s * 0.34f, s * 0.20f)
            lineTo(s * 0.78f, s * 0.50f)
            lineTo(s * 0.34f, s * 0.80f)
            close()
        },
        tint,
    )
}

/** Rotation-only mode: an orbit arrow, turning without travelling. */
@Composable
internal fun GlyphRotate(tint: Color) = glyph(tint) { w ->
    val s = size.minDimension
    val c = Offset(s / 2f, s / 2f)
    val r = s * 0.30f
    // Open arc, so it reads as turning rather than as a closed ring.
    drawArc(
        color = tint,
        startAngle = 40f,
        sweepAngle = 280f,
        useCenter = false,
        topLeft = Offset(c.x - r, c.y - r),
        size = Size(r * 2, r * 2),
        style = Stroke(w, cap = StrokeCap.Round),
    )
    // Arrow head on the open end.
    val a = Offset(c.x + r * 0.77f, c.y + r * 0.64f)
    drawLine(tint, a, Offset(a.x + s * 0.12f, a.y - s * 0.03f), w, StrokeCap.Round)
    drawLine(tint, a, Offset(a.x + s * 0.02f, a.y - s * 0.14f), w, StrokeCap.Round)
}

/**
 * The host owns the lens: a desktop display.
 *
 * A glyph rather than the word "Blender" because in the vertical strip every
 * segment shares a column width, so one seven-letter label made a column of
 * two-digit numbers far wider than it needed to be. The dimmed "-- mm" readout
 * beside the strip carries the meaning in words.
 */
@Composable
internal fun GlyphHost(tint: Color) = glyph(tint) { w ->
    val s = size.minDimension
    drawRect(
        tint,
        Offset(s * 0.14f, s * 0.20f),
        Size(s * 0.72f, s * 0.46f),
        style = Stroke(w),
    )
    drawLine(tint, Offset(s * 0.5f, s * 0.66f), Offset(s * 0.5f, s * 0.80f), w)
    drawLine(
        tint,
        Offset(s * 0.30f, s * 0.82f),
        Offset(s * 0.70f, s * 0.82f),
        w,
        StrokeCap.Round,
    )
}

/**
 * The link to Blender: rising bars.
 *
 * Replaces a pill that spelled out the round-trip time over the top-left of every
 * shot. The bars carry the health; the number beside them is three characters.
 */
@Composable
internal fun GlyphLink(tint: Color) = glyph(tint) { w ->
    val s = size.minDimension
    for (i in 0..2) {
        val x = s * (0.22f + i * 0.28f)
        val h = s * (0.26f + i * 0.24f)
        drawLine(tint, Offset(x, s * 0.80f), Offset(x, s * 0.80f - h), w * 1.4f, StrokeCap.Round)
    }
}

/** No Wi-Fi: the arcs, struck through. */
@Composable
internal fun GlyphWifiOff(tint: Color) = glyph(tint) { w ->
    val s = size.minDimension
    val c = Offset(s * 0.5f, s * 0.74f)
    for (r in listOf(0.22f, 0.42f)) {
        drawArc(
            color = tint,
            startAngle = 200f,
            sweepAngle = 140f,
            useCenter = false,
            topLeft = Offset(c.x - s * r, c.y - s * r),
            size = Size(s * r * 2, s * r * 2),
            style = Stroke(w, cap = StrokeCap.Round),
        )
    }
    drawCircle(tint, s * 0.06f, c)
    drawLine(tint, Offset(s * 0.18f, s * 0.18f), Offset(s * 0.82f, s * 0.86f), w, StrokeCap.Round)
}

/**
 * Offline: the monitor, struck through.
 *
 * Reuses the glyph that already means "Blender" on the lens ownership button, so
 * a strike through it reads as "no Blender" with no new vocabulary to learn. It
 * replaces a rounded rectangle with a dot in it that was meant to be a phone and
 * at 17dp was simply a yellow rectangle.
 */
@Composable
internal fun GlyphHostOff(tint: Color) = glyph(tint) { w ->
    val s = size.minDimension
    drawRect(
        tint,
        Offset(s * 0.12f, s * 0.18f),
        Size(s * 0.76f, s * 0.48f),
        style = Stroke(w),
    )
    drawLine(tint, Offset(s * 0.5f, s * 0.66f), Offset(s * 0.5f, s * 0.80f), w)
    drawLine(
        tint,
        Offset(s * 0.28f, s * 0.82f),
        Offset(s * 0.72f, s * 0.82f),
        w,
        StrokeCap.Round,
    )
    // The strike, drawn over a dark gap so it stays legible where it crosses the
    // screen's own outline rather than merging into it.
    drawLine(
        Rig.Colors.instrumentShadow,
        Offset(s * 0.10f, s * 0.90f),
        Offset(s * 0.90f, s * 0.10f),
        w * 2.6f,
        StrokeCap.Round,
    )
    drawLine(
        tint,
        Offset(s * 0.14f, s * 0.86f),
        Offset(s * 0.86f, s * 0.14f),
        w * 1.2f,
        StrokeCap.Round,
    )
}

/** To start: a bar and two arrows back, the transport mark for "rewind to top". */
@Composable
internal fun GlyphToStart(tint: Color) = glyph(tint) { w ->
    val s = size.minDimension
    drawLine(tint, Offset(s * 0.20f, s * 0.24f), Offset(s * 0.20f, s * 0.76f), w * 1.4f, StrokeCap.Round)
    for (x in listOf(0.54f, 0.84f)) {
        drawPath(
            Path().apply {
                moveTo(s * x, s * 0.24f)
                lineTo(s * (x - 0.26f), s * 0.50f)
                lineTo(s * x, s * 0.76f)
                close()
            },
            tint,
        )
    }
}

/** Orientation lock: a padlock, shut when locked and open when following. */
@Composable
internal fun GlyphLock(tint: Color, locked: Boolean) = glyph(tint) { w ->
    val s = size.minDimension
    drawRoundRect(
        color = tint,
        topLeft = Offset(s * 0.22f, s * 0.46f),
        size = Size(s * 0.56f, s * 0.40f),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(s * 0.08f, s * 0.08f),
        style = Stroke(w),
    )
    // The shackle leans open rather than vanishing, so the two states differ by
    // more than a colour -- which is the one cue some operators will not get.
    val cx = if (locked) s * 0.50f else s * 0.62f
    drawArc(
        color = tint,
        startAngle = 180f,
        sweepAngle = 180f,
        useCenter = false,
        topLeft = Offset(cx - s * 0.17f, s * 0.20f),
        size = Size(s * 0.34f, s * 0.34f),
        style = Stroke(w, cap = StrokeCap.Round),
    )
    drawLine(tint, Offset(cx - s * 0.17f, s * 0.37f), Offset(cx - s * 0.17f, s * 0.47f), w)
    if (locked) {
        drawLine(tint, Offset(cx + s * 0.17f, s * 0.37f), Offset(cx + s * 0.17f, s * 0.47f), w)
    }
}

/** Rename: a pencil. */
@Composable
internal fun GlyphPencil(tint: Color) = glyph(tint) { w ->
    val s = size.minDimension
    // An outlined body with a tip, not a thick diagonal smear. The first version
    // was two heavy strokes that read as a slash at 17dp.
    val path = Path().apply {
        moveTo(s * 0.20f, s * 0.80f)
        lineTo(s * 0.28f, s * 0.58f)
        lineTo(s * 0.62f, s * 0.24f)
        lineTo(s * 0.78f, s * 0.40f)
        lineTo(s * 0.44f, s * 0.74f)
        close()
    }
    drawPath(path, tint, style = Stroke(w, join = StrokeJoin.Round))
    // The collar where the wood meets the metal, which is what makes it read as
    // a pencil rather than as an arrow.
    drawLine(
        tint,
        Offset(s * 0.55f, s * 0.31f),
        Offset(s * 0.71f, s * 0.47f),
        w,
        StrokeCap.Round,
    )
}

/** Delete: a bin. Deliberately unmistakable -- it is the destructive one. */
@Composable
internal fun GlyphTrash(tint: Color) = glyph(tint) { w ->
    val s = size.minDimension
    drawLine(tint, Offset(s * 0.16f, s * 0.28f), Offset(s * 0.84f, s * 0.28f), w, StrokeCap.Round)
    drawLine(tint, Offset(s * 0.40f, s * 0.20f), Offset(s * 0.60f, s * 0.20f), w, StrokeCap.Round)
    drawRect(
        tint,
        Offset(s * 0.26f, s * 0.28f),
        Size(s * 0.48f, s * 0.56f),
        style = Stroke(w),
    )
    for (x in listOf(0.42f, 0.58f)) {
        drawLine(tint, Offset(s * x, s * 0.40f), Offset(s * x, s * 0.72f), w * 0.8f, StrokeCap.Round)
    }
}

/** Done / back out: an arrow returning to where you came from. */
@Composable
internal fun GlyphBack(tint: Color) = glyph(tint) { w ->
    val s = size.minDimension
    val y = s * 0.5f
    drawLine(tint, Offset(s * 0.84f, y), Offset(s * 0.20f, y), w, StrokeCap.Round)
    drawLine(
        tint,
        Offset(s * 0.20f, y),
        Offset(s * 0.44f, y - s * 0.22f),
        w,
        StrokeCap.Round,
    )
    drawLine(
        tint,
        Offset(s * 0.20f, y),
        Offset(s * 0.44f, y + s * 0.22f),
        w,
        StrokeCap.Round,
    )
}

/** Manual entry: a keyboard, i.e. type it instead of pointing at it. */
@Composable
internal fun GlyphKeyboard(tint: Color) = glyph(tint) { w ->
    val s = size.minDimension
    drawRect(
        tint,
        Offset(s * 0.08f, s * 0.26f),
        Size(s * 0.84f, s * 0.48f),
        style = Stroke(w),
    )
    // Two rows of keys and a space bar: enough to read as a keyboard at 17dp.
    // The keys are dashes rather than dots -- at this size dots rendered as a
    // grey smear instead of as anything you could name.
    for (row in 0..1) {
        val y = s * (0.40f + row * 0.13f)
        for (col in 0..2) {
            val x = s * (0.22f + col * 0.22f) - if (row == 1) s * 0.07f else 0f
            drawLine(tint, Offset(x, y), Offset(x + s * 0.09f, y), w, StrokeCap.Round)
        }
    }
    drawLine(
        tint,
        Offset(s * 0.32f, s * 0.66f),
        Offset(s * 0.68f, s * 0.66f),
        w,
        StrokeCap.Round,
    )
}

/** Record offline: a filled dot, the universal "this records" mark. */
@Composable
internal fun GlyphRecordDot(tint: Color) = glyph(tint) { w ->
    val s = size.minDimension
    drawCircle(tint, s * 0.34f, Offset(s / 2f, s / 2f), style = Stroke(w))
    drawCircle(tint, s * 0.17f, Offset(s / 2f, s / 2f))
}
