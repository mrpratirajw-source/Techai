// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.pocketrig.android.LENS_FALLBACK_MM
import dev.pocketrig.android.R
import kotlin.math.roundToInt

/**
 * The zoom control: one continuous dial, always.
 *
 * It used to be two states -- a row of preset buttons that expanded into a fine
 * ruler -- and that was wrong three ways at once. The dial was gated to portrait,
 * so in landscape the fine control simply did not exist. Dragging the presets
 * scrubbed the value but never revealed the ruler, so there was no feedback for
 * what the drag was doing. And a zoom whose resting state is five buttons teaches
 * you to tap, which is the least useful thing you can do with a lens.
 *
 * One dial fixes all three by deleting the distinction. The standard lengths are
 * still there as labelled ticks, so a known lens is still a target you can land
 * on; they no longer have a mode of their own.
 *
 * Deliberately **floats** rather than being grounded to the dock: permanent
 * chrome is grounded, and a zoom is worked while composing, so it belongs near
 * the frame being judged.
 */
@Composable
internal fun LensZoomWidget(
    /** null = Blender owns the lens (spec 4.5) and we are only reporting it. */
    focalMm: Float?,
    /** The host's lens, shown while Blender owns it so the value is never blank. */
    hostLensMm: Float?,
    onFocalMm: (Float) -> Unit,
    onToggleLensOwnership: () -> Unit,
    onSettled: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shown = focalMm ?: hostLensMm
    val driving = focalMm != null
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        // The value floats free of the dial, over the frame, so the number never
        // has to fight the ruler for space. Dimmed while Blender owns the lens:
        // still the truth, but not ours. A dash rather than nothing when no value
        // is known, so the slot never collapses and nothing looks half-drawn.
        Text(
            text = shown?.let { "${it.roundToInt()} mm" } ?: "-- mm",
            color = if (driving) Color.White else Rig.Colors.onGlassDim,
            fontSize = Rig.Type.lensReadout,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.upright(),
        )
        val dial: @Composable () -> Unit = {
            Box(
                Modifier
                    // Nobody has told us a focal length yet: neither side is
                    // driving and the host has not reported one (the window
                    // before the first PARAMS, or a lens being animated by a
                    // take). The readout already says "-- mm"; dimming the ruler
                    // stops the index mark asserting a reading to match, which
                    // would be the one number on screen that is made up.
                    .alpha(if (shown == null) 0.45f else 1f)
                    .background(
                        Rig.Colors.floatFill,
                        RoundedCornerShape(Rig.Radius.floating),
                    )
                    // Bounded so the ruler never stretches the whole screen, where
                    // crossing a single stop would take a hand-span of travel.
                    .widthIn(max = 300.dp)
                    .padding(horizontal = Rig.Space.md, vertical = Rig.Space.xs),
            ) {
                LensDial(
                    // Dragging takes the lens if Blender still owns it, starting
                    // from Blender's own value so the shot never jumps at the
                    // moment of taking it. With no value known at all, park on
                    // the same neutral the ownership button would adopt, so the
                    // two routes into driving the lens cannot land differently.
                    focalMm = shown ?: LENS_FALLBACK_MM,
                    onFocalMm = onFocalMm,
                    onSettled = onSettled,
                )
            }
        }
        Row(
            Modifier.padding(top = Rig.Space.sm),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(Rig.Space.sm),
        ) {
            OwnerButton(driving = driving, onToggle = onToggleLensOwnership)
            dial()
        }
    }
}

/**
 * Who owns the lens, as one button beside the dial.
 *
 * It swaps ownership both ways. It used to only ever hand the lens BACK, which
 * made it inert in half its states -- and, because it was armed while Blender
 * held the lens, inert in precisely the state where it was the brightest thing
 * on the control. Its spoken label said "give the lens back" in both states too.
 *
 * Armed now means what [Rig.Colors.armed] means everywhere else in the app, and
 * what its own definition says: this is on, the phone is driving. Blender
 * holding the lens is the resting state, so it gets the resting fill.
 *
 * The glyph carries the same fact a second way, for anyone who cannot use the
 * tint: a monitor while Blender has it, a lens once you do. A glyph rather than
 * a word because the word was three times wider than anything else here and
 * ended up setting the control's size.
 *
 * Dragging the dial still takes the lens on its own -- this button exists so
 * that taking it is also a deliberate, reversible act rather than a side effect
 * of touching the zoom.
 */
@Composable
private fun OwnerButton(driving: Boolean, onToggle: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val label = stringResource(if (driving) R.string.lens_release else R.string.lens_take)
    Box(
        Modifier
            .upright()
            .defaultMinSize(minWidth = 40.dp, minHeight = 36.dp)
            .background(
                if (driving) Rig.Colors.armed else Rig.Colors.floatFill,
                RoundedCornerShape(Rig.Radius.floating),
            )
            .clickable(
                interactionSource = interaction,
                indication = null,
                onClick = onToggle,
            )
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center,
    ) {
        if (driving) GlyphLens(Color(0xFF06121F)) else GlyphHost(Rig.Colors.onGlass)
    }
}
