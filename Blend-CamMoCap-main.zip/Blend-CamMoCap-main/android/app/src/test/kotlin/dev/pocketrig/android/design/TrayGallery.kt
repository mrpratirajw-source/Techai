// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.design

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.unit.Density
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.github.takahirom.roborazzi.captureRoboImage
import dev.pocketrig.android.ui.PocketrigTheme
import dev.pocketrig.android.ui.v2.AdjustSheetV2
import dev.pocketrig.android.ui.v2.AdjustUiState
import dev.pocketrig.android.ui.v2.LandingScreenV2
import dev.pocketrig.android.ui.v2.LandingUiState
import dev.pocketrig.android.ui.v2.LocalDeviceRotation
import dev.pocketrig.android.ui.v2.ViewportImage
import androidx.compose.ui.graphics.asImageBitmap
import dev.pocketrig.android.ViewportClient
import dev.pocketrig.android.ui.v2.OfflineScreenV2
import dev.pocketrig.android.ui.v2.OfflineUiState
import dev.pocketrig.android.ui.v2.TakeRowUi
import dev.pocketrig.android.ui.v2.TakesSheetV2
import dev.pocketrig.android.ui.v2.TakesUiState
import dev.pocketrig.android.ui.v2.Attitude
import dev.pocketrig.android.ui.v2.CameraScreenV2
import dev.pocketrig.android.ui.v2.CameraUiState
import dev.pocketrig.android.ui.v2.WorldSheetHost
import dev.pocketrig.protocol.FinalizationStage
import dev.pocketrig.protocol.TrackingIssue
import dev.pocketrig.protocol.TrackingQuality
import dev.pocketrig.protocol.TrackingStatus
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

/**
 * Renders the redesigned camera screen (variant `01-tray`) beside the current UI.
 *
 * Same device profiles and orientations as [ScreenGallery], so the two variants
 * are compared like-for-like rather than by memory. The state list here is the
 * enumeration from the design brief: a state that is not in this list does not
 * get looked at, and every UI bug this project shipped was a state nobody had
 * looked at.
 */
@RunWith(AndroidJUnit4::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [34])
class TrayGallery {

    @get:Rule
    val compose = createComposeRule()

    private val slot = mutableStateOf<@Composable () -> Unit>({})

    @Test fun small() = renderAll(DEVICE_PROFILES[0])

    @Test fun medium() = renderAll(DEVICE_PROFILES[1])

    @Test fun large() = renderAll(DEVICE_PROFILES[2])

    @Test fun smallLargeFont() = renderAll(DEVICE_PROFILES[3])

    /**
     * Every screen, at every way the phone can be held.
     *
     * There are no landscape device profiles any more, because there is no
     * landscape window any more: the app is pinned to portrait and the phone's
     * orientation only turns the CONTENT. So the axis that used to be
     * portrait-vs-landscape is now the four values of [LocalDeviceRotation], and
     * rendering all four is the only way to see that a turned control still fits
     * the space it reports.
     */
    private fun renderAll(device: DeviceProfile) {
        Renders.writeManifest(VARIANT)
        RuntimeEnvironment.setQualifiers(device.qualifier)
        val rotation = mutableStateOf(0)
        compose.setContent {
            val base = LocalDensity.current
            CompositionLocalProvider(
                LocalDensity provides Density(base.density, device.fontScale),
                LocalDeviceRotation provides rotation.value,
            ) {
                PocketrigTheme {
                    Box(Modifier.fillMaxSize().background(Color.Black)) { slot.value() }
                }
            }
        }
        for (rot in listOf(0, 90, 180, 270)) {
            rotation.value = rot
            for (onScene in listOf(false, true)) {
                val variant = if (onScene) SCENE_VARIANT else VARIANT
                val dir = "${Renders.DIR}/$variant/rot-$rot"

                fun shoot(name: String, content: @Composable () -> Unit) {
                    slot.value = content
                    compose.waitForIdle()
                    compose.onRoot().captureRoboImage("$dir/${name}__${device.id}.png")
                }

                for ((name, landing) in LANDING) {
                    shoot(name) {
                        LandingScreenV2(
                            landing,
                            // The landing screen's camera is pointed at a monitor,
                            // not a room, so it gets its own backdrop. Rendered
                            // over black it was being flattered: nothing competed
                            // with the scan frame.
                            scanner = if (onScene) {
                                { ScannerBackdrop() }
                            } else {
                                null
                            },
                        )
                    }
                }
                for ((name, offline) in OFFLINE) {
                    shoot(name) {
                        OfflineScreenV2(
                            offline,
                            // Through the viewfinder SLOT, not behind the screen:
                            // the frame paints black when that slot is empty, so a
                            // backdrop drawn underneath was simply covered up.
                            viewfinder = if (onScene) {
                                { SceneBackdrop() }
                            } else {
                                null
                            },
                        )
                    }
                }
                for ((name, sheet) in OVERLAYS) {
                    shoot(name) {
                        if (onScene) SceneBackdrop()
                        CameraScreenV2(LIVE_BEHIND_SHEET)
                        // Through the real host, so the render shows what the
                        // operator sees: a sheet standing upright in the world
                        // even when the phone is not.
                        WorldSheetHost(onDismiss = {}) { sheet() }
                    }
                }
                for ((name, state) in STATES) {
                    shoot(name) {
                        if (onScene) SceneBackdrop()
                        CameraScreenV2(state)
                    }
                }
            }
        }
    }

    private companion object {
        const val VARIANT = "01-tray"

        /** The same screens over a stand-in camera image (see SceneBackdrop). */
        const val SCENE_VARIANT = "02-tray-on-scene"

        private val SAMPLE_TAKES = listOf(
            TakeRowUi("t1", "Take 04", "0:12", hasPosition = true, sent = false),
            TakeRowUi("t2", "Dolly in, wide", "0:31", hasPosition = true, sent = true),
            TakeRowUi("t3", "Take 02", "0:07", hasPosition = false, sent = true),
            TakeRowUi(
                "t4",
                "A very long take name that has to truncate somewhere",
                "1:48",
                hasPosition = false,
                sent = false,
            ),
        )

        val OVERLAYS: List<Pair<String, @Composable () -> Unit>> = listOf(
            "20-adjust" to { AdjustSheetV2(AdjustUiState()) },
            // Shake hold switched off: the threshold slider goes away with it,
            // so the sheet is a row shorter. Rendered because a section that
            // changes height is where a layout leaves a hole.
            "20c-adjust-shake-off" to {
                AdjustSheetV2(AdjustUiState(shakeHoldDps = 0f))
            },
            // Locked mid-take: every value here changes what the take records,
            // so the sheet has to read as inert without going blank.
            // The viewport section against a host that can stream, and switched
            // on. The default state above already covers the unavailable case,
            // where the toggle is greyed and carries an extra explanatory line —
            // and the two differ in height, which is where a layout leaves a
            // hole.
            "20d-adjust-viewport-on" to {
                AdjustSheetV2(
                    AdjustUiState(
                        viewportOn = true, viewportAvailable = true,
                        viewportSizes = listOf(1280 to 720, 960 to 540, 640 to 360),
                        viewportSize = 960 to 540,
                        viewportFps = 30,
                        // With a ceiling reported, which is the case that grew
                        // the Refresh row by a line: the host cannot stream
                        // faster than its own viewport redraws, and a control
                        // that quietly stops responding part way up needs to
                        // say so rather than look broken.
                        viewportMaxFps = 30,
                        // Shown, which is the case worth looking at: hidden is
                        // the default and the segment pair is the same height
                        // either way, so this row is about the copy reading
                        // right next to the three cost lines above it.
                        viewportOverlays = true,
                        // Manual, so the two controls a preset replaces are
                        // both on screen; the preset case is the row below.
                        viewportProfile = null,
                    ),
                )
            },
            // The default: Blender choosing. Resolution and Refresh are gone
            // and replaced by what it actually picked, which is the whole
            // point of the control -- the operator states an intent and can
            // still see the consequence.
            "20e-adjust-viewport-auto" to {
                AdjustSheetV2(
                    AdjustUiState(
                        viewportOn = true, viewportAvailable = true,
                        viewportSizes = listOf(1280 to 720, 960 to 540, 640 to 360),
                        viewportProfile = "balanced",
                        viewportChosenSize = 1280 to 720,
                        viewportMaxFps = 30,
                    ),
                )
            },
            "20b-adjust-locked" to {
                AdjustSheetV2(
                    AdjustUiState(
                        positionScale = 2.5f, takeSource = "live",
                        locked = true,
                    ),
                )
            },
            // The streamed frame at every grip. Blender sends it world-upright
            // in the render's aspect whatever the phone is doing, so these four
            // renders must all read the same way up -- and the landscape frame
            // must still fill the width in a portrait grip rather than being
            // fitted to the unturned box and spun into a hole.
            "22-viewport-frame" to {
                Box(Modifier.fillMaxSize().background(Color.Black)) {
                    ViewportImage(
                        ViewportClient.ViewportImage(
                            image = orientationTestFrame(),
                            ordinal = 0, width = 640, height = 360, decodedNs = 0,
                        ),
                    )
                }
            },
            "21-takes" to { TakesSheetV2(TakesUiState(takes = SAMPLE_TAKES)) },
            // A row opened: the only state where Apply, Rename and Delete are
            // visible, and where the 6DOF scale warning appears.
            // Renaming in place: the row that used to hand off to a dialog.
            "21f-takes-renaming" to {
                TakesSheetV2(
                    TakesUiState(
                        takes = SAMPLE_TAKES,
                        expandedId = "t2",
                        renamingId = "t2",
                        renameDraft = "Dolly in, wide",
                    ),
                )
            },
            "21b-takes-expanded" to {
                TakesSheetV2(
                    TakesUiState(
                        takes = SAMPLE_TAKES,
                        expandedId = "t2",
                        positionScale = 2.5f,
                    ),
                )
            },
            // Disconnected: Apply has to say WHY, not just grey out.
            "21c-takes-offline" to {
                TakesSheetV2(
                    TakesUiState(
                        takes = SAMPLE_TAKES,
                        expandedId = "t1",
                        connected = false,
                    ),
                )
            },
            "21d-takes-applying" to {
                TakesSheetV2(TakesUiState(takes = SAMPLE_TAKES, applyingId = "t2"))
            },
            "21e-takes-empty" to { TakesSheetV2(TakesUiState()) },
        )

        /**
         * The landing screen. Rendered full-bleed rather than as an overlay,
         * because unlike the sheets it IS the screen.
         */
        val LANDING: List<Pair<String, LandingUiState>> = listOf(
            "00-landing" to LandingUiState(savedCount = 3, onWifi = true),
            // Nothing saved yet: the Takes control is present but inert, so its
            // existence is learned before it is needed.
            "00b-landing-empty" to LandingUiState(savedCount = 0, onWifi = true),
            // No camera: the scanner cannot run, so the frame goes away rather
            // than drawing a target that cannot be aimed.
            "00c-landing-no-camera" to LandingUiState(cameraReady = false),
            "00d-landing-error" to LandingUiState(
                savedCount = 1,
                onWifi = true,
                error = "That QR code isn't a pocketrig pairing code",
            ),
            // Off Wi-Fi: the commonest reason pairing fails, and the only state
            // where the second status badge appears.
            "00e-landing-no-wifi" to LandingUiState(savedCount = 2, onWifi = false),
            // Permitted but the camera would not open -- usually our own ARCore
            // session still holding it. Unrendered, this is a scan frame over a
            // black rectangle that will never work.
            "00h-landing-camera-busy" to LandingUiState(
                savedCount = 1,
                onWifi = true,
                cameraError = "The camera could not be opened. " +
                    "Another app may be using it.",
            ),
            // Manual entry. Previously unrenderable: the state existed and the
            // link toggled it, but nothing was ever drawn for it.
            "00f-landing-manual" to LandingUiState(
                savedCount = 3,
                onWifi = true,
                manualOpen = true,
                address = "192.168.1.23:47800",
                code = "K3XG9A",
            ),
            // Manual entry that was rejected, with an empty address so the
            // Connect button's disabled state gets looked at too.
            "00g-landing-manual-error" to LandingUiState(
                manualOpen = true,
                onWifi = true,
                error = "Enter the address as ip:port",
            ),
        )

        /** A gentle off-level attitude, so the horizon is visibly doing something. */
        val TILTED = Attitude(rollDeg = -4.5f, pitchDeg = 6f)

        /**
         * Offline recording: the whole no-PC workflow, which had exactly one
         * design state ever looked at before this.
         */
        val OFFLINE: List<Pair<String, OfflineUiState>> = listOf(
            "30-offline-idle" to OfflineUiState(savedCount = 3, attitude = TILTED),
            // Nothing saved and nothing named: what a first-time operator sees.
            "30b-offline-first-run" to OfflineUiState(attitude = TILTED),
            "31-offline-named" to OfflineUiState(
                savedCount = 3, takeName = "Dolly in, wide", attitude = TILTED,
            ),
            // Rolling: elapsed replaces the resting label, Done and the mode
            // switch lock, and the name pill goes inert without going away.
            "32-offline-recording" to OfflineUiState(
                recording = true, elapsedLabel = "0:14", savedCount = 3,
                takeName = "Dolly in, wide", sixDofEnabled = true,
                tracking = TrackingStatus(TrackingQuality.GOOD), attitude = TILTED,
            ),
            "33-offline-6dof-good" to OfflineUiState(
                savedCount = 1, sixDofEnabled = true,
                tracking = TrackingStatus(TrackingQuality.GOOD), attitude = TILTED,
            ),
            "34-offline-6dof-degraded" to OfflineUiState(
                savedCount = 1, sixDofEnabled = true,
                tracking = TrackingStatus(
                    TrackingQuality.DEGRADED, TrackingIssue.INSUFFICIENT_LIGHT,
                ),
                attitude = TILTED,
            ),
            // No ARCore on this phone: the mode switch is locked, not absent.
            "35-offline-no-6dof" to OfflineUiState(
                savedCount = 2, sixDofSupported = false, attitude = TILTED,
            ),
            "36-offline-naming" to OfflineUiState(
                savedCount = 3, namingOpen = true, takeName = "Dolly in, wide",
                attitude = TILTED,
            ),
            // A name long enough to have to truncate somewhere.
            "37-offline-long-name" to OfflineUiState(
                savedCount = 3,
                takeName = "Crane down past the window, second pass",
                attitude = TILTED,
            ),
        )

        /** What sits behind the sheet: an ordinary live screen. */
        val LIVE_BEHIND_SHEET = CameraUiState(
            rttMs = 12, focalMm = 35f, hostLensMm = 35f, attitude = TILTED,
        )


        val STATES: List<Pair<String, CameraUiState>> = listOf(
            "03-live-rotation" to CameraUiState(
                rttMs = 12, attitude = TILTED,
            ),
            "04-live-6dof-good" to CameraUiState(
                rttMs = 9, sixDofEnabled = true,
                tracking = TrackingStatus(TrackingQuality.GOOD),
                focalMm = 35f, hostLensMm = 35f, attitude = TILTED,
            ),
            "05-live-6dof-degraded" to CameraUiState(
                rttMs = 140, sixDofEnabled = true,
                tracking = TrackingStatus(
                    TrackingQuality.DEGRADED, TrackingIssue.INSUFFICIENT_FEATURES,
                ),
                attitude = TILTED,
            ),
            "05b-live-6dof-lost" to CameraUiState(
                rttMs = 22, sixDofEnabled = true,
                tracking = TrackingStatus(
                    TrackingQuality.LOST, TrackingIssue.CAMERA_UNAVAILABLE,
                ),
                attitude = TILTED,
            ),
            "05c-position-held" to CameraUiState(
                rttMs = 14, sixDofEnabled = true,
                tracking = TrackingStatus(TrackingQuality.GOOD),
                positionHeld = true, attitude = TILTED,
            ),
            "06-recording" to CameraUiState(
                rttMs = 11, recording = true, elapsedLabel = "0:07",
                sixDofEnabled = true,
                tracking = TrackingStatus(TrackingQuality.GOOD),
                focalMm = 85f, hostLensMm = 85f, attitude = TILTED,
            ),
            "07-paused" to CameraUiState(rttMs = 11, paused = true),
            "08-finalizing" to CameraUiState(
                rttMs = 11, finalization = FinalizationStage.TRANSFERRING,
                finalizationProgress = 0.45f, attitude = TILTED,
            ),
            "09-reconnecting" to CameraUiState(
                rttMs = null, reconnecting = true, attitude = TILTED,
            ),
            // The lens beyond the rail's travel: the host sits at 300mm, which
            // the phone must show truthfully rather than clamp (see
            // lensTakeoverMm) -- a three-digit label is also the widest the
            // chip ever gets, so it is the layout's worst case.
            "10-lens-beyond-dial-range" to CameraUiState(
                rttMs = 10, focalMm = 300f, hostLensMm = 300f, attitude = TILTED,
            ),
            // Blender owns the lens: what a fresh connection shows. The value
            // is Blender's, dimmed, and no focal length is filled.
            "02b-lens-blender-owned" to CameraUiState(
                rttMs = 12, focalMm = null, hostLensMm = 50f, attitude = TILTED,
            ),
            // Nobody has said what the lens is: the window before the host's
            // first PARAMS, and the case of an animated lens the host declines
            // to report (spec 5.7). The readout has no number to show, so the
            // ruler must not imply one -- rendered because "dimmed enough to
            // read as inactive, legible enough to still be a control" is a
            // judgement that cannot be made from the source.
            "02c-lens-unknown" to CameraUiState(
                rttMs = 12, focalMm = null, hostLensMm = null, attitude = TILTED,
            ),
            // The shake-hold section adds a segmented switch whose OFF state
            // hides the slider below it, so the sheet changes height. Both
            // states are rendered because "does the sheet still fit, and does
            // removing a row leave a hole" is exactly what a render answers and
            // reasoning does not.
            // The zoom dial, open. This is the state the operator spends the
            // most attention in, so it gets rendered rather than assumed.
            "11-lens-mid-range" to CameraUiState(
                rttMs = 10, focalMm = 50f, hostLensMm = 50f, attitude = TILTED,
            ),
            "11b-lens-widest" to CameraUiState(
                rttMs = 10, focalMm = 14f, hostLensMm = 14f, attitude = TILTED,
            ),
            "11c-lens-longest" to CameraUiState(
                rttMs = 10, focalMm = 200f, hostLensMm = 200f,
                sixDofEnabled = true,
                tracking = TrackingStatus(TrackingQuality.GOOD),
                attitude = TILTED,
            ),
            // Host name revealed: what a fresh connection shows briefly, and
            // what a tap on the readout brings back.
            // Axis locked from the dock: the one state where the lock chip is
            // armed, and the worst case for the settings row's width.
            "13-shot-locked" to CameraUiState(
                rttMs = 12, shotLocked = true, sixDofEnabled = true,
                tracking = TrackingStatus(TrackingQuality.GOOD), attitude = TILTED,
            ),
            "12-host-revealed" to CameraUiState(
                rttMs = 12, showHost = true, attitude = TILTED,
            ),
        )
    }
}

/**
 * A frame whose "up" is unmistakable: a wide bar along the TOP and a narrow one
 * down the LEFT, in a landscape aspect.
 *
 * Rendered at each of the four grips, the bar must stay at the top of the
 * picture. A plain colour or a symmetric pattern would render identically
 * whichever way the geometry was wrong, which is the whole failure this is
 * meant to catch.
 */
private fun orientationTestFrame(): androidx.compose.ui.graphics.ImageBitmap {
    val w = 640
    val h = 360
    val bmp = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bmp)
    canvas.drawColor(android.graphics.Color.rgb(70, 70, 78))
    val paint = android.graphics.Paint()
    paint.color = android.graphics.Color.rgb(80, 170, 255)
    canvas.drawRect(0f, 0f, w.toFloat(), 48f, paint)          // TOP
    paint.color = android.graphics.Color.rgb(255, 120, 80)
    canvas.drawRect(0f, 0f, 24f, h.toFloat(), paint)          // LEFT
    return bmp.asImageBitmap()
}
