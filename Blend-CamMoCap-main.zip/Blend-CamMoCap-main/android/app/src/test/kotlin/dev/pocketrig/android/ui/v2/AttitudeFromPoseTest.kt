// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

import dev.pocketrig.protocol.Quaternion
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * The horizon's numbers, checked against known orientations.
 *
 * Worth testing rather than eyeballing: a sign error here produces a horizon that
 * tilts the wrong way, which looks plausible in a still render and is completely
 * wrong in the hand. Every case below is a rotation whose answer is known before
 * the code runs.
 */
class AttitudeFromPoseTest {

    /** Rotation of [deg] about a unit axis, in the protocol's camera frame. */
    private fun about(ax: Float, ay: Float, az: Float, deg: Double): Quaternion {
        val h = Math.toRadians(deg) / 2.0
        val s = sin(h).toFloat()
        return Quaternion(cos(h).toFloat(), ax * s, ay * s, az * s)
    }

    /**
     * A level camera, aimed at the horizon.
     *
     * NOT the identity. The protocol camera looks along its own -Z and the world
     * is Z-up (spec 3), so an identity rotation is aimed straight DOWN -- exactly
     * as a Blender camera with no rotation is. Level is a quarter turn up from
     * there, and every case below is expressed relative to it rather than to
     * identity, which is what these tests originally got wrong.
     */
    private val level = about(1f, 0f, 0f, 90.0)

    /** [q] applied in the camera's own frame, on top of [level]. */
    private fun tilted(q: Quaternion) = level * q

    @Test
    fun `a level camera reads zero`() {
        val a = attitudeOf(level)!!
        assertEquals(0f, a.rollDeg, 1e-3f)
        assertEquals(0f, a.pitchDeg, 1e-3f)
    }

    @Test
    fun `tilting up reads as positive pitch`() {
        // +X is right, so a positive rotation about X lifts the forward axis.
        val a = attitudeOf(tilted(about(1f, 0f, 0f, 30.0)))!!
        assertEquals(30f, a.pitchDeg, 0.05f)
        assertEquals(0f, a.rollDeg, 0.05f)
    }

    @Test
    fun `tilting down reads as negative pitch`() {
        val a = attitudeOf(tilted(about(1f, 0f, 0f, -25.0)))!!
        assertEquals(-25f, a.pitchDeg, 0.05f)
    }

    @Test
    fun `rolling right drops the right-hand side`() {
        // Roll is about the forward axis, which is -Z in the camera frame. The
        // sign convention is what makes the drawn horizon tilt WITH the phone
        // rather than mirror it, so it is asserted rather than assumed.
        val a = attitudeOf(tilted(about(0f, 0f, -1f, 20.0)))!!
        assertEquals(20f, a.rollDeg, 0.05f)
        assertEquals(0f, a.pitchDeg, 0.05f)
    }

    @Test
    fun `rolling left is the mirror of rolling right`() {
        val right = attitudeOf(tilted(about(0f, 0f, -1f, 20.0)))!!
        val left = attitudeOf(tilted(about(0f, 0f, -1f, -20.0)))!!
        assertEquals(-right.rollDeg, left.rollDeg, 0.05f)
    }

    @Test
    fun `panning does not change roll or pitch`() {
        // Yaw is about the camera's up axis. A pan must leave the horizon alone,
        // or the indicator would appear to drift every time the operator turns.
        for (deg in listOf(-170.0, -90.0, 45.0, 90.0, 175.0)) {
            val a = attitudeOf(tilted(about(0f, 1f, 0f, deg)))!!
            assertEquals("yaw $deg leaked into pitch", 0f, a.pitchDeg, 0.05f)
            assertEquals("yaw $deg leaked into roll", 0f, a.rollDeg, 0.05f)
        }
    }

    @Test
    fun `an unnormalised pose gives the same answer`() {
        // Poses arrive off the wire and are not guaranteed unit length; scaling
        // one must not scale the reported angles.
        val q = tilted(about(1f, 0f, 0f, 30.0))
        val scaled = Quaternion(q.w * 3f, q.x * 3f, q.y * 3f, q.z * 3f)
        assertEquals(
            attitudeOf(q)!!.pitchDeg,
            attitudeOf(scaled)!!.pitchDeg,
            1e-3f,
        )
    }

    @Test
    fun `straight up and straight down stay finite`() {
        // The pole cases, where a naive Euler decomposition divides by zero. The
        // horizon must still get a number rather than a NaN it would silently
        // fail to draw.
        for (deg in listOf(89.999, -89.999)) {
            val a = attitudeOf(tilted(about(1f, 0f, 0f, deg)))!!
            assertEquals(deg.toFloat(), a.pitchDeg, 0.05f)
            assertEquals(true, a.rollDeg.isFinite())
        }
    }

    @Test
    fun `a degenerate or non-finite pose reports nothing`() {
        // Null means "draw no horizon". Returning a level attitude from a bad pose
        // would be a confident lie about the one thing this indicator reports.
        assertNull(attitudeOf(Quaternion(0f, 0f, 0f, 0f)))
        assertNull(attitudeOf(Quaternion(Float.NaN, 0f, 0f, 0f)))
        assertNull(attitudeOf(Quaternion(Float.POSITIVE_INFINITY, 0f, 0f, 0f)))
    }
}
