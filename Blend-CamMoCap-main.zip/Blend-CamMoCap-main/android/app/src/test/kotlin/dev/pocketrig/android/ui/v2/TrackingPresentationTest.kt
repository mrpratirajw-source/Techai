// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

import dev.pocketrig.android.R
import dev.pocketrig.protocol.TrackingIssue
import dev.pocketrig.protocol.TrackingQuality
import dev.pocketrig.protocol.TrackingStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * The tracking badge previously froze on whatever it last displayed, because the
 * one unconditional publish ended up inside a branch. These tests exist because
 * that bug was invisible in any static design and shipped to the user's phone.
 */
class TrackingPresentationTest {

    private fun badge(
        enabled: Boolean = true,
        quality: TrackingQuality = TrackingQuality.GOOD,
        issue: TrackingIssue = TrackingIssue.NONE,
        held: Boolean = false,
    ) = trackingBadge(enabled, TrackingStatus(quality, issue), held)

    @Test
    fun `rotation-only shows no badge at all`() {
        // Rotation-only is a complete way to use the app, not a degraded 6DOF.
        // A reassuring green "tracking" badge there would be a lie.
        assertNull(badge(enabled = false))
        assertNull(badge(enabled = false, quality = TrackingQuality.LOST))
    }

    @Test
    fun `every tracking quality yields a badge, so none can go stale`() {
        // The point of totality: there is no input for which the badge has
        // nothing to say and therefore keeps its previous text.
        for (q in TrackingQuality.entries) {
            val spec = badge(quality = q)
            assertEquals("$q produced no badge", true, spec != null)
        }
    }

    @Test
    fun `every issue maps to a specific instruction`() {
        assertEquals(
            R.string.tracking_needs_features,
            badge(
                quality = TrackingQuality.DEGRADED,
                issue = TrackingIssue.INSUFFICIENT_FEATURES,
            )!!.textRes,
        )
        assertEquals(
            R.string.tracking_needs_light,
            badge(
                quality = TrackingQuality.DEGRADED,
                issue = TrackingIssue.INSUFFICIENT_LIGHT,
            )!!.textRes,
        )
        assertEquals(
            R.string.tracking_camera_unavailable,
            badge(
                quality = TrackingQuality.LOST,
                issue = TrackingIssue.CAMERA_UNAVAILABLE,
            )!!.textRes,
        )
    }

    @Test
    fun `losing tracking reads worse than degrading, on the same advice`() {
        val degraded = badge(
            quality = TrackingQuality.DEGRADED,
            issue = TrackingIssue.INSUFFICIENT_LIGHT,
        )!!
        val lost = badge(
            quality = TrackingQuality.LOST,
            issue = TrackingIssue.INSUFFICIENT_LIGHT,
        )!!
        assertEquals("the fix is the same", degraded.textRes, lost.textRes)
        assertEquals(Tone.WARN, degraded.tone)
        assertEquals(Tone.BAD, lost.tone)
    }

    @Test
    fun `a held position outranks good tracking`() {
        // The shake-hold gate is what is affecting the shot right now, so it
        // must not be hidden behind an otherwise-green tracking state.
        val spec = badge(quality = TrackingQuality.GOOD, held = true)!!
        assertEquals(R.string.position_held, spec.textRes)
        assertEquals(Tone.WARN, spec.tone)
    }

    @Test
    fun `good tracking is the only state that reads as live`() {
        assertEquals(Tone.LIVE, badge(quality = TrackingQuality.GOOD)!!.tone)
        for (q in TrackingQuality.entries.filter { it != TrackingQuality.GOOD }) {
            assertEquals("$q must not read as live", true, badge(quality = q)!!.tone != Tone.LIVE)
        }
    }
}
