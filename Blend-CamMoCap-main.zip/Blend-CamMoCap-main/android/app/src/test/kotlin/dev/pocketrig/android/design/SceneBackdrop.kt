// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.design

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import kotlin.math.sin
import kotlin.random.Random

/**
 * A stand-in for the live camera feed, for testing contrast.
 *
 * Every render so far has been over pure black, which flatters any UI. The whole
 * matte-chrome decision rests on the claim that the controls stay legible over a
 * real camera image, and that claim was untested.
 *
 * Drawn rather than photographed on purpose: a checked-in photo would be one
 * arbitrary scene, whereas this deliberately contains the two cases that actually
 * break a dark UI, in one image — a **blown-out highlight** where white text and
 * white strokes disappear, and a **dark region** where a dark panel loses its
 * edge. It is also deterministic, so a contrast regression shows up as a changed
 * render rather than as a differently-lit photograph.
 */
@Composable
internal fun SceneBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxSize()) {
        // Warm mid-tone base, roughly the luminance of a lit interior — the most
        // common thing a phone is pointed at.
        drawRect(
            Brush.linearGradient(
                colors = listOf(
                    Color(0xFFC9A97E),
                    Color(0xFFE8D4B0),
                    Color(0xFF6E5B41),
                ),
                start = Offset(0f, 0f),
                end = Offset(size.width, size.height),
            ),
        )

        // Grain/texture, so the UI is judged against detail rather than a flat
        // wash. Fixed seed: the backdrop must not change between runs.
        val rng = Random(20260726)
        val strokes = (size.width * size.height / 9000f).toInt().coerceIn(200, 4000)
        repeat(strokes) {
            val x = rng.nextFloat() * size.width
            val y = rng.nextFloat() * size.height
            val len = size.minDimension * (0.01f + rng.nextFloat() * 0.03f)
            drawLine(
                color = Color.Black.copy(alpha = 0.05f + rng.nextFloat() * 0.07f),
                start = Offset(x, y),
                end = Offset(x + len * 0.9f, y + len * 0.35f),
                strokeWidth = 1.5f,
            )
        }

        // Blown-out highlight: the case that kills white-on-transparent text.
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White, Color.White.copy(alpha = 0f)),
                center = Offset(size.width * 0.78f, size.height * 0.22f),
                radius = size.minDimension * 0.55f,
            ),
            radius = size.minDimension * 0.55f,
            center = Offset(size.width * 0.78f, size.height * 0.22f),
        )

        // Deep shadow: the case where a dark panel loses its own edge.
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color.Black.copy(alpha = 0.85f),
                    Color.Black.copy(alpha = 0f),
                ),
                center = Offset(size.width * 0.18f, size.height * 0.80f),
                radius = size.minDimension * 0.5f,
            ),
            radius = size.minDimension * 0.5f,
            center = Offset(size.width * 0.18f, size.height * 0.80f),
        )

        // A few hard edges, so overlaid line art has to compete with real
        // contours rather than only with soft gradients.
        for (i in 0..4) {
            val t = (i + 1) / 6f
            drawLine(
                color = Color(0xFF3A2E1E).copy(alpha = 0.5f),
                start = Offset(0f, size.height * t + sin(t * 6f) * 40f),
                end = Offset(size.width, size.height * (t + 0.06f)),
                strokeWidth = 2.5f,
                cap = StrokeCap.Round,
            )
        }
    }
}
