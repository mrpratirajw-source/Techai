// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.design

import java.io.File

/**
 * Where design renders are written, and the device manifest that describes them.
 *
 * Lived on the old `ScreenGallery` until that class was deleted with the screens
 * it drew. The paths outlived it, so they moved here rather than being pinned to
 * whichever gallery happens to exist.
 */
internal object Renders {

    /** Absolute so the PNGs land in .designs/, not in build/. */
    val DIR: String = File(
        System.getProperty("pocketrig.designDir") ?: "../.designs/renders",
    ).absolutePath.replace('\\', '/')

    /**
     * Device metadata for the contact sheet, which scales each render to its true
     * physical size. Without the millimetres, a sheet compares pixel counts,
     * which is the one thing that does not matter about how a phone UI feels.
     */
    fun writeManifest(variant: String) {
        val devices = DEVICE_PROFILES.joinToString(",") { d ->
            """{"id":"${d.id}","label":"${d.label}","widthDp":${d.widthDp},""" +
                """"heightDp":${d.heightDp},"densityDpi":${d.densityDpi},""" +
                """"widthMm":${"%.1f".format(d.physicalWidthMm)},""" +
                """"heightMm":${"%.1f".format(d.physicalHeightMm)},""" +
                """"fontScale":${d.fontScale},"note":"${d.note}"}"""
        }
        val f = File("$DIR/../manifest.json")
        f.parentFile.mkdirs()
        f.writeText("""{"variant":"$variant","devices":[$devices]}""")
    }
}
