// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The auto-hide rule for the zoom dial and the host name.
 *
 * The point of it being a function rather than a timer is that it can be checked
 * at every instant that matters without waiting for any of them.
 */
class TransientRevealTest {

    @Test
    fun `nothing is revealed before it is triggered`() {
        assertFalse(revealActive(sinceMs = null, nowMs = 10_000L, holdMs = 2_000L))
    }

    @Test
    fun `it is active immediately and until the hold elapses`() {
        val t = 10_000L
        assertTrue(revealActive(t, t, 2_000L))
        assertTrue(revealActive(t, t + 1L, 2_000L))
        assertTrue(revealActive(t, t + 1_999L, 2_000L))
    }

    @Test
    fun `it is over exactly at the hold, not after`() {
        // The boundary is asserted because "off by one frame" here is the
        // difference between a control that leaves cleanly and one that flickers.
        val t = 10_000L
        assertFalse(revealActive(t, t + 2_000L, 2_000L))
        assertFalse(revealActive(t, t + 2_001L, 2_000L))
    }

    @Test
    fun `re-triggering restarts the hold`() {
        // What makes the dial survive a series of small adjustments: each touch
        // moves sinceMs forward, so the ruler does not vanish between them.
        val first = 10_000L
        assertFalse(revealActive(first, first + 3_000L, 2_000L))
        val second = first + 2_900L
        assertTrue(revealActive(second, first + 3_000L, 2_000L))
    }

    @Test
    fun `a clock that disagrees with itself keeps the reveal up`() {
        // A negative elapsed means the event reads as being in the future. Better
        // to treat that as "just happened" than to yank a control out from under a
        // finger still resting on it.
        assertTrue(revealActive(sinceMs = 10_000L, nowMs = 9_000L, holdMs = 2_000L))
    }

    @Test
    fun `a zero or negative hold never reveals`() {
        assertFalse(revealActive(10_000L, 10_000L, 0L))
        assertFalse(revealActive(10_000L, 10_000L, -500L))
    }

    @Test
    fun `both real holds are long enough to read and short enough to leave`() {
        // Guards the constants themselves: a hold under a second is a flicker, and
        // one over five seconds is chrome that has stopped being transient.
        for (hold in listOf(LENS_DIAL_HOLD_MS, HOST_NAME_HOLD_MS)) {
            assertTrue("$hold is too brief to read", hold >= 1_000L)
            assertTrue("$hold has stopped being transient", hold <= 5_000L)
        }
    }
}
