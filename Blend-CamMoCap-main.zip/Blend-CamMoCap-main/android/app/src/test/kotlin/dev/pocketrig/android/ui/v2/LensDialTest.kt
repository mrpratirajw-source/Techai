// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The zoom dial's maths, extracted so it can be checked without a screen.
 *
 * The old lens rail's bug was a stale captured value, which no unit test would
 * have caught — but the *feel* of a zoom is arithmetic, and arithmetic is exactly
 * what should not be verified by dragging a finger on a phone.
 */
class LensDialTest {

    @Test
    fun `the dial is logarithmic, so equal travel is equal ratio`() {
        // Half-way along the dial should be the geometric mean of the ends, not
        // the arithmetic one. Linear travel would spend most of the dial in the
        // long end where it changes the shot least.
        val mid = lensFromFraction(0.5f)
        val geometric = Math.sqrt(14.0 * 200.0).toFloat()
        assertEquals(geometric, mid, 0.5f)
    }

    @Test
    fun `fraction and focal length round-trip`() {
        for (mm in listOf(14f, 24f, 35f, 50f, 85f, 135f, 200f)) {
            assertEquals(mm, lensFromFraction(lensFraction(mm)), 0.05f)
        }
    }

    @Test
    fun `the dial cannot travel past its ends`() {
        assertEquals(14f, lensFromFraction(-2f), 1e-3f)
        assertEquals(200f, lensFromFraction(5f), 1e-3f)
        assertEquals(0f, lensFraction(1f), 1e-4f)
        assertEquals(1f, lensFraction(9000f), 1e-4f)
    }

    @Test
    fun `pinch multiplies, so the gesture matches the scale`() {
        // Spreading 20% lengthens the lens 20%: pinch is multiplicative and so
        // is focal length, so no curve fitting is needed between them.
        assertEquals(60f, pinchToFocalMm(50f, 1.2f), 0.01f)
        assertEquals(25f, pinchToFocalMm(50f, 0.5f), 0.01f)
    }

    @Test
    fun `pinch stays inside the dial's travel`() {
        // A hard pinch must not throw the lens somewhere the dial cannot reach.
        assertEquals(200f, pinchToFocalMm(180f, 8f), 0.01f)
        assertEquals(14f, pinchToFocalMm(16f, 0.05f), 0.01f)
    }

    @Test
    fun `a nonsense pinch scale changes nothing`() {
        for (bad in listOf(0f, -1f, Float.NaN, Float.POSITIVE_INFINITY)) {
            assertEquals(50f, pinchToFocalMm(50f, bad), 1e-4f)
        }
    }

    @Test
    fun `detents pull to standard stops only when already close`() {
        assertEquals(50f, snapLensMm(50.4f), 0.01f)
        // ...and leave an intermediate value alone, so aiming between stops is
        // possible. A magnet across the whole gap would make that impossible.
        val between = 42f
        assertEquals(between, snapLensMm(between), 0.01f)
    }

    @Test
    fun `every standard stop is its own detent`() {
        for (stop in LENS_STOPS) {
            assertEquals(stop.toFloat(), snapLensMm(stop.toFloat()), 0.01f)
        }
    }

    @Test
    fun `stops are ordered along the dial`() {
        val fractions = LENS_STOPS.map { lensFraction(it.toFloat()) }
        assertTrue("stops must increase along the dial", fractions == fractions.sorted())
    }
}
