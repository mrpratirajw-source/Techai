// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android

import dev.pocketrig.protocol.Quaternion
import dev.pocketrig.protocol.Vec3
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MotionTraceJsonTest {
    @Test
    fun traceCueCountUsesOneBeepForRoomAndTwoForClose() {
        assertEquals(1, traceCueCount("ROOM"))
        assertEquals(2, traceCueCount("CLOSE"))
        assertEquals(2, traceCueCount("close"))
    }

    @Test
    fun traceSourceDefaultsToThePipelineActuallyRunning() {
        assertEquals("arcore", traceSource(null, activePoseSourceIsAr = true))
        assertEquals("sensor", traceSource(null, activePoseSourceIsAr = false))
        assertEquals("arcore", traceSource(" ARCORE ", activePoseSourceIsAr = false))
        assertEquals("sensor", traceSource("sensor", activePoseSourceIsAr = true))
        assertEquals("arcore", traceSource("unknown", activePoseSourceIsAr = true))
    }

    @Test
    fun cameraExperimentNamesAreStableAndInvalidFocusIsRejected() {
        assertEquals(
            "default_fixed",
            ArCoreCameraExperiment().traceName,
        )
        assertEquals(
            "config_7_auto",
            ArCoreCameraExperiment(7, ArCoreCameraExperiment.Focus.AUTO).traceName,
        )
        assertEquals(ArCoreCameraExperiment.Focus.FIXED, ArCoreCameraExperiment.Focus.parse(null))
        assertNull(ArCoreCameraExperiment.Focus.parse("continuous"))
    }

    @Test
    fun poseModeParserKeepsExperimentNamesExplicit() {
        assertEquals(ArCorePoseMode.RAW, ArCorePoseMode.parse("raw"))
        assertEquals(ArCorePoseMode.ANCHOR_RELATIVE, ArCorePoseMode.parse("anchor"))
        assertEquals(ArCorePoseMode.ANCHOR_RELATIVE, ArCorePoseMode.parse("anchor_relative"))
        assertNull(ArCorePoseMode.parse("automatic"))
    }

    @Test
    fun headerIsValidJsonAndEscapesDeviceStrings() {
        val line = MotionTraceJson.header(
            MotionTraceHeader(
                source = "arcore",
                manufacturer = "Go\"ogle",
                model = "Pixel\\Lab\nRig",
                sdkInt = 35,
                appId = "dev.pocketrig.android",
                versionName = "0.1.0",
                versionCode = 1,
                debug = true,
                startedNs = 42,
            ),
        )
        val root = Json.parseToJsonElement(line).jsonObject
        assertEquals(MotionTraceJson.FORMAT, root.getValue("format").jsonPrimitive.content)
        assertEquals(1, root.getValue("version").jsonPrimitive.content.toInt())
        assertEquals("Go\"ogle", root.getValue("device").jsonObject.getValue("manufacturer").jsonPrimitive.content)
        assertEquals("Pixel\\Lab\nRig", root.getValue("device").jsonObject.getValue("model").jsonPrimitive.content)
    }

    @Test
    fun markerIsTimestampedAndEscaped() {
        val root = Json.parseToJsonElement(
            MotionTraceJson.marker(42, "CLOSE \"A\""),
        ).jsonObject
        assertEquals("marker", root.getValue("kind").jsonPrimitive.content)
        assertEquals("42", root.getValue("observed_ns").jsonPrimitive.content)
        assertEquals("CLOSE \"A\"", root.getValue("label").jsonPrimitive.content)
    }

    @Test
    fun imuSamplePreservesSensorTimeValuesAndAccuracy() {
        val root = Json.parseToJsonElement(
            MotionTraceJson.imu(
                ImuSampleTelemetry(
                    observedNs = 52,
                    sensorNs = 42,
                    sensor = "gyroscope",
                    x = 1.25f,
                    y = -2.5f,
                    z = 0.125f,
                    accuracy = 3,
                ),
            ) ?: error("valid IMU sample rejected"),
        ).jsonObject
        assertEquals("imu", root.getValue("kind").jsonPrimitive.content)
        assertEquals("42", root.getValue("sensor_ns").jsonPrimitive.content)
        assertEquals("gyroscope", root.getValue("sensor").jsonPrimitive.content)
        assertEquals(3, root.getValue("v").jsonArray.size)
        assertEquals("3", root.getValue("accuracy").jsonPrimitive.content)
    }

    @Test
    fun nonFiniteImuSampleIsRejected() {
        assertNull(
            MotionTraceJson.imu(
                ImuSampleTelemetry(
                    observedNs = 52,
                    sensorNs = 42,
                    sensor = "accelerometer",
                    x = Float.NaN,
                    y = 0f,
                    z = 9.8f,
                    accuracy = 3,
                ),
            ),
        )
    }

    @Test
    fun posePreservesSourceAndOmitsInvalidPosition() {
        val line = MotionTraceJson.pose(
            source = "sensor",
            q = Quaternion(1.0, 0.0, 0.0, 0.0),
            sourceNs = 10,
            observedNs = 15,
            pos = null,
        ) ?: error("valid pose rejected")
        val root = Json.parseToJsonElement(line).jsonObject
        assertEquals("pose", root.getValue("kind").jsonPrimitive.content)
        assertEquals("sensor", root.getValue("source").jsonPrimitive.content)
        assertFalse(root.containsKey("p"))
        assertEquals(4, root.getValue("q").jsonArray.size)
    }

    @Test
    fun nonFinitePoseIsRejectedWithoutWritingInvalidJson() {
        assertNull(
            MotionTraceJson.pose(
                source = "arcore",
                q = Quaternion(Double.NaN, 0.0, 0.0, 0.0),
                sourceNs = 10,
                observedNs = 15,
                pos = Vec3(0f, 0f, 0f),
            ),
        )
        assertNull(
            MotionTraceJson.pose(
                source = "arcore",
                q = Quaternion(1.0, 0.0, 0.0, 0.0),
                sourceNs = 10,
                observedNs = 15,
                pos = Vec3(Float.POSITIVE_INFINITY, 0f, 0f),
            ),
        )
    }

    @Test
    fun lostFrameContainsStateButNoPose() {
        val frame = ArCoreFrameTelemetry(
            observedNs = 200,
            frameNs = 190,
            trackingState = "PAUSED",
            failureReason = "INSUFFICIENT_LIGHT",
        )
        val line = MotionTraceJson.arCoreFrame(frame) ?: error("valid frame rejected")
        val root = Json.parseToJsonElement(line).jsonObject
        assertEquals("PAUSED", root.getValue("state").jsonPrimitive.content)
        assertEquals("INSUFFICIENT_LIGHT", root.getValue("reason").jsonPrimitive.content)
        assertFalse(root.containsKey("camera_q"))
        assertFalse(root.containsKey("display_q"))
        assertEquals("raw", root.getValue("pose_mode").jsonPrimitive.content)
        assertEquals("UNAVAILABLE", root.getValue("anchor_state").jsonPrimitive.content)
        assertTrue(MotionTraceJson.tracking(frame).contains("\"kind\":\"tracking\""))
    }

    @Test
    fun anchorFrameCarriesRawAndRelativeRigidPoses() {
        val frame = ArCoreFrameTelemetry(
            observedNs = 200,
            frameNs = 190,
            trackingState = "TRACKING",
            failureReason = "NONE",
            cameraQ = Quaternion.IDENTITY,
            cameraP = Vec3(10f, 0f, 0f),
            displayQ = Quaternion(0.707, 0.0, 0.0, -0.707),
            displayP = Vec3(10f, 0f, 0f),
            poseMode = "anchor_relative",
            anchorGeneration = 3,
            anchorState = "TRACKING",
            anchorQ = Quaternion.IDENTITY,
            anchorP = Vec3(10f, 0f, 0f),
            relativeCameraQ = Quaternion.IDENTITY,
            relativeCameraP = Vec3(0f, 0f, 0f),
            relativeDisplayQ = Quaternion(0.707, 0.0, 0.0, -0.707),
            relativeDisplayP = Vec3(0f, 0f, 0f),
        )
        val line = MotionTraceJson.arCoreFrame(frame) ?: error("valid frame rejected")
        val root = Json.parseToJsonElement(line).jsonObject
        assertEquals("anchor_relative", root.getValue("pose_mode").jsonPrimitive.content)
        assertEquals("3", root.getValue("anchor_generation").jsonPrimitive.content)
        assertEquals("TRACKING", root.getValue("anchor_state").jsonPrimitive.content)
        assertEquals(4, root.getValue("anchor_q").jsonArray.size)
        assertEquals(3, root.getValue("relative_camera_p").jsonArray.size)
        assertEquals(4, root.getValue("relative_display_q").jsonArray.size)
    }

    @Test
    fun frameCarriesOptionalCameraMetadataAndOmitsNonFiniteFocus() {
        val frame = ArCoreFrameTelemetry(
            observedNs = 200,
            frameNs = 190,
            trackingState = "TRACKING",
            failureReason = "NONE",
            afState = 4,
            aeState = 2,
            focusDistanceDiopters = 1.25f,
            exposureTimeNs = 8_333_333,
            sensitivityIso = 320,
        )
        val root = Json.parseToJsonElement(
            MotionTraceJson.arCoreFrame(frame) ?: error("valid frame rejected"),
        ).jsonObject
        assertEquals("4", root.getValue("af_state").jsonPrimitive.content)
        assertEquals("2", root.getValue("ae_state").jsonPrimitive.content)
        assertEquals(1.25f, root.getValue("focus_distance_diopters").jsonPrimitive.content.toFloat())
        assertEquals("8333333", root.getValue("exposure_time_ns").jsonPrimitive.content)
        assertEquals("320", root.getValue("sensitivity_iso").jsonPrimitive.content)

        val invalid = frame.copy(focusDistanceDiopters = Float.NaN)
        val invalidRoot = Json.parseToJsonElement(
            MotionTraceJson.arCoreFrame(invalid) ?: error("metadata must not reject frame"),
        ).jsonObject
        assertFalse(invalidRoot.containsKey("focus_distance_diopters"))
    }

    @Test
    fun configContainsMeasuredCameraProperties() {
        val line = MotionTraceJson.arCoreConfig(
            ArCoreConfigTelemetry(
                observedNs = 1,
                cameraId = "0",
                fpsLower = 30,
                fpsUpper = 30,
                cpuWidth = 640,
                cpuHeight = 480,
                textureWidth = 1920,
                textureHeight = 1080,
                depthSensorUsage = "DO_NOT_USE",
                stereoCameraUsage = "DO_NOT_USE",
                focusMode = "FIXED",
                imageStabilization = "OFF",
                inventoryIndex = 4,
                experimentProfile = "config_4_fixed",
            ),
        )
        val root = Json.parseToJsonElement(line).jsonObject
        assertEquals("arcore_config", root.getValue("kind").jsonPrimitive.content)
        assertEquals("30", root.getValue("fps_range").jsonArray[0].jsonPrimitive.content)
        assertEquals("FIXED", root.getValue("focus_mode").jsonPrimitive.content)
        assertEquals("4", root.getValue("inventory_index").jsonPrimitive.content)
        assertEquals("config_4_fixed", root.getValue("experiment_profile").jsonPrimitive.content)
    }

    @Test
    fun configInventoryPreservesEveryComparableCameraProperty() {
        val line = MotionTraceJson.arCoreConfigInventory(
            ArCoreConfigInventoryTelemetry(
                observedNs = 5,
                configs = listOf(
                    ArCoreCameraConfigTelemetry(
                        cameraId = "0",
                        fpsLower = 30,
                        fpsUpper = 30,
                        cpuWidth = 640,
                        cpuHeight = 480,
                        textureWidth = 1920,
                        textureHeight = 1080,
                        depthSensorUsage = "DO_NOT_USE",
                        stereoCameraUsage = "DO_NOT_USE",
                    ),
                    ArCoreCameraConfigTelemetry(
                        cameraId = "0",
                        fpsLower = 60,
                        fpsUpper = 60,
                        cpuWidth = 1280,
                        cpuHeight = 720,
                        textureWidth = 1280,
                        textureHeight = 720,
                        depthSensorUsage = "REQUIRE_AND_USE",
                        stereoCameraUsage = "REQUIRE_AND_USE",
                    ),
                ),
            ),
        )
        val root = Json.parseToJsonElement(line).jsonObject
        assertEquals("arcore_config_inventory", root.getValue("kind").jsonPrimitive.content)
        val configs = root.getValue("configs").jsonArray
        assertEquals(2, configs.size)
        assertEquals("0", configs[0].jsonObject.getValue("index").jsonPrimitive.content)
        assertEquals("60", configs[1].jsonObject.getValue("fps_range").jsonArray[0].jsonPrimitive.content)
        assertEquals(
            "REQUIRE_AND_USE",
            configs[1].jsonObject.getValue("stereo_camera_usage").jsonPrimitive.content,
        )
    }
}
