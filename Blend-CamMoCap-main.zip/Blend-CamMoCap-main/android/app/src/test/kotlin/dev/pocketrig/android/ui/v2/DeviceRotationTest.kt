// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.ui.v2

import androidx.compose.ui.Alignment
import dev.pocketrig.protocol.Frames
import dev.pocketrig.protocol.Quaternion
import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * The rotation rules, tested away from any screen.
 *
 * These are exactly the sort of thing that looks right in a render taken at one
 * angle and is wrong at another, so they are pure functions with tests rather
 * than arithmetic buried in a composable.
 */
class DeviceRotationTest {

    @Test
    fun snapsToTheNearestUpright() {
        assertEquals(0, quantizeDeviceRotation(2, current = 0))
        assertEquals(90, quantizeDeviceRotation(88, current = 90))
        assertEquals(180, quantizeDeviceRotation(181, current = 180))
        assertEquals(270, quantizeDeviceRotation(275, current = 270))
        // 359 is nearer to 0 than to 270, and must not read as a fourth quadrant.
        assertEquals(0, quantizeDeviceRotation(359, current = 0))
    }

    @Test
    fun holdsTheCurrentQuadrantUntilWellPastHalfway() {
        // 50 degrees is past the 45 midpoint but inside the margin: an operator
        // holding the phone near the diagonal must get ONE answer, not a strobe.
        assertEquals(0, quantizeDeviceRotation(50, current = 0))
        assertEquals(0, quantizeDeviceRotation(59, current = 0))
        // Past the margin, it commits.
        assertEquals(90, quantizeDeviceRotation(61, current = 0))
    }

    @Test
    fun unknownAngleKeepsWhateverWeHad() {
        // ORIENTATION_UNKNOWN is what a phone flat on a table reports, and that
        // is precisely when snapping the UI upright would be most annoying.
        assertEquals(270, quantizeDeviceRotation(-1, current = 270))
    }

    @Test
    fun contentTurnsOppositeToThePhone() {
        assertEquals(0, contentRotationFor(0))
        assertEquals(270, contentRotationFor(90))
        assertEquals(180, contentRotationFor(180))
        assertEquals(90, contentRotationFor(270))
    }

    /**
     * The check that matters: a level shot must draw a level line however the
     * phone is held. attitudeOf reports roll about the camera's forward axis, so
     * holding the phone sideways is itself a 90 degree roll.
     */
    @Test
    fun aLevelShotReadsLevelInEveryGrip() {
        assertEquals(0f, displayRollDeg(0f, 0), 1e-3f)
        assertEquals(0f, displayRollDeg(90f, 90), 1e-3f)
        assertEquals(0f, displayRollDeg(180f, 180), 1e-3f)
        assertEquals(0f, displayRollDeg(-90f, 270), 1e-3f)
    }

    @Test
    fun aTiltedShotKeepsItsTiltInEveryGrip() {
        // Ten degrees off level is ten degrees off level, whichever way you hold
        // the phone. If this ever reported 100, the horizon would be useless
        // sideways while looking perfectly fine in portrait.
        assertEquals(10f, displayRollDeg(10f, 0), 1e-3f)
        assertEquals(10f, displayRollDeg(100f, 90), 1e-3f)
        assertEquals(10f, displayRollDeg(-170f, 180), 1e-3f)
        assertEquals(10f, displayRollDeg(-80f, 270), 1e-3f)
    }

    @Test
    fun displayRollStaysInTheSignedHalfTurn() {
        // Wrapping matters: the horizon draws an angle, and 190 degrees would
        // draw the line upside down rather than 10 degrees the other way.
        assertEquals(-170f, displayRollDeg(190f, 0), 1e-3f)
        assertEquals(180f, displayRollDeg(-180f, 0), 1e-3f)
    }

    /**
     * Sheets anchor to the world's bottom, which is a different edge of the
     * phone in each grip. Getting this wrong slides a sheet in from the side.
     */
    @Test
    fun sheetsRiseFromWhicheverEdgeIsCurrentlyDown() {
        assertEquals(Alignment.BottomCenter, worldBottomAlignment(0))
        assertEquals(Alignment.CenterEnd, worldBottomAlignment(90))
        assertEquals(Alignment.TopCenter, worldBottomAlignment(180))
        assertEquals(Alignment.CenterStart, worldBottomAlignment(270))
    }

    /**
     * The convention, pinned against the real pose maths rather than reasoned.
     *
     * [displayRollDeg] subtracts the device rotation from the roll, which is only
     * correct if turning the phone clockwise makes [attitudeOf] report a POSITIVE
     * roll of the same size. Get that backwards and the horizon reads 180 degrees
     * out sideways -- which looks plausible in a still render and is obviously
     * broken in the hand.
     *
     * Built as: a level portrait shot (camera +Y up, -Z forward, world Z-up),
     * then rolled about the camera's own forward axis by a quarter turn the way
     * an operator turning the phone clockwise would roll it.
     */
    @Test
    fun turningThePhoneClockwiseIsAPositiveRoll() {
        // Level portrait: camera x->world x, y->world z, -z->world -y.
        // That is a +90 degree rotation about world X.
        val h = kotlin.math.sqrt(0.5).toFloat()
        val level = Quaternion(w = h.toDouble(), x = h.toDouble(), y = 0.0, z = 0.0)
        assertEquals(0f, attitudeOf(level)!!.rollDeg, 1e-3f)

        // Clockwise to the operator is a NEGATIVE turn about the camera's +Z,
        // because +Z points back out of the screen toward them.
        val cw90 = multiply(level, Quaternion(w = h.toDouble(), x = 0.0, y = 0.0, z = -h.toDouble()))
        assertEquals(90f, attitudeOf(cw90)!!.rollDeg, 1e-3f)

        // Which is exactly what OrientationEventListener calls 90, so the shot
        // still reads level.
        assertEquals(0f, displayRollDeg(attitudeOf(cw90)!!.rollDeg, 90), 1e-3f)
    }

    private fun multiply(a: Quaternion, b: Quaternion) = Quaternion(
        w = a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z,
        x = a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
        y = a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
        z = a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w,
    )

    /**
     * The shot correction, checked end to end against the roll it exists to undo.
     *
     * Both pose pipelines hand over a PORTRAIT-oriented camera, so holding the
     * phone sideways leaves the virtual camera rolled a quarter turn and the shot
     * arrives in Blender on its side. Frames.shotRotated cancels exactly that.
     *
     * Tested through attitudeOf rather than by comparing quaternion components,
     * because roll is the thing that is actually wrong on screen and component
     * equality would pass for a quaternion that is off by a sign somewhere
     * harmless-looking.
     */
    @Test
    fun shotRotationCancelsTheRollFromHoldingThePhoneSideways() {
        val h = kotlin.math.sqrt(0.5)
        val level = Quaternion(w = h, x = h, y = 0.0, z = 0.0)

        for (deg in listOf(90, 180, 270)) {
            val half = Math.toRadians(deg.toDouble()) / 2.0
            // The phone physically turned clockwise by `deg`: the same
            // construction as turningThePhoneClockwiseIsAPositiveRoll.
            val held = multiply(
                level,
                Quaternion(kotlin.math.cos(half), 0.0, 0.0, -kotlin.math.sin(half)),
            )
            assertEquals(
                "raw roll at $deg",
                deg.toFloat(),
                normalise(attitudeOf(held)!!.rollDeg),
                1e-3f,
            )
            // Corrected for that grip, the shot is level again.
            assertEquals(
                "corrected roll at $deg",
                0f,
                normalise(attitudeOf(Frames.shotRotated(held, deg))!!.rollDeg),
                1e-3f,
            )
        }
    }

    @Test
    fun shotRotationLeavesAnUprightPhoneAlone() {
        val h = kotlin.math.sqrt(0.5)
        val level = Quaternion(w = h, x = h, y = 0.0, z = 0.0)
        assertEquals(level, Frames.shotRotated(level, 0))
    }

    /** Roll wraps; 180 and -180 are the same angle. */
    private fun normalise(deg: Float): Float {
        val d = ((deg % 360f) + 360f) % 360f
        return if (d > 359.999f) 0f else d
    }

    /**
     * A lock fixes the axis, not the grip.
     *
     * Both portrait and landscape have two grips half a turn apart. Pinning
     * "landscape" to one of them made the setting demand the phone be flipped
     * end for end -- so a lock picks whichever of its pair the phone is nearest,
     * and still cannot let portrait become landscape mid-shot.
     */
    @Test
    fun aLockFollowsWhicheverWayRoundThePhoneIsHeld() {
        // Landscape, either way round, is left alone.
        assertEquals(90, shotRotationFor("landscape", 90))
        assertEquals(270, shotRotationFor("landscape", 270))
        // Portrait, either way up, likewise.
        assertEquals(0, shotRotationFor("portrait", 0))
        assertEquals(180, shotRotationFor("portrait", 180))
    }

    @Test
    fun aLockStillOverridesTheOtherAxis() {
        // Held upright but locked to landscape: the lock wins, which is the
        // whole reason it exists.
        assertEquals(90, shotRotationFor("landscape", 0))
        assertEquals(0, shotRotationFor("portrait", 90))
    }

    @Test
    fun autoJustFollowsThePhone() {
        for (d in listOf(0, 90, 180, 270)) {
            assertEquals(d, shotRotationFor("auto", d))
        }
    }

    @Test
    fun angularDistanceTakesTheShortWayRound() {
        assertEquals(2, angularDistanceDeg(359, 1))
        assertEquals(90, angularDistanceDeg(0, 270))
        assertEquals(180, angularDistanceDeg(0, 180))
    }
}
