// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android

import dev.pocketrig.protocol.SessionState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WindowPolicyTest {
    @Test
    fun offlineViewfinderStaysAwakeWhileDisconnected() {
        assertTrue(shouldKeepScreenOn(SessionState.Disconnected, viewfinderActive = true))
    }

    @Test
    fun disconnectedNonCameraScreensMaySleep() {
        assertFalse(shouldKeepScreenOn(SessionState.Disconnected, viewfinderActive = false))
        assertFalse(
            shouldKeepScreenOn(
                SessionState.Connecting("192.168.1.2", 47800),
                viewfinderActive = false,
            ),
        )
    }

    @Test
    fun connectedCameraStatesStayAwakeWithoutViewfinderSignal() {
        assertTrue(
            shouldKeepScreenOn(
                SessionState.Live("Blender"),
                viewfinderActive = false,
            ),
        )
        assertTrue(
            shouldKeepScreenOn(
                SessionState.Recording(
                    serverName = "Blender",
                    startTimestampNs = 1,
                    startedAtWallMs = 1,
                    takeId = "test-take",
                ),
                viewfinderActive = false,
            ),
        )
        assertTrue(
            shouldKeepScreenOn(
                SessionState.Finalizing(
                    serverName = "Blender",
                    takeId = "test-take",
                    stage = dev.pocketrig.protocol.FinalizationStage.BAKING,
                ),
                viewfinderActive = false,
            ),
        )
    }

    // ------------------------------------------------------- record control

    @Test
    fun `recording does not disable its own stop control`() {
        // The regression this guards: the button was gated on a general "busy"
        // flag that included `recording`, so while a take was rolling it rendered
        // as a stop square that could not be pressed. The only way to end a take
        // was the host's scene-end auto-stop.
        assertTrue(recordControlEnabled(finalizing = false, applying = false))
    }

    @Test
    fun `finalization blocks the record control`() {
        // Nothing to stop and nothing new can start until the take is confirmed.
        assertFalse(recordControlEnabled(finalizing = true, applying = false))
    }

    @Test
    fun `an in-flight apply blocks the record control`() {
        assertFalse(recordControlEnabled(finalizing = false, applying = true))
    }

    // ---- Taking the lens must not move the lens (spec 5.7 lens_mm) ----

    @Test
    fun `taking the lens adopts the host's current focal length`() {
        // The whole point: opening the rail is an ownership change, not a lens
        // change, so the first value we drive has to equal what Blender has.
        assertEquals(50f, lensTakeoverMm(50.0), 1e-4f)
        assertEquals(18.0f, lensTakeoverMm(18.0), 1e-4f)
    }

    @Test
    fun `a host lens beyond the rail's travel is adopted, not clamped`() {
        // Clamping 300mm into a 14-200 rail would reframe the shot by the act of
        // opening the control -- the exact bug this replaced.
        assertEquals(300f, lensTakeoverMm(300.0), 1e-4f)
        assertEquals(8f, lensTakeoverMm(8.0), 1e-4f)
    }

    @Test
    fun `an unreported or implausible host lens falls back to neutral`() {
        assertEquals(LENS_FALLBACK_MM, lensTakeoverMm(null), 1e-4f)
        assertEquals(LENS_FALLBACK_MM, lensTakeoverMm(0.0), 1e-4f)
        assertEquals(LENS_FALLBACK_MM, lensTakeoverMm(-50.0), 1e-4f)
        assertEquals(LENS_FALLBACK_MM, lensTakeoverMm(9000.0), 1e-4f)
        assertEquals(LENS_FALLBACK_MM, lensTakeoverMm(Double.NaN), 1e-4f)
        assertEquals(LENS_FALLBACK_MM, lensTakeoverMm(Double.POSITIVE_INFINITY), 1e-4f)
    }
}
