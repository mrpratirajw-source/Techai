// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.design

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.random.Random

/**
 * A stand-in for what the landing screen's camera actually sees: a monitor.
 *
 * [SceneBackdrop] is the wrong test for this screen. The live screen is pointed
 * at a room; the landing screen is pointed at a bright display a metre away in a
 * dim room, which is close to the worst case for white line art — the QR code
 * itself is pure white with hard black detail, and a scan frame drawn over it
 * has to stay visible against both at once.
 *
 * Rendering the landing screen over black, as the gallery did, flattered it
 * badly: the frame looked crisp because nothing was competing with it, and it
 * hid that the frame had no dark underlay at all.
 */
@Composable
internal fun ScannerBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxSize()) {
        // Dim room: a desk lit only by the screen it holds.
        drawRect(
            Brush.linearGradient(
                colors = listOf(
                    Color(0xFF16181D),
                    Color(0xFF23262E),
                    Color(0xFF0C0D10),
                ),
                start = Offset(0f, 0f),
                end = Offset(size.width, size.height),
            ),
        )

        // Off centre, and small enough that the scan frame straddles the bright
        // monitor AND the dark room behind it. Filling the frame with white was
        // only half a test: it never showed the marks over a dark surround.
        val cx = size.width * 0.56f
        val cy = size.height * 0.42f
        val panel = size.minDimension * 0.52f

        // Screen glow spilling into the room.
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color(0xFF9FB4CC).copy(alpha = 0.30f),
                    Color.Transparent,
                ),
                center = Offset(cx, cy),
                radius = panel * 1.5f,
            ),
            radius = panel * 1.5f,
            center = Offset(cx, cy),
        )

        // A monitor, slightly off square to the phone -- nobody lines these up.
        rotate(degrees = -3.5f, pivot = Offset(cx, cy)) {
            val w = panel * 1.30f
            val h = panel * 0.94f
            val tl = Offset(cx - w / 2f, cy - h / 2f)
            drawRect(Color(0xFF05060A), tl, Size(w, h))
            drawRect(
                Color(0xFFE9EDF2),
                Offset(tl.x + w * 0.03f, tl.y + h * 0.04f),
                Size(w * 0.94f, h * 0.92f),
            )

            // The pairing code. Not a real QR payload -- a deterministic block
            // field of the right density, which is all the contrast test needs.
            val q = h * 0.66f
            val qx = cx - q / 2f
            val qy = cy - q / 2f
            val modules = 21
            val cell = q / modules
            val rng = Random(20260726)
            for (row in 0 until modules) {
                for (col in 0 until modules) {
                    if (rng.nextFloat() < 0.46f) {
                        drawRect(
                            Color(0xFF0B0C0F),
                            Offset(qx + col * cell, qy + row * cell),
                            Size(cell, cell),
                        )
                    }
                }
            }
            // Finder squares, so it reads as a QR code rather than as noise.
            for ((fx, fy) in listOf(0 to 0, modules - 7 to 0, 0 to modules - 7)) {
                val ox = qx + fx * cell
                val oy = qy + fy * cell
                drawRect(Color(0xFFE9EDF2), Offset(ox, oy), Size(cell * 7, cell * 7))
                drawRect(Color(0xFF0B0C0F), Offset(ox, oy), Size(cell * 7, cell * 7))
                drawRect(
                    Color(0xFFE9EDF2),
                    Offset(ox + cell, oy + cell),
                    Size(cell * 5, cell * 5),
                )
                drawRect(
                    Color(0xFF0B0C0F),
                    Offset(ox + cell * 2, oy + cell * 2),
                    Size(cell * 3, cell * 3),
                )
            }
        }
    }
}
