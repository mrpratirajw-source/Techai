// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.design

/**
 * Phone profiles the UI has to work on, not just the one on the desk.
 *
 * The point of rendering several is that most layout bugs are size bugs: a rail
 * that fits at 412dp and collides at 360, a status strip that wraps only on a
 * short screen, a control that leaves the safe area on a tall 20:9 panel. One
 * device profile hides all of that.
 *
 * [physicalWidthMm] is the *screen's* width, not the phone's body, and is what
 * lets the contact sheet show every render at true physical size regardless of
 * the reviewer's monitor — the whole point being to judge against a real phone.
 */
internal data class DeviceProfile(
    val id: String,
    val label: String,
    val widthDp: Int,
    val heightDp: Int,
    val densityDpi: Int,
    /** Short edge of the screen in mm — the phone held upright. */
    val shortEdgeMm: Double,
    /** Larger system font, the accessibility case that breaks tight layouts. */
    val fontScale: Float = 1.0f,
    val note: String = "",
    val landscape: Boolean = false,
) {
    private val densityBucket: String = when (densityDpi) {
        in 0..200 -> "hdpi"
        in 201..400 -> "xhdpi"
        in 401..520 -> "xxhdpi"
        else -> "xxxhdpi"
    }

    /**
     * Robolectric qualifier. Orientation sits between the size qualifiers and
     * density, matching Android's resource-qualifier order.
     */
    val qualifier: String
        get() = "w${widthDp}dp-h${heightDp}dp-" +
            (if (landscape) "land-" else "port-") + densityBucket

    val physicalWidthMm: Double
        get() = if (landscape) shortEdgeMm * widthDp / heightDp else shortEdgeMm
    val physicalHeightMm: Double
        get() = if (landscape) shortEdgeMm else shortEdgeMm * heightDp / widthDp

    /**
     * The same physical phone turned on its side. A virtual camera gets held
     * this way a lot — it is how cameras are held — so every screen has to work
     * in a 2:1-ish landscape box, not only a tall portrait one.
     */
    fun landscape(): DeviceProfile = copy(
        widthDp = heightDp,
        heightDp = widthDp,
        landscape = true,
    )
}

/**
 * Deliberately spans the range rather than centring on the dev phone: a small
 * cheap Android, a mainstream mid-size, a large flagship, and the same small
 * device at a large system font — which is where cramped layouts fail first.
 */
internal val DEVICE_PROFILES = listOf(
    DeviceProfile(
        id = "small",
        label = "Small phone · 360×740dp",
        widthDp = 360, heightDp = 740, densityDpi = 320,
        shortEdgeMm = 64.0,
        note = "Budget/compact Android. The tightest layout we must not break.",
    ),
    DeviceProfile(
        id = "medium",
        label = "Mainstream · 393×851dp",
        widthDp = 393, heightDp = 851, densityDpi = 480,
        shortEdgeMm = 68.0,
        note = "Pixel 8 / S24 class. The most common shape.",
    ),
    DeviceProfile(
        id = "large",
        label = "Large flagship · 448×998dp",
        widthDp = 448, heightDp = 998, densityDpi = 480,
        shortEdgeMm = 71.0,
        note = "Pixel 8 Pro class — the development device.",
    ),
    DeviceProfile(
        id = "small-a11y",
        label = "Small + large font · 360×740dp @1.3×",
        widthDp = 360, heightDp = 740, densityDpi = 320,
        shortEdgeMm = 64.0,
        fontScale = 1.3f,
        note = "Same small phone with the system font turned up. Text that " +
            "only just fits at 1.0 overflows here.",
    ),
)

/** Every profile in both orientations — 8 boxes each screen has to survive. */
internal val ALL_PROFILES: List<DeviceProfile> =
    DEVICE_PROFILES + DEVICE_PROFILES.map { it.landscape() }
