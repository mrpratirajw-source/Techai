// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.android.bench

import android.app.Activity

/**
 * The release half of the viewport bench: nothing at all.
 *
 * `MainActivity` calls `installViewportBench` unconditionally, and the variant
 * decides which of these two files is compiled. In release that is this one, so
 * the measurement code, its exported receiver and its `MediaCodec` machinery are
 * not merely unreachable — they are absent from the APK.
 *
 * A `BuildConfig.DEBUG` branch would have been less work and weaker: the
 * bytecode still ships and it falls to R8 to prove it unreachable. For an
 * exported `BroadcastReceiver` that distinction is worth a second file.
 */
@Suppress("UNUSED_PARAMETER")
fun installViewportBench(activity: Activity, onDropViewport: () -> Unit) = Unit
