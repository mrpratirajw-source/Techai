# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# App-specific R8 rules. Deliberately empty so far: Compose, coroutines and
# zxing-android-embedded all ship their own consumer rules, and the app itself
# uses no reflection. Add rules here only with a reproducible release-build
# failure that demands them.
