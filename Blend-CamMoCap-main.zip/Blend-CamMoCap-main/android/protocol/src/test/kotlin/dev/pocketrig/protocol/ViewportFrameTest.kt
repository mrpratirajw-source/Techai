// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

import java.io.ByteArrayInputStream
import java.io.InputStream
import kotlin.test.Test
import kotlin.test.assertContentEquals
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * A framing bug in a stream does not fail loudly. It produces a truncated
 * picture, or reads the next header from the middle of a payload and turns every
 * later frame into garbage — and from inside the app both look like a broken
 * encoder on the other end. So the parser is pinned here, where it is cheap, and
 * against bytes the host actually produces rather than only its own output.
 */
class ViewportFrameTest {

    @Test
    fun `a header round-trips every field`() {
        val bytes = ViewportFrame.encodeHeader(
            ordinal = 4_000_000_000L, // past Int range: the wire field is u32
            captureNs = 26_775_570_277_700L,
            width = 793,
            height = 444,
            payloadLen = 42_697,
        )
        assertEquals(ViewportFrame.HEADER_SIZE, bytes.size)

        val header = assertNotNull(ViewportFrame.parseHeader(bytes))
        assertEquals(4_000_000_000L, header.ordinal, "u32 ordinal must not go negative")
        assertEquals(26_775_570_277_700L, header.captureNs)
        assertEquals(793, header.width)
        assertEquals(444, header.height)
        assertEquals(42_697, header.payloadLen)
        assertEquals("jpeg", header.codecName)
        assertTrue(header.isKeyframe)
    }

    @Test
    fun `the parser agrees with bytes the host actually produced`() {
        // Captured from blender/core/protocol.py's encoder during the live
        // end-to-end verification. Two implementations agreeing on their own
        // output proves nothing; this is the only assertion here that would
        // catch the two drifting apart.
        val hostBytes = byteArrayOf(
            0x50, 0x52, 0x56, 0x50, // "PRVP"
            0x01,                   // version
            0x01,                   // codec: jpeg
            0x01, 0x00,             // flags: keyframe
            0x00, 0x00, 0x00, 0x00, // ordinal 0
            0x00, 0x2C, 0x53, 0x59, 0x59, 0x18, 0x00, 0x00, // capture_ns
            0x78, 0x01,             // width 376
            0xC8.toByte(), 0x00,    // height 200
            0xC9.toByte(), 0xA6.toByte(), 0x00, 0x00, // payload_len 42697
        )
        val header = assertNotNull(
            ViewportFrame.parseHeader(hostBytes),
            "the host's own header must parse here",
        )
        assertEquals(0L, header.ordinal)
        assertEquals(376, header.width)
        assertEquals(200, header.height)
        assertEquals(42_697, header.payloadLen)
        assertTrue(header.isKeyframe)
    }

    @Test
    fun `a malformed header is null, so the caller closes rather than guesses`() {
        val good = ViewportFrame.encodeHeader(1L, 1L, 8, 8, 100)

        val badMagic = good.copyOf().also { it[0] = 'X'.code.toByte() }
        assertNull(ViewportFrame.parseHeader(badMagic), "bad magic")

        val badVersion = good.copyOf().also { it[4] = 9 }
        assertNull(ViewportFrame.parseHeader(badVersion), "wrong version")

        // 0 is reserved precisely so an all-zero buffer cannot decode as valid.
        val zeroCodec = good.copyOf().also { it[5] = 0 }
        assertNull(ViewportFrame.parseHeader(zeroCodec), "codec 0 is reserved")

        assertNull(ViewportFrame.parseHeader(ByteArray(ViewportFrame.HEADER_SIZE)), "all zeroes")
        assertNull(ViewportFrame.parseHeader(good.copyOf(10)), "truncated")
    }

    @Test
    fun `an implausible length is rejected before anything is allocated`() {
        val huge = ViewportFrame.encodeHeader(1L, 1L, 8, 8, ViewportFrame.MAX_PAYLOAD + 1)
        assertNull(ViewportFrame.parseHeader(huge))
        val zero = ViewportFrame.encodeHeader(1L, 1L, 8, 8, 0)
        assertNull(ViewportFrame.parseHeader(zero))
    }

    @Test
    fun `readFully keeps reading past a short read`() {
        // The bug this exists for: InputStream.read may return fewer bytes than
        // asked. A receiver that treats one short read as a whole frame shows a
        // truncated image and then parses the NEXT header from the middle of a
        // payload, so every frame after it is garbage.
        val payload = ByteArray(1000) { (it % 251).toByte() }
        val dribbling = object : InputStream() {
            private val inner = ByteArrayInputStream(payload)
            override fun read(): Int = inner.read()
            override fun read(b: ByteArray, off: Int, len: Int): Int =
                inner.read(b, off, minOf(len, 7)) // never gives you what you asked for
        }
        assertContentEquals(payload, ViewportFrame.readFully(dribbling, payload.size))
    }

    @Test
    fun `readFully returns null when the stream ends early`() {
        val short = ByteArrayInputStream(ByteArray(10))
        assertNull(ViewportFrame.readFully(short, 100))
    }

    @Test
    fun `a non-keyframe is reported as one`() {
        // No v1 codec produces these, but the flag is the transport's permission
        // to drop frames freely, so reading it must not be guesswork.
        val bytes = ViewportFrame.encodeHeader(1L, 1L, 8, 8, 10, keyframe = false)
        assertFalse(assertNotNull(ViewportFrame.parseHeader(bytes)).isKeyframe)
    }

    // ------------------------------------------------------ control messages

    @Test
    fun `viewport control round-trips through the codec`() {
        val encoded = Packets.encode(
            Message.ViewportControl(
                1, 2, "camera", codec = "jpeg", size = 960 to 540,
                fps = 30.0, quality = 75,
            ),
        )
        val decoded = Packets.decode(encoded)
        assertNotNull(decoded)
        assertEquals(Packets.TYPE_VIEWPORT_CONTROL, decoded.msgType)
    }

    @Test
    fun `welcome without viewport keys means the host cannot stream`() {
        // An older host omits them entirely, and we must not connect to a port
        // it never advertised.
        val welcome = Packets.decode(
            Packets.encode(
                Message.Welcome(
                    1, 1, "Blender", "blender", "4.5", "0.1.0",
                    Packets.PROTOCOL_VERSION, 24.0,
                ),
            ),
        )
        val parsed = assertNotNull(welcome as? Message.Welcome)
        assertNull(parsed.viewportPort)
        assertTrue(parsed.viewportSizes.isEmpty())
    }
}
