// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull
import kotlin.test.assertTrue
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.double
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.long

/**
 * The offline-take upload/file body (spec §5.10) is what the host's TCP
 * listener parses; this pins the producer format so the two platforms cannot
 * drift.
 */
class TakeBodyTest {

    private val samples = listOf(
        PoseUpdate(Quaternion(1.0, 0.0, 0.0, 0.0), 1_000L, null),
        PoseUpdate(Quaternion(0.70710678, 0.70710678, 0.0, 0.0), 2_000L, Vec3(1f, -2f, 3f)),
    )

    @Test
    fun `upload body is well-formed JSONL with token and rows`() {
        val text = encodeTakeBody(samples, startNs = 1_000L, endNs = 2_000L, token = "K3XG9A")
            .decodeToString()
        val lines = text.trimEnd('\n').split("\n")
        assertEquals(3, lines.size, "header + 2 rows")

        val header = Json.parseToJsonElement(lines[0]).jsonObject
        assertEquals("pocketrig-take", header["format"]!!.jsonPrimitive.content)
        assertEquals(0, header["version"]!!.jsonPrimitive.int)
        assertEquals("K3XG9A", header["token"]!!.jsonPrimitive.content)
        assertEquals(1_000L, header["start_ns"]!!.jsonPrimitive.long)
        assertEquals(2_000L, header["end_ns"]!!.jsonPrimitive.long)
        assertEquals(2, header["sample_count"]!!.jsonPrimitive.int)

        val rotOnly = Json.parseToJsonElement(lines[1]).jsonObject
        assertEquals(1_000L, rotOnly["t"]!!.jsonPrimitive.long)
        assertEquals(4, rotOnly["q"]!!.jsonArray.size)
        assertNull(rotOnly["p"], "rotation-only sample has no position")

        val sixDof = Json.parseToJsonElement(lines[2]).jsonObject
        assertEquals(3, sixDof["p"]!!.jsonArray.size)
        assertEquals(-2.0, sixDof["p"]!!.jsonArray[1].jsonPrimitive.content.toDouble())
    }

    @Test
    fun `name, id and source ride the upload header (spec 5_11)`() {
        val text = encodeTakeBody(
            samples, 1_000L, 2_000L, token = "K3XG9A",
            name = "Rooftop \"A\"", id = "take-1.take", source = "arcore",
            transactionId = "tx-1",
        ).decodeToString()
        val header = Json.parseToJsonElement(text.trimEnd('\n').split("\n")[0]).jsonObject
        assertEquals("Rooftop \"A\"", header["name"]!!.jsonPrimitive.content)
        assertEquals("take-1.take", header["id"]!!.jsonPrimitive.content)
        assertEquals("arcore", header["source"]!!.jsonPrimitive.content)
        assertEquals("tx-1", header["take_id"]!!.jsonPrimitive.content)
    }

    @Test
    fun `file body omits the token but is otherwise identical`() {
        val fileText = encodeTakeBody(samples, 1_000L, 2_000L, token = null).decodeToString()
        val header = Json.parseToJsonElement(fileText.trimEnd('\n').split("\n")[0]).jsonObject
        assertNull(header["token"], "the on-disk .take body carries no token")
        assertEquals(2, header["sample_count"]!!.jsonPrimitive.int)
        assertTrue(fileText.contains("\"format\":\"pocketrig-take\""))
    }

    @Test
    fun `quality metadata is optional and preserved per row`() {
        val sample = PoseUpdate(
            Quaternion.IDENTITY,
            3_000L,
            null,
            TrackingQuality.LOST,
            TrackingIssue.INSUFFICIENT_LIGHT,
        )
        val row = Json.parseToJsonElement(
            encodeTakeBody(listOf(sample), 3_000L, 3_000L, token = null)
                .decodeToString().trimEnd('\n').split("\n")[1],
        ).jsonObject
        assertEquals("lost", row["quality"]!!.jsonPrimitive.content)
        assertEquals("insufficient_light", row["issue"]!!.jsonPrimitive.content)
        assertNull(row["p"])
    }

    @Test
    fun `a row carries focal length only when the lens is being driven`() {
        // This is the single writer for the row format, used by the upload body
        // AND the durable file. The format previously existed twice and the two
        // drifted: focal length was added to one and missed on the other, so a
        // recorded zoom reached the wire but no take on disk ever had it.
        val sb = StringBuilder()
        appendTakeRow(sb, PoseUpdate(Quaternion.IDENTITY, 1L, null, focalLengthMm = 35f))
        appendTakeRow(sb, PoseUpdate(Quaternion.IDENTITY, 2L, null))
        val rows = sb.toString().trimEnd('\n').split("\n")
        assertEquals(2, rows.size)

        val driven = Json.parseToJsonElement(rows[0]).jsonObject
        assertEquals(35.0, driven["f"]!!.jsonPrimitive.double, 1e-6)
        val notDriven = Json.parseToJsonElement(rows[1]).jsonObject
        assertNull(notDriven["f"], "an undriven lens must not claim a focal length")
    }

    @Test
    fun `a file header omits what is not known yet and carries position_samples`() {
        // The phone's durable .take header shares this writer with the upload
        // body (they were two hand-written copies). Two things it must get right
        // that an upload never exercises:
        //  - at record start end_ns/sample_count are genuinely unknown, and must
        //    be ABSENT rather than null -- the library reader calls getLong on
        //    them and treats a throw as "unfinished".
        //  - position_samples is file-only, and is what the take list uses to
        //    advertise whether a take actually has 6DOF in it.
        val partial = encodeTakeHeader(
            startNs = 100L, endNs = null, sampleCount = null, token = null,
            name = "Take 1", source = "arcore",
        ).decodeToString()
        val open = Json.parseToJsonElement(partial.trimEnd('\n')).jsonObject
        assertNull(open["end_ns"], "end_ns is not known at record start")
        assertNull(open["sample_count"], "sample_count is not known at record start")
        assertNull(open["token"], "a file header must not carry the session token")
        assertEquals("Take 1", open["name"]!!.jsonPrimitive.content)
        assertEquals("arcore", open["source"]!!.jsonPrimitive.content)
        assertEquals(100L, open["start_ns"]!!.jsonPrimitive.long)

        val finalized = encodeTakeHeader(
            startNs = 100L, endNs = 900L, sampleCount = 42, token = null,
            name = "Take 1", source = "arcore", positionCount = 40,
        ).decodeToString()
        val done = Json.parseToJsonElement(finalized.trimEnd('\n')).jsonObject
        assertEquals(900L, done["end_ns"]!!.jsonPrimitive.long)
        assertEquals(42, done["sample_count"]!!.jsonPrimitive.int)
        assertEquals(40, done["position_samples"]!!.jsonPrimitive.int)

        // An upload never reports position_samples, so it must not appear there.
        val upload = encodeTakeHeader(
            startNs = 100L, endNs = 900L, sampleCount = 42, token = "ABC123",
        ).decodeToString()
        val wire = Json.parseToJsonElement(upload.trimEnd('\n')).jsonObject
        assertEquals("ABC123", wire["token"]!!.jsonPrimitive.content)
        assertNull(wire["position_samples"])
    }
}
