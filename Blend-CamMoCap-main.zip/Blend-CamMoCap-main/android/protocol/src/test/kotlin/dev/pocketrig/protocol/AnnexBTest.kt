// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

import kotlin.test.Test
import kotlin.test.assertContentEquals
import kotlin.test.assertEquals
import kotlin.test.assertTrue

/**
 * A decoder fed slightly wrong access units does not fail loudly. It reports a
 * plausible frame count and a plausible latency, and the measurement built on it
 * is quietly wrong -- which is exactly the failure mode this whole measurement
 * pass exists to avoid. So the splitter is pinned against hand-built streams
 * where the right answer is known by construction.
 */
class AnnexBTest {

    private fun nal(type: Int, vararg payload: Byte, fourByte: Boolean = true): ByteArray {
        val start = if (fourByte) byteArrayOf(0, 0, 0, 1) else byteArrayOf(0, 0, 1)
        // Low five bits are the type; the ref_idc bits above are set to a
        // plausible non-zero value so the header is not trivially 0x05.
        val header = ((0x60) or (type and 0x1F)).toByte()
        return start + byteArrayOf(header) + payload
    }

    @Test
    fun `both start code lengths are found`() {
        val data = nal(5, 0xAA.toByte()) + nal(1, 0xBB.toByte(), fourByte = false)
        assertEquals(listOf(0, 6), AnnexB.startCodes(data))
    }

    @Test
    fun `parameter sets attach to the picture that follows`() {
        // SPS + PPS + IDR is one access unit, not three. Feeding them separately
        // makes a decoder wait for a picture that already went past it.
        val sps = nal(7, 0x01)
        val pps = nal(8, 0x02)
        val idr = nal(5, 0x03)
        val units = AnnexB.split(sps + pps + idr)

        assertEquals(1, units.size, "SPS+PPS+IDR is a single access unit")
        assertContentEquals(sps + pps + idr, units[0].bytes)
        assertTrue(units[0].isKeyframe)
    }

    @Test
    fun `consecutive pictures split into one unit each`() {
        val first = nal(5, 0x01)
        val second = nal(1, 0x02)
        val third = nal(1, 0x03)
        val units = AnnexB.split(first + second + third)

        assertEquals(3, units.size)
        assertContentEquals(first, units[0].bytes)
        assertContentEquals(second, units[1].bytes)
        assertContentEquals(third, units[2].bytes)
        assertTrue(units[0].isKeyframe, "IDR is decodable on its own")
        assertTrue(!units[1].isKeyframe, "a non-IDR slice is not")
    }

    @Test
    fun `an all-intra stream is every-frame-a-keyframe`() {
        // The property the whole transport design leans on: with all-intra, any
        // frame may be dropped without corrupting later ones, so the channel
        // needs no retransmission. If this stopped holding, that permission
        // would have to be withdrawn from the spec.
        var stream = ByteArray(0)
        repeat(5) { i -> stream += nal(7, 0x01) + nal(8, 0x02) + nal(5, i.toByte()) }
        val units = AnnexB.split(stream)

        assertEquals(5, units.size)
        assertTrue(units.all { it.isKeyframe }, "every unit must stand alone")
    }

    @Test
    fun `a stream with no start code yields nothing`() {
        assertEquals(emptyList(), AnnexB.split(byteArrayOf(1, 2, 3, 4, 5)))
        assertEquals(emptyList(), AnnexB.split(ByteArray(0)))
    }

    @Test
    fun `every byte of the input survives the split`() {
        // Nothing may be dropped between units: a decoder handed a stream with a
        // hole reports fewer frames rather than an error, which would read as a
        // slow decoder rather than a broken parser.
        var stream = ByteArray(0)
        repeat(4) { i -> stream += nal(7, 0x09) + nal(5, i.toByte(), 0x77) }
        val rejoined = AnnexB.split(stream).fold(ByteArray(0)) { acc, u -> acc + u.bytes }
        assertContentEquals(stream, rejoined)
    }
}
