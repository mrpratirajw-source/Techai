// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.test.Test
import kotlin.test.assertTrue

class RigidPoseTest {
    private val tolerance = 1e-5

    @Test
    fun `identity and inverse round trip arbitrary pose`() {
        val pose = RigidPose(axisAngle(1.0, 2.0, -0.5, 73.0), Vec3(1.25f, -3.5f, 0.2f))
        assertPose(pose, RigidPose.IDENTITY.compose(pose))
        assertPose(RigidPose.IDENTITY, pose.inverse().compose(pose))
        assertPose(RigidPose.IDENTITY, pose.compose(pose.inverse()))
    }

    @Test
    fun `relative pose reconstructs the original world pose`() {
        val reference = RigidPose(axisAngle(0.3, 1.0, 0.2, 41.0), Vec3(4f, -2f, 1f))
        val child = RigidPose(axisAngle(-0.7, 0.2, 1.0, 112.0), Vec3(-3f, 5f, 0.4f))
        val relative = child.relativeTo(reference)
        assertPose(child, reference.compose(relative))
    }

    @Test
    fun `translation remains world aligned under identity rotation anchor`() {
        val initialCamera = RigidPose(axisAngle(1.0, 0.0, 0.0, 65.0), Vec3(3f, 4f, 5f))
        val anchor = RigidPose(Quaternion.IDENTITY, initialCamera.p)
        val movedCamera = RigidPose(initialCamera.q, Vec3(3.25f, 3.5f, 5.75f))
        val relative = movedCamera.relativeTo(anchor)
        assertVec(Vec3(0.25f, -0.5f, 0.75f), relative.p)
        assertQuat(initialCamera.q, relative.q)
    }

    @Test
    fun `common world correction cancels from anchor-relative output`() {
        val anchor = RigidPose(Quaternion.IDENTITY, Vec3(1f, 2f, -3f))
        val camera = RigidPose(axisAngle(0.2, -1.0, 0.4, 38.0), Vec3(2.5f, 1.25f, -1f))
        val correction = RigidPose(axisAngle(0.5, 0.3, 1.0, 127.0), Vec3(-8f, 4f, 6f))
        val before = camera.relativeTo(anchor)
        val after = correction.compose(camera).relativeTo(correction.compose(anchor))
        assertPose(before, after)
    }

    @Test
    fun `composition handles noncommuting rotations and translated child`() {
        val x90 = RigidPose(axisAngle(1.0, 0.0, 0.0, 90.0), Vec3(1f, 0f, 0f))
        val z90 = RigidPose(axisAngle(0.0, 0.0, 1.0, 90.0), Vec3(0f, 2f, 0f))
        val xThenZ = x90.compose(z90)
        val zThenX = z90.compose(x90)
        assertTrue(!sameRotation(xThenZ.q, zThenX.q), "rotations unexpectedly commuted")
        assertTrue(!sameVector(xThenZ.p, zThenX.p), "translations unexpectedly matched")
        assertPose(z90, x90.inverse().compose(xThenZ))
    }

    @Test
    fun `display grip delta is preserved in relative pose`() {
        val anchor = RigidPose(Quaternion.IDENTITY, Vec3(7f, -2f, 0.5f))
        val physical = RigidPose(axisAngle(0.0, 1.0, 0.0, 25.0), anchor.p)
        val gripDelta = RigidPose(axisAngle(0.0, 0.0, 1.0, -90.0), Vec3(0f, 0f, 0f))
        val display = physical.compose(gripDelta)
        val relativePhysical = physical.relativeTo(anchor)
        val relativeDisplay = display.relativeTo(anchor)
        assertPose(relativeDisplay, relativePhysical.compose(gripDelta))
    }

    private fun axisAngle(x: Double, y: Double, z: Double, degrees: Double): Quaternion {
        val length = kotlin.math.sqrt(x * x + y * y + z * z)
        val half = degrees * PI / 360.0
        val scale = sin(half) / length
        return Quaternion(cos(half), x * scale, y * scale, z * scale).normalized()
    }

    private fun assertPose(expected: RigidPose, actual: RigidPose) {
        assertQuat(expected.q, actual.q)
        assertVec(expected.p, actual.p)
    }

    private fun assertQuat(expected: Quaternion, actual: Quaternion) {
        assertTrue(
            sameRotation(expected, actual),
            "expected rotation $expected, got $actual",
        )
    }

    private fun assertVec(expected: Vec3, actual: Vec3) {
        assertTrue(sameVector(expected, actual), "expected position $expected, got $actual")
    }

    private fun sameRotation(a: Quaternion, b: Quaternion): Boolean {
        val dot = abs(a.normalized().dot(b.normalized()))
        return abs(1.0 - dot) < tolerance
    }

    private fun sameVector(a: Vec3, b: Vec3): Boolean =
        abs(a.x - b.x) < tolerance && abs(a.y - b.y) < tolerance && abs(a.z - b.z) < tolerance
}
