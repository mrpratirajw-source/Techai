// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

/** Algebra sanity for [Quaternion]: Hamilton product, conjugate, norm. */
class QuaternionTest {

    private val eps = 1e-12
    private val sqrtHalf = sqrt(0.5)

    private fun assertQuat(expected: Quaternion, actual: Quaternion, msg: String? = null) {
        assertTrue(
            abs(expected.w - actual.w) < 1e-9 &&
                abs(expected.x - actual.x) < 1e-9 &&
                abs(expected.y - actual.y) < 1e-9 &&
                abs(expected.z - actual.z) < 1e-9,
            (msg ?: "quaternion mismatch") + ": expected $expected, got $actual",
        )
    }

    @Test
    fun `identity is the multiplicative unit`() {
        val q = Quaternion(0.5, 0.5, -0.5, 0.5)
        assertQuat(q, q * Quaternion.IDENTITY)
        assertQuat(q, Quaternion.IDENTITY * q)
    }

    @Test
    fun `product times conjugate is identity for unit quaternions`() {
        val q = Quaternion(0.5, 0.5, -0.5, 0.5)
        assertQuat(Quaternion.IDENTITY, q * q.conjugate())
        assertQuat(Quaternion.IDENTITY, q.conjugate() * q)
    }

    @Test
    fun `hamilton product matches the spec worked example`() {
        // coordinate-systems.md §3 worked check: q_sensor ⊗ Rz(−90°).
        val qSensor = Quaternion(0.5, 0.5, -0.5, 0.5)
        val rzMinus90 = Quaternion(sqrtHalf, 0.0, 0.0, -sqrtHalf)
        assertQuat(Quaternion(sqrtHalf, sqrtHalf, 0.0, 0.0), qSensor * rzMinus90)
    }

    @Test
    fun `product order applies the right operand first`() {
        // Rz(90) ⊗ Rx(90): rotate about X first, then Z.
        val rx90 = Quaternion(sqrtHalf, sqrtHalf, 0.0, 0.0)
        val rz90 = Quaternion(sqrtHalf, 0.0, 0.0, sqrtHalf)
        assertQuat(Quaternion(0.5, 0.5, 0.5, 0.5), rz90 * rx90)
        assertQuat(Quaternion(0.5, 0.5, -0.5, 0.5), rx90 * rz90)
    }

    @Test
    fun `norm and normalized behave`() {
        val q = Quaternion(2.0, 0.0, 0.0, 0.0)
        assertEquals(2.0, q.norm(), eps)
        assertQuat(Quaternion.IDENTITY, q.normalized())
        assertEquals(1.0, Quaternion(1.0, 2.0, 3.0, 4.0).normalized().norm(), 1e-12)
        // Degenerate input does not produce NaNs.
        assertQuat(Quaternion.IDENTITY, Quaternion(0.0, 0.0, 0.0, 0.0).normalized())
    }

    @Test
    fun `dot and negated support hemisphere alignment`() {
        val q = Quaternion(sqrtHalf, sqrtHalf, 0.0, 0.0)
        assertTrue(q.dot(q.negated()) < 0)
        assertEquals(1.0, q.dot(q), 1e-12)
        assertQuat(Quaternion(-sqrtHalf, -sqrtHalf, -0.0, -0.0), q.negated())
    }
}
