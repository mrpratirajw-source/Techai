// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue
import kotlinx.serialization.json.double
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.long

/**
 * Phone-side motion thresholds must equal `fixtures/motion_gates.json`.
 *
 * `shake_hold_dps` is the one that genuinely spans the wire: the host holds
 * 6DOF position above it, and this client shows its "position held" cue and
 * marks poses DEGRADED/EXCESSIVE_MOTION from the same computation at the same
 * threshold. If the two drift apart the cue starts lying — the phone claims the
 * camera is being held when it is not, or vice versa. That agreement used to
 * rest on a comment in each language pointing at the other. The host asserts
 * the same fixture in `blender/tests/test_motion_gates.py`.
 */
class MotionGatesTest {
    private val gates by lazy {
        Fixtures.load("motion_gates.json")
            .jsonObject["gates"]!!
            .jsonArray
            .associateBy { it.jsonObject["id"]!!.jsonPrimitive.content }
    }

    private fun value(id: String) = gates.getValue(id).jsonObject["value"]!!.jsonPrimitive

    private fun usedBy(id: String) =
        gates.getValue(id).jsonObject["used_by"]!!.jsonArray
            .map { it.jsonPrimitive.content }
            .toSet()

    @Test
    fun `shake hold gate matches the shared fixture`() {
        assertEquals(value("shake_hold_dps").double, SessionClient.SHAKE_HOLD_DPS)
    }

    @Test
    fun `shake hold gate is declared shared with the host`() {
        assertEquals(setOf("host", "phone"), usedBy("shake_hold_dps"))
    }

    @Test
    fun `tracking quality dwell times match the shared fixture`() {
        // Defaults of TrackingQualityEstimator, which is what ships; the spec
        // states these as section 4.2 SHOULDs for any 6DOF sender.
        val estimator = TrackingQualityEstimator()
        assertEquals(value("quality_warmup_ns").long, estimator.warmupNs)
        assertEquals(value("quality_lost_after_ns").long, estimator.lostAfterNs)
        assertEquals(value("quality_recovery_ns").long, estimator.recoveryNs)
        assertEquals(value("quality_frame_gap_ns").long, estimator.frameGapNs)
    }

    @Test
    fun `every phone gate in the fixture is checked here`() {
        val declared = gates.values
            .filter { "phone" in it.jsonObject["used_by"]!!.jsonArray.map { u -> u.jsonPrimitive.content } }
            .map { it.jsonObject["id"]!!.jsonPrimitive.content }
            .toSet()
        assertEquals(
            setOf(
                "shake_hold_dps",
                "quality_warmup_ns",
                "quality_lost_after_ns",
                "quality_recovery_ns",
                "quality_frame_gap_ns",
            ),
            declared,
            "a gate marked used_by phone was added without an assertion here",
        )
    }

    @Test
    fun `shake gate sits between a deliberate pan and the relocalization guard`() {
        val shake = value("shake_hold_dps").double
        assertTrue(shake > 90.0, "a deliberate pan must not trip the gate")
        assertTrue(
            shake < value("rot_teleport_dps").double,
            "shaking must be caught before the relocalization guard",
        )
    }
}
