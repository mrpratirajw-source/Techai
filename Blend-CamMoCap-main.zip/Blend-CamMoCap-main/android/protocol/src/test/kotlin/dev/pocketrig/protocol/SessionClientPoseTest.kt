// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class SessionClientPoseTest {
    @Test
    fun `ordinary motion does not trigger the fast-motion hold`() {
        val client = SessionClient()
        client.updatePose(Quaternion.IDENTITY, 1_000_000L, Vec3(1f, 2f, 3f), good())
        val update = assertNotNull(
            client.updatePose(
                Quaternion(0.9999619, 0.0, 0.0, 0.0087265),
                101_000_000L,
                Vec3(1.1f, 2f, 3f),
                good(),
            ),
        )
        assertEquals(TrackingQuality.GOOD, update.quality)
        assertFalse(client.fastMotion.value)
    }

    @Test
    fun `aggressive rotation marks raw position invalid without deleting it`() {
        val client = SessionClient()
        client.updatePose(Quaternion.IDENTITY, 1_000_000L, Vec3(1f, 2f, 3f), good())
        val update = assertNotNull(
            client.updatePose(
                Quaternion(0.7071068, 0.0, 0.0, 0.7071068),
                11_000_000L,
                Vec3(9f, 8f, 7f),
                good(),
            ),
        )
        assertEquals(TrackingQuality.DEGRADED, update.quality)
        assertEquals(TrackingIssue.EXCESSIVE_MOTION, update.issue)
        assertEquals(Vec3(9f, 8f, 7f), update.pos)
        assertTrue(client.fastMotion.value)
    }

    // ---------------------------------------------------------------- source
    // The two pipelines sit in unrelated world frames, so a pose from the
    // outgoing one arriving after a switch is not merely late: it is expressed
    // in the frame the host is trying to leave. A pipeline can still be inside a
    // frame callback when the switch happens, which is why rapid 6DOF toggling
    // made the inter-source yaw stick instead of cancelling.

    @Test
    fun `a pose from the inactive source is dropped`() {
        val client = SessionClient()
        client.setActivePoseSource(PoseSource.ARCORE)
        assertNull(
            client.updatePose(
                Quaternion.IDENTITY, 1_000_000L, source = PoseSource.SENSOR,
            ),
            "a sensor pose must not land once ARCore is authoritative",
        )
        assertNotNull(
            client.updatePose(
                Quaternion.IDENTITY, 2_000_000L, Vec3(1f, 2f, 3f), good(),
                source = PoseSource.ARCORE,
            ),
        )
    }

    @Test
    fun `switching authority flips which source is accepted`() {
        val client = SessionClient()
        client.setActivePoseSource(PoseSource.SENSOR)
        assertNotNull(
            client.updatePose(
                Quaternion.IDENTITY, 1_000_000L, source = PoseSource.SENSOR,
            ),
        )
        assertNull(
            client.updatePose(
                Quaternion.IDENTITY, 2_000_000L, Vec3(1f, 2f, 3f), good(),
                source = PoseSource.ARCORE,
            ),
            "an ARCore pose must not land while the sensor is authoritative",
        )
    }

    @Test
    fun `an untagged pose is always accepted`() {
        // Callers that do not participate in source switching (tests, tools)
        // must keep working unchanged.
        val client = SessionClient()
        client.setActivePoseSource(PoseSource.ARCORE)
        assertNotNull(client.updatePose(Quaternion.IDENTITY, 1_000_000L))
    }

    @Test
    fun `the sensor is authoritative before anything declares a source`() {
        val client = SessionClient()
        assertNotNull(
            client.updatePose(
                Quaternion.IDENTITY, 1_000_000L, source = PoseSource.SENSOR,
            ),
            "the rotation-vector path is the default source at startup",
        )
    }

    // ------------------------------------------------- continuous output frame
    // The two pipelines have unrelated world frames (measured: a fixed ~90 deg
    // yaw). Rather than emit a seam and rely on the host absorbing it -- which
    // depended on a control message, a threshold, and a race, and so was
    // intermittent -- the emitted stream is made continuous by construction.

    private fun yawDeg(deg: Double): Quaternion {
        val h = Math.toRadians(deg) / 2.0
        return Quaternion(kotlin.math.cos(h), 0.0, 0.0, kotlin.math.sin(h))
    }

    private fun angleBetween(a: Quaternion, b: Quaternion): Double {
        val d = kotlin.math.min(1.0, kotlin.math.abs(a.dot(b)))
        return Math.toDegrees(2.0 * kotlin.math.acos(d))
    }

    @Test
    fun `a source switch emits no orientation step`() {
        val client = SessionClient()
        client.setActivePoseSource(PoseSource.SENSOR)
        val last = assertNotNull(
            client.updatePose(yawDeg(10.0), 1_000_000L, source = PoseSource.SENSOR),
        )
        // ARCore's frame is 90 deg away from the sensor's for the same pose.
        client.setActivePoseSource(PoseSource.ARCORE)
        val first = assertNotNull(
            client.updatePose(
                yawDeg(100.0), 11_000_000L, Vec3(1f, 0f, 0f), good(),
                source = PoseSource.ARCORE,
            ),
        )
        assertTrue(
            angleBetween(last.q, first.q) < 1e-6,
            "first pose after a switch must equal the last emitted pose, " +
                "got ${angleBetween(last.q, first.q)} deg",
        )
    }

    @Test
    fun `motion after a switch is preserved, only the frame is rotated`() {
        val client = SessionClient()
        client.setActivePoseSource(PoseSource.SENSOR)
        client.updatePose(yawDeg(10.0), 1_000_000L, source = PoseSource.SENSOR)
        client.setActivePoseSource(PoseSource.ARCORE)
        val a = assertNotNull(
            client.updatePose(
                yawDeg(100.0), 101_000_000L, Vec3(1f, 0f, 0f), good(),
                source = PoseSource.ARCORE,
            ),
        )
        // The source then rotates 7 deg; the emitted stream must rotate 7 deg.
        val b = assertNotNull(
            client.updatePose(
                yawDeg(107.0), 201_000_000L, Vec3(1f, 0f, 0f), good(),
                source = PoseSource.ARCORE,
            ),
        )
        assertEquals(7.0, angleBetween(a.q, b.q), 1e-6)
    }

    @Test
    fun `position is rotated with the frame so q and p stay one rigid pair`() {
        // Spec 3.1: a sender must never correct the quaternion alone. If p were
        // left unrotated, 6DOF translation would land on the wrong axes -- the
        // exact defect that made an earlier sender-side correction be reverted.
        val client = SessionClient()
        client.setActivePoseSource(PoseSource.SENSOR)
        client.updatePose(Quaternion.IDENTITY, 1_000_000L, source = PoseSource.SENSOR)
        client.setActivePoseSource(PoseSource.ARCORE)
        // Raw frame is yawed +90 deg, so the correction is -90 deg about Z and
        // must take +X to -Y.
        val u = assertNotNull(
            client.updatePose(
                yawDeg(90.0), 11_000_000L, Vec3(1f, 0f, 0f), good(),
                source = PoseSource.ARCORE,
            ),
        )
        val p = assertNotNull(u.pos)
        assertEquals(0.0, p.x.toDouble(), 1e-5)
        assertEquals(-1.0, p.y.toDouble(), 1e-5)
        assertEquals(0.0, p.z.toDouble(), 1e-5)
    }

    @Test
    fun `toggling back and forth never accumulates a step`() {
        // The reported symptom: rapid toggling spun the camera 90 deg at a time
        // and came back after four. Continuity must hold for every switch.
        val client = SessionClient()
        client.setActivePoseSource(PoseSource.SENSOR)
        var t = 1_000_000L
        var previous = assertNotNull(
            client.updatePose(yawDeg(10.0), t, source = PoseSource.SENSOR),
        )
        for (i in 1..8) {
            val toArcore = i % 2 == 1
            client.setActivePoseSource(
                if (toArcore) PoseSource.ARCORE else PoseSource.SENSOR,
            )
            t += 100_000_000L
            // Each source reports the same physical pose in its own frame.
            val raw = if (toArcore) yawDeg(100.0) else yawDeg(10.0)
            val next = assertNotNull(
                client.updatePose(
                    raw, t,
                    if (toArcore) Vec3(1f, 0f, 0f) else null,
                    if (toArcore) good() else TrackingQuality.UNKNOWN,
                    source = if (toArcore) PoseSource.ARCORE else PoseSource.SENSOR,
                ),
            )
            assertTrue(
                angleBetween(previous.q, next.q) < 1e-6,
                "switch $i introduced ${angleBetween(previous.q, next.q)} deg",
            )
            previous = next
        }
    }

    @Test
    fun `the shake gate does not fire on a source switch`() {
        // A 90 deg seam across one pose interval reads as thousands of deg/s and
        // used to trip the fast-motion cue. Measuring the corrected stream makes
        // that impossible.
        val client = SessionClient()
        client.setActivePoseSource(PoseSource.SENSOR)
        client.updatePose(yawDeg(10.0), 1_000_000L, source = PoseSource.SENSOR)
        client.setActivePoseSource(PoseSource.ARCORE)
        client.updatePose(
            yawDeg(100.0), 11_000_000L, Vec3(1f, 0f, 0f), good(),
            source = PoseSource.ARCORE,
        )
        assertFalse(client.fastMotion.value)
    }

    /** ~800 deg/s for [samples] poses: a genuine shake, above the 500 default. */
    private fun shake(client: SessionClient, samples: Int = 8): Long {
        var ts = 1_000_000L
        client.updatePose(yawDeg(0.0), ts, Vec3(1f, 2f, 3f), good())
        for (i in 1..samples) {
            ts += 10_000_000L
            client.updatePose(yawDeg(8.0 * i), ts, Vec3(1f, 2f, 3f), good())
        }
        return ts
    }

    @Test
    fun `the host's shake threshold is used, not our default`() {
        // The cue and the host's hold have to agree, so the threshold is
        // mirrored (spec 5.7). Using our own constant while the host uses
        // another does not make the cue approximate -- it makes it describe
        // something that is not happening.
        val client = SessionClient()
        client.sendParams(0.3, 0.15, 1.0, shakeHoldDps = 900.0)
        shake(client)
        assertFalse(
            client.fastMotion.value,
            "an 800 deg/s shake must not trip a 900 deg/s gate",
        )
    }

    @Test
    fun `a zero threshold switches the hold off entirely`() {
        // 0 means the operator turned the gate off (spec 5.7). The phone must
        // then never claim a hold, and never mark a pose EXCESSIVE_MOTION --
        // that marking is what makes an offline take's position invalid.
        val client = SessionClient()
        client.sendParams(0.3, 0.15, 1.0, shakeHoldDps = 0.0)
        val ts = shake(client)
        val update = assertNotNull(
            client.updatePose(yawDeg(80.0), ts + 10_000_000L, Vec3(4f, 5f, 6f), good()),
        )
        assertFalse(client.fastMotion.value, "the hold is off; nothing may be held")
        assertEquals(TrackingQuality.GOOD, update.quality)
        assertEquals(TrackingIssue.NONE, update.issue)
        assertEquals(Vec3(4f, 5f, 6f), update.pos, "position stays valid when off")
    }

    @Test
    fun `the default threshold still catches a real shake`() {
        // The counterweight to the two above: raising the default and adding an
        // off switch must not quietly disable the feature for everyone else.
        val client = SessionClient()
        shake(client)
        assertTrue(client.fastMotion.value, "800 deg/s must trip the 500 default")
    }

    @Test
    fun `turning the phone is not a shake`() {
        // The shot axis is quantized, so a continuous turn of the phone produces
        // one discrete quarter-turn step in the emitted pose at the moment the
        // quadrant flips. That is our own relabelling -- `shotRotated` rolling
        // the camera to cancel the grip -- and the device may not have moved at
        // all. Measured as motion it reads as thousands of deg/s, so simply
        // turning the phone lit "position held" and made the host hold with it.
        val client = SessionClient()
        var ts = 1_000_000L
        repeat(5) {
            ts += 10_000_000L
            client.updatePose(yawDeg(0.0), ts, Vec3(1f, 2f, 3f), good())
        }
        assertFalse(client.fastMotion.value, "a still phone is not shaking")

        client.shotRotationDeg = 90 // the quadrant flips; the phone is still
        repeat(5) {
            ts += 10_000_000L
            client.updatePose(yawDeg(0.0), ts, Vec3(1f, 2f, 3f), good())
        }
        assertFalse(
            client.fastMotion.value,
            "a shot-axis change is a relabelling, not device motion",
        )
    }

    @Test
    fun `with no host connected the phone uses its own threshold`() {
        // The gate runs offline too: it marks rows EXCESSIVE_MOTION, and those
        // marks travel in the take file and decide whether Blender treats that
        // stretch as having valid position. So the operator's choice has to
        // survive having no host to mirror it.
        val client = SessionClient()
        client.localShakeHoldDps = 0.0
        shake(client)
        assertFalse(
            client.fastMotion.value,
            "the phone's own 'off' must hold with no host connected",
        )

        val strict = SessionClient()
        strict.localShakeHoldDps = 200.0
        shake(strict, samples = 4)
        assertTrue(strict.fastMotion.value, "a lowered local threshold must bite")
    }

    @Test
    fun `a reference boundary discards the smoothed speed`() {
        // The gate reads a SMOOTHED angular speed, deliberately, so that noise
        // and single-sample spikes cannot fire it. That average is derived from
        // the previous pose, so a boundary that forgets the previous pose must
        // forget the average too -- otherwise a real shake before the boundary
        // keeps the cue lit afterwards, on evidence that no longer exists, and
        // the host holds 6DOF position at the moment tracking is meant to resume.
        val client = SessionClient()
        client.updatePose(yawDeg(0.0), 1_000_000L, Vec3(1f, 2f, 3f), good())
        // ~800 deg/s: a genuine shake, well above the 300 deg/s gate.
        var ts = 1_000_000L
        for (i in 1..8) {
            ts += 10_000_000L
            client.updatePose(yawDeg(8.0 * i), ts, Vec3(1f, 2f, 3f), good())
        }
        assertTrue(client.fastMotion.value, "a real shake must still fire the gate")

        // Teardown is a reference boundary: it drops the pose history, and the
        // pipelines keep calling updatePose regardless of session state.
        client.disconnect()

        // Two calm poses. Without the fix the second one revives the cue from
        // the stale average alone, with the phone provably still.
        val calm = yawDeg(64.0)
        ts += 10_000_000L
        client.updatePose(calm, ts, Vec3(1f, 2f, 3f), good())
        ts += 10_000_000L
        val update = assertNotNull(
            client.updatePose(calm, ts, Vec3(1f, 2f, 3f), good()),
        )
        assertFalse(
            client.fastMotion.value,
            "a held-still phone must not report fast motion after a boundary",
        )
        assertEquals(TrackingQuality.GOOD, update.quality)
        assertEquals(Vec3(1f, 2f, 3f), update.pos)
    }

    @Test
    fun `the frame correction is rigid under non-commuting 3D rotations`() {
        // THE test for this mechanism. A previous sender-side correction (commit
        // 6b4dfbc, reverted) rotated the quaternion and left position in the raw
        // frame, so 6DOF translation followed wrong axes. Its tests used
        // Z-only rotations, which commute, and missed it entirely.
        //
        // The frame-agnostic invariant: position expressed in the CAMERA frame
        // must be untouched by a world-frame re-framing, because
        //     (W q)^-1 . (W p) == q^-1 . p
        // holds only if BOTH were rotated by the same W. Rotate one and not the
        // other and this fails immediately.
        fun axis(x: Double, y: Double, z: Double, deg: Double): Quaternion {
            val h = Math.toRadians(deg) / 2.0
            val n = kotlin.math.sqrt(x * x + y * y + z * z)
            val s = kotlin.math.sin(h) / n
            return Quaternion(kotlin.math.cos(h), x * s, y * s, z * s).normalized()
        }
        // Deliberately non-commuting: three different axes, awkward angles.
        val sensorPose = axis(0.0, 0.0, 1.0, 37.0) * axis(1.0, 0.0, 0.0, 51.0)
        val rawQ = (axis(0.0, 1.0, 0.0, 113.0) * axis(1.0, 0.0, 0.0, -29.0) *
            axis(0.0, 0.0, 1.0, 64.0)).normalized()
        val rawP = Vec3(0.37f, -1.24f, 2.06f)

        val client = SessionClient()
        client.setActivePoseSource(PoseSource.SENSOR)
        client.updatePose(sensorPose, 1_000_000L, source = PoseSource.SENSOR)
        client.setActivePoseSource(PoseSource.ARCORE)
        val out = assertNotNull(
            client.updatePose(
                rawQ, 101_000_000L, rawP, good(), source = PoseSource.ARCORE,
            ),
        )
        val emittedP = assertNotNull(out.pos)

        val rawInCamera = rawQ.conjugate().rotate(rawP)
        val emittedInCamera = out.q.conjugate().rotate(emittedP)
        assertEquals(rawInCamera.x.toDouble(), emittedInCamera.x.toDouble(), 1e-4)
        assertEquals(rawInCamera.y.toDouble(), emittedInCamera.y.toDouble(), 1e-4)
        assertEquals(rawInCamera.z.toDouble(), emittedInCamera.z.toDouble(), 1e-4)
        // And the distance from the tracking origin is a rotation invariant.
        fun len(v: Vec3) = kotlin.math.sqrt(
            (v.x * v.x + v.y * v.y + v.z * v.z).toDouble(),
        )
        assertEquals(len(rawP), len(emittedP), 1e-4)
    }

    @Test
    fun `subsequent translation follows the re-framed axes`() {
        // The user-visible half of the same property: after a switch, moving the
        // source by D must move the emitted position by the SAME D re-expressed
        // in the output frame -- same magnitude, same relationship to the camera.
        fun axis(x: Double, y: Double, z: Double, deg: Double): Quaternion {
            val h = Math.toRadians(deg) / 2.0
            val n = kotlin.math.sqrt(x * x + y * y + z * z)
            val s = kotlin.math.sin(h) / n
            return Quaternion(kotlin.math.cos(h), x * s, y * s, z * s).normalized()
        }
        val client = SessionClient()
        client.setActivePoseSource(PoseSource.SENSOR)
        client.updatePose(
            axis(0.0, 0.0, 1.0, 15.0) * axis(1.0, 0.0, 0.0, 40.0),
            1_000_000L, source = PoseSource.SENSOR,
        )
        client.setActivePoseSource(PoseSource.ARCORE)
        val heldQ = (axis(0.0, 1.0, 0.0, 95.0) * axis(1.0, 0.0, 0.0, 22.0)).normalized()
        val a = assertNotNull(
            client.updatePose(
                heldQ, 101_000_000L, Vec3(1f, 1f, 1f), good(), source = PoseSource.ARCORE,
            ),
        )
        val b = assertNotNull(
            client.updatePose(
                heldQ, 201_000_000L, Vec3(1.5f, 1f, 1f), good(), source = PoseSource.ARCORE,
            ),
        )
        val pa = assertNotNull(a.pos)
        val pb = assertNotNull(b.pos)
        val moved = kotlin.math.sqrt(
            ((pb.x - pa.x) * (pb.x - pa.x) + (pb.y - pa.y) * (pb.y - pa.y) +
                (pb.z - pa.z) * (pb.z - pa.z)).toDouble(),
        )
        assertEquals(0.5, moved, 1e-4, "a 0.5 m source move must emit a 0.5 m move")
    }

    @Test
    fun `a recovery alignment is continuous and needs no round-trip`() {
        // Recovering from a tracking loss must re-align the frame WITHOUT
        // gating the pose stream: it happens constantly in a handheld shot, and
        // a round-trip per recovery is a visible hitch in the preview.
        val client = SessionClient()
        client.setActivePoseSource(PoseSource.ARCORE)
        val before = assertNotNull(
            client.updatePose(
                yawDeg(20.0), 1_000_000L, Vec3(1f, 0f, 0f), good(),
                source = PoseSource.ARCORE,
            ),
        )
        // ARCore returns from a blind run with a relocalized reference.
        client.requestFrameAlignment()
        val after = assertNotNull(
            client.updatePose(
                yawDeg(65.0), 101_000_000L, Vec3(1f, 0f, 0f), good(),
                source = PoseSource.ARCORE,
            ),
        )
        assertTrue(
            angleBetween(before.q, after.q) < 1e-6,
            "recovery must not step the emitted orientation, got " +
                "${angleBetween(before.q, after.q)} deg",
        )
    }

    private fun good() = TrackingQuality.GOOD
}
