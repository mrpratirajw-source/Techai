// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue
import kotlinx.serialization.json.double
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.long

/**
 * Replays recorded Pixel 8 Pro traces through the detector.
 *
 * This is deliberately real device evidence rather than synthetic input: the
 * failure it guards against — ARCore reporting healthy TRACKING while blind and
 * dead-reckoning 6.18 cm that never happened — was invisible to every synthetic
 * test and to `trackingState` itself, and was only found by covering the lens and
 * measuring. Keeping the recording makes it a regression test instead of an
 * anecdote.
 */
class MotionCorroborationTest {

    private val fixture by lazy {
        Fixtures.load("motion_corroboration.json").jsonObject
    }

    private fun thresholds() = fixture["thresholds"]!!.jsonObject

    private fun detector() = thresholds().let { t ->
        MotionCorroboration(
            windowNs = t["window_ns"]!!.jsonPrimitive.long,
            netDisplacementM = t["net_displacement_m"]!!.jsonPrimitive.double,
            restAccelRms = t["rest_accel_rms"]!!.jsonPrimitive.double,
            restGyroRms = t["rest_gyro_rms"]!!.jsonPrimitive.double,
            sustainNs = t["sustain_ns"]!!.jsonPrimitive.long,
            holdNs = t["hold_ns"]!!.jsonPrimitive.long,
            minPoses = t["min_poses"]!!.jsonPrimitive.int,
            minImu = t["min_imu"]!!.jsonPrimitive.int,
        )
    }

    /** Feed one regime in timestamp order, exactly as the phone would. */
    private fun replay(name: String): Pair<MotionCorroboration, Boolean> {
        val regime = fixture["regimes"]!!.jsonObject[name]!!.jsonObject
        val poses = regime["poses_t_xyz"]!!.jsonArray.map { it.jsonArray }
        val imu = regime["imu_t_kind_xyz"]!!.jsonArray.map { it.jsonArray }
        val det = detector()
        var everFlagged = false
        var pi = 0
        var ii = 0
        while (pi < poses.size || ii < imu.size) {
            val pt = if (pi < poses.size) poses[pi][0].jsonPrimitive.long else Long.MAX_VALUE
            val it0 = if (ii < imu.size) imu[ii][0].jsonPrimitive.long else Long.MAX_VALUE
            if (it0 <= pt) {
                val row = imu[ii++]
                val v = Vec3(
                    row[2].jsonPrimitive.double.toFloat(),
                    row[3].jsonPrimitive.double.toFloat(),
                    row[4].jsonPrimitive.double.toFloat(),
                )
                if (row[1].jsonPrimitive.int == 0) det.onAccel(v, it0) else det.onGyro(v, it0)
            } else {
                val row = poses[pi++]
                det.onPose(
                    Vec3(
                        row[1].jsonPrimitive.double.toFloat(),
                        row[2].jsonPrimitive.double.toFloat(),
                        row[3].jsonPrimitive.double.toFloat(),
                    ),
                    pt,
                )
                if (!det.corroborated) everFlagged = true
            }
        }
        return det to everFlagged
    }

    private fun expectation(name: String): Boolean =
        fixture["regimes"]!!.jsonObject[name]!!.jsonObject["expect_corroborated"]!!
            .jsonPrimitive.content.toBoolean()

    @Test
    fun `a still phone with a clear lens is never flagged`() {
        val (_, flagged) = replay("still_lens_clear")
        assertFalse(flagged, "honest tracking must not be called invented")
        assertTrue(expectation("still_lens_clear"))
    }

    @Test
    fun `a still phone after recovery is never flagged`() {
        val (_, flagged) = replay("still_after_recovery")
        assertFalse(flagged)
    }

    @Test
    fun `a covered lens dead-reckoning while still IS caught`() {
        val (det, flagged) = replay("still_lens_covered")
        assertTrue(
            flagged,
            "6.18 cm of invented translation over a still phone must be detected",
        )
        assertFalse(det.corroborated, "the verdict must still stand at the end of the drift")
        assertFalse(expectation("still_lens_covered"))
    }

    @Test
    fun `a handheld phone with a clear lens is never flagged`() {
        // The regime the first thresholds were NOT derived from. They came from a
        // propped phone, and in the hand the detector fired constantly and the
        // camera never tracked at all.
        val (_, flagged) = replay("handheld_lens_clear")
        assertFalse(flagged, "a working camera in the hand must never be accused")
    }

    @Test
    fun `deliberate operator motion is never flagged`() {
        // Real motion is not at rest, so the test abstains rather than guessing.
        val (_, flagged) = replay("handheld_moving")
        assertFalse(flagged, "real motion must never be mistaken for invented motion")
    }

    @Test
    fun `every regime in the fixture is replayed`() {
        // Adding a regime without a test would silently prove nothing.
        assertEquals(
            setOf(
                "still_lens_clear",
                "still_after_recovery",
                "handheld_lens_clear",
                "handheld_moving",
                "still_lens_covered",
            ),
            fixture["regimes"]!!.jsonObject.keys,
        )
    }

    // ------------------------------------------------------------- unit checks

    @Test
    fun `no verdict before the window has enough samples`() {
        val det = detector()
        det.onPose(Vec3(0f, 0f, 0f), 0)
        assertTrue(det.corroborated, "an unformed verdict must not accuse")
        assertFalse(det.atRest)
    }

    @Test
    fun `the verdict expires once the evidence stops`() {
        // It must NOT latch until innocence is proven. Proving innocence needs the
        // phone at rest, which handheld may never be, so the first version stuck
        // permanently and the camera never tracked again.
        val det = MotionCorroboration()
        var t = 0L
        repeat(400) {
            det.onAccel(Vec3(0f, 0f, 9.81f), t)
            det.onGyro(Vec3(0f, 0f, 0f), t)
            if (it % 4 == 0) det.onPose(Vec3(it * 0.0004f, 0f, 0f), t)
            t += 5_000_000L
        }
        assertFalse(det.corroborated, "sustained drift while still must be caught")
        repeat(1200) {
            det.onAccel(Vec3(0f, 0f, 9.81f), t)
            det.onGyro(Vec3(0f, 0f, 0f), t)
            if (it % 4 == 0) det.onPose(Vec3(1f, 0f, 0f), t)
            t += 5_000_000L
        }
        assertTrue(det.corroborated, "the verdict must expire without needing proof")
    }

    @Test
    fun `the verdict expires even though a flag stops poses being fed`() {
        // The defect this guards: a flag withholds position, so the caller stops
        // offering poses as evidence -- and the expiry used to be driven only by
        // poses. The flag switched off its own input and the camera never tracked
        // again. Inertial samples flow unconditionally, so they carry the clock.
        val det = MotionCorroboration()
        var t = 0L
        repeat(400) {
            det.onAccel(Vec3(0f, 0f, 9.81f), t)
            det.onGyro(Vec3(0f, 0f, 0f), t)
            if (it % 4 == 0) det.onPose(Vec3(it * 0.0004f, 0f, 0f), t)
            t += 5_000_000L
        }
        assertFalse(det.corroborated, "sustained drift while still must be caught")
        // Now behave exactly as production does once flagged: IMU only, NO poses.
        repeat(800) {
            det.onAccel(Vec3(0f, 0f, 9.81f), t)
            det.onGyro(Vec3(0f, 0f, 0f), t)
            t += 5_000_000L
        }
        assertTrue(
            det.corroborated,
            "the hold must expire on the inertial clock, or the flag is permanent",
        )
    }

    @Test
    fun `a single noisy window does not accuse`() {
        // Evidence must persist before the verdict flips, so one bad window from
        // tracker noise cannot withhold position from a working camera.
        val det = MotionCorroboration()
        var t = 0L
        repeat(240) {
            det.onAccel(Vec3(0f, 0f, 9.81f), t)
            det.onGyro(Vec3(0f, 0f, 0f), t)
            val x = if (it in 100..110) 0.03f else 0f
            if (it % 4 == 0) det.onPose(Vec3(x, 0f, 0f), t)
            t += 5_000_000L
        }
        assertTrue(det.corroborated, "a transient must not be treated as invention")
    }

    @Test
    fun `a stalled sensor cannot manufacture a verdict from stale samples`() {
        val det = MotionCorroboration()
        var t = 0L
        repeat(60) {
            det.onAccel(Vec3(0f, 0f, 9.81f), t)
            det.onGyro(Vec3(0f, 0f, 0f), t)
            t += 8_000_000L
        }
        // IMU stops; poses keep coming well past the window.
        t += 3_000_000_000L
        repeat(40) {
            det.onPose(Vec3(it * 0.01f, 0f, 0f), t)
            t += 30_000_000L
        }
        assertFalse(det.atRest, "stale IMU must not count as evidence of rest")
        assertTrue(det.corroborated)
    }

    @Test
    fun `concurrent sensor and pose threads do not corrupt it`() {
        // The detector is fed from two threads in production: IMU samples on the
        // sensor thread, poses on the tracker's render thread. evaluate()
        // iterates the sample buffers, so an unguarded push from the other
        // thread throws ConcurrentModificationException -- which it did, on
        // device, the moment 6DOF was switched on. Every test here had been
        // single-threaded, so none of them saw it.
        val det = MotionCorroboration()
        val failure = java.util.concurrent.atomic.AtomicReference<Throwable?>(null)
        val stop = java.util.concurrent.atomic.AtomicBoolean(false)
        val imu = Thread {
            try {
                var t = 0L
                while (!stop.get()) {
                    det.onAccel(Vec3(0f, 0f, 9.81f), t)
                    det.onGyro(Vec3(0f, 0f, 0f), t)
                    t += 5_000_000L
                }
            } catch (e: Throwable) {
                failure.compareAndSet(null, e)
            }
        }
        val poses = Thread {
            try {
                var t = 0L
                while (!stop.get()) {
                    det.onPose(Vec3(t / 1e9f * 0.01f, 0f, 0f), t)
                    t += 30_000_000L
                }
            } catch (e: Throwable) {
                failure.compareAndSet(null, e)
            }
        }
        imu.start()
        poses.start()
        Thread.sleep(750)
        stop.set(true)
        imu.join(2_000)
        poses.join(2_000)
        assertEquals(null, failure.get()?.toString(), "concurrent access threw")
    }

    @Test
    fun `reset returns it to trusting`() {
        val det = MotionCorroboration()
        var t = 0L
        repeat(120) {
            det.onAccel(Vec3(0f, 0f, 9.81f), t)
            det.onGyro(Vec3(0f, 0f, 0f), t)
            if (it % 4 == 0) det.onPose(Vec3(it * 0.0006f, 0f, 0f), t)
            t += 8_000_000L
        }
        assertFalse(det.corroborated)
        det.reset()
        assertTrue(det.corroborated)
        assertFalse(det.atRest)
    }
}
