// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

import kotlin.test.Test
import kotlin.test.assertContentEquals
import kotlin.test.assertEquals
import kotlin.test.assertIs
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue
import kotlin.test.fail
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.double
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.long

/** Conformance against `fixtures/packet_vectors.json` — exact wire bytes. */
class PacketsTest {

    private val vectors = Fixtures.load("packet_vectors.json").jsonObject

    // ------------------------------------------------------------- binary

    private fun binaryEntry(id: String): JsonObject =
        vectors["binary"]!!.jsonArray.map { it.jsonObject }
            .firstOrNull { it["id"]!!.jsonPrimitive.content == id }
            ?: fail("binary fixture '$id' missing")

    private fun messageFor(entry: JsonObject): Message {
        val msgType = entry["msg_type"]!!.jsonPrimitive.int
        val seq = entry["seq"]!!.jsonPrimitive.long
        val ts = entry["timestamp_ns"]!!.jsonPrimitive.long
        return when (msgType) {
            Packets.TYPE_POSE -> {
                val q = entry["quat_wxyz"]!!.jsonArray.map { it.jsonPrimitive.double }
                val pos = entry["pos_xyz"]?.jsonArray?.map { it.jsonPrimitive.double }
                Message.Pose(
                    seq = seq,
                    timestampNs = ts,
                    q = Quaternion(q[0], q[1], q[2], q[3]),
                    focalLengthMm = entry["reserved_f"]!!.jsonPrimitive.double.toFloat(),
                    recording = entry["flags"]!!.jsonPrimitive.int and 1 != 0,
                    pos = pos?.let { Vec3(it[0].toFloat(), it[1].toFloat(), it[2].toFloat()) },
                )
            }
            Packets.TYPE_ACK -> Message.Ack(seq, ts, entry["acked_seq"]!!.jsonPrimitive.long)
            Packets.TYPE_BYE -> Message.Bye(seq, ts)
            else -> fail("unhandled binary msg_type $msgType")
        }
    }

    @Test
    fun `binary vectors encode to the exact fixture bytes`() {
        for (entry in vectors["binary"]!!.jsonArray.map { it.jsonObject }) {
            val id = entry["id"]!!.jsonPrimitive.content
            val expectedHex = entry["hex"]!!.jsonPrimitive.content.lowercase()
            val encoded = Packets.encode(messageFor(entry))
            assertEquals(expectedHex, encoded.toHex(), "encode mismatch for '$id'")
        }
    }

    @Test
    fun `binary vectors decode to the fixture fields`() {
        for (entry in vectors["binary"]!!.jsonArray.map { it.jsonObject }) {
            val id = entry["id"]!!.jsonPrimitive.content
            val bytes = entry["hex"]!!.jsonPrimitive.content.hexToBytes()
            val decoded = assertNotNull(Packets.decode(bytes), "decode returned null for '$id'")
            assertEquals(entry["msg_type"]!!.jsonPrimitive.int, decoded.msgType, id)
            assertEquals(entry["seq"]!!.jsonPrimitive.long, decoded.seq, id)
            assertEquals(entry["timestamp_ns"]!!.jsonPrimitive.long, decoded.timestampNs, id)
            when (decoded) {
                is Message.Pose -> {
                    val q = entry["quat_wxyz"]!!.jsonArray.map { it.jsonPrimitive.double }
                    // Exact after f32 round-trip, per the fixture tolerance note.
                    assertEquals(q[0].toFloat(), decoded.q.w.toFloat(), "$id q.w")
                    assertEquals(q[1].toFloat(), decoded.q.x.toFloat(), "$id q.x")
                    assertEquals(q[2].toFloat(), decoded.q.y.toFloat(), "$id q.y")
                    assertEquals(q[3].toFloat(), decoded.q.z.toFloat(), "$id q.z")
                    assertEquals(entry["reserved_f"]!!.jsonPrimitive.double.toFloat(), decoded.focalLengthMm, id)
                    assertEquals(entry["flags"]!!.jsonPrimitive.int and 1 != 0, decoded.recording, id)
                    val pos = entry["pos_xyz"]?.jsonArray?.map { it.jsonPrimitive.double }
                    assertEquals(
                        pos?.let { Vec3(it[0].toFloat(), it[1].toFloat(), it[2].toFloat()) },
                        decoded.pos,
                        "$id pos",
                    )
                }
                is Message.Ack ->
                    assertEquals(entry["acked_seq"]!!.jsonPrimitive.long, decoded.ackedSeq, id)
                is Message.Bye -> Unit
                else -> fail("unexpected decoded type for '$id': $decoded")
            }
        }
    }

    // --------------------------------------------------------------- JSON

    private fun jsonMessageFor(entry: JsonObject): Message {
        val msgType = entry["msg_type"]!!.jsonPrimitive.int
        val seq = entry["seq"]!!.jsonPrimitive.long
        val ts = entry["timestamp_ns"]!!.jsonPrimitive.long
        val body = entry["body"]!!.jsonObject
        fun str(k: String) = body[k]!!.jsonPrimitive.content
        fun int(k: String) = body[k]!!.jsonPrimitive.int
        fun long(k: String) = body[k]!!.jsonPrimitive.long
        fun dbl(k: String) = body[k]!!.jsonPrimitive.double
        return when (msgType) {
            Packets.TYPE_HELLO -> Message.Hello(seq, ts, str("device_name"), str("app_version"), int("protocol_version"), str("token"))
            Packets.TYPE_WELCOME -> Message.Welcome(
                seq, ts, str("server_name"), str("host_app"), str("host_version"),
                str("addon_version"), int("protocol_version"), dbl("scene_fps"),
                takePort = body["take_port"]?.jsonPrimitive?.int,
            )
            Packets.TYPE_RECORD_START -> Message.RecordStart(seq, ts, long("start_timestamp_ns"))
            Packets.TYPE_RECORD_STOP -> Message.RecordStop(
                seq, ts, long("end_timestamp_ns"), int("sample_count"),
                offline = body["offline"]?.jsonPrimitive?.content == "true",
            )
            Packets.TYPE_PONG -> Message.Pong(seq, ts, long("t1"), long("t2"))
            Packets.TYPE_PARAMS -> Message.Params(
                seq, ts, dbl("live_smoothing"), dbl("record_smoothing"), dbl("move_scale"),
                layout = body["layout"]?.jsonPrimitive?.content,
                takeSource = body["take_source"]?.jsonPrimitive?.content,
            )
            Packets.TYPE_PAUSE -> Message.Pause(
                seq, ts, paused = body["paused"]!!.jsonPrimitive.content == "true",
            )
            Packets.TYPE_SEEK -> Message.Seek(
                seq, ts, frame = body["frame"]?.jsonPrimitive?.long,
            )
            Packets.TYPE_TAKE_LIST -> Message.TakeList(
                seq, ts,
                takes = (body["takes"] as? kotlinx.serialization.json.JsonArray)?.map { e ->
                    val t = e.jsonObject
                    TakeInfo(
                        id = t["id"]!!.jsonPrimitive.content,
                        name = t["name"]!!.jsonPrimitive.content,
                        durationS = t["duration_s"]!!.jsonPrimitive.double,
                        source = t["source"]!!.jsonPrimitive.content,
                        samples = t["samples"]!!.jsonPrimitive.int,
                        sent = t["sent"]!!.jsonPrimitive.content == "true",
                    )
                },
            )
            Packets.TYPE_TAKE_PULL -> Message.TakePull(
                seq, ts, id = body["id"]!!.jsonPrimitive.content,
            )
            else -> fail("unhandled json msg_type $msgType")
        }
    }

    @Test
    fun `json messages produce the expected header and round-trip their bodies`() {
        for (entry in vectors["json_messages"]!!.jsonArray.map { it.jsonObject }) {
            val id = entry["id"]!!.jsonPrimitive.content
            val message = jsonMessageFor(entry)
            val encoded = Packets.encode(message)

            (entry["expected_header_hex"] as? JsonPrimitive)?.let { expected ->
                assertEquals(
                    expected.content.lowercase(),
                    encoded.copyOfRange(0, Packets.HEADER_SIZE).toHex(),
                    "header mismatch for '$id'",
                )
            }

            val decoded = assertNotNull(Packets.decode(encoded), "round-trip decode null for '$id'")
            assertEquals(message, decoded, "round-trip mismatch for '$id'")
        }
    }

    @Test
    fun `json bodies straight from the fixture decode to the same fields`() {
        for (entry in vectors["json_messages"]!!.jsonArray.map { it.jsonObject }) {
            val id = entry["id"]!!.jsonPrimitive.content
            val message = jsonMessageFor(entry)
            // Rebuild the datagram with the fixture's own body text (key order
            // as authored) behind our header, and decode that.
            val header = Packets.encode(message).copyOfRange(0, Packets.HEADER_SIZE)
            val body = entry["body"]!!.jsonObject.toString().encodeToByteArray()
            val decoded = assertNotNull(Packets.decode(header + body), "fixture-body decode null for '$id'")
            assertEquals(message, decoded, "fixture-body mismatch for '$id'")
        }
    }

    @Test
    fun `unknown json keys are ignored`() {
        val entry = vectors["json_messages"]!!.jsonArray.map { it.jsonObject }
            .first { it["id"]!!.jsonPrimitive.content == "welcome" }
        val message = jsonMessageFor(entry)
        val header = Packets.encode(message).copyOfRange(0, Packets.HEADER_SIZE)
        val body = entry["body"]!!.jsonObject.toMutableMap()
            .apply { put("future_key", JsonPrimitive("ignored")) }
        val bytes = header + JsonObject(body).toString().encodeToByteArray()
        assertEquals(message, Packets.decode(bytes), "unknown key broke decoding")
    }

    @Test
    fun `params carries the host's lens and tolerates its absence`() {
        // spec 5.7 lens_mm, host -> phone: what the phone's lens control should
        // OPEN on. Absent is a real state (the host omits it while we drive the
        // lens or while its own lens is animated), so it must decode to null
        // rather than a default that would silently reframe the shot.
        val entry = vectors["json_messages"]!!.jsonArray.map { it.jsonObject }
            .first { it["id"]!!.jsonPrimitive.content == "params" }
        val message = jsonMessageFor(entry)
        val header = Packets.encode(message).copyOfRange(0, Packets.HEADER_SIZE)

        val withLens = entry["body"]!!.jsonObject.toMutableMap()
            .apply { put("lens_mm", JsonPrimitive(52.5)) }
        val decoded = Packets.decode(
            header + JsonObject(withLens).toString().encodeToByteArray(),
        )
        assertEquals(52.5, assertIs<Message.Params>(assertNotNull(decoded)).lensMm)

        val bare = Packets.decode(
            header + entry["body"]!!.jsonObject.toString().encodeToByteArray(),
        )
        assertNull(assertIs<Message.Params>(assertNotNull(bare)).lensMm)
    }

    @Test
    fun `params carries the shake threshold, including zero`() {
        // spec 5.7 shake_hold_dps. Zero is the "gate off" value, so it has to
        // survive a round trip as 0.0 and not be confused with absence -- absent
        // means "unchanged", which is the opposite of switching the hold off.
        val entry = vectors["json_messages"]!!.jsonArray.map { it.jsonObject }
            .first { it["id"]!!.jsonPrimitive.content == "params" }
        val header = Packets.encode(jsonMessageFor(entry)).copyOfRange(0, Packets.HEADER_SIZE)

        for (gate in listOf(0.0, 500.0, 1200.0)) {
            val body = entry["body"]!!.jsonObject.toMutableMap()
                .apply { put("shake_hold_dps", JsonPrimitive(gate)) }
            val decoded = Packets.decode(
                header + JsonObject(body).toString().encodeToByteArray(),
            )
            assertEquals(
                gate,
                assertIs<Message.Params>(assertNotNull(decoded)).shakeHoldDps,
                "shake_hold_dps $gate must survive the round trip",
            )
        }

        val bare = Packets.decode(
            header + entry["body"]!!.jsonObject.toString().encodeToByteArray(),
        )
        assertNull(assertIs<Message.Params>(assertNotNull(bare)).shakeHoldDps)

        // And it must actually be written, not merely readable: a codec that
        // decodes a field it never encodes makes every round-trip test a lie.
        val reencoded = Packets.decode(
            Packets.encode(
                Message.Params(7, 7, 0.3, 0.15, 1.0, shakeHoldDps = 0.0),
            ),
        )
        assertEquals(0.0, assertIs<Message.Params>(assertNotNull(reencoded)).shakeHoldDps)

        // The measured viewport ceiling rides the same message. Absent is a
        // real state -- the host has not measured its loop yet -- and must not
        // decode to a number.
        val withCeiling = Packets.decode(
            header + JsonObject(
                entry["body"]!!.jsonObject.toMutableMap()
                    .apply { put("viewport_max_fps", JsonPrimitive(30.0)) },
            ).toString().encodeToByteArray(),
        )
        assertEquals(
            30.0,
            assertIs<Message.Params>(assertNotNull(withCeiling)).viewportMaxFps,
        )
        assertNull(assertIs<Message.Params>(assertNotNull(bare)).viewportMaxFps)
        val ceilingReencoded = Packets.decode(
            Packets.encode(Message.Params(7, 7, 0.3, 0.15, 1.0, viewportMaxFps = 30.0)),
        )
        assertEquals(
            30.0,
            assertIs<Message.Params>(assertNotNull(ceilingReencoded)).viewportMaxFps,
        )
    }

    // --------------------------------------------------- tolerance / dropping

    @Test
    fun `pose with trailing bytes decodes (append-only rule)`() {
        val poseHex = binaryEntry("pose_identity")["hex"]!!.jsonPrimitive.content
        val extended = poseHex.hexToBytes() + byteArrayOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12)
        val decoded = assertNotNull(Packets.decode(extended), "extended POSE must decode")
        val pose = assertIs<Message.Pose>(decoded)
        assertEquals(1.0f, pose.q.w.toFloat())
        assertEquals(1L, pose.seq)
        assertNull(pose.pos, "no position_valid flag: appended bytes are junk, not a position")
    }

    @Test
    fun `position flag without the bytes yields no position`() {
        // Hostile/buggy sender: 40-byte POSE with bit 1 set (spec §4.1 needs both).
        val bytes = binaryEntry("pose_identity")["hex"]!!.jsonPrimitive.content.hexToBytes()
        bytes[36] = (bytes[36].toInt() or Packets.FLAG_HAS_POSITION).toByte()
        val pose = assertIs<Message.Pose>(assertNotNull(Packets.decode(bytes)))
        assertNull(pose.pos)
    }

    @Test
    fun `6dof pose round-trips through encode and decode`() {
        val original = Message.Pose(
            seq = 9, timestampNs = 88, q = Quaternion(1.0, 0.0, 0.0, 0.0),
            recording = true, pos = Vec3(0.5f, -0.25f, 1.5f),
        )
        val encoded = Packets.encode(original)
        assertEquals(Packets.POSE_6DOF_SIZE, encoded.size)
        assertEquals(original, Packets.decode(encoded))
    }

    @Test
    fun `tracking quality and issue round-trip in append-only flags`() {
        val original = Message.Pose(
            seq = 10,
            timestampNs = 99,
            q = Quaternion.IDENTITY,
            pos = null,
            trackingQuality = TrackingQuality.LOST,
            trackingIssue = TrackingIssue.INSUFFICIENT_FEATURES,
        )
        val decoded = assertIs<Message.Pose>(Packets.decode(Packets.encode(original)))
        assertEquals(TrackingQuality.LOST, decoded.trackingQuality)
        assertEquals(TrackingIssue.INSUFFICIENT_FEATURES, decoded.trackingIssue)
        assertNull(decoded.pos)
    }

    @Test
    fun `frame reset round-trips and is reliable`() {
        val original = Message.FrameReset(29, 1234, reason = "source")
        assertEquals(original, Packets.decode(Packets.encode(original)))
        assertTrue(Packets.isReliable(Packets.TYPE_FRAME_RESET))
    }

    @Test
    fun `record transaction identity round-trips and remains optional`() {
        val id = "9c6a5f91-d70a-46dc-a604-d255cd13fc55"
        val start = Message.RecordStart(1, 2, 3, takeId = id)
        val stop = Message.RecordStop(2, 3, 4, 5, offline = true, takeId = id)
        val baked = Message.RecordBaked(3, 4, 24, 24.0, 10, 10, "offline", id)
        assertEquals(start, Packets.decode(Packets.encode(start)))
        assertEquals(stop, Packets.decode(Packets.encode(stop)))
        assertEquals(baked, Packets.decode(Packets.encode(baked)))
        assertNull(
            assertIs<Message.RecordStart>(
                Packets.decode(Packets.encode(Message.RecordStart(4, 5, 6))),
            ).takeId,
        )
    }

    @Test
    fun `take list advertises actual position capability backward compatibly`() {
        val sixDof = TakeInfo(
            "six.take", "Six", 2.0, "arcore", 200, false, positionSamples = 180,
        )
        val rotation = TakeInfo(
            "rot.take", "Rot", 1.0, "sensor", 100, true, positionSamples = 0,
        )
        val decoded = assertIs<Message.TakeList>(
            Packets.decode(Packets.encode(Message.TakeList(8, 9, listOf(sixDof, rotation)))),
        )
        assertEquals(listOf(sixDof, rotation), decoded.takes)
    }

    @Test
    fun `bad magic, bad version, unknown type and truncated packets drop to null`() {
        val good = binaryEntry("pose_identity")["hex"]!!.jsonPrimitive.content.hexToBytes()

        val badMagic = good.copyOf().also { it[0] = 'X'.code.toByte() }
        assertNull(Packets.decode(badMagic), "bad magic must drop")

        val badVersion = good.copyOf().also { it[2] = 2 }
        assertNull(Packets.decode(badVersion), "version != 1 must drop")

        val unknownType = good.copyOf().also { it[3] = 0x7E }
        assertNull(Packets.decode(unknownType), "unknown msg_type must be ignored")

        assertNull(Packets.decode(good, length = 8), "truncated header must drop")
        assertNull(Packets.decode(good, length = 39), "truncated POSE must drop")
        assertTrue(Packets.decode(good, length = 40) is Message.Pose)
    }

    @Test
    fun `ack shorter than 20 bytes drops to null`() {
        val ack = binaryEntry("ack_of_seq1")["hex"]!!.jsonPrimitive.content.hexToBytes()
        assertNull(Packets.decode(ack, length = 19))
        assertContentEquals(ack, Packets.encode(Packets.decode(ack)!!))
    }
}
