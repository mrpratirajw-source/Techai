// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.ServerSocket
import java.net.SocketTimeoutException
import java.io.ByteArrayInputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertTrue
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout

class SessionClientSocketTest {
    @Test
    fun `library apply pauses before upload and unlocks only after baked`() = runBlocking {
        val loopback = InetAddress.getLoopbackAddress()
        val udp = DatagramSocket(0, loopback)
        val tcp = ServerSocket(udp.localPort, 1, loopback).apply { soTimeout = 3_000 }
        val pauseSeen = CountDownLatch(1)
        val uploadDone = CountDownLatch(1)
        val allowBaked = CountDownLatch(1)
        val uploadStartedBeforePause = AtomicBoolean(false)

        val tcpThread = thread(name = "library-apply-upload-test") {
            tcp.accept().use { conn ->
                if (pauseSeen.count > 0) uploadStartedBeforePause.set(true)
                val input = conn.getInputStream().bufferedReader()
                input.readLine() // replacement header
                input.readLine() // one pose row
                conn.getOutputStream().write("ok\n".encodeToByteArray())
                conn.getOutputStream().flush()
            }
            uploadDone.countDown()
        }
        val udpThread = thread(name = "library-apply-udp-test") {
            val packet = DatagramPacket(ByteArray(4096), 4096)
            udp.receive(packet)
            val address = packet.socketAddress
            val welcome = Packets.encode(
                Message.Welcome(
                    40, 40, "Blender", "blender", "5.1", "0.1.0",
                    Packets.PROTOCOL_VERSION, 24.0, takePort = udp.localPort,
                ),
            )
            udp.send(DatagramPacket(welcome, welcome.size, address))
            while (pauseSeen.count > 0) {
                packet.length = packet.data.size
                udp.receive(packet)
                val msg = Packets.decode(packet.data, packet.length)
                if (msg is Message.Pause && msg.paused) {
                    pauseSeen.countDown()
                    val ack = Packets.encode(Message.Ack(41, 41, msg.seq))
                    udp.send(DatagramPacket(ack, ack.size, address))
                }
            }
            assertTrue(uploadDone.await(2, TimeUnit.SECONDS))
            assertTrue(allowBaked.await(2, TimeUnit.SECONDS))
            val baked = Packets.encode(
                Message.RecordBaked(42, 42, 3, 24.0, 1, 1, "offline", null),
            )
            udp.send(DatagramPacket(baked, baked.size, address))
        }

        val body = encodeTakeBody(
            listOf(PoseUpdate(Quaternion.IDENTITY, 100L, Vec3(1f, 2f, 3f))),
            100L, 100L, token = null,
        )
        val source = TakeUploadSource(
            id = "saved.take", name = "Saved 6DOF", source = "arcore",
            startNs = 100L, endNs = 100L, sampleCount = 1,
            byteCount = body.size.toLong(), openFile = { ByteArrayInputStream(body) },
        )
        val client = SessionClient()
        try {
            client.connect("127.0.0.1", udp.localPort, "ABC123", "TestPhone")
            withTimeout(2_000) {
                while (client.state.value !is SessionState.Live) delay(10)
            }
            assertTrue(client.uploadSavedTake(source))
            assertFalse(uploadStartedBeforePause.get())
            assertTrue(client.paused.value)
            assertEquals(source.id, client.libraryApplyId.value)
            client.startRecording()
            assertTrue(client.state.value is SessionState.Live, "record started during Apply")
            allowBaked.countDown()
            withTimeout(2_000) {
                while (client.libraryApplyId.value != null) delay(10)
            }
            assertTrue(client.paused.value, "bake confirmation must remain paused for review")
        } finally {
            client.disconnect()
            udp.close()
            tcp.close()
            udpThread.join(1_000)
            tcpThread.join(1_000)
        }
    }

    @Test
    fun `the host's reported lens survives our own params and its omission`() = runBlocking {
        // spec 5.7 lens_mm. The lens rail opens on this value, and the only
        // fallback for not having it is a made-up default that reframes the
        // operator's shot -- so losing it is a real bug, not a cosmetic one.
        // Two ways it can be lost, both covered here: our own outgoing PARAMS
        // (a smoothing slider) rebuilding the mirror without it, and the host
        // legitimately omitting it while we drive the lens.
        val loopback = InetAddress.getLoopbackAddress()
        val udp = DatagramSocket(0, loopback)
        val peer = AtomicReference<java.net.SocketAddress?>(null)
        val running = AtomicBoolean(true)

        val udpThread = thread(name = "lens-mirror-host") {
            val packet = DatagramPacket(ByteArray(4096), 4096)
            udp.soTimeout = 200
            var seq = 100L
            while (running.get()) {
                packet.length = packet.data.size
                try {
                    udp.receive(packet)
                } catch (_: SocketTimeoutException) {
                    continue
                }
                peer.set(packet.socketAddress)
                val msg = Packets.decode(packet.data, packet.length) ?: continue
                if (msg is Message.Hello) {
                    val welcome = Packets.encode(
                        Message.Welcome(
                            seq++, seq, "Blender", "blender", "5.1", "0.1.0",
                            Packets.PROTOCOL_VERSION, 24.0,
                        ),
                    )
                    udp.send(DatagramPacket(welcome, welcome.size, packet.socketAddress))
                }
            }
        }

        fun hostSendParams(lensMm: Double?, seq: Long) {
            val addr = assertNotNull(peer.get(), "no client address yet")
            val bytes = Packets.encode(
                Message.Params(seq, seq, 0.3, 0.1, 1.0, lensMm = lensMm),
            )
            udp.send(DatagramPacket(bytes, bytes.size, addr))
        }

        val client = SessionClient()
        try {
            client.connect("127.0.0.1", udp.localPort, "ABC123", "TestPhone")
            withTimeout(2_000) {
                while (client.state.value !is SessionState.Live) delay(10)
            }

            hostSendParams(52.5, 500)
            withTimeout(2_000) {
                while (client.params.value?.hostLensMm != 52.5) delay(10)
            }

            // A local slider change must not blank it.
            client.sendParams(0.9, 0.4, 2.0)
            assertEquals(
                52.5, client.params.value?.hostLensMm,
                "our own PARAMS wiped the host's lens",
            )

            // Nor may the host omitting it (which it does while we drive the lens).
            hostSendParams(null, 501)
            withTimeout(2_000) {
                while (client.params.value?.moveScale != 1.0) delay(10)
            }
            assertEquals(
                52.5, client.params.value?.hostLensMm,
                "an omitted lens_mm was treated as 'unknown' instead of 'not reporting'",
            )
        } finally {
            running.set(false)
            client.disconnect()
            udpThread.join(1_000)
            udp.close()
        }
    }

    @Test
    fun `short ack cannot truncate a following welcome`() = runBlocking {
        val loopback = InetAddress.getLoopbackAddress()
        val server = DatagramSocket(0, loopback)
        val serverThread = thread(name = "session-client-test-server") {
            val incoming = DatagramPacket(ByteArray(2048), 2048)
            server.receive(incoming)
            val client = incoming.socketAddress

            // ACK is exactly 20 bytes. DatagramPacket re-use used to leave the
            // client's next receive capped at this size, truncating WELCOME.
            val ack = Packets.encode(Message.Ack(1, 1, ackedSeq = 999))
            server.send(DatagramPacket(ack, ack.size, client))

            val welcome = Packets.encode(
                Message.Welcome(
                    seq = 2,
                    timestampNs = 2,
                    serverName = "Blender test host with a deliberately long name",
                    hostApp = "blender",
                    hostVersion = "5.1.0",
                    addonVersion = "0.1.0",
                    protocolVersion = Packets.PROTOCOL_VERSION,
                    sceneFps = 24.0,
                ),
            )
            server.send(DatagramPacket(welcome, welcome.size, client))
        }

        val client = SessionClient()
        try {
            client.connect("127.0.0.1", server.localPort, "ABC123", "TestPhone")
            withTimeout(2_000) {
                while (client.state.value !is SessionState.Live) delay(10)
            }
            assertTrue(client.state.value is SessionState.Live)
        } finally {
            client.disconnect()
            server.close()
            serverThread.join(1_000)
        }
    }

    @Test
    fun `hello retries reuse one reliable sequence`() = runBlocking {
        val loopback = InetAddress.getLoopbackAddress()
        val server = DatagramSocket(0, loopback)
        var firstSeq = -1L
        var secondSeq = -2L
        val serverThread = thread(name = "hello-retry-test-server") {
            val first = DatagramPacket(ByteArray(2048), 2048)
            server.receive(first)
            firstSeq = (Packets.decode(first.data, first.length) as Message.Hello).seq

            val second = DatagramPacket(ByteArray(2048), 2048)
            server.receive(second)
            secondSeq = (Packets.decode(second.data, second.length) as Message.Hello).seq

            val welcome = Packets.encode(
                Message.Welcome(
                    20, 20, "Blender", "blender", "5.1", "0.1.0",
                    Packets.PROTOCOL_VERSION, 24.0,
                ),
            )
            server.send(DatagramPacket(welcome, welcome.size, second.socketAddress))
        }

        val client = SessionClient()
        try {
            client.connect("127.0.0.1", server.localPort, "ABC123", "TestPhone")
            withTimeout(2_000) {
                while (client.state.value !is SessionState.Live) delay(10)
            }
            assertEquals(firstSeq, secondSeq)
        } finally {
            client.disconnect()
            server.close()
            serverThread.join(1_000)
        }
    }

    @Test
    fun `frame reset gates poses until ack then resumes one rigid pose`() = runBlocking {
        val loopback = InetAddress.getLoopbackAddress()
        val server = DatagramSocket(0, loopback)
        val baselineSeen = CountDownLatch(1)
        val finished = CountDownLatch(1)
        val poseBeforeAck = AtomicBoolean(false)
        val resumedPose = AtomicReference<Message.Pose?>()

        val serverThread = thread(name = "frame-reset-test-server") {
            try {
                val packet = DatagramPacket(ByteArray(2048), 2048)
                server.receive(packet)
                val clientAddress = packet.socketAddress
                val welcome = Packets.encode(
                    Message.Welcome(
                        50, 50, "Blender", "blender", "5.1", "0.1.0",
                        Packets.PROTOCOL_VERSION, 24.0,
                    ),
                )
                server.send(DatagramPacket(welcome, welcome.size, clientAddress))
                val unpause = Packets.encode(Message.Pause(52, 52, paused = false))
                server.send(DatagramPacket(unpause, unpause.size, clientAddress))

                // Establish that normal POSE output is flowing first.
                while (true) {
                    packet.length = packet.data.size
                    server.receive(packet)
                    if (Packets.decode(packet.data, packet.length) is Message.Pose) {
                        baselineSeen.countDown()
                        break
                    }
                }

                var reset: Message.FrameReset? = null
                while (reset == null) {
                    packet.length = packet.data.size
                    server.receive(packet)
                    reset = Packets.decode(packet.data, packet.length) as? Message.FrameReset
                }
                val boundary = requireNotNull(reset)

                // Hold the ACK longer than many 100 Hz pose ticks. No POSE
                // newer than FRAME_RESET may cross this control boundary.
                server.soTimeout = 25
                val deadline = System.nanoTime() + 250_000_000L
                while (System.nanoTime() < deadline) {
                    try {
                        packet.length = packet.data.size
                        server.receive(packet)
                        val msg = Packets.decode(packet.data, packet.length)
                        if (msg is Message.Pose && msg.seq > boundary.seq) {
                            poseBeforeAck.set(true)
                        }
                    } catch (_: SocketTimeoutException) {
                        // Keep observing until the full hold window expires.
                    }
                }

                val ack = Packets.encode(Message.Ack(51, 51, ackedSeq = boundary.seq))
                server.send(DatagramPacket(ack, ack.size, clientAddress))
                server.soTimeout = 1_000
                while (resumedPose.get() == null) {
                    packet.length = packet.data.size
                    server.receive(packet)
                    val msg = Packets.decode(packet.data, packet.length)
                    if (msg is Message.Pose && msg.seq > boundary.seq) resumedPose.set(msg)
                }
            } finally {
                finished.countDown()
            }
        }

        val client = SessionClient()
        try {
            client.connect("127.0.0.1", server.localPort, "ABC123", "TestPhone")
            withTimeout(2_000) {
                while (client.state.value !is SessionState.Live || client.paused.value) delay(10)
            }
            client.updatePose(Quaternion.IDENTITY, 100, Vec3(0f, 0f, 0f))
            assertTrue(baselineSeen.await(1, TimeUnit.SECONDS), "baseline POSE never arrived")

            client.requestFrameReset("source")
            val rawQ = Quaternion(0.0, 1.0, 0.0, 0.0)
            val rawP = Vec3(1f, 2f, 3f)
            client.updatePose(rawQ, 200, rawP)

            assertTrue(finished.await(2, TimeUnit.SECONDS), "FRAME_RESET flow timed out")
            assertFalse(poseBeforeAck.get(), "POSE crossed the unacknowledged frame boundary")
            val resumed = assertNotNull(resumedPose.get())
            // The sender now re-expresses a reference change into the frame it
            // is already emitting, so the resumed pose is the raw pose rotated
            // into that frame rather than the raw pose verbatim. What must still
            // hold is that it is the SAME rigid transform: position expressed in
            // the camera frame is untouched, which is false the moment the
            // quaternion is corrected without the position (the 2026-07-22
            // regression). Continuity itself is covered by SessionClientPoseTest.
            val resumedP = assertNotNull(resumed.pos)
            val rawInCamera = rawQ.normalized().conjugate().rotate(rawP)
            val emittedInCamera = resumed.q.normalized().conjugate().rotate(resumedP)
            assertEquals(rawInCamera.x.toDouble(), emittedInCamera.x.toDouble(), 1e-4)
            assertEquals(rawInCamera.y.toDouble(), emittedInCamera.y.toDouble(), 1e-4)
            assertEquals(rawInCamera.z.toDouble(), emittedInCamera.z.toDouble(), 1e-4)
        } finally {
            client.disconnect()
            server.close()
            serverThread.join(1_000)
        }
    }

    @Test
    fun `record transaction finalizes streams and completes only matching bake`() = runBlocking {
        val loopback = InetAddress.getLoopbackAddress()
        val udp = DatagramSocket(0, loopback)
        val tcp = ServerSocket(udp.localPort, 1, loopback).apply { soTimeout = 3_000 }
        val startId = AtomicReference<String?>()
        val stopId = AtomicReference<String?>()
        val uploaded = AtomicReference<String?>()
        val uploadDone = CountDownLatch(1)

        val store = object : ConnectedTakeStore {
            var active: String? = null
            override fun beginConnectedTake(takeId: String, startNs: Long, source: String): Boolean {
                active = takeId
                return true
            }

            override fun finishConnectedTake(takeId: String, endNs: Long): TakeUploadSource? {
                assertEquals(active, takeId)
                val rows = encodeTakeBody(
                    listOf(PoseUpdate(Quaternion.IDENTITY, 100L, null)),
                    100L, endNs, token = null,
                )
                return TakeUploadSource(
                    id = "take-$takeId.take",
                    name = "Take",
                    source = "sensor",
                    startNs = 100L,
                    endNs = endNs,
                    sampleCount = 1,
                    byteCount = rows.size.toLong(),
                    openFile = { ByteArrayInputStream(rows) },
                )
            }

            override fun abortConnectedTake(takeId: String): TakeUploadSource? = null
        }

        val tcpThread = thread(name = "transaction-upload-test") {
            tcp.accept().use { conn ->
                val lines = conn.getInputStream().bufferedReader()
                val header = lines.readLine()
                lines.readLine() // one sample
                uploaded.set(header)
                conn.getOutputStream().write("ok\n".encodeToByteArray())
                conn.getOutputStream().flush()
            }
            uploadDone.countDown()
        }

        val udpThread = thread(name = "transaction-udp-test") {
            val packet = DatagramPacket(ByteArray(4096), 4096)
            udp.receive(packet)
            val address = packet.socketAddress
            val welcome = Packets.encode(
                Message.Welcome(
                    50, 50, "Blender", "blender", "5.1", "0.1.0",
                    Packets.PROTOCOL_VERSION, 24.0, takePort = udp.localPort,
                ),
            )
            udp.send(DatagramPacket(welcome, welcome.size, address))

            while (stopId.get() == null) {
                packet.length = packet.data.size
                udp.receive(packet)
                when (val msg = Packets.decode(packet.data, packet.length)) {
                    is Message.RecordStart -> {
                        startId.set(msg.takeId)
                        val ack = Packets.encode(Message.Ack(60, 60, msg.seq))
                        udp.send(DatagramPacket(ack, ack.size, address))
                    }
                    is Message.RecordStop -> {
                        stopId.set(msg.takeId)
                        val ack = Packets.encode(Message.Ack(61, 61, msg.seq))
                        udp.send(DatagramPacket(ack, ack.size, address))
                    }
                    else -> Unit
                }
            }
            assertTrue(uploadDone.await(2, TimeUnit.SECONDS))
            val baked = Packets.encode(
                Message.RecordBaked(
                    62, 62, 1, 24.0, 1, 1, "offline", stopId.get(),
                ),
            )
            udp.send(DatagramPacket(baked, baked.size, address))
        }

        val client = SessionClient(takeStore = store)
        try {
            client.connect("127.0.0.1", udp.localPort, "ABC123", "TestPhone")
            withTimeout(2_000) {
                while (client.state.value !is SessionState.Live) delay(10)
            }
            client.updatePose(Quaternion.IDENTITY, 100L)
            client.startRecording()
            withTimeout(2_000) {
                while (client.state.value !is SessionState.Recording) delay(10)
            }
            client.updatePose(Quaternion.IDENTITY, 200L)
            client.stopRecording()
            assertTrue(client.state.value is SessionState.Finalizing)
            withTimeout(3_000) {
                while (client.state.value !is SessionState.Live) delay(10)
            }
            assertNotNull(startId.get())
            assertEquals(startId.get(), stopId.get())
            assertTrue(uploaded.get()!!.contains("\"take_id\":\"${startId.get()}\""))
        } finally {
            client.disconnect()
            udp.close()
            tcp.close()
            udpThread.join(1_000)
            tcpThread.join(1_000)
        }
    }
}
