// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull

/** The spec §4.1 tracking-loss contract, enforced at the emit decision. */
class SixDofFeedTest {

    private val qId = Quaternion.IDENTITY // ARCore identity pose

    @Test
    fun `tracking frames emit converted pose with position and frame timestamp`() {
        val feed = SixDofFeed()
        val u = assertNotNull(
            feed.update(good(), qId, Vec3(1f, 2f, 3f), frameTimestampNs = 100, nowNs = 999),
        )
        assertEquals(100, u.timestampNs)
        assertEquals(Frames.arcorePosToProtocol(1f, 2f, 3f), u.pos)
        assertEquals(Frames.arcoreToProtocol(qId), u.q)
    }

    @Test
    fun `loss before any tracking emits nothing`() {
        val feed = SixDofFeed()
        assertNull(feed.update(lost(), null, null, frameTimestampNs = 100, nowNs = 999))
    }

    @Test
    fun `loss after tracking emits rotation-only with advancing now timestamps`() {
        val feed = SixDofFeed()
        val good = assertNotNull(feed.update(good(), qId, Vec3(1f, 2f, 3f), 100, 100))
        val lost1 = assertNotNull(feed.update(lost(), null, null, frameTimestampNs = 100, nowNs = 200))
        val lost2 = assertNotNull(feed.update(lost(), null, null, frameTimestampNs = 100, nowNs = 300))
        assertNull(lost1.pos, "position_valid must clear on loss (spec 4.1)")
        assertNull(lost2.pos)
        assertEquals(good.q, lost1.q, "holds last-known-good orientation")
        assertEquals(200, lost1.timestampNs, "timestamps must keep advancing")
        assertEquals(300, lost2.timestampNs)
    }

    @Test
    fun `recovery resumes positional emission`() {
        val feed = SixDofFeed()
        feed.update(good(), qId, Vec3(0f, 0f, 0f), 100, 100)
        feed.update(lost(), null, null, 100, 200)
        val back = assertNotNull(feed.update(good(), qId, Vec3(9f, 9f, 9f), 400, 400))
        assertEquals(Frames.arcorePosToProtocol(9f, 9f, 9f), back.pos)
        assertEquals(400, back.timestampNs)
    }

    @Test
    fun `reset forgets the last-good orientation`() {
        val feed = SixDofFeed()
        feed.update(good(), qId, Vec3(0f, 0f, 0f), 100, 100)
        feed.reset()
        assertNull(feed.update(lost(), null, null, 100, 200))
    }

    @Test
    fun `recovering tracks current orientation and withholds position`() {
        val feed = SixDofFeed()
        val good = assertNotNull(feed.update(good(), qId, Vec3(1f, 2f, 3f), 100, 100))
        val recovering = assertNotNull(
            feed.update(
                TrackingStatus(TrackingQuality.RECOVERING),
                Quaternion(0.0, 0.0, 0.0, 1.0),
                Vec3(9f, 9f, 9f),
                200,
                220,
            ),
        )
        assertEquals(
            Frames.arcoreToProtocol(Quaternion(0.0, 0.0, 0.0, 1.0)),
            recovering.q,
        )
        assertEquals(false, good.q == recovering.q)
        assertNull(recovering.pos)
        assertEquals(TrackingQuality.RECOVERING, recovering.quality)
        assertEquals(200, recovering.timestampNs)
    }

    @Test
    fun `warming emits current rotation but withholds position`() {
        val feed = SixDofFeed()
        val q = Quaternion(0.5, 0.5, -0.5, 0.5)
        val update = feed.update(
            TrackingStatus.WARMING, q, Vec3(9f, 8f, 7f), 123L, 456L,
        )
        assertNotNull(update)
        assertEquals(TrackingQuality.WARMING, update.quality)
        assertNull(update.pos)
        assertEquals(123L, update.timestampNs)
        assertEquals(Frames.arcoreToProtocol(q), update.q)
    }

    // ---------------------------------------------------------------------
    // Inertial rotation continuation through a visual loss.
    //
    // Orientation does not need the camera. Holding it still while ARCore is
    // blind loses every degree the operator turns and then delivers all of it
    // in one pose step on recovery -- measured on device as the camera snapping
    // to a "random" orientation.

    /** Rotation about Z by [deg], as a protocol-frame quaternion. */
    private fun yaw(deg: Double): Quaternion {
        val h = Math.toRadians(deg) / 2.0
        return Quaternion(kotlin.math.cos(h), 0.0, 0.0, kotlin.math.sin(h))
    }

    private fun pitch(deg: Double): Quaternion {
        val h = Math.toRadians(deg) / 2.0
        return Quaternion(kotlin.math.cos(h), kotlin.math.sin(h), 0.0, 0.0)
    }

    private fun assertQuatEquals(expected: Quaternion, actual: Quaternion, msg: String = "") {
        // q and -q are the same rotation.
        val d = kotlin.math.abs(expected.dot(actual))
        kotlin.test.assertTrue(d > 0.999999, "$msg expected $expected got $actual")
    }

    @Test
    fun `first blind frame is continuous with the last tracked orientation`() {
        val feed = SixDofFeed()
        val sensorAtLoss = yaw(37.0)
        val tracked = assertNotNull(
            feed.update(good(), qId, Vec3(1f, 2f, 3f), 100, 100, sensorAtLoss),
        )
        // Phone has not moved yet: the continuation must be an exact no-op.
        val blind = assertNotNull(
            feed.update(lost(), null, null, 100, 200, sensorAtLoss),
        )
        assertQuatEquals(tracked.q, blind.q, "handoff must not move the camera:")
        assertNull(blind.pos)
    }

    @Test
    fun `rotation continues inertially while ARCore is blind`() {
        val feed = SixDofFeed()
        val sensorAtLoss = yaw(10.0)
        val tracked = assertNotNull(
            feed.update(good(), qId, Vec3(0f, 0f, 0f), 100, 100, sensorAtLoss),
        )
        // The operator turns 90 deg (a body-frame rotation) while blind.
        val bodyDelta = yaw(90.0)
        val blind = assertNotNull(
            feed.update(lost(), null, null, 100, 200, sensorAtLoss * bodyDelta),
        )
        assertQuatEquals(
            (tracked.q * bodyDelta).normalized(), blind.q,
            "blind rotation must follow the inertial delta:",
        )
        assertNull(blind.pos, "position stays invalid while blind")
    }

    @Test
    fun `continuation is immune to the ARCore-vs-sensor yaw mismatch`() {
        // The two world frames are both gravity-aligned but their yaw origins
        // are unrelated. The continuation uses only a BODY-frame delta, so
        // re-expressing the sensor's world by any yaw must change nothing. If
        // this property broke, every recovery would introduce a yaw error.
        val bodyDelta = pitch(25.0) * yaw(40.0)
        val results = listOf(0.0, 17.0, 90.0, 213.0).map { worldYaw ->
            val feed = SixDofFeed()
            val offset = yaw(worldYaw)
            val atLoss = offset * yaw(5.0)
            feed.update(good(), qId, Vec3(0f, 0f, 0f), 100, 100, atLoss)
            assertNotNull(feed.update(lost(), null, null, 100, 200, atLoss * bodyDelta)).q
        }
        results.drop(1).forEach {
            assertQuatEquals(results[0], it, "yaw reference leaked into the result:")
        }
    }

    @Test
    fun `without an inertial reference rotation holds still as before`() {
        val feed = SixDofFeed()
        val tracked = assertNotNull(feed.update(good(), qId, Vec3(0f, 0f, 0f), 100, 100))
        val blind = assertNotNull(feed.update(lost(), null, null, 100, 200))
        assertQuatEquals(tracked.q, blind.q)
    }

    @Test
    fun `returning from blind reports one reference boundary`() {
        val feed = SixDofFeed()
        val s = yaw(0.0)
        feed.update(good(), qId, Vec3(0f, 0f, 0f), 100, 100, s)
        kotlin.test.assertFalse(
            feed.consumeReferenceBoundary(), "tracking frames are not boundaries",
        )
        feed.update(lost(), null, null, 100, 200, s * yaw(30.0))
        kotlin.test.assertFalse(
            feed.consumeReferenceBoundary(), "the loss itself is continuous",
        )
        feed.update(good(), qId, Vec3(1f, 1f, 1f), 300, 300, s * yaw(30.0))
        kotlin.test.assertTrue(
            feed.consumeReferenceBoundary(), "recovery changes the visual reference",
        )
        kotlin.test.assertFalse(
            feed.consumeReferenceBoundary(), "boundary is reported once only",
        )
    }

    @Test
    fun `reset clears the boundary and the inertial reference`() {
        val feed = SixDofFeed()
        val s = yaw(0.0)
        feed.update(good(), qId, Vec3(0f, 0f, 0f), 100, 100, s)
        feed.update(lost(), null, null, 100, 200, s)
        feed.reset()
        kotlin.test.assertFalse(feed.consumeReferenceBoundary())
        assertNull(feed.update(lost(), null, null, 100, 300, s))
    }

    private fun good() = TrackingStatus(TrackingQuality.GOOD)
    private fun lost() = TrackingStatus(
        TrackingQuality.LOST,
        TrackingIssue.INSUFFICIENT_FEATURES,
    )
}
