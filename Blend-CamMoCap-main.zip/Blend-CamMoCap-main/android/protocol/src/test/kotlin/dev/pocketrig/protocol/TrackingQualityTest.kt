// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class TrackingQualityTest {
    @Test
    fun `startup requires a stable tracked interval before position`() {
        val q = TrackingQualityEstimator(warmupNs = 200, recoveryNs = 300)
        assertEquals(TrackingQuality.WARMING, q.update(true, "NONE", 100).quality)
        assertFalse(q.status.positionValid)
        assertEquals(TrackingQuality.WARMING, q.update(true, "NONE", 299).quality)
        assertEquals(TrackingQuality.GOOD, q.update(true, "NONE", 300).quality)
        assertTrue(q.status.positionValid)
    }

    @Test
    fun `hard failure degrades immediately and becomes lost`() {
        val q = goodEstimator()
        val degraded = q.update(false, "INSUFFICIENT_FEATURES", 400)
        assertEquals(TrackingQuality.DEGRADED, degraded.quality)
        assertEquals(TrackingIssue.INSUFFICIENT_FEATURES, degraded.issue)
        assertFalse(degraded.positionValid)
        assertEquals(TrackingQuality.LOST, q.update(false, "INSUFFICIENT_FEATURES", 900).quality)
    }

    @Test
    fun `recovery is stable and resets issue before restoring position`() {
        val q = goodEstimator()
        q.update(false, "INSUFFICIENT_LIGHT", 400)
        val recovering = q.update(true, "NONE", 500)
        assertEquals(TrackingQuality.RECOVERING, recovering.quality)
        assertEquals(TrackingIssue.NONE, recovering.issue)
        assertFalse(recovering.positionValid)
        assertEquals(TrackingQuality.RECOVERING, q.update(true, "NONE", 799).quality)
        assertEquals(TrackingQuality.GOOD, q.update(true, "NONE", 800).quality)
    }

    @Test
    fun `large frame gap requires recovery even if ARCore says tracking`() {
        val q = TrackingQualityEstimator(
            warmupNs = 200,
            lostAfterNs = 500,
            recoveryNs = 300,
            frameGapNs = 250,
        ).also {
            it.update(true, "NONE", 100)
            it.update(true, "NONE", 300)
        }
        assertEquals(TrackingQuality.RECOVERING, q.update(true, "NONE", 700).quality)
        assertFalse(q.status.positionValid)
        assertEquals(TrackingQuality.RECOVERING, q.update(true, "NONE", 800).quality)
        assertEquals(TrackingQuality.GOOD, q.update(true, "NONE", 1_000).quality)
    }

    @Test
    fun `stalled source frame degrades then becomes lost`() {
        val q = TrackingQualityEstimator(
            warmupNs = 200,
            lostAfterNs = 500,
            recoveryNs = 300,
            frameGapNs = 250,
        )
        q.update(true, "NONE", observedNs = 100, sourceTimestampNs = 100)
        q.update(true, "NONE", observedNs = 300, sourceTimestampNs = 300)
        assertEquals(
            TrackingQuality.DEGRADED,
            q.update(true, "NONE", observedNs = 551, sourceTimestampNs = 300).quality,
        )
        assertEquals(
            TrackingQuality.LOST,
            q.update(true, "NONE", observedNs = 1_051, sourceTimestampNs = 300).quality,
        )
    }

    @Test
    fun `wire values are bounded and unknown-safe`() {
        for (quality in TrackingQuality.entries) {
            assertEquals(quality, TrackingQuality.fromWireCode(quality.wireCode))
            assertEquals(quality, TrackingQuality.fromWireName(quality.wireName))
        }
        for (issue in TrackingIssue.entries) {
            assertEquals(issue, TrackingIssue.fromWireCode(issue.wireCode))
            assertEquals(issue, TrackingIssue.fromWireName(issue.wireName))
        }
        assertEquals(TrackingQuality.UNKNOWN, TrackingQuality.fromWireCode(99))
        assertEquals(TrackingIssue.UNKNOWN, TrackingIssue.fromWireCode(99))
    }

    private fun goodEstimator(): TrackingQualityEstimator =
        TrackingQualityEstimator(warmupNs = 200, lostAfterNs = 500, recoveryNs = 300).also {
            it.update(true, "NONE", 100)
            it.update(true, "NONE", 300)
        }
}
