// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

import java.io.File
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement

/** Locates and loads the shared conformance fixtures from the repo root. */
object Fixtures {
    val json = Json { ignoreUnknownKeys = true }

    /**
     * Walks up from the working directory until a directory containing
     * `fixtures/` is found (works from repo root, `android/`, or the module
     * directory, wherever Gradle runs the tests from).
     */
    private fun repoRoot(): File {
        var dir: File? = File(System.getProperty("user.dir")).absoluteFile
        while (dir != null) {
            if (File(dir, "fixtures").isDirectory) return dir
            dir = dir.parentFile
        }
        error(
            "Could not locate the repo's fixtures/ directory walking up from " +
                System.getProperty("user.dir") +
                " — run the tests from within the PocketCamRig checkout.",
        )
    }

    fun load(name: String): JsonElement {
        val file = File(File(repoRoot(), "fixtures"), name)
        check(file.isFile) { "Fixture not found: ${file.absolutePath}" }
        return json.parseToJsonElement(file.readText(Charsets.UTF_8))
    }
}

fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }

fun String.hexToBytes(): ByteArray {
    require(length % 2 == 0) { "odd-length hex string" }
    return ByteArray(length / 2) { i ->
        substring(i * 2, i * 2 + 2).toInt(16).toByte()
    }
}
