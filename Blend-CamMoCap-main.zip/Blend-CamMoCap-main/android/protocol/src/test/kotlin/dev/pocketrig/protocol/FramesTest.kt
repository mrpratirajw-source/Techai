// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

import kotlin.math.abs
import kotlin.test.Test
import kotlin.test.assertTrue
import kotlinx.serialization.json.double
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/** Conformance against `fixtures/orientation_cases.json`. */
class FramesTest {

    private val tolerance = 1e-6

    /**
     * The fixture expresses `display_rotation` in degrees (0/90/180/270);
     * [Frames.sensorToProtocol] takes the `Surface.ROTATION_*` constant value
     * (0/1/2/3). ROTATION_90 == 1 means the display content is rotated 90°,
     * i.e. the device was turned 90° counter-clockwise from natural portrait.
     */
    private fun degreesToSurfaceRotation(deg: Int): Int = when (deg) {
        0 -> 0
        90 -> 1
        180 -> 2
        270 -> 3
        else -> error("fixture uses unexpected display_rotation $deg")
    }

    @Test
    fun `every orientation case maps to the expected protocol quaternion`() {
        val cases = Fixtures.load("orientation_cases.json").jsonObject["cases"]!!.jsonArray
        assertTrue(cases.isNotEmpty(), "no orientation cases loaded")
        for (case in cases.map { it.jsonObject }) {
            val id = case["id"]!!.jsonPrimitive.content
            val s = case["android_sensor_quat"]!!.jsonArray.map { it.jsonPrimitive.double }
            val e = case["expected_protocol_quat"]!!.jsonArray.map { it.jsonPrimitive.double }
            val rotation = degreesToSurfaceRotation(case["display_rotation"]!!.jsonPrimitive.int)

            val actual = Frames.sensorToProtocol(Quaternion(s[0], s[1], s[2], s[3]), rotation)
            val expected = Quaternion(e[0], e[1], e[2], e[3])

            assertTrue(
                quatEquals(actual, expected) || quatEquals(actual, expected.negated()),
                "case '$id': expected $expected (or its negation), got $actual",
            )
            assertTrue(
                abs(actual.norm() - 1.0) < tolerance,
                "case '$id': result not normalized (norm=${actual.norm()})",
            )
        }
    }

    @Test
    fun `every arcore case maps to the expected protocol quaternion and position`() {
        val cases = Fixtures.load("arcore_cases.json").jsonObject["cases"]!!.jsonArray
        assertTrue(cases.isNotEmpty(), "no arcore cases loaded")
        for (case in cases.map { it.jsonObject }) {
            val id = case["id"]!!.jsonPrimitive.content
            val a = case["arcore_quat_wxyz"]!!.jsonArray.map { it.jsonPrimitive.double }
            val p = case["arcore_pos_xyz"]!!.jsonArray.map { it.jsonPrimitive.double }
            val eq = case["expected_protocol_quat"]!!.jsonArray.map { it.jsonPrimitive.double }
            val ep = case["expected_protocol_pos"]!!.jsonArray.map { it.jsonPrimitive.double }

            val actualQ = Frames.arcoreToProtocol(Quaternion(a[0], a[1], a[2], a[3]))
            val expectedQ = Quaternion(eq[0], eq[1], eq[2], eq[3])
            assertTrue(
                quatEquals(actualQ, expectedQ) || quatEquals(actualQ, expectedQ.negated()),
                "case '$id': expected $expectedQ (or its negation), got $actualQ",
            )

            val actualP = Frames.arcorePosToProtocol(
                p[0].toFloat(), p[1].toFloat(), p[2].toFloat(),
            )
            val expectedP = Vec3(ep[0].toFloat(), ep[1].toFloat(), ep[2].toFloat())
            assertTrue(
                abs(actualP.x - expectedP.x) < tolerance &&
                    abs(actualP.y - expectedP.y) < tolerance &&
                    abs(actualP.z - expectedP.z) < tolerance,
                "case '$id': expected pos $expectedP, got $actualP",
            )
        }
    }

    @Test
    fun `arcore identity equals the upright_north sensor anchor`() {
        // The two pose sources must agree on what "level, facing north" means,
        // or switching the 6DOF toggle would slew the camera.
        val fromArcore = Frames.arcoreToProtocol(Quaternion.IDENTITY)
        val anchor = Quaternion(0.70710678, 0.70710678, 0.0, 0.0)
        assertTrue(
            quatEquals(fromArcore, anchor) || quatEquals(fromArcore, anchor.negated()),
            "arcore identity $fromArcore != upright_north $anchor",
        )
    }

    private fun quatEquals(a: Quaternion, b: Quaternion): Boolean =
        abs(a.w - b.w) < tolerance &&
            abs(a.x - b.x) < tolerance &&
            abs(a.y - b.y) < tolerance &&
            abs(a.z - b.z) < tolerance
}
