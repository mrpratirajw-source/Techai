// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * The per-frame 6DOF decision, tested without ARCore, a camera or a GL thread.
 *
 * This logic used to be inlined in `ArCorePipeline.onDrawFrame`, where it could
 * not be tested at all, and four consecutive defects shipped from it in one
 * afternoon while every extracted component's own tests passed. Each class of
 * failure gets a test here:
 *
 * - conditional calls: corroboration is fed only when position is valid, and the
 *   verdict must not become self-sustaining;
 * - clocks: the estimator's source clock versus arrival time;
 * - output publication: an outcome always carries a status;
 * - lifecycle: what a tracker start/stop forgets.
 */
class SixDofFramePolicyTest {

    private val ms = 1_000_000L
    private val identity = RigidPose(Quaternion.IDENTITY, Vec3(0f, 0f, 0f))

    private fun frame(
        tracking: Boolean = true,
        reason: String? = "NONE",
        pose: RigidPose? = identity,
        t: Long,
        observed: Long = t,
        sensor: Quaternion? = null,
    ) = SixDofFrame(tracking, reason, pose, t, observed, sensor)

    /** Run frames at 30 fps until [untilNs], returning the last outcome. */
    private fun run(
        policy: SixDofFramePolicy,
        fromNs: Long,
        untilNs: Long,
        pose: (Long) -> RigidPose? = { identity },
        tracking: Boolean = true,
        reason: String? = "NONE",
        sensor: (Long) -> Quaternion? = { null },
    ): SixDofOutcome {
        var t = fromNs
        var last: SixDofOutcome? = null
        while (t <= untilNs) {
            last = policy.onFrame(
                frame(tracking, reason, pose(t), t, t, sensor(t)),
            )
            t += 33 * ms
        }
        return assertNotNull(last)
    }

    // ------------------------------------------------------------- acquisition

    @Test
    fun `warming then good after the dwell`() {
        val policy = SixDofFramePolicy()
        val first = policy.onFrame(frame(t = 0))
        assertEquals(TrackingQuality.WARMING, first.status.quality)
        assertNull(first.pose?.pos, "position is withheld while warming")

        val later = run(policy, 33 * ms, 400 * ms)
        assertEquals(TrackingQuality.GOOD, later.status.quality)
        assertNotNull(later.pose?.pos, "position flows once good")
    }

    @Test
    fun `tracking with no pose is named rather than reported healthy`() {
        // A tracker claiming to track while producing nothing cannot be described
        // by its own reason string, so it must not pass as healthy tracking.
        val policy = SixDofFramePolicy()
        val out = policy.onFrame(frame(tracking = true, pose = null, t = 0))
        assertEquals(TrackingQuality.DEGRADED, out.status.quality)
        assertEquals(TrackingIssue.BAD_STATE, out.status.issue)
    }

    @Test
    fun `a tracker failure reason is carried through`() {
        val policy = SixDofFramePolicy()
        val out = policy.onFrame(
            frame(tracking = false, reason = "INSUFFICIENT_LIGHT", pose = null, t = 0),
        )
        assertEquals(TrackingIssue.INSUFFICIENT_LIGHT, out.status.issue)
    }

    @Test
    fun `camera unavailable still emits a rotation-only hold`() {
        // Otherwise the 100 Hz sender repeats the last GOOD positional pose while
        // the camera is held elsewhere, and both UIs lie.
        val policy = SixDofFramePolicy()
        run(policy, 0, 400 * ms) // reach GOOD so there is an orientation to hold
        val out = policy.onFrame(
            frame(
                tracking = false,
                reason = TrackingIssue.CAMERA_UNAVAILABLE.name,
                pose = null,
                t = 500 * ms,
            ),
        )
        assertEquals(TrackingIssue.CAMERA_UNAVAILABLE, out.status.issue)
        val pose = assertNotNull(out.pose, "the stream must stay alive")
        assertNull(pose.pos, "but with no position")
    }

    // ------------------------------------------------------------------ clocks

    @Test
    fun `a frame that arrives long after its own timestamp is stale`() {
        // The estimator's source clock and arrival time are different things.
        // Passing the wrong one is exactly the kind of wiring error this class
        // exists to make testable.
        val policy = SixDofFramePolicy()
        run(policy, 0, 400 * ms)
        val out = policy.onFrame(
            frame(t = 600 * ms, observed = 600 * ms + 400 * ms),
        )
        assertTrue(
            out.status.quality == TrackingQuality.DEGRADED ||
                out.status.quality == TrackingQuality.LOST,
            "a stale frame must not read as healthy, got ${out.status}",
        )
    }

    @Test
    fun `a gap in the source clock forces recovery before good returns`() {
        val policy = SixDofFramePolicy()
        run(policy, 0, 400 * ms)
        val after = policy.onFrame(frame(t = 400 * ms + 600 * ms))
        assertEquals(
            TrackingQuality.RECOVERING, after.status.quality,
            "a source gap must not resume as GOOD",
        )
        assertNull(after.pose?.pos, "position stays withheld through recovery")
    }

    // --------------------------------------------------------- corroboration

    /** Enough inertial samples for the detector to form a verdict, phone still. */
    private fun feedRest(c: MotionCorroboration, fromNs: Long, untilNs: Long) {
        var t = fromNs
        while (t <= untilNs) {
            c.onAccel(Vec3(0f, 0f, 9.81f), t)
            c.onGyro(Vec3(0f, 0f, 0f), t)
            t += 5 * ms
        }
    }

    @Test
    fun `drift while still degrades the status and withholds position`() {
        val corr = MotionCorroboration()
        val policy = SixDofFramePolicy(corroboration = corr)
        var t = 0L
        var last: SixDofOutcome? = null
        while (t <= 3_000 * ms) {
            feedRest(corr, t, t + 32 * ms)
            // Tracker slides 1 cm per 500 ms while the phone is provably still.
            val x = (t / 1e9f) * 0.02f
            last = policy.onFrame(frame(pose = RigidPose(Quaternion.IDENTITY, Vec3(x, 0f, 0f)), t = t))
            t += 33 * ms
        }
        val out = assertNotNull(last)
        assertEquals(TrackingQuality.DEGRADED, out.status.quality)
        assertEquals(TrackingIssue.INSUFFICIENT_FEATURES, out.status.issue)
        assertNull(out.pose?.pos, "invented translation must not be sent")
        assertNotNull(out.pose, "rotation keeps flowing: it needs no camera")
    }

    @Test
    fun `an honest still tracker is never degraded`() {
        val corr = MotionCorroboration()
        val policy = SixDofFramePolicy(corroboration = corr)
        var t = 0L
        var last: SixDofOutcome? = null
        while (t <= 3_000 * ms) {
            feedRest(corr, t, t + 32 * ms)
            last = policy.onFrame(frame(t = t))
            t += 33 * ms
        }
        val out = assertNotNull(last)
        assertEquals(TrackingQuality.GOOD, out.status.quality)
        assertNotNull(out.pose?.pos)
    }

    @Test
    fun `the verdict is not self-sustaining once position is withheld`() {
        // The feedback deadlock: a verdict withholds position, which stops poses
        // reaching the detector, which used to stop the verdict from ever
        // expiring. The policy is the component that applies that gate, so this is
        // the level the property has to be checked at.
        val corr = MotionCorroboration()
        val policy = SixDofFramePolicy(corroboration = corr)
        var t = 0L
        while (t <= 3_000 * ms) {
            feedRest(corr, t, t + 32 * ms)
            val x = (t / 1e9f) * 0.02f
            policy.onFrame(frame(pose = RigidPose(Quaternion.IDENTITY, Vec3(x, 0f, 0f)), t = t))
            t += 33 * ms
        }
        assertFalse(corr.corroborated, "precondition: the drift was caught")
        // Tracker now holds still. Position is withheld, so the policy stops
        // offering poses -- yet the verdict must still be able to clear.
        var last: SixDofOutcome? = null
        while (t <= 9_000 * ms) {
            feedRest(corr, t, t + 32 * ms)
            last = policy.onFrame(frame(pose = RigidPose(Quaternion.IDENTITY, Vec3(1f, 0f, 0f)), t = t))
            t += 33 * ms
        }
        val out = assertNotNull(last)
        assertEquals(
            TrackingQuality.GOOD, out.status.quality,
            "the camera must recover, or one trip disables 6DOF permanently",
        )
        assertNotNull(out.pose?.pos)
    }

    // ----------------------------------------------------- reference boundary

    @Test
    fun `returning from a blind run reports one reference boundary`() {
        val policy = SixDofFramePolicy()
        run(policy, 0, 400 * ms)
        // Blind: no pose. Rotation continues from the inertial orientation.
        var t = 433 * ms
        while (t <= 900 * ms) {
            val out = policy.onFrame(frame(tracking = false, pose = null, t = t))
            assertFalse(out.crossedReferenceBoundary, "the loss itself is continuous")
            t += 33 * ms
        }
        val back = policy.onFrame(frame(t = t))
        assertTrue(back.crossedReferenceBoundary, "recovery changes the visual reference")
        val next = policy.onFrame(frame(t = t + 33 * ms))
        assertFalse(next.crossedReferenceBoundary, "reported once only")
    }

    @Test
    fun `rotation continues inertially through a blind run`() {
        val policy = SixDofFramePolicy()
        val start = Quaternion(0.9239, 0.0, 0.0, 0.3827) // 45 deg yaw
        run(policy, 0, 400 * ms, sensor = { start })
        val held = assertNotNull(run(policy, 433 * ms, 466 * ms, sensor = { start }).pose).q
        // Operator turns 30 deg further while the tracker cannot see.
        val turned = start * Quaternion(0.9659, 0.0, 0.0, 0.2588)
        val blind = assertNotNull(
            policy.onFrame(frame(tracking = false, pose = null, t = 500 * ms, sensor = turned)).pose,
        )
        val moved = Math.toDegrees(
            2.0 * kotlin.math.acos(kotlin.math.min(1.0, kotlin.math.abs(held.dot(blind.q)))),
        )
        assertTrue(moved > 25.0, "rotation must follow the operator, moved $moved deg")
        assertNull(blind.pos, "position stays invalid while blind")
    }

    // ------------------------------------------------------------- lifecycle

    @Test
    fun `every outcome carries a status`() {
        // Structural: the caller cannot forget to publish it, which is what froze
        // the phone's badge while the wire stayed correct.
        val policy = SixDofFramePolicy()
        val outcomes = listOf(
            policy.onFrame(frame(t = 0)),
            policy.onFrame(frame(tracking = false, pose = null, t = 33 * ms)),
            policy.onFrame(frame(tracking = true, pose = null, t = 66 * ms)),
        )
        outcomes.forEach { assertNotNull(it.status) }
    }

    @Test
    fun `starting the tracker clears a stale verdict and restarts warm-up`() {
        val corr = MotionCorroboration()
        val policy = SixDofFramePolicy(corroboration = corr)
        var t = 0L
        while (t <= 3_000 * ms) {
            feedRest(corr, t, t + 32 * ms)
            val x = (t / 1e9f) * 0.02f
            policy.onFrame(frame(pose = RigidPose(Quaternion.IDENTITY, Vec3(x, 0f, 0f)), t = t))
            t += 33 * ms
        }
        assertFalse(corr.corroborated)
        val status = policy.onTrackerStarted()
        assertEquals(TrackingQuality.WARMING, status.quality, "warm-up restarts")
        assertTrue(corr.corroborated, "a verdict must not outlive the tracker that earned it")
    }

    @Test
    fun `stopping the tracker forgets the orientation it was holding`() {
        val policy = SixDofFramePolicy()
        run(policy, 0, 400 * ms)
        assertEquals(TrackingQuality.UNKNOWN, policy.onTrackerStopped().quality)
        // With nothing remembered there is no orientation to hold, so a blind
        // frame emits nothing rather than resurrecting a stale reference.
        assertNull(
            policy.onFrame(frame(tracking = false, pose = null, t = 500 * ms)).pose,
        )
    }

    @Test
    fun `changing the selected frame forgets the emission reference`() {
        val policy = SixDofFramePolicy()
        run(policy, 0, 400 * ms)
        policy.onSelectedFrameChanged()
        assertNull(
            policy.onFrame(frame(tracking = false, pose = null, t = 500 * ms)).pose,
            "a different world frame must not continue from the old one",
        )
    }
}
