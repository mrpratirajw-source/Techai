// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

/**
 * Splits an H.264 Annex-B elementary stream into access units.
 *
 * Lives here rather than beside the benchmark that needs it, for the reason
 * `SixDofFramePolicy` was carved out of `ArCorePipeline`: logic inlined where
 * nothing can test it is where this project's defects have come from. A decoder
 * fed slightly wrong access units does not fail loudly — it reports a plausible
 * frame count and a plausible latency, and the measurement built on it is quietly
 * wrong. Pure JVM, so `:protocol:test` covers it.
 *
 * Annex-B is NAL units separated by a three- or four-byte start code. The NAL
 * header's low five bits are its type; 1 (non-IDR slice) and 5 (IDR slice) carry
 * picture data, everything else here is parameter sets or SEI that belong to the
 * picture that follows. So an access unit is "any non-picture NALs, then exactly
 * one picture NAL", which is enough for the single-slice streams this measures
 * and is deliberately not a general H.264 parser.
 */
object AnnexB {

    /** NAL types that carry picture data; anything else prefixes the next one. */
    private const val NAL_NON_IDR = 1
    private const val NAL_IDR = 5

    /** One access unit: the bytes to hand `MediaCodec` as a single input buffer. */
    data class AccessUnit(
        val bytes: ByteArray,
        /** True when this unit can be decoded without any earlier frame. */
        val isKeyframe: Boolean,
    ) {
        // Data class equality on a ByteArray compares references, which makes
        // every assertion in a test silently pass. Compare contents.
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is AccessUnit) return false
            return isKeyframe == other.isKeyframe && bytes.contentEquals(other.bytes)
        }

        override fun hashCode(): Int = 31 * bytes.contentHashCode() + isKeyframe.hashCode()
    }

    /** Offsets of every start code in [data], in order. */
    internal fun startCodes(data: ByteArray): List<Int> {
        val out = ArrayList<Int>()
        var i = 0
        while (i + 2 < data.size) {
            if (data[i] == 0.toByte() && data[i + 1] == 0.toByte()) {
                if (data[i + 2] == 1.toByte()) {
                    out.add(i)
                    i += 3
                    continue
                }
                if (i + 3 < data.size &&
                    data[i + 2] == 0.toByte() && data[i + 3] == 1.toByte()
                ) {
                    out.add(i)
                    i += 4
                    continue
                }
            }
            i++
        }
        return out
    }

    private fun nalTypeAt(data: ByteArray, startCodeOffset: Int): Int {
        // Skip the start code itself: three bytes, or four when the third is 0.
        val headerAt = if (data[startCodeOffset + 2] == 1.toByte()) {
            startCodeOffset + 3
        } else {
            startCodeOffset + 4
        }
        if (headerAt >= data.size) return -1
        return data[headerAt].toInt() and 0x1F
    }

    /**
     * Group [data] into access units, each starting at a start code.
     *
     * Parameter sets and SEI are attached to the picture that follows them, so
     * the first unit of a stream carries its own SPS/PPS and can be fed to a
     * freshly configured decoder without a separate configuration step.
     */
    fun split(data: ByteArray): List<AccessUnit> {
        val starts = startCodes(data)
        if (starts.isEmpty()) return emptyList()

        val units = ArrayList<AccessUnit>()
        var unitStart = starts[0]
        var sawPicture = false
        var isKey = false

        for ((index, offset) in starts.withIndex()) {
            val type = nalTypeAt(data, offset)
            if (sawPicture && type != NAL_NON_IDR && type != NAL_IDR) {
                // A non-picture NAL after a picture opens the next access unit.
                units.add(AccessUnit(data.copyOfRange(unitStart, offset), isKey))
                unitStart = offset
                sawPicture = false
                isKey = false
            } else if (sawPicture && (type == NAL_NON_IDR || type == NAL_IDR)) {
                // Two pictures back to back: one unit each.
                units.add(AccessUnit(data.copyOfRange(unitStart, offset), isKey))
                unitStart = offset
                isKey = false
            }
            if (type == NAL_NON_IDR || type == NAL_IDR) {
                sawPicture = true
                if (type == NAL_IDR) isKey = true
            }
            if (index == starts.lastIndex) {
                units.add(AccessUnit(data.copyOfRange(unitStart, data.size), isKey))
            }
        }
        return units
    }
}
