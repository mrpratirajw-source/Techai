// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

import kotlin.math.sqrt

/**
 * The critical coordinate-frame math: Android sensor quaternion → protocol
 * quaternion, per `spec/coordinate-systems.md` §3.
 *
 * Conventions (normative, pinned by `fixtures/orientation_cases.json`):
 * - Quaternions are (w, x, y, z), Hamilton, unit norm.
 * - World frame: right-handed, Z up (Android's game-rotation world frame is
 *   adopted as the protocol world frame as-is).
 * - Camera frame: +X right, +Y up, −Z forward — exactly Blender's camera.
 *
 * This file is platform-free: it never touches Android types. The caller
 * (the app's sensor pipeline) converts `SensorEvent` data to a [Quaternion]
 * and passes the display rotation as a plain Int.
 */
object Frames {

    private val SQRT_HALF = sqrt(0.5)

    /** q_remap for Surface.ROTATION_0 — natural portrait: identity. */
    private val REMAP_0 = Quaternion.IDENTITY

    /** q_remap for Surface.ROTATION_90 — top of phone points left: Rz(−90°). */
    private val REMAP_90 = Quaternion(SQRT_HALF, 0.0, 0.0, -SQRT_HALF)

    /** q_remap for Surface.ROTATION_180 — upside-down portrait: Rz(180°). */
    private val REMAP_180 = Quaternion(0.0, 0.0, 0.0, 1.0)

    /** q_remap for Surface.ROTATION_270 — top of phone points right: Rz(+90°). */
    private val REMAP_270 = Quaternion(SQRT_HALF, 0.0, 0.0, SQRT_HALF)

    /**
     * Converts an Android game-rotation-vector quaternion into the protocol
     * camera orientation:
     *
     * ```
     * q_protocol = q_sensor ⊗ q_remap(display_rotation)
     * ```
     *
     * The remap re-labels the device axes so "camera up" follows the physical
     * grip: with the phone top pointing left, camera-up is the device's +X,
     * and so on. All four grips of the same physical camera pose converge on
     * the same protocol quaternion — the invariant the shared fixtures enforce.
     *
     * @param q the sensor quaternion (w, x, y, z) — the rotation from the
     *   device frame (natural portrait: +X right edge, +Y top edge, +Z out of
     *   the screen) to Android's Z-up world frame. On Android this is the
     *   output of `SensorManager.getQuaternionFromVector`, which fills its
     *   array as `[w, x, y, z]` — already this order.
     * @param surfaceRotation the current display rotation as the
     *   `android.view.Surface.ROTATION_*` constant value, i.e. an Int in 0..3:
     *   `0 = ROTATION_0` (natural portrait), `1 = ROTATION_90` (top points
     *   left — Android rotates the device 90° counter-clockwise from natural),
     *   `2 = ROTATION_180` (upside down), `3 = ROTATION_270` (top points
     *   right). Values outside 0..3 are treated as ROTATION_0.
     * @return the normalized protocol quaternion (normalization guards f32
     *   drift, as the spec requires before sending).
     */
    fun sensorToProtocol(q: Quaternion, surfaceRotation: Int): Quaternion {
        val remap = when (surfaceRotation) {
            1 -> REMAP_90
            2 -> REMAP_180
            3 -> REMAP_270
            else -> REMAP_0
        }
        return (q * remap).normalized()
    }

    /**
     * Cancels the roll introduced by holding the phone off-portrait.
     *
     * The pipelines both produce a PORTRAIT-oriented camera: the sensor path
     * because the window is pinned to portrait so its surface rotation is always
     * ROTATION_0, and the ARCore path because `setDisplayGeometry` is given the
     * real (portrait) display rotation, which it must be or the passthrough
     * image renders sideways. Held in landscape, that leaves the virtual camera
     * rolled a quarter turn and the shot arrives in Blender on its side.
     *
     * [shotRotationDeg] is how far the phone is turned CLOCKWISE from portrait.
     * The fix is to roll the camera back by the same amount about its own
     * forward axis, which is a post-multiplication: the axis is the camera's,
     * not the world's, so it must be applied on the right.
     *
     * Position is untouched. A roll about the forward axis does not move the
     * camera, and rotating the translation here would drag the shot sideways.
     */
    fun shotRotated(q: Quaternion, shotRotationDeg: Int): Quaternion {
        val deg = ((shotRotationDeg % 360) + 360) % 360
        if (deg == 0) return q
        val half = Math.toRadians(deg.toDouble()) / 2.0
        // +sin, not -sin: a phone turned clockwise reads as a POSITIVE roll, so
        // undoing it is a negative roll about the camera's +Z, which points back
        // out of the screen. Getting this sign wrong lands the shot 180 degrees
        // out, which looks deliberate and is not.
        return (q * Quaternion(kotlin.math.cos(half), 0.0, 0.0, kotlin.math.sin(half)))
            .normalized()
    }

    /**
     * ARCore world (right-handed, +Y up) → protocol world (right-handed,
     * +Z up): a fixed +90° rotation about X, left-composed. Pinned by
     * `fixtures/arcore_cases.json`.
     */
    private val ARCORE_TO_PROTOCOL_WORLD = Quaternion(SQRT_HALF, SQRT_HALF, 0.0, 0.0)

    /**
     * Converts an ARCore `displayOrientedPose` camera rotation into the
     * protocol camera orientation:
     *
     * ```
     * q_protocol = Rx(90°) ⊗ q_arcore
     * ```
     *
     * The display-oriented camera frame (+X right, +Y up, −Z forward — OpenGL)
     * already IS the protocol camera convention, so only the world frame
     * changes basis. ARCore's arbitrary horizontal heading is absorbed by the
     * host's re-center, exactly like the sensor path's arbitrary yaw.
     */
    fun arcoreToProtocol(q: Quaternion): Quaternion =
        (ARCORE_TO_PROTOCOL_WORLD * q).normalized()

    /**
     * Converts an ARCore world-frame position (meters) into the protocol
     * world frame: the same +90°-about-X basis change, `(x, y, z) → (x, −z, y)`.
     */
    fun arcorePosToProtocol(x: Float, y: Float, z: Float): Vec3 = Vec3(x, -z, y)
}
