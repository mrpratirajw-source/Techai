// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

/**
 * A platform-free rigid transform whose quaternion rotates local vectors into
 * the parent frame and whose translation is expressed in that parent frame.
 *
 * Keeping this math in :protocol makes the ARCore boundary testable without
 * Android or a device. [compose] follows the same left-composition convention
 * as [Quaternion.times]: `a.compose(b)` applies `b`, then `a`.
 */
data class RigidPose(
    val q: Quaternion,
    val p: Vec3,
) {
    /** `this * other`: transform [other] from its local frame into this frame. */
    fun compose(other: RigidPose): RigidPose {
        val rotation = q.normalized()
        val translated = rotation.rotate(other.p)
        return RigidPose(
            q = (rotation * other.q.normalized()).normalized(),
            p = Vec3(p.x + translated.x, p.y + translated.y, p.z + translated.z),
        )
    }

    /** The transform from this pose's parent frame back into its local frame. */
    fun inverse(): RigidPose {
        val inverseRotation = q.normalized().conjugate()
        val inverseTranslation = inverseRotation.rotate(Vec3(-p.x, -p.y, -p.z))
        return RigidPose(inverseRotation, inverseTranslation)
    }

    /** This pose expressed in [reference]'s local coordinate frame. */
    fun relativeTo(reference: RigidPose): RigidPose = reference.inverse().compose(this)

    companion object {
        val IDENTITY = RigidPose(Quaternion.IDENTITY, Vec3(0f, 0f, 0f))
    }
}
