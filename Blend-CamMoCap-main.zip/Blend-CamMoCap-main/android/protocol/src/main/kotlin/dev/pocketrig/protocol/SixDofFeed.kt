// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

/** One pose emission decided by [SixDofFeed]: what to hand to
 * [SessionClient.updatePose] for a single ARCore frame. */
data class PoseUpdate(
    val q: Quaternion,
    val timestampNs: Long,
    val pos: Vec3?,
    val quality: TrackingQuality = TrackingQuality.UNKNOWN,
    val issue: TrackingIssue = TrackingIssue.NONE,
    /**
     * Lens focal length in mm, or 0 when the lens is not being driven (§4.5).
     * Carried here so the wire and the recorded take agree: a zoom performed
     * during a take has to survive into it.
     */
    val focalLengthMm: Float = 0f,
)

/**
 * The per-frame emit decision of the 6DOF pipeline, extracted pure so it is
 * JVM-testable (no ARCore types): given the tracking state and the raw ARCore
 * pose, decide what the protocol should carry.
 *
 * Spec §4.1 rule this class exists to enforce: a 6DOF sender that loses
 * tracking MUST clear position_valid but keep the stream alive — rotation-only
 * poses with **advancing** timestamps. Going silent instead leaves the host
 * repeating a stale positional pose with a frozen timestamp, and the
 * accumulated real motion lands in one frame when tracking resumes (the
 * "rotate to landscape → camera jumps" bug).
 *
 * Freezing the *orientation* through a loss had the same defect in slower
 * motion: every degree the operator turned while ARCore could not see was
 * delivered as one enormous step on recovery. Orientation does not depend on
 * visual features, so while ARCore is blind this class continues rotation from
 * the inertial rotation vector instead of holding it still.
 *
 * The continuation is composed as a **body-frame relative** rotation:
 *
 * ```
 * q_emit = q_ar_at_loss ⊗ (q_sensor_at_loss⁻¹ ⊗ q_sensor_now)
 * ```
 *
 * ARCore's world frame and Android's rotation-vector world frame are both
 * gravity-aligned but have unrelated yaw references, so the two orientations
 * may not be substituted for one another. The bracketed term is
 * `cam_at_loss ← cam_now` — expressed purely in the camera body frame — so that
 * mismatch cancels exactly, and at the instant of loss the term is identity, so
 * the handoff is continuous by construction rather than by tuning.
 */
class SixDofFeed {

    private var lastQ: Quaternion? = null
    private var lastSensorQ: Quaternion? = null

    /** ARCore orientation at the moment vision was lost; null while tracking. */
    private var holdArQ: Quaternion? = null

    /** Inertial orientation sampled at that same moment. */
    private var holdSensorQ: Quaternion? = null

    private var referenceBoundary = false

    /**
     * @param status the hysteretic quality decision for this frame.
     * @param qArcore displayOrientedPose rotation (ARCore world) when tracking.
     * @param pArcore displayOrientedPose translation (ARCore world, meters).
     * @param frameTimestampNs ARCore frame timestamp (elapsedRealtimeNanos domain).
     * @param nowNs current elapsedRealtimeNanos — used while NOT tracking so
     *   timestamps keep advancing (a mid-take loss bakes a truthful hold).
     * @param qSensorProtocol the inertial orientation already converted to the
     *   protocol frame ([Frames.sensorToProtocol]), sampled as close to this
     *   frame as possible. When null, rotation falls back to holding still.
     * @return what to send, or null (nothing — never tracked yet).
     */
    fun update(
        status: TrackingStatus,
        qArcore: Quaternion?,
        pArcore: Vec3?,
        frameTimestampNs: Long,
        nowNs: Long,
        qSensorProtocol: Quaternion? = null,
    ): PoseUpdate? {
        if (qArcore != null) {
            val q = Frames.arcoreToProtocol(qArcore)
            // Returning from a blind run: the orientation we have been emitting
            // came from inertial continuation, and ARCore's own estimate has
            // drifted from it (and may have relocalized outright). That is a
            // pose-reference boundary, not camera motion — see spec §5.12.
            if (holdArQ != null) referenceBoundary = true
            holdArQ = null
            holdSensorQ = null
            lastQ = q
            lastSensorQ = qSensorProtocol
            return PoseUpdate(
                q,
                frameTimestampNs,
                if (status.positionValid && pArcore != null) {
                    Frames.arcorePosToProtocol(pArcore.x, pArcore.y, pArcore.z)
                } else {
                    null
                },
                status.quality,
                status.issue,
            )
        }

        // ARCore cannot see. Position is not knowable, but orientation is:
        // continue it inertially, relative to the last jointly observed pair.
        val held = lastQ ?: return null
        if (holdArQ == null) {
            holdArQ = held
            holdSensorQ = lastSensorQ
        }
        val base = holdSensorQ
        val continued = if (base != null && qSensorProtocol != null) {
            (holdArQ!! * (base.conjugate() * qSensorProtocol)).normalized()
        } else {
            held // no inertial reference available: hold, as before
        }
        lastQ = continued
        return PoseUpdate(continued, nowNs, null, status.quality, status.issue)
    }

    /**
     * True once per return-from-blind transition. The caller announces it with a
     * reliable `FRAME_RESET` so the host rebases its offsets against the first
     * fresh ARCore pose and the visible camera does not move.
     */
    fun consumeReferenceBoundary(): Boolean {
        val crossed = referenceBoundary
        referenceBoundary = false
        return crossed
    }

    /** Forget all references (pipeline pause/teardown). */
    fun reset() {
        lastQ = null
        lastSensorQ = null
        holdArQ = null
        holdSensorQ = null
        referenceBoundary = false
    }
}
