// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

import kotlin.math.sqrt

/**
 * A rotation quaternion in the pocketrig convention:
 *
 * - Component order **(w, x, y, z)** — scalar first.
 * - **Hamilton** convention, right-handed: [times] implements the Hamilton
 *   product, so `q1 * q2` applies `q2` first, then `q1`, and a pose quaternion
 *   rotates camera-frame vectors into world-frame vectors
 *   (`v_world = q ⊗ v_cam ⊗ q⁻¹`).
 * - `q` and `-q` encode the same rotation; receivers hemisphere-align
 *   consecutive samples (see [dot] / [negated]).
 *
 * Doubles are used internally for precision; the wire format quantizes to f32
 * (see [Packets]).
 */
data class Quaternion(
    val w: Double,
    val x: Double,
    val y: Double,
    val z: Double,
) {
    constructor(w: Float, x: Float, y: Float, z: Float) :
        this(w.toDouble(), x.toDouble(), y.toDouble(), z.toDouble())

    /**
     * Hamilton product `this ⊗ other`: the rotation that applies [other]
     * first, then `this`.
     */
    operator fun times(other: Quaternion): Quaternion = Quaternion(
        w = w * other.w - x * other.x - y * other.y - z * other.z,
        x = w * other.x + x * other.w + y * other.z - z * other.y,
        y = w * other.y - x * other.z + y * other.w + z * other.x,
        z = w * other.z + x * other.y - y * other.x + z * other.w,
    )

    /** Conjugate `(w, -x, -y, -z)`; equals the inverse for unit quaternions. */
    fun conjugate(): Quaternion = Quaternion(w, -x, -y, -z)

    /** Euclidean norm (length) of the 4-vector. */
    fun norm(): Double = sqrt(w * w + x * x + y * y + z * z)

    /**
     * This quaternion scaled to unit length. Returns [IDENTITY] for a
     * degenerate (near-zero) input rather than propagating NaNs.
     */
    fun normalized(): Quaternion {
        val n = norm()
        if (n < 1e-12) return IDENTITY
        return Quaternion(w / n, x / n, y / n, z / n)
    }

    /** 4-vector dot product; negative means the two lie in opposite hemispheres. */
    fun dot(other: Quaternion): Double =
        w * other.w + x * other.x + y * other.y + z * other.z

    /** `-q`, the same rotation in the opposite hemisphere. */
    fun negated(): Quaternion = Quaternion(-w, -x, -y, -z)

    /**
     * Rotate [value] by this quaternion: `v' = q ⊗ v ⊗ q⁻¹`.
     *
     * Computed without allocating two pure-vector quaternions:
     * `t = 2(q.xyz × v)`, `v' = v + w·t + q.xyz × t`.
     */
    fun rotate(value: Vec3): Vec3 {
        val unit = normalized()
        val tx = 2.0 * (unit.y * value.z - unit.z * value.y)
        val ty = 2.0 * (unit.z * value.x - unit.x * value.z)
        val tz = 2.0 * (unit.x * value.y - unit.y * value.x)
        return Vec3(
            (value.x + unit.w * tx + unit.y * tz - unit.z * ty).toFloat(),
            (value.y + unit.w * ty + unit.z * tx - unit.x * tz).toFloat(),
            (value.z + unit.w * tz + unit.x * ty - unit.y * tx).toFloat(),
        )
    }

    companion object {
        /** The identity rotation (1, 0, 0, 0). */
        val IDENTITY = Quaternion(1.0, 0.0, 0.0, 0.0)
    }
}
