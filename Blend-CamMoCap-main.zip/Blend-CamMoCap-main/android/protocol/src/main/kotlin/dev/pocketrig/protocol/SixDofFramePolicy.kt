// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

/**
 * One tracker frame's raw facts. Deliberately contains no ARCore or Android
 * types, so the decision it feeds can be tested without a device.
 */
data class SixDofFrame(
    /** The tracker reports it is tracking this frame (ARCore `TrackingState`). */
    val tracking: Boolean,
    /** The tracker's failure-reason name, or null. Mapped by [TrackingIssue]. */
    val failureReason: String?,
    /**
     * The selected pose in the tracker's own world frame, or null when the
     * tracker has none this frame. Which pose is "selected" (raw versus
     * anchor-relative) is the caller's choice; by here it is just a pose.
     */
    val pose: RigidPose?,
    /** Tracker frame timestamp; shares an epoch with the inertial clock. */
    val frameTimestampNs: Long,
    /** When this frame reached us, for staleness and dwell timing. */
    val observedNs: Long,
    /**
     * Latest inertial orientation already converted to the protocol frame, used
     * to continue rotation while the tracker cannot see (§4.3). Null disables
     * the continuation.
     */
    val sensorOrientation: Quaternion? = null,
)

/**
 * Everything one frame should cause.
 *
 * [status] is non-null on every path. That is deliberate structure, not
 * decoration: the previous shape had the pipeline write its status field
 * directly, an edit left the only write inside a conditional branch, and the
 * phone's badge froze on its last value for every frame that did not take that
 * branch — while the wire stayed correct, so the host looked right and the phone
 * lied. Returning the status makes "forgot to publish it" unrepresentable.
 */
data class SixDofOutcome(
    /** Publish this, and send it. One value, one meaning. */
    val status: TrackingStatus,
    /** What to transmit, or null for nothing (never tracked yet). */
    val pose: PoseUpdate?,
    /**
     * The tracker just returned from a run where it could not see, so its visual
     * reference may have moved. The caller announces this so the frame is
     * re-aligned rather than taken as camera motion (§5.12).
     */
    val crossedReferenceBoundary: Boolean,
)

/**
 * The per-frame decision of the 6DOF path, extracted whole so it can be tested
 * without ARCore, a camera, or a GL thread.
 *
 * It composes the three pure pieces — [TrackingQualityEstimator] for hysteretic
 * acquisition state, [MotionCorroboration] for whether the tracker's translation
 * is physically plausible, and [SixDofFeed] for what to emit — and applies the
 * ordering between them that the pipeline used to inline.
 *
 * ## Why this exists
 *
 * The logic below was previously inside `ArCorePipeline.onDrawFrame`, which needs
 * ARCore, a camera and a GL thread and therefore had no tests at all. Four
 * consecutive defects shipped from that gap in one afternoon while every
 * extracted component's own unit tests passed: a thread-safety crash, thresholds
 * validated against the wrong posture, a feedback deadlock where a verdict
 * suppressed the input that would have cleared it, and a status that stopped
 * being published. None were logic errors in the parts; all were wiring.
 *
 * ## Threading
 *
 * [onFrame] is called from the tracker's render thread only. [MotionCorroboration]
 * is the exception and is explicitly thread-safe, because inertial samples arrive
 * on a sensor thread; this class does not serialise that for it.
 */
class SixDofFramePolicy(
    private val quality: TrackingQualityEstimator = TrackingQualityEstimator(),
    private val feed: SixDofFeed = SixDofFeed(),
    /**
     * Optional physical corroboration. Fed its inertial samples by the caller
     * from a different thread, so it is shared rather than owned.
     */
    private val corroboration: MotionCorroboration? = null,
) {

    fun onFrame(frame: SixDofFrame): SixDofOutcome {
        val pose = frame.pose
        // A tracker claiming to track while producing no pose is in a state we
        // cannot describe with its own reason string, so name it rather than
        // reporting healthy tracking with nothing behind it.
        var status = quality.update(
            tracking = frame.tracking && pose != null,
            failureReason = if (frame.tracking && pose == null) {
                TrackingIssue.BAD_STATE.name
            } else {
                frame.failureReason
            },
            observedNs = frame.observedNs,
            sourceTimestampNs = frame.frameTimestampNs,
        )

        val corr = corroboration
        if (corr != null) {
            // Only a position the tracker itself considers valid carries a claim
            // worth testing. Note this gate is why the verdict's expiry must be
            // driven by the inertial clock: a flag withholds position, which stops
            // poses arriving here, which would otherwise leave the verdict
            // permanently stuck.
            if (status.positionValid && pose != null) {
                corr.onPose(pose.p, frame.frameTimestampNs)
            }
            if (!corr.corroborated) {
                // Withhold position exactly as a real tracking failure does, so
                // the host holds location and re-anchors on recovery through
                // machinery that already exists. Rotation is unaffected: it does
                // not depend on the camera seeing anything.
                status = TrackingStatus(
                    TrackingQuality.DEGRADED,
                    TrackingIssue.INSUFFICIENT_FEATURES,
                )
            }
        }

        val update = feed.update(
            status = status,
            qArcore = pose?.q,
            pArcore = pose?.p,
            frameTimestampNs = frame.frameTimestampNs,
            nowNs = frame.observedNs,
            qSensorProtocol = frame.sensorOrientation,
        )
        return SixDofOutcome(
            status = status,
            pose = update,
            crossedReferenceBoundary = feed.consumeReferenceBoundary(),
        )
    }

    /**
     * The tracker session started. Warm-up begins at the first tracked frame
     * rather than here, and a stale corroboration verdict must not outlive the
     * tracker that earned it. Returns the status to publish.
     */
    fun onTrackerStarted(): TrackingStatus {
        corroboration?.reset()
        return quality.reset()
    }

    /**
     * The tracker session stopped. Forgets the last-known orientation so a later
     * frame cannot continue from a reference that no longer means anything.
     */
    fun onTrackerStopped(): TrackingStatus {
        feed.reset()
        return TrackingStatus.UNKNOWN
    }

    /**
     * The caller changed which pose it selects (e.g. raw versus anchor-relative).
     * That is a different world frame, so the emission reference is dropped; the
     * caller announces the boundary itself, since it knows the reason.
     */
    fun onSelectedFrameChanged() {
        feed.reset()
    }
}
