// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

import java.io.InputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import java.util.UUID
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/** Connection state exposed to the UI. */
sealed interface SessionState {
    data object Disconnected : SessionState

    data class Connecting(val host: String, val port: Int) : SessionState

    data class Live(
        val serverName: String,
        val rttMs: Long? = null,
        val reconnecting: Boolean = false,
    ) : SessionState

    data class Recording(
        val serverName: String,
        val rttMs: Long? = null,
        val reconnecting: Boolean = false,
        /** Record start in the sensor timestamp domain (for the protocol). */
        val startTimestampNs: Long,
        /** Record start in wall-clock millis (for the elapsed timer only). */
        val startedAtWallMs: Long,
        /** Stable identity spanning record, save, upload and host bake. */
        val takeId: String,
    ) : SessionState

    data class Finalizing(
        val serverName: String,
        val rttMs: Long? = null,
        val reconnecting: Boolean = false,
        val takeId: String,
        val stage: FinalizationStage,
        val progress: Float? = null,
        val failure: String? = null,
    ) : SessionState
}

/** User-visible post-recording work. A new take cannot start until Ready. */
enum class FinalizationStage { SAVING, TRANSFERRING, BAKING, FAILED }

/** A finalized phone file that can be streamed without loading it into RAM. */
data class TakeUploadSource(
    val id: String,
    val name: String,
    val source: String,
    val startNs: Long,
    val endNs: Long,
    val sampleCount: Int,
    val byteCount: Long,
    val openFile: () -> InputStream,
)

/** App-owned durable store; deliberately contains no Android types. */
interface ConnectedTakeStore {
    fun beginConnectedTake(takeId: String, startNs: Long, source: String): Boolean
    fun finishConnectedTake(takeId: String, endNs: Long): TakeUploadSource?
    fun abortConnectedTake(takeId: String): TakeUploadSource?
}

/**
 * Which pipeline is allowed to feed poses. Exactly one is authoritative at a
 * time (ADR-0006), and the two sit in unrelated world frames, so a pose from the
 * wrong one is not merely late — it is expressed in the frame the host is trying
 * to leave.
 */
enum class PoseSource { SENSOR, ARCORE }

/** Session tuning values mirrored with the host (spec §5.7). */
data class CamParams(
    val liveSmoothing: Double,
    val recordSmoothing: Double,
    val moveScale: Double,
    /** Legacy/deprecated mirrored "portrait" | "landscape" value. */
    val layout: String? = null,
    /** "offline" | "live" | null — what a finished take bakes from. */
    val takeSource: String? = null,
    /**
     * The host's current focal length in mm, or null when it has not reported
     * one (spec §5.7, host → phone only).
     *
     * This is what the lens rail opens on, so that taking the lens does not
     * change it. It is NOT the value being driven — that is [focalLengthMm] on
     * the outgoing pose — and receiving it never starts driving.
     */
    val hostLensMm: Double? = null,
    /**
     * Angular speed above which the host holds 6DOF position, or 0.0 for off
     * (spec §5.7). Null until the host states one; we use our own default then.
     *
     * This is mirrored rather than local because the "position held" cue and the
     * EXCESSIVE_MOTION quality marking both have to mean what the host means by
     * them. A cue drawn from a different threshold is not an approximation, it
     * is a description of something that is not happening.
     */
    val shakeHoldDps: Double? = null,
    /**
     * The viewport rate the host has measured itself reaching, or null before
     * it has measured one.
     *
     * Distinct from [ViewportOffer.maxFps], which is what the host will accept
     * being asked for. This is what its event loop delivers, and it is the only
     * honest ceiling for the Refresh control -- a timer callback on the host
     * fires once per loop iteration, and the loop runs at the operator's
     * viewport redraw rate, which no setting on this phone can raise.
     */
    val viewportMaxFps: Double? = null,
)

/** One-shot events (toasts/snackbars), delivered via [SessionClient.events]. */
sealed interface SessionEvent {
    /** Host finished baking keyframes ("Baked 240 frames @ 24 fps"). */
    data class Baked(
        val frames: Int,
        val fps: Double,
        val received: Int,
        val sent: Int,
        /** "offline" | "live" — which take was baked (§5.10). */
        val source: String = "live",
        val takeId: String? = null,
    ) : SessionEvent

    /** Host-reported protocol error (bad_token, busy, version_unsupported…). */
    data class HostError(val code: String, val message: String) : SessionEvent

    /** Connect attempt failed (timeout or socket error). */
    data class ConnectFailed(val reason: String) : SessionEvent

    /** The crash-safe phone copy has entered the take library. */
    data class TakeSaved(val id: String) : SessionEvent

    /**
     * The lossless take could not be transferred, so Blender will bake its
     * live-streamed fallback instead. Nothing is lost — [id] is still in the
     * phone library and can be applied — but the finished take came from the
     * lower-quality source, and saying so is the honest thing to do.
     */
    data class TakeTransferFailed(val id: String) : SessionEvent
}

/**
 * The pocketrig client session state machine — pure JVM (UDP via
 * [DatagramSocket], concurrency via kotlinx.coroutines). Implements the v1
 * lifecycle of `spec/protocol.md` §8:
 *
 * - HELLO resent every 200 ms until WELCOME (5 s give-up on initial connect;
 *   during reconnection the HELLO loop continues until the user disconnects,
 *   as §8 places no client-side bound on reconnection).
 * - POSE ticked at 100 Hz with the latest sensor sample (latest-wins).
 * - Reliable messages (RECORD_START/STOP, RECENTER, BYE) resent every 200 ms,
 *   5 s give-up; incoming reliables (WELCOME, RECORD_BAKED, ERROR, BYE) are
 *   ACKed every time and deduplicated by seq.
 * - PING every 2 s; RTT from PONG (`rtt = now − t1`); 3 consecutive missed
 *   PONGs → reconnecting (POSE keeps flowing).
 *
 * All header sequence numbers are per-sender monotonic starting at 1.
 *
 * @param nowNs monotonic clock in the same domain as the sensor timestamps
 *   passed to [updatePose] (on Android: `SystemClock.elapsedRealtimeNanos`).
 * @param ioDispatcher dispatcher for socket I/O.
 */
class SessionClient(
    private val nowNs: () -> Long = System::nanoTime,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    /** Durable connected-take storage supplied by the Android app. */
    private val takeStore: ConnectedTakeStore? = null,
    private val finalizationTimeoutMs: Long = 60_000L,
) {
    // Internal rather than private so MotionGatesTest can assert SHAKE_HOLD_DPS
    // against fixtures/motion_gates.json: the host holds 6DOF position at the
    // same threshold, and a comment cannot enforce that across two languages.
    internal companion object {
        const val POSE_INTERVAL_MS = 10L // 100 Hz
        const val RESEND_INTERVAL_MS = 200L
        const val RELIABLE_GIVE_UP_MS = 5_000L
        const val PING_INTERVAL_MS = 2_000L
        const val MAX_MISSED_PONGS = 3
        const val RECEIVE_BUFFER_SIZE = 2048
        const val DEDUP_WINDOW = 256
        // One retry covers a transient Wi-Fi drop without pushing past the
        // host's ~10 s offline-take fallback deadline (spec 5.4).
        const val TRANSFER_RETRY_DELAY_MS = 400L
        // Must match the host's SHAKE_HOLD_DPS (blender/bl/apply.py): above this
        // angular speed the host holds 6DOF position, so the phone shows the
        // matching "position held" cue. Same signal, same threshold = honest.
        // Pinned to fixtures/motion_gates.json by MotionGatesTest on this side
        // and test_motion_gates.py on the host's, so the two cannot drift.
        /**
         * DEFAULT shake-hold threshold, used until the host states one.
         *
         * The live value is [CamParams.shakeHoldDps] and 0.0 turns the gate off
         * (spec §5.7). It is a setting rather than a constant because no single
         * number works: the gate must sit above every legitimate fast reframe and
         * below a real shake, and those overlap. 300 dps is a 90-degree turn in
         * 0.3 s, which is a framing move, not a shake — hence the default of 500.
         *
         * MUST match the host's SHAKE_HOLD_DPS default (blender/bl/apply.py).
         * Pinned to fixtures/motion_gates.json on both sides.
         */
        const val SHAKE_HOLD_DPS = DEFAULT_SHAKE_HOLD_DPS
        const val FAST_MOTION_HOLD_NS = 250_000_000L // debounce the cue

        /**
         * Weight of each new sample in the smoothed angular speed.
         *
         * ~4 samples to reach most of a step, so roughly 40 ms at 100 Hz: long
         * enough to reject the single-sample spikes that were firing the gate
         * during slow deliberate moves, short enough that a real shake is caught
         * well inside FAST_MOTION_HOLD_NS.
         */
        const val SHAKE_SMOOTHING = 0.25

        /** Below this the division is noise amplification, not a measurement. */
        const val MIN_SHAKE_DT_S = 0.002
    }

    private val _state = MutableStateFlow<SessionState>(SessionState.Disconnected)

    /** Current session state (drive the whole UI from this). */
    val state: StateFlow<SessionState> = _state.asStateFlow()

    private val _events = MutableSharedFlow<SessionEvent>(extraBufferCapacity = 16)

    /** One-shot events: bake results, host errors, connect failures. */
    val events: SharedFlow<SessionEvent> = _events.asSharedFlow()

    private val _params = MutableStateFlow<CamParams?>(null)

    /** Host-mirrored tuning values (spec §5.7); null until the host syncs. */
    val params: StateFlow<CamParams?> = _params.asStateFlow()

    private val _paused = MutableStateFlow(false)

    /** Host-mirrored pause state (spec §5.8): true = live drive suspended. */
    val paused: StateFlow<Boolean> = _paused.asStateFlow()

    private val _libraryApplyId = MutableStateFlow<String?>(null)

    /** Saved take being applied to Blender. Non-null from the user's Apply
     * tap until Blender confirms RECORD_BAKED (or the operation fails). */
    val libraryApplyId: StateFlow<String?> = _libraryApplyId.asStateFlow()

    private val _takeListRequests = MutableSharedFlow<Unit>(extraBufferCapacity = 8)

    /** Host asked for the take library (spec §5.11) — reply via [sendTakeList]. */
    val takeListRequests: SharedFlow<Unit> = _takeListRequests.asSharedFlow()

    private val _takePullRequests = MutableSharedFlow<String>(extraBufferCapacity = 16)

    /** Host asked to pull a take by id (spec §5.11) — upload it. */
    val takePullRequests: SharedFlow<String> = _takePullRequests.asSharedFlow()

    /**
     * What the host said it can stream, from WELCOME (viewport-channel.md §3).
     *
     * Null means it cannot: either an older host, or one whose listener failed
     * to bind. Either way we MUST NOT connect to a port that was never
     * advertised.
     */
    private val _viewport = MutableStateFlow<ViewportOffer?>(null)
    val viewport: StateFlow<ViewportOffer?> = _viewport.asStateFlow()

    private val _fastMotion = MutableStateFlow(false)

    /** True while the phone is rotating fast enough that the host holds 6DOF
     * position (the shake-hold gate). Same angular-speed condition and
     * threshold the host uses, so the "position held" cue is honest. */
    val fastMotion: StateFlow<Boolean> = _fastMotion.asStateFlow()

    private var shakePrevQ: Quaternion? = null
    private var shakePrevTsNs = 0L
    private var shakeLastFastNs = Long.MIN_VALUE
    private var shakeDps = 0.0

    /** Shot axis the last emitted pose used, to spot our own relabelling. */
    private var lastShotRotationDeg = 0

    /**
     * Shake-hold threshold to use when no host has stated one (spec §5.7).
     *
     * The setting is the host's while connected, but the gate also runs with no
     * host at all — offline recording marks its rows EXCESSIVE_MOTION from this
     * same computation, and those marks travel with the take. So the phone keeps
     * its own copy, seeded from the last host value it saw, rather than falling
     * back to a constant an operator has already overridden once.
     */
    @Volatile
    var localShakeHoldDps: Double = SHAKE_HOLD_DPS

    // A display/source/resume boundary is a control-plane event, not pose
    // math. Hold outgoing preview poses until the host ACKs FRAME_RESET, then
    // send the newest raw rigid pose for an atomic host-side rebase.
    private val frameResetGeneration = AtomicLong(0)
    @Volatile
    private var poseOutputBlocked = false

    private class PoseSample(
        val q: Quaternion,
        val timestampNs: Long,
        val pos: Vec3?,
        val quality: TrackingQuality,
        val issue: TrackingIssue,
        val focalLengthMm: Float,
    )

    @Volatile
    private var latestPose: PoseSample? = null

    /**
     * The pipeline currently allowed to feed [updatePose]. Set by the app before
     * it switches pipelines, so a pose still in flight from the outgoing one is
     * discarded rather than mistaken for the new frame's first pose.
     */
    @Volatile
    private var activePoseSource: PoseSource = PoseSource.SENSOR

    /**
     * World-frame rotation mapping the current source's raw frame onto the frame
     * already being emitted, so a source switch produces no discontinuity.
     */
    @Volatile
    private var frameCorrection: Quaternion = Quaternion.IDENTITY

    /** Recompute [frameCorrection] against the next raw pose. */
    @Volatile
    private var alignPending = false

    /** Last pose actually emitted, in the continuous output frame. */
    @Volatile
    private var lastEmittedQ: Quaternion? = null

    /**
     * Lens focal length in mm, or 0 to leave the host's lens alone (§4.5).
     * Sent on every POSE because latest-wins state cannot carry an event.
     */
    @Volatile
    private var focalLengthMm: Float = 0f

    /** Drive the host's lens, or pass 0 to stop driving it. */
    fun setFocalLengthMm(mm: Float) {
        focalLengthMm = if (mm.isFinite() && mm > 0f) mm else 0f
    }

    /** Declare the authoritative pose source. Call BEFORE switching pipelines. */
    fun setActivePoseSource(source: PoseSource) {
        if (source != activePoseSource) alignPending = true
        activePoseSource = source
    }

    /**
     * Re-align the output frame against the next pose, **without** the
     * FRAME_RESET round-trip.
     *
     * For a boundary the sender can absorb entirely on its own, gating the pose
     * stream until the host acknowledges a control message buys nothing and
     * costs a stall — up to a resend interval if the datagram is lost. That is
     * fine for a rare, user-initiated switch, and wrong for something that
     * happens every time ARCore blinks: a handheld shot dips in and out of
     * tracking constantly, and each stall is a visible hitch in the preview.
     */
    fun requestFrameAlignment() {
        alignPending = true
    }

    // The app's existing full-rate pipeline tap writes the durable file. The
    // protocol client owns its transaction marker and finalization lifecycle.
    @Volatile
    private var capturingTakeId: String? = null

    /** Host string for the TCP take upload, and the advertised take port. */
    @Volatile
    private var remoteHost: String? = null
    @Volatile
    private var takePort: Int? = null

    private var scope: CoroutineScope? = null
    private var socket: DatagramSocket? = null
    private var helloJob: Job? = null

    private val seq = AtomicLong(1)
    private val pendingAcks = ConcurrentHashMap<Long, CompletableDeferred<Unit>>()

    /** Seqs of reliable host messages already processed (dedup window). */
    private val processedReliableSeqs = LinkedHashSet<Long>()

    private var token = ""
    private var deviceName = ""
    private var missedPongs = 0

    /** True from connect() until WELCOME lands or the session dies. Lets a
     * silent connect keep the HELLO loop alive while the UI state stays
     * Disconnected. */
    @Volatile
    private var awaitingWelcome = false

    /** True for a background reconnect probe: no Connecting state, no
     * ConnectFailed event — failure looks like nothing happened. */
    @Volatile
    private var silentConnect = false

    /** POSEs sent inside the current record window (for RECORD_STOP). */
    @Volatile
    private var recordSampleCount = 0
    private var recordStartAck: CompletableDeferred<Boolean>? = null
    private var finalizationTimeoutJob: Job? = null
    private var libraryApplyTimeoutJob: Job? = null
    @Volatile
    private var latestPoseHasRawPosition = false

    /**
     * Stores the latest protocol-frame pose. Safe to call from the sensor
     * thread at any rate; the send loop ships the freshest sample at 100 Hz.
     *
     * @param q normalized protocol quaternion (see [Frames.sensorToProtocol]).
     * @param sensorTimestampNs the sensor sample time (`SensorEvent.timestamp`).
     * @param pos protocol-world camera position in meters (6DOF sources only);
     *   null sends a 40-byte rotation-only POSE (spec §4.1).
     */
    /**
     * How far the phone is turned clockwise from portrait, for the shot's axes.
     *
     * Set by the app from the shot-orientation setting. Applied HERE rather than
     * in each pipeline: the sensor and ARCore paths arrive at a portrait camera
     * by different routes, and correcting them separately is how the two modes
     * end up disagreeing about which way is up.
     */
    @Volatile
    var shotRotationDeg: Int = 0

    fun updatePose(
        q: Quaternion,
        sensorTimestampNs: Long,
        pos: Vec3? = null,
        quality: TrackingQuality = TrackingQuality.UNKNOWN,
        issue: TrackingIssue = TrackingIssue.NONE,
        source: PoseSource? = null,
    ): PoseUpdate? {
        // Shot orientation first: everything downstream -- smoothing, the take
        // recorder, latest-wins -- must see the same corrected pose, or a take
        // and its own live preview disagree about which way is up.
        val shotDeg = shotRotationDeg
        @Suppress("NAME_SHADOWING") val q = Frames.shotRotated(q, shotDeg)
        // The shot axis just changed, so the pose we are about to emit is a
        // quarter turn from the last one -- and none of that is the device
        // moving. It is our own relabelling: `shotRotated` rolls the camera to
        // cancel the grip, and the roll is quantized, so a continuous turn of the
        // phone produces one discrete step at the moment the quadrant flips.
        //
        // Measured as motion that step reads as thousands of deg/s, which is well
        // past the shake gate, so simply turning the phone lit "position held"
        // and made the host hold 6DOF position with it. Forget the previous pose
        // instead: there is no honest speed to be had across a boundary where the
        // two samples are expressed differently, and the estimate expires with
        // the pose it came from.
        if (shotDeg != lastShotRotationDeg) {
            lastShotRotationDeg = shotDeg
            shakePrevQ = null
        }
        // A pipeline being torn down can still be inside a frame callback when
        // the switch happens, and land one more pose in `latestPose` AFTER the
        // FRAME_RESET boundary was acknowledged. The host then rebases against a
        // pose from the frame it is leaving, and every pose after it is off by
        // the whole inter-source yaw. Slow toggles hide this because the old
        // pipeline has finished by then; rapid toggles overlap and it sticks.
        if (source != null && source != activePoseSource) return null
        val rawQ = q.normalized()
        // ---- one continuous output frame -------------------------------------
        // The two pipelines have unrelated world frames (measured: a fixed ~90
        // deg yaw), so switching between them used to hand the host a seam and
        // expect it to paper over it -- via a reliable control message, a
        // threshold guard, and a race-free slot handoff. Every one of those is
        // fallible, which is why the symptom was intermittent rather than gone.
        //
        // Instead, make the emitted stream continuous by construction: on a
        // reference change, rotate the incoming frame onto the one already being
        // emitted, so the first corrected pose EQUALS the last emitted pose and
        // there is no seam for anything downstream to handle.
        //
        // The correction is a world-frame rotation applied to BOTH q and p, so
        // they remain one rigid pair in one frame -- the thing spec section 3.1
        // forbids breaking, and the reason a quaternion-only correction was
        // reverted before.
        if (alignPending) {
            val anchor = lastEmittedQ
            frameCorrection = if (anchor != null) {
                (anchor * rawQ.conjugate()).normalized()
            } else {
                Quaternion.IDENTITY // nothing emitted yet: adopt this frame
            }
            alignPending = false
        }
        val correction = frameCorrection
        val normalizedQ = if (correction == Quaternion.IDENTITY) {
            rawQ
        } else {
            (correction * rawQ).normalized()
        }
        val correctedPos = if (pos == null || correction == Quaternion.IDENTITY) {
            pos
        } else {
            correction.rotate(pos)
        }
        lastEmittedQ = normalizedQ
        latestPoseHasRawPosition = pos != null
        // Angular speed vs the previous sample -> the shake-hold cue. Same
        // computation the host does on the quaternion stream (spec §6).
        val prev = shakePrevQ
        if (prev == null) {
            // The smoothed speed is derived from the previous pose, so it cannot
            // outlive it. A reference boundary (FRAME_RESET, connect, teardown)
            // forgets that pose, and this average used to survive it: a genuine
            // shake just before the boundary left a stale value above the gate,
            // and the "position held" cue fired on evidence that no longer
            // existed -- while the host, which shares this computation, really
            // did hold. Expiring it with its evidence can only make the gate LESS
            // eager: the average restarts at zero, so the hold has to be earned
            // again from real motion.
            shakeDps = 0.0
        } else {
            val dt = (sensorTimestampNs - shakePrevTsNs) / 1e9
            // A floor on dt, because the measure is an angle DIVIDED by it: two
            // samples arriving a few hundred microseconds apart turn a fraction
            // of a degree of sensor noise into thousands of degrees per second.
            if (dt >= MIN_SHAKE_DT_S) {
                val d = kotlin.math.min(1.0, kotlin.math.abs(prev.dot(normalizedQ)))
                val dps = Math.toDegrees(2.0 * kotlin.math.acos(d)) / dt
                // Smoothed, not instantaneous. One sample interval is far too
                // short a window to tell a shake from noise: at 100 Hz, half a
                // degree of jitter reads as 50 dps and a couple of noisy samples
                // in a row clear a 300 dps gate while the phone is nearly still.
                // The average still crosses the gate within a few samples of a
                // real shake, comfortably inside the 250 ms hold.
                shakeDps += SHAKE_SMOOTHING * (dps - shakeDps)
                // The host's value, not ours, so the cue describes what Blender
                // is actually doing. 0.0 means the operator switched the hold
                // off; we must then never claim a position is being held.
                val gate = _params.value?.shakeHoldDps ?: localShakeHoldDps
                if (gate > 0.0 && shakeDps > gate) shakeLastFastNs = sensorTimestampNs
            }
        }
        val fastMotion = shakeLastFastNs != Long.MIN_VALUE &&
            sensorTimestampNs >= shakeLastFastNs &&
            sensorTimestampNs - shakeLastFastNs < FAST_MOTION_HOLD_NS
        _fastMotion.value = fastMotion
        shakePrevQ = normalizedQ
        shakePrevTsNs = sensorTimestampNs

        val effectiveQuality = if (fastMotion && quality == TrackingQuality.GOOD) {
            TrackingQuality.DEGRADED
        } else {
            quality
        }
        val effectiveIssue = if (fastMotion && quality == TrackingQuality.GOOD) {
            TrackingIssue.EXCESSIVE_MOTION
        } else {
            issue
        }
        // Preserve raw position in the lossless take, but never advertise it
        // as valid live position while the shake gate is active. The quality
        // marker lets Blender segment the take without destroying evidence.
        val lensMm = focalLengthMm
        latestPose = PoseSample(
            normalizedQ,
            sensorTimestampNs,
            if (effectiveQuality == TrackingQuality.GOOD ||
                effectiveQuality == TrackingQuality.UNKNOWN
            ) correctedPos else null,
            effectiveQuality,
            effectiveIssue,
            lensMm,
        )
        return PoseUpdate(
            normalizedQ, sensorTimestampNs, correctedPos, effectiveQuality,
            effectiveIssue, lensMm,
        )
    }

    /**
     * Announce that the next raw POSE may use a different display/source/world
     * reference. POSE output is gated until the reliable FRAME_RESET is ACKed,
     * then Blender rebases against the newest complete quaternion+position.
     * This is deliberately not user RECENTER and cannot change pause or Home.
     */
    fun requestFrameReset(reason: String) {
        val current = _state.value
        if (current !is SessionState.Live || current.reconnecting || _paused.value) return
        val currentScope = scope ?: return
        val generation = frameResetGeneration.incrementAndGet()
        poseOutputBlocked = true
        latestPose = null
        // Any declared reference change re-aligns the output frame, so the host
        // sees continuity even if this control message is lost or arrives late.
        alignPending = true
        shakePrevQ = null
        shakeLastFastNs = Long.MIN_VALUE
        _fastMotion.value = false
        currentScope.launch {
            var ok = false
            try {
                ok = sendReliable(Message.FrameReset(nextSeq(), nowNs(), reason))
            } finally {
                if (frameResetGeneration.get() == generation) {
                    poseOutputBlocked = false
                }
            }
            if (!ok) enterReconnecting()
        }
    }

    /**
     * Opens the UDP flow and runs the HELLO loop. On WELCOME the state becomes
     * [SessionState.Live]; on failure (bad token, timeout) it returns to
     * [SessionState.Disconnected] with a [SessionEvent] explaining why.
     *
     * With [silent] (auto-reconnect probe on app launch): the state stays
     * Disconnected until WELCOME actually lands, and failure emits nothing —
     * the user never sees a probe that went nowhere.
     */
    fun connect(host: String, port: Int, token: String, deviceName: String, silent: Boolean = false) {
        shutdownNow() // defensive: drop any half-open session without ceremony

        this.token = token
        this.deviceName = deviceName
        this.remoteHost = host
        takePort = null
        seq.set(1)
        missedPongs = 0
        latestPose = null
        latestPoseHasRawPosition = false
        frameCorrection = Quaternion.IDENTITY
        alignPending = false
        lastEmittedQ = null
        frameResetGeneration.set(0)
        poseOutputBlocked = false
        shakePrevQ = null
        shakeLastFastNs = Long.MIN_VALUE
        _fastMotion.value = false
        capturingTakeId = null
        _libraryApplyId.value = null
        _viewport.value = null
        synchronized(processedReliableSeqs) { processedReliableSeqs.clear() }
        pendingAcks.clear()

        val newScope = CoroutineScope(SupervisorJob() + ioDispatcher)
        scope = newScope
        silentConnect = silent
        awaitingWelcome = true
        if (!silent) _state.value = SessionState.Connecting(host, port)

        newScope.launch {
            val sock = try {
                DatagramSocket().also {
                    it.connect(InetSocketAddress(InetAddress.getByName(host), port))
                }
            } catch (e: Exception) {
                if (!silent) {
                    _events.tryEmit(SessionEvent.ConnectFailed(e.message ?: "socket error"))
                }
                shutdown(sendBye = false)
                return@launch
            }
            socket = sock

            launch { receiveLoop(sock) }
            launch { poseLoop() }
            launch { pingLoop() }

            // Initial HELLO loop: resend until WELCOME flips us to Live,
            // give up after 5 s (reliability rule, spec §6).
            val connected = helloLoop(giveUpMs = RELIABLE_GIVE_UP_MS)
            if (!connected && awaitingWelcome) {
                if (!silent) _events.tryEmit(SessionEvent.ConnectFailed("timeout"))
                shutdown(sendBye = false)
            }
        }
    }

    /** Sends BYE (best-effort reliable) and tears the session down. */
    fun disconnect() = shutdown(sendBye = true)

    /**
     * Reliable RECORD_START stamped with the latest sensor timestamp. The
     * state flips to [SessionState.Recording] immediately (the ACK normally
     * lands within a frame); a reliability give-up degrades to reconnecting.
     */
    fun startRecording() {
        if (_libraryApplyId.value != null) return
        val live = _state.value as? SessionState.Live ?: return
        val startNs = latestPose?.timestampNs ?: nowNs()
        val takeId = UUID.randomUUID().toString()
        recordSampleCount = 0
        // Capture the take losslessly on-device iff the host advertised a take
        // port and take_source isn't forced to "live". Decided ONCE at start
        // (the host freezes take_source during a take).
        val wantsOffline = takePort != null && _params.value?.takeSource != "live"
        // Label capability from the raw source, not temporary live validity:
        // an ARCore frame may be quality-held at the exact Record tap while
        // the durable take still contains valid position before/after it.
        val source = if (latestPoseHasRawPosition) "arcore" else "sensor"
        val offline = wantsOffline &&
            takeStore?.beginConnectedTake(takeId, startNs, source) == true
        capturingTakeId = if (offline) takeId else null
        _state.value = SessionState.Recording(
            serverName = live.serverName,
            rttMs = live.rttMs,
            reconnecting = live.reconnecting,
            startTimestampNs = startNs,
            startedAtWallMs = System.currentTimeMillis(),
            takeId = takeId,
        )
        val startResult = CompletableDeferred<Boolean>()
        recordStartAck = startResult
        scope?.launch {
            val msg = Message.RecordStart(
                nextSeq(), nowNs(), startTimestampNs = startNs, takeId = takeId,
            )
            val ok = sendReliable(msg)
            startResult.complete(ok)
            if (!ok) enterReconnecting()
        }
    }

    /** Reliable RECORD_STOP; uploads the offline take if one was captured. */
    fun stopRecording() {
        finishRecording()
    }

    /**
     * Ends the current take (user- or host-initiated): enters Finalizing,
     * atomically closes the phone file, sends RECORD_STOP, and streams that
     * file to Blender. The host holds its live-streamed
     * copy as a fallback until the upload lands, so a take is never lost.
     */
    private fun finishRecording() {
        val rec = _state.value as? SessionState.Recording ?: return
        val endNs = latestPose?.timestampNs ?: nowNs()
        val liveCount = recordSampleCount
        val captureId = capturingTakeId
        capturingTakeId = null
        _state.value = SessionState.Finalizing(
            rec.serverName, rec.rttMs, rec.reconnecting, rec.takeId,
            FinalizationStage.SAVING,
        )
        finalizationTimeoutJob?.cancel()
        finalizationTimeoutJob = scope?.launch {
            delay(finalizationTimeoutMs)
            _state.update { s ->
                if (s is SessionState.Finalizing && s.takeId == rec.takeId) {
                    s.copy(
                        stage = FinalizationStage.FAILED,
                        progress = null,
                        failure = "Blender did not confirm the take",
                    )
                } else {
                    s
                }
            }
        }
        scope?.launch {
            // Start and Stop are separate reliable controls but one ordered
            // transaction. A very fast tap must never put STOP on the wire
            // before START has completed its resend/ACK cycle.
            recordStartAck?.await()
            recordStartAck = null
            val saved = if (captureId == rec.takeId) {
                withContext(ioDispatcher) {
                    runCatching {
                        takeStore?.finishConnectedTake(rec.takeId, endNs)
                    }.getOrNull()
                }
            } else {
                null
            }
            val offline = saved != null && takePort != null
            if (saved != null) _events.tryEmit(SessionEvent.TakeSaved(saved.id))
            val msg = Message.RecordStop(
                nextSeq(), nowNs(),
                endTimestampNs = endNs,
                sampleCount = liveCount,
                offline = offline,
                takeId = rec.takeId,
            )
            if (!sendReliable(msg)) enterReconnecting()
            if (saved != null && takePort != null) {
                updateFinalizationStage(
                    rec.takeId, FinalizationStage.TRANSFERRING, progress = 0f,
                )
                // The upload result used to be discarded, so a failed transfer
                // silently downgraded the finished take to the live preview —
                // the exact opposite of the promise that the lossless local
                // capture is the default source. Retry once for a transient
                // drop, then say what happened. The host's fallback deadline
                // still bakes something either way, so a take is never lost.
                var uploaded = uploadTake(saved, rec.takeId)
                if (!uploaded) {
                    delay(TRANSFER_RETRY_DELAY_MS)
                    updateFinalizationStage(
                        rec.takeId, FinalizationStage.TRANSFERRING, progress = 0f,
                    )
                    uploaded = uploadTake(saved, rec.takeId)
                }
                if (!uploaded) _events.tryEmit(SessionEvent.TakeTransferFailed(saved.id))
                updateFinalizationStage(rec.takeId, FinalizationStage.BAKING)
            } else {
                updateFinalizationStage(rec.takeId, FinalizationStage.BAKING)
            }
        }
    }

    private fun updateFinalizationStage(
        takeId: String,
        stage: FinalizationStage,
        progress: Float? = null,
    ) {
        _state.update { s ->
            if (s is SessionState.Finalizing && s.takeId == takeId) {
                s.copy(stage = stage, progress = progress, failure = null)
            } else {
                s
            }
        }
    }

    /**
     * The host refused this take (ERROR `record_rejected`). Close the durable
     * capture so its rows are not orphaned as a `.partial`, keep the resulting
     * file in the library, and return to Live so the user can simply try again.
     */
    private fun abandonRejectedRecording() {
        val current = _state.value
        if (current !is SessionState.Recording && current !is SessionState.Finalizing) return
        val capture = capturingTakeId
        capturingTakeId = null
        finalizationTimeoutJob?.cancel()
        finalizationTimeoutJob = null
        recordStartAck?.complete(false)
        recordStartAck = null
        if (capture != null) {
            val recovered = runCatching { takeStore?.abortConnectedTake(capture) }.getOrNull()
            if (recovered != null) _events.tryEmit(SessionEvent.TakeSaved(recovered.id))
        }
        _state.update { s ->
            when (s) {
                is SessionState.Recording -> SessionState.Live(s.serverName, s.rttMs, s.reconnecting)
                is SessionState.Finalizing -> SessionState.Live(s.serverName, s.rttMs, s.reconnecting)
                else -> s
            }
        }
    }

    /** Leave an explicitly failed finalization; the durable phone copy stays. */
    fun dismissFinalizationFailure() {
        _state.update { s ->
            if (s is SessionState.Finalizing && s.stage == FinalizationStage.FAILED) {
                SessionState.Live(s.serverName, s.rttMs, s.reconnecting)
            } else {
                s
            }
        }
    }

    private suspend fun uploadTake(source: TakeUploadSource, takeId: String?): Boolean {
        val host = remoteHost ?: return false
        val port = takePort ?: return false
        return withContext(ioDispatcher) {
            runCatching {
                java.net.Socket().use { sock ->
                    sock.connect(InetSocketAddress(host, port), 3000)
                    sock.soTimeout = 6000
                    val out = sock.getOutputStream().buffered()
                    out.write(
                        encodeTakeHeader(
                            startNs = source.startNs,
                            endNs = source.endNs,
                            sampleCount = source.sampleCount,
                            token = token,
                            name = source.name,
                            id = source.id,
                            source = source.source,
                            transactionId = takeId,
                        ),
                    )
                    source.openFile().buffered().use { input ->
                        // The durable file already has its own token-free
                        // header. Replace only that line, then stream rows.
                        while (true) {
                            val b = input.read()
                            if (b < 0 || b == '\n'.code) break
                        }
                        val buffer = ByteArray(64 * 1024)
                        var copied = 0L
                        while (true) {
                            val n = input.read(buffer)
                            if (n < 0) break
                            out.write(buffer, 0, n)
                            copied += n
                            val denominator = source.byteCount.coerceAtLeast(1L)
                            if (takeId != null) {
                                updateFinalizationStage(
                                    takeId,
                                    FinalizationStage.TRANSFERRING,
                                    (copied.toDouble() / denominator)
                                        .coerceIn(0.0, 1.0).toFloat(),
                                )
                            }
                        }
                    }
                    out.flush()
                    sock.getInputStream().bufferedReader().readLine()?.trim() == "ok"
                }
            }.getOrDefault(false)
        }
    }

    /** True once WELCOME advertised a take port — the host can receive uploads. */
    val takeUploadReady: Boolean get() = takePort != null && remoteHost != null

    /** Applies a durable phone take without materializing all rows in RAM. */
    suspend fun uploadSavedTake(source: TakeUploadSource): Boolean {
        if (source.sampleCount <= 0 || !takeUploadReady) return false
        if (_state.value !is SessionState.Live) return false
        if (!_libraryApplyId.compareAndSet(null, source.id)) return false

        // Apply is pause -> transfer -> bake -> review. Pause is reliable and
        // ordered before TCP upload, so Blender's main tick freezes the visible
        // camera before it sees the take. This removes the old moving-anchor
        // race and makes phone-push identical to Blender-pull.
        _paused.value = true
        val pausedOk = sendReliable(Message.Pause(nextSeq(), nowNs(), true))
        if (!pausedOk) {
            _libraryApplyId.compareAndSet(source.id, null)
            return false
        }
        val uploaded = uploadTake(source, takeId = null)
        if (!uploaded) {
            _libraryApplyId.compareAndSet(source.id, null)
            return false
        }
        libraryApplyTimeoutJob?.cancel()
        libraryApplyTimeoutJob = scope?.launch {
            delay(finalizationTimeoutMs)
            _libraryApplyId.compareAndSet(source.id, null)
        }
        return true
    }

    /** Reliable RECENTER (`{}`): current framing becomes the new reference. */
    fun recenter() {
        if (_state.value !is SessionState.Live) return // host ignores it while recording anyway
        scope?.launch {
            sendReliable(Message.Recenter(nextSeq(), nowNs()))
        }
    }

    /** User toggled pause on the phone: request it (spec §5.8; the host may
     * refuse while recording and will push the actual state back). */
    fun sendPause(paused: Boolean) {
        if (!paused && _libraryApplyId.value != null) return
        _paused.value = paused
        scope?.launch {
            sendReliable(Message.Pause(nextSeq(), nowNs(), paused))
        }
    }

    /**
     * User moved a slider on the phone: request the host apply these values
     * (spec §5.7 — the host clamps and does not echo, so the local mirror
     * updates optimistically).
     */
    fun sendParams(
        liveSmoothing: Double,
        recordSmoothing: Double,
        moveScale: Double,
        layout: String? = null,
        takeSource: String? = null,
        shakeHoldDps: Double? = null,
    ) {
        // hostLensMm is the host's to report, not ours to send: carry the last
        // known one forward so moving a smoothing slider does not blank the
        // value the lens rail opens on. shakeHoldDps carries forward for the
        // same reason -- it is mirrored, so an omission here would silently
        // return the gate to its default on the next slider touch.
        val gate = shakeHoldDps ?: _params.value?.shakeHoldDps
        val p = CamParams(
            liveSmoothing, recordSmoothing, moveScale, layout, takeSource,
            hostLensMm = _params.value?.hostLensMm,
            shakeHoldDps = gate,
            // Host-reported, like hostLensMm: carry it forward so touching a
            // slider does not blank the Refresh control's ceiling.
            viewportMaxFps = _params.value?.viewportMaxFps,
        )
        _params.value = p
        scope?.launch {
            sendReliable(
                Message.Params(
                    nextSeq(), nowNs(),
                    liveSmoothing = p.liveSmoothing,
                    recordSmoothing = p.recordSmoothing,
                    moveScale = p.moveScale,
                    layout = p.layout,
                    takeSource = p.takeSource,
                    shakeHoldDps = gate,
                ),
            )
        }
    }

    /** Jump the host's playhead to the scene start — the retake button. */
    fun seekToStart() {
        scope?.launch {
            sendReliable(Message.Seek(nextSeq(), nowNs(), frame = null))
        }
    }

    /** Reply to a host TAKE_LIST request with the phone's library (spec §5.11). */
    /**
     * Start, reconfigure or stop the viewport stream (viewport-channel.md §5.1).
     *
     * [size] must be one the host advertised: it renders the camera at one of
     * those and nothing else.
     */
    fun sendViewportControl(
        mode: String,
        codec: String? = null,
        size: Pair<Int, Int>? = null,
        fps: Double? = null,
        quality: Int? = null,
        overlays: Boolean? = null,
        profile: String? = null,
    ) {
        scope?.launch {
            sendReliable(
                Message.ViewportControl(
                    nextSeq(), nowNs(), mode, codec, size, fps, quality, overlays,
                    profile,
                ),
            )
        }
    }

    /**
     * Report that a frame reached the screen (viewport-channel.md §5.2).
     *
     * Deliberately NOT reliable, and sent raw rather than through the resend
     * layer: this is telemetry about a preview, and on a struggling link it
     * should be dropped rather than queued behind the frames it describes.
     */
    fun sendViewportStat(ordinal: Long, decodedNs: Long, presentedNs: Long) {
        val sock = socket ?: return
        sendRawOn(
            sock,
            Packets.encode(
                Message.ViewportStat(nextSeq(), nowNs(), ordinal, decodedNs, presentedNs),
            ),
        )
    }

    fun sendTakeList(takes: List<TakeInfo>) {
        scope?.launch {
            sendReliable(Message.TakeList(nextSeq(), nowNs(), takes = takes))
        }
    }

    // ------------------------------------------------------------------ loops

    /**
     * Resends HELLO every 200 ms until the state leaves Connecting/reconnecting
     * (WELCOME received). Returns true once connected, false on give-up.
     * [giveUpMs] ≤ 0 means no give-up (reconnection loop).
     */
    private suspend fun helloLoop(giveUpMs: Long): Boolean {
        val deadline = if (giveUpMs > 0) System.nanoTime() + giveUpMs * 1_000_000 else Long.MAX_VALUE
        // HELLO is reliable: retries are the identical datagram/sequence, just
        // like every other reliable control. WELCOME is the successful reply.
        val hello = Packets.encode(
            Message.Hello(
                seq = nextSeq(),
                timestampNs = nowNs(),
                deviceName = deviceName,
                appVersion = APP_VERSION,
                protocolVersion = Packets.PROTOCOL_VERSION,
                token = token,
            ),
        )
        while (System.nanoTime() < deadline) {
            if (!isWaitingForWelcome()) return true
            sendRaw(hello)
            delay(RESEND_INTERVAL_MS)
        }
        return !isWaitingForWelcome()
    }

    private fun isWaitingForWelcome(): Boolean = when (val s = _state.value) {
        is SessionState.Connecting -> true
        is SessionState.Live -> s.reconnecting
        is SessionState.Recording -> s.reconnecting
        is SessionState.Finalizing -> s.reconnecting
        // A silent connect keeps the HELLO loop alive with the UI still
        // showing Disconnected.
        is SessionState.Disconnected -> awaitingWelcome
    }

    /** 100 Hz POSE ticker: finalization keeps the disposable live preview moving. */
    private suspend fun poseLoop() {
        while (true) {
            delay(POSE_INTERVAL_MS)
            val s = _state.value
            val recording = s is SessionState.Recording
            if (s !is SessionState.Live &&
                s !is SessionState.Recording &&
                s !is SessionState.Finalizing
            ) continue
            if (poseOutputBlocked) continue
            val pose = latestPose ?: continue
            val msg = Message.Pose(
                seq = nextSeq(),
                timestampNs = pose.timestampNs,
                q = pose.q,
                recording = recording,
                pos = pose.pos,
                trackingQuality = pose.quality,
                trackingIssue = pose.issue,
                focalLengthMm = pose.focalLengthMm,
            )
            sendRaw(Packets.encode(msg))
            if (recording && pose.timestampNs >= (s as SessionState.Recording).startTimestampNs) {
                recordSampleCount++
            }
        }
    }

    /** PING every 2 s; 3 consecutive misses (~6 s) → reconnecting (spec §8). */
    private suspend fun pingLoop() {
        while (true) {
            delay(PING_INTERVAL_MS)
            val s = _state.value
            if (s !is SessionState.Live &&
                s !is SessionState.Recording &&
                s !is SessionState.Finalizing
            ) {
                missedPongs = 0
                continue
            }
            sendRaw(Packets.encode(Message.Ping(nextSeq(), nowNs())))
            // Any PONG resets missedPongs to 0 (see handleIncoming); if three
            // pings go out with no reset in between, the link is gone.
            missedPongs++
            if (missedPongs >= MAX_MISSED_PONGS) enterReconnecting()
        }
    }

    private suspend fun receiveLoop(sock: DatagramSocket) {
        val buf = ByteArray(RECEIVE_BUFFER_SIZE)
        val packet = DatagramPacket(buf, buf.size)
        while (true) {
            try {
                // DatagramPacket.length is both the received length and the
                // next receive's maximum. Restore capacity after every short
                // datagram (especially 20-byte ACKs) or larger controls are
                // truncated and silently fail decoding.
                packet.length = buf.size
                sock.receive(packet)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                if (sock.isClosed) return
                continue // e.g. ICMP port-unreachable surfaced as SocketException
            }
            val msg = Packets.decode(packet.data, packet.length) ?: continue
            handleIncoming(msg)
        }
    }

    // ------------------------------------------------------------ dispatching

    private fun handleIncoming(msg: Message) {
        when (msg) {
            is Message.Ack -> pendingAcks[msg.ackedSeq]?.complete(Unit)

            is Message.Pong -> {
                missedPongs = 0
                val rttMs = ((nowNs() - msg.t1) / 1_000_000L).coerceAtLeast(0)
                _state.update { s ->
                    when (s) {
                        is SessionState.Live -> s.copy(rttMs = rttMs)
                        is SessionState.Recording -> s.copy(rttMs = rttMs)
                        is SessionState.Finalizing -> s.copy(rttMs = rttMs)
                        else -> s
                    }
                }
            }

            is Message.Welcome -> {
                ack(msg.seq)
                if (markProcessed(msg.seq)) {
                    missedPongs = 0
                    takePort = msg.takePort  // offline-take upload port (§5.10)
                    _viewport.value = msg.viewportPort?.let { port ->
                        ViewportOffer(
                            port = port,
                            modes = msg.viewportModes,
                            codecs = msg.viewportCodecs,
                            sizes = msg.viewportSizes,
                            maxFps = msg.viewportMaxFps,
                        )
                    }
                    val wasAwaiting = awaitingWelcome
                    awaitingWelcome = false
                    // A fresh connect (Connecting/silent-Disconnected -> Live)
                    // starts PAUSED: the interactive host starts paused and its
                    // PAUSE lands a beat later, so default to paused now to avoid
                    // a flash of "live". The host stays authoritative — it will
                    // send paused=false if it is actually live. A reconnect blip
                    // (Live/Recording already) keeps whatever state it had.
                    val freshConnect = _state.value is SessionState.Connecting ||
                        (wasAwaiting && _state.value is SessionState.Disconnected)
                    if (freshConnect) _paused.value = true
                    _state.update { s ->
                        when (s) {
                            is SessionState.Connecting -> SessionState.Live(msg.serverName)
                            is SessionState.Live -> s.copy(serverName = msg.serverName, reconnecting = false)
                            is SessionState.Recording -> s.copy(serverName = msg.serverName, reconnecting = false)
                            is SessionState.Finalizing ->
                                s.copy(serverName = msg.serverName, reconnecting = false)
                            // Silent connect completing: Disconnected -> Live.
                            is SessionState.Disconnected ->
                                if (wasAwaiting) SessionState.Live(msg.serverName) else s
                        }
                    }
                }
            }

            is Message.RecordBaked -> {
                ack(msg.seq)
                if (markProcessed(msg.seq)) {
                    // Arriving while still Recording means the HOST ended the
                    // take (scene end frame = cut; spec §5.5): leave Recording.
                    val current = _state.value
                    val rec = current as? SessionState.Recording
                    val matchesActive = when (current) {
                        is SessionState.Recording ->
                            msg.takeId == null || msg.takeId == current.takeId
                        is SessionState.Finalizing ->
                            msg.takeId == null || msg.takeId == current.takeId
                        else -> true
                    }
                    if (!matchesActive) return
                    // A standalone library Apply has no recording transaction
                    // id. Its confirmation ends the separate Apply lock; the
                    // host's PAUSE mirror remains true for review/scrubbing.
                    if (current is SessionState.Live && _libraryApplyId.value != null) {
                        _libraryApplyId.value = null
        _viewport.value = null
                        libraryApplyTimeoutJob?.cancel()
                        libraryApplyTimeoutJob = null
                    }
                    finalizationTimeoutJob?.cancel()
                    finalizationTimeoutJob = null
                    if (rec != null) {
                        // RECORD_STOP normally arrives first and runs the full
                        // finalizer. If it was lost but the host already baked,
                        // stop capture authoritatively without uploading a
                        // second standalone take back to the host.
                        val saved = runCatching {
                            takeStore?.finishConnectedTake(
                                rec.takeId, latestPose?.timestampNs ?: nowNs(),
                            )
                        }.getOrNull()
                        capturingTakeId = null
                        if (saved != null) _events.tryEmit(SessionEvent.TakeSaved(saved.id))
                        _state.value = SessionState.Live(
                            rec.serverName, rec.rttMs, rec.reconnecting,
                        )
                    } else if (
                        current is SessionState.Finalizing &&
                        (msg.takeId == null || msg.takeId == current.takeId)
                    ) {
                        _state.value = SessionState.Live(
                            current.serverName, current.rttMs, current.reconnecting,
                        )
                    }
                    _events.tryEmit(
                        SessionEvent.Baked(
                            msg.frames, msg.fps, msg.received, msg.sent, msg.source, msg.takeId,
                        ),
                    )
                }
            }

            is Message.ErrorMsg -> {
                ack(msg.seq)
                if (markProcessed(msg.seq)) {
                    if (_libraryApplyId.value != null) {
                        _libraryApplyId.value = null
        _viewport.value = null
                        libraryApplyTimeoutJob?.cancel()
                        libraryApplyTimeoutJob = null
                    }
                    // The host refused to start this take (it is still recording
                    // or baking another one). Abandon it now rather than waiting
                    // out the finalization timeout: the durable phone copy is
                    // closed and kept in the library, so nothing captured is
                    // lost, and the controls unlock immediately.
                    if (msg.code == "record_rejected") {
                        abandonRejectedRecording()
                    }
                    _state.update { s ->
                        if (s is SessionState.Finalizing && msg.code == "bake_failed") {
                            s.copy(
                                stage = FinalizationStage.FAILED,
                                progress = null,
                                failure = msg.message.ifBlank { "Blender could not create keyframes" },
                            )
                        } else {
                            s
                        }
                    }
                    if (_state.value is SessionState.Finalizing && msg.code == "bake_failed") {
                        finalizationTimeoutJob?.cancel()
                        finalizationTimeoutJob = null
                    }
                    if (!silentConnect || !awaitingWelcome) {
                        _events.tryEmit(SessionEvent.HostError(msg.code, msg.message))
                    }
                    if (_state.value is SessionState.Connecting ||
                        (awaitingWelcome && _state.value is SessionState.Disconnected)
                    ) {
                        shutdown(sendBye = false)
                    }
                }
            }

            is Message.Params -> {
                ack(msg.seq)
                if (markProcessed(msg.seq)) {
                    // Host truth: update the mirror, never reply (spec §5.7).
                    // An omitted lens_mm means "not reporting right now" (we are
                    // driving it, or it is animated) -- not "unknown" -- so keep
                    // the last one. The only fallback for having none is a made-up
                    // default, which is the reframing this whole field exists to
                    // avoid, so reach it as rarely as possible.
                    _params.value = CamParams(
                        msg.liveSmoothing, msg.recordSmoothing, msg.moveScale,
                        msg.layout, msg.takeSource,
                        hostLensMm = msg.lensMm ?: _params.value?.hostLensMm,
                        // Same "omitted means unchanged" rule: 0.0 is a real
                        // value (gate off) and must not read as "not stated".
                        shakeHoldDps = msg.shakeHoldDps ?: _params.value?.shakeHoldDps,
                        // Sticky for the same reason: the host omits it while
                        // the stream is off or idle, and "not being measured
                        // right now" is not "the ceiling went away".
                        viewportMaxFps = msg.viewportMaxFps
                            ?: _params.value?.viewportMaxFps,
                    )
                }
            }

            is Message.Pause -> {
                ack(msg.seq)
                if (markProcessed(msg.seq)) _paused.value = msg.paused
            }

            is Message.RecordStop -> {
                // Host ended the take (e.g. scene end frame, spec §5.4): stop
                // exactly as if the user pressed stop — reply + upload.
                ack(msg.seq)
                if (markProcessed(msg.seq)) finishRecording()
            }

            is Message.TakeList -> {
                // Only requests reach the phone (takes == null); the app replies.
                ack(msg.seq)
                if (markProcessed(msg.seq) && msg.takes == null) {
                    _takeListRequests.tryEmit(Unit)
                }
            }

            is Message.TakePull -> {
                ack(msg.seq)
                if (markProcessed(msg.seq)) _takePullRequests.tryEmit(msg.id)
            }

            is Message.Bye -> {
                ack(msg.seq)
                if (markProcessed(msg.seq)) shutdown(sendBye = false)
            }

            // Phone→host message types echoing back: ignore.
            else -> Unit
        }
    }

    private fun enterReconnecting() {
        var entered = false
        _state.update { s ->
            when (s) {
                is SessionState.Live ->
                    if (s.reconnecting) s else s.copy(reconnecting = true, rttMs = null).also { entered = true }
                is SessionState.Recording ->
                    if (s.reconnecting) s else s.copy(reconnecting = true, rttMs = null).also { entered = true }
                is SessionState.Finalizing ->
                    if (s.reconnecting) s else s.copy(reconnecting = true, rttMs = null).also { entered = true }
                else -> s
            }
        }
        if (entered) {
            missedPongs = 0
            helloJob?.cancel()
            // Same token resumes the session (spec §8); POSE keeps flowing.
            helloJob = scope?.launch { helloLoop(giveUpMs = 0) }
        }
    }

    // --------------------------------------------------------------- plumbing

    private fun nextSeq(): Long = seq.getAndIncrement()

    /**
     * Sends a reliable message on the current socket: resend every 200 ms
     * until its seq is ACKed; give up after [giveUpMs]. Returns true if ACKed.
     */
    private suspend fun sendReliable(msg: Message, giveUpMs: Long = RELIABLE_GIVE_UP_MS): Boolean {
        val sock = socket ?: return false
        return sendReliableOn(sock, msg, giveUpMs)
    }

    /** [sendReliable] against an explicit socket (used during shutdown). */
    private suspend fun sendReliableOn(sock: DatagramSocket, msg: Message, giveUpMs: Long): Boolean {
        val bytes = Packets.encode(msg)
        val acked = CompletableDeferred<Unit>()
        pendingAcks[msg.seq] = acked
        try {
            val deadline = System.nanoTime() + giveUpMs * 1_000_000
            while (System.nanoTime() < deadline) {
                sendRawOn(sock, bytes)
                val remainingMs = (deadline - System.nanoTime()) / 1_000_000
                val wait = withTimeoutOrNull(RESEND_INTERVAL_MS.coerceAtMost(remainingMs.coerceAtLeast(1))) {
                    acked.await()
                }
                if (wait != null) return true
            }
            return false
        } finally {
            pendingAcks.remove(msg.seq)
        }
    }

    /** ACK every incoming reliable datagram, duplicates included (spec §6). */
    private fun ack(receivedSeq: Long) {
        sendRaw(Packets.encode(Message.Ack(nextSeq(), nowNs(), ackedSeq = receivedSeq)))
    }

    /** Returns true the first time [seq] is seen (process once, spec §6). */
    private fun markProcessed(seq: Long): Boolean = synchronized(processedReliableSeqs) {
        if (!processedReliableSeqs.add(seq)) return false
        if (processedReliableSeqs.size > DEDUP_WINDOW) {
            processedReliableSeqs.remove(processedReliableSeqs.first())
        }
        true
    }

    private fun sendRaw(bytes: ByteArray) {
        val sock = socket ?: return
        sendRawOn(sock, bytes)
    }

    private fun sendRawOn(sock: DatagramSocket, bytes: ByteArray) {
        try {
            sock.send(DatagramPacket(bytes, bytes.size))
        } catch (_: Exception) {
            // Transient send failures are absorbed; heartbeat catches real loss.
        }
    }

    /**
     * Ends the session. Captures the socket and scope *before* clearing the
     * fields so a follow-up [connect] can never race against the cleanup of
     * a previous session. With [sendBye], BYE is resent per the reliability
     * rules for up to 1.5 s (honest best-effort on user exit; the host's 8 s
     * timeout covers a lost BYE) while the old receive loop stays alive to
     * take the ACK.
     */
    private fun shutdown(sendBye: Boolean) {
        val oldScope = scope
        val oldSocket = socket
        scope = null
        socket = null
        helloJob = null
        latestPose = null
        latestPoseHasRawPosition = false
        frameCorrection = Quaternion.IDENTITY
        alignPending = false
        lastEmittedQ = null
        frameResetGeneration.incrementAndGet()
        poseOutputBlocked = false
        shakePrevQ = null
        shakeLastFastNs = Long.MIN_VALUE
        _fastMotion.value = false
        awaitingWelcome = false
        silentConnect = false
        val interruptedTake = capturingTakeId
        capturingTakeId = null
        _paused.value = false
        _libraryApplyId.value = null
        _viewport.value = null
        val wasConnected = _state.value !is SessionState.Disconnected
        _state.value = SessionState.Disconnected
        pendingAcks.clear()
        recordStartAck?.cancel()
        recordStartAck = null
        finalizationTimeoutJob?.cancel()
        finalizationTimeoutJob = null
        libraryApplyTimeoutJob?.cancel()
        libraryApplyTimeoutJob = null

        if (interruptedTake != null) {
            val recovered = runCatching {
                takeStore?.abortConnectedTake(interruptedTake)
            }.getOrNull()
            if (recovered != null) _events.tryEmit(SessionEvent.TakeSaved(recovered.id))
        }

        if (oldScope == null) {
            oldSocket?.close()
            return
        }
        oldScope.launch {
            withContext(NonCancellable) {
                try {
                    if (sendBye && wasConnected && oldSocket != null) {
                        sendReliableOn(oldSocket, Message.Bye(nextSeq(), nowNs()), giveUpMs = 1_500L)
                    }
                } finally {
                    oldSocket?.close()
                    oldScope.cancel()
                }
            }
        }
    }

    /** Synchronous, ceremony-free variant used when a new session replaces an old one. */
    private fun shutdownNow() {
        val oldScope = scope
        val oldSocket = socket
        scope = null
        socket = null
        helloJob = null
        latestPose = null
        latestPoseHasRawPosition = false
        frameCorrection = Quaternion.IDENTITY
        alignPending = false
        lastEmittedQ = null
        frameResetGeneration.incrementAndGet()
        poseOutputBlocked = false
        shakePrevQ = null
        shakeLastFastNs = Long.MIN_VALUE
        _fastMotion.value = false
        awaitingWelcome = false
        silentConnect = false
        val interruptedTake = capturingTakeId
        capturingTakeId = null
        _libraryApplyId.value = null
        _viewport.value = null
        _state.value = SessionState.Disconnected
        pendingAcks.clear()
        recordStartAck?.cancel()
        recordStartAck = null
        finalizationTimeoutJob?.cancel()
        finalizationTimeoutJob = null
        libraryApplyTimeoutJob?.cancel()
        libraryApplyTimeoutJob = null
        if (interruptedTake != null) {
            val recovered = runCatching {
                takeStore?.abortConnectedTake(interruptedTake)
            }.getOrNull()
            if (recovered != null) _events.tryEmit(SessionEvent.TakeSaved(recovered.id))
        }
        oldSocket?.close()
        oldScope?.cancel()
    }
}

/** Client app version advertised in HELLO. */
const val APP_VERSION = "0.1.0"

/**
 * Default shake-hold threshold in deg/s (spec §5.7); `0.0` disables the gate.
 *
 * Public because the app needs it too — for the value Adjust restores when the
 * hold is switched back on, and as the fallback before anything is persisted.
 * Those were briefly a second literal `500` in the UI, which is one edit away
 * from the phone showing a threshold it is not using. Pinned to
 * `fixtures/motion_gates.json` through [SessionClient.SHAKE_HOLD_DPS].
 */
const val DEFAULT_SHAKE_HOLD_DPS = 500.0

/**
 * Complete JSONL header, including its trailing newline.
 *
 * The single writer for the header format, used for both the upload body and
 * the phone's durable `.take` file. Those were two hand-written copies whose
 * shared keys could drift apart silently -- the same shape of bug that lost a
 * recorded zoom from every take on disk (see [appendTakeRow]).
 *
 * The two uses differ legitimately, which is why the extras are nullable rather
 * than split into two functions: only an upload carries [token] and [id], only a
 * file carries [positionCount], and a file's header is written once at record
 * start when [endNs] and [sampleCount] are not yet known, then rewritten whole
 * at stop.
 */
fun encodeTakeHeader(
    startNs: Long,
    endNs: Long?,
    sampleCount: Int?,
    token: String?,
    name: String? = null,
    id: String? = null,
    source: String = "sensor",
    transactionId: String? = null,
    positionCount: Int? = null,
): ByteArray {
    fun esc(s: String) = s.replace("\\", "\\\\").replace("\"", "\\\"")
    val sb = StringBuilder(240)
    sb.append("{\"format\":\"pocketrig-take\",\"version\":0")
    if (token != null) sb.append(",\"token\":\"").append(esc(token)).append('"')
    if (name != null) sb.append(",\"name\":\"").append(esc(name)).append('"')
    if (id != null) sb.append(",\"id\":\"").append(esc(id)).append('"')
    if (transactionId != null) {
        sb.append(",\"take_id\":\"").append(esc(transactionId)).append('"')
    }
    sb.append(",\"start_ns\":").append(startNs)
    if (endNs != null) sb.append(",\"end_ns\":").append(endNs)
    if (sampleCount != null) sb.append(",\"sample_count\":").append(sampleCount)
    if (positionCount != null) {
        sb.append(",\"position_samples\":").append(positionCount)
    }
    sb.append(",\"source\":\"").append(esc(source)).append("\"}\n")
    return sb.toString().encodeToByteArray()
}

/**
 * Appends one spec 5.10 JSONL row, newline included.
 *
 * The single writer for the row format. It previously existed twice -- here and
 * inline in the app's durable-file recorder -- and the two drifted: focal length
 * was added to this one and silently missed on the other, so a recorded zoom was
 * on the wire but absent from every take actually written to disk. One writer
 * means TakeBodyTest covers both paths.
 */
fun appendTakeRow(sb: StringBuilder, p: PoseUpdate) {
    sb.append("{\"t\":").append(p.timestampNs)
        .append(",\"q\":[").append(p.q.w).append(',').append(p.q.x)
        .append(',').append(p.q.y).append(',').append(p.q.z).append(']')
    p.pos?.let {
        sb.append(",\"p\":[").append(it.x).append(',').append(it.y)
            .append(',').append(it.z).append(']')
    }
    if (p.quality != TrackingQuality.UNKNOWN) {
        sb.append(",\"quality\":\"").append(p.quality.wireName).append('"')
    }
    if (p.issue != TrackingIssue.NONE) {
        sb.append(",\"issue\":\"").append(p.issue.wireName).append('"')
    }
    if (p.focalLengthMm > 0f) {
        sb.append(",\"f\":").append(p.focalLengthMm)
    }
    sb.append("}\n")
}

/**
 * Encodes an offline take as the spec §5.10 JSONL body: a header line then one
 * row per sample. Pass [token] for an upload body, or null for the on-disk
 * `.take` file body (identical minus the token). This is the exact format the
 * host's TCP listener parses, kept as a pure function so it is directly
 * testable.
 */
internal fun encodeTakeBody(
    samples: List<PoseUpdate>,
    startNs: Long,
    endNs: Long,
    token: String?,
    name: String? = null,
    id: String? = null,
    source: String = "sensor",
    transactionId: String? = null,
): ByteArray {
    val sb = StringBuilder(samples.size * 96 + 200)
    sb.append(
        encodeTakeHeader(
            startNs, endNs, samples.size, token, name, id, source, transactionId,
        ).decodeToString(),
    )
    for (p in samples) appendTakeRow(sb, p)
    return sb.toString().encodeToByteArray()
}
