// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

import kotlin.math.sqrt

/**
 * Decides whether the visual tracker's translation is corroborated by the phone's
 * own inertial sensors.
 *
 * ARCore reports `TRACKING` with no failure reason while it cannot see, and
 * dead-reckons meanwhile. Measured on a Pixel 8 Pro with the lens covered and the
 * phone propped still: **5.21 s of healthy-looking tracking and 6.18 cm of camera
 * translation that never happened**, delivered as GOOD. At the 5-10x position
 * scale hosts recommend for desk work that is 30-60 cm of invented travel, and no
 * host-side guard can see it: the timestamps are continuous and the implied speed
 * is entirely plausible.
 *
 * ## Why this shape of test
 *
 * Constant-velocity motion is inertially indistinguishable from rest -- physics,
 * not a sensor limitation -- so tracker displacement alone can never prove
 * invention. The test only asks the question while the phone is *demonstrably at
 * rest*: if the accelerometer and gyroscope both say nothing is happening yet the
 * tracker reports the camera travelling, the tracker is wrong.
 *
 * Net displacement is used rather than path length because dead-reckoning drift
 * is **directional** and accumulates, while tracker noise cancels.
 *
 * ## Being wrong is expensive, so it is hard to trigger and easy to leave
 *
 * A false positive withholds position from a working camera, which is worse than
 * the drift it prevents. Two properties keep that in check:
 *
 * - evidence must **persist** for [sustainNs] before the verdict flips, so a
 *   single noisy window cannot accuse;
 * - the verdict **expires** [holdNs] after the evidence stops, rather than
 *   latching until innocence is proven.
 *
 * The first version latched until the tracker was observed agreeing with rest,
 * which requires the phone to be genuinely still. Handheld that may never happen,
 * so one spurious flag stuck permanently and the camera never tracked again.
 *
 * Thresholds are in `fixtures/motion_corroboration.json`, derived by replaying
 * recorded device traces with the **same clocks production uses** and requiring
 * zero flags across every honest regime including handheld, while still catching
 * the covered-lens drift. Deriving them from a propped phone alone was the
 * mistake that shipped a detector which fired constantly in the hand.
 */
class MotionCorroboration(
    private val windowNs: Long = 1_000_000_000L,
    /** Net tracker displacement over the window that counts as "moving", metres. */
    private val netDisplacementM: Double = 0.010,
    /** Accelerometer RMS below which the phone is at rest, m/s^2 (gravity removed). */
    private val restAccelRms: Double = 0.15,
    /** Gyroscope RMS below which the phone is at rest, rad/s. */
    private val restGyroRms: Double = 0.05,
    /** Evidence must persist this long before the verdict flips. */
    private val sustainNs: Long = 500_000_000L,
    /** The verdict expires this long after the evidence stops. */
    private val holdNs: Long = 2_000_000_000L,
    /** Samples needed in the window before any verdict is formed. */
    private val minPoses: Int = 10,
    private val minImu: Int = 20,
) {
    private class Stamped(val v: Vec3, val tNs: Long)

    // Fed from two threads: IMU samples arrive on the sensor thread while poses
    // arrive on the tracker's render thread. Every buffer touch is guarded --
    // evaluate() iterates the sample buffers, so an unsynchronised push from the
    // other thread throws ConcurrentModificationException, which crashed the app
    // on the GL thread the moment 6DOF was switched on.
    private val lock = Any()

    private val poses = ArrayDeque<Stamped>()
    private val accel = ArrayDeque<Stamped>()
    private val gyro = ArrayDeque<Stamped>()

    private var badSinceNs: Long? = null
    private var lastBadNs: Long? = null

    /**
     * False while the tracker has recently been caught reporting translation the
     * phone did not make. Expires on its own once the evidence stops.
     *
     * Volatile: written under [lock], read freely from the render thread.
     */
    @Volatile
    var corroborated: Boolean = true
        private set

    /** True while the phone is demonstrably still, i.e. the verdict is live. */
    @Volatile
    var atRest: Boolean = false
        private set

    fun reset() = synchronized(lock) {
        poses.clear()
        accel.clear()
        gyro.clear()
        badSinceNs = null
        lastBadNs = null
        corroborated = true
        atRest = false
    }

    fun onAccel(v: Vec3, tNs: Long) = synchronized(lock) {
        push(accel, v, tNs)
        // Inertial samples flow unconditionally, so they carry the clock that lets
        // a verdict expire. Poses cannot: a flag withholds position, which stops
        // poses being offered as evidence, which would stop the hold from ever
        // expiring -- the flag switching off its own input. That deadlock left the
        // camera permanently untracked after a single trip.
        expire(tNs)
    }

    fun onGyro(v: Vec3, tNs: Long) = synchronized(lock) {
        push(gyro, v, tNs)
        expire(tNs)
    }

    /**
     * Feed one tracker position, then re-evaluate. Only call with positions the
     * tracker itself considers valid; a withheld position carries no claim.
     */
    fun onPose(p: Vec3, tNs: Long) = synchronized(lock) {
        push(poses, p, tNs)
        evaluate(tNs)
    }

    private fun push(into: ArrayDeque<Stamped>, v: Vec3, tNs: Long) {
        into.addLast(Stamped(v, tNs))
        val cutoff = tNs - windowNs
        while (into.isNotEmpty() && into.first().tNs < cutoff) into.removeFirst()
    }

    private fun evaluate(nowNs: Long) {
        // Prune by the pose clock so a stalled sensor cannot keep stale samples
        // alive and manufacture a verdict from them. ARCore frame timestamps lag
        // the sensor clock by ~60 ms on the reference device -- same epoch, well
        // inside the window, so no correction is needed.
        val cutoff = nowNs - windowNs
        while (accel.isNotEmpty() && accel.first().tNs < cutoff) accel.removeFirst()
        while (gyro.isNotEmpty() && gyro.first().tNs < cutoff) gyro.removeFirst()
        if (poses.size < minPoses || accel.size < minImu || gyro.size < minImu) {
            atRest = false
            badSinceNs = null
            expire(nowNs)
            return
        }
        // Subtract the window mean rather than a nominal g: it removes gravity and
        // sensor bias together, and assumes no particular orientation.
        val n = accel.size
        var mx = 0.0; var my = 0.0; var mz = 0.0
        for (s in accel) { mx += s.v.x; my += s.v.y; mz += s.v.z }
        mx /= n; my /= n; mz /= n
        var aSum = 0.0
        for (s in accel) {
            val dx = s.v.x - mx; val dy = s.v.y - my; val dz = s.v.z - mz
            aSum += dx * dx + dy * dy + dz * dz
        }
        val accelRms = sqrt(aSum / n)

        var gSum = 0.0
        for (s in gyro) gSum += s.v.x * s.v.x + s.v.y * s.v.y + s.v.z * s.v.z
        val gyroRms = sqrt(gSum / gyro.size)

        atRest = accelRms < restAccelRms && gyroRms < restGyroRms

        val first = poses.first().v
        val last = poses.last().v
        val dx = (last.x - first.x).toDouble()
        val dy = (last.y - first.y).toDouble()
        val dz = (last.z - first.z).toDouble()
        val net = sqrt(dx * dx + dy * dy + dz * dz)

        if (atRest && net > netDisplacementM) {
            val since = badSinceNs ?: nowNs.also { badSinceNs = it }
            if (nowNs - since >= sustainNs) lastBadNs = nowNs
        } else {
            // Moving, or the tracker agrees with rest: no evidence this instant.
            // Not proof of innocence either -- the hold below decides.
            badSinceNs = null
        }
        expire(nowNs)
    }

    private fun expire(nowNs: Long) {
        val last = lastBadNs
        corroborated = last == null || (nowNs - last) >= holdNs
    }
}
