// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

/**
 * What the host can stream, as advertised in WELCOME (viewport-channel.md §3).
 *
 * [sizes] is a list the client chooses *from*, not a range it may pick within.
 * The host renders the camera at one of these and nothing else; asking for
 * another earns an `ERROR viewport_unsupported`.
 *
 * [modes] and [codecs] are lists even holding one entry each, so a second codec
 * or the scene mode arrives as an additive change rather than a negotiation
 * redesign. A video mode existed here once and was deleted: it streamed the
 * operator's own viewport, which made the picture depend on them not using
 * Blender.
 */
data class ViewportOffer(
    val port: Int,
    val modes: List<String>,
    val codecs: List<String>,
    val sizes: List<Pair<Int, Int>>,
    val maxFps: Int,
) {
    /**
     * The host can stream the scene camera, independent of what its operator is
     * looking at. This is what makes the feature a viewfinder rather than screen
     * sharing, and it is the only mode there is.
     */
    val supportsCamera: Boolean
        get() = "camera" in modes && "jpeg" in codecs && sizes.isNotEmpty()

    /** `"camera"`, or null when this host cannot stream. */
    val bestMode: String? get() = if (supportsCamera) "camera" else null

    /**
     * The largest offered size fitting within [maxWidth] x [maxHeight], or the
     * smallest offered one when none do.
     *
     * Chosen by area rather than by width: the viewfinder is a box, and a frame
     * that fits its width but not its height still gets scaled down, which
     * spends link budget on pixels that are then thrown away.
     */
    fun bestSizeWithin(maxWidth: Int, maxHeight: Int): Pair<Int, Int>? {
        if (sizes.isEmpty()) return null
        return sizes.filter { it.first <= maxWidth && it.second <= maxHeight }
            .maxByOrNull { it.first.toLong() * it.second }
            ?: sizes.minByOrNull { it.first.toLong() * it.second }
    }
}
