// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

import java.io.InputStream

/**
 * The viewport stream's frame header (`spec/viewport-channel.md` §4).
 *
 * Pure JVM so `:protocol:test` covers it. That matters more here than usual: a
 * framing bug in a stream does not fail, it produces plausible-looking garbage
 * or silently stalls, and neither is visible from the app.
 *
 * ```
 * magic "PRVP" | u8 version | u8 codec | u16 flags
 * u32 ordinal  | u64 capture_ns | u16 width | u16 height | u32 payload_len
 * ```
 */
data class ViewportFrameHeader(
    val codec: Int,
    val flags: Int,
    /**
     * Per-connection, counting frames the host *produced*. A gap means a frame
     * was dropped — by the host under backpressure or by the network — and the
     * receiver is meant to carry on, not to ask for it back.
     */
    val ordinal: Long,
    /** The host's monotonic clock at capture. Its clock, not ours. */
    val captureNs: Long,
    /**
     * Dimensions of *this* frame, not of the negotiated size.
     *
     * The operator can drag a viewport edge at any moment and no control
     * message announces it, so anything sized from the negotiation is one
     * resize away from being stale.
     */
    val width: Int,
    val height: Int,
    val payloadLen: Int,
) {
    /** True when the frame decodes without reference to any other. */
    val isKeyframe: Boolean get() = (flags and ViewportFrame.FLAG_KEYFRAME) != 0

    val codecName: String
        get() = if (codec == ViewportFrame.CODEC_JPEG) "jpeg" else "unknown"
}

object ViewportFrame {

    const val HEADER_SIZE = 28
    const val CODEC_JPEG = 1
    const val FLAG_KEYFRAME = 0x0001
    private const val VERSION = 1

    /**
     * A frame larger than this is not a frame; it is a desynchronised reader
     * about to allocate whatever a garbage length said.
     */
    const val MAX_PAYLOAD = 8 * 1024 * 1024

    private val MAGIC = byteArrayOf(
        'P'.code.toByte(), 'R'.code.toByte(), 'V'.code.toByte(), 'P'.code.toByte(),
    )

    /**
     * Parse a header, or null if it is not one.
     *
     * Null means **close the connection**, never hunt for the next plausible
     * header: a desynchronised reader cannot tell a payload byte from a header
     * byte, so "resynchronising" is just guessing with extra steps.
     */
    fun parseHeader(bytes: ByteArray, offset: Int = 0): ViewportFrameHeader? {
        if (bytes.size - offset < HEADER_SIZE) return null
        for (i in 0..3) {
            if (bytes[offset + i] != MAGIC[i]) return null
        }
        if (bytes[offset + 4].toInt() != VERSION) return null

        val codec = bytes[offset + 5].toInt() and 0xFF
        // 0 is reserved precisely so an all-zero buffer cannot decode as valid.
        if (codec != CODEC_JPEG) return null

        val payloadLen = u32(bytes, offset + 24)
        if (payloadLen <= 0 || payloadLen > MAX_PAYLOAD) return null

        return ViewportFrameHeader(
            codec = codec,
            flags = u16(bytes, offset + 6),
            ordinal = u32(bytes, offset + 8).toLong() and 0xFFFFFFFFL,
            captureNs = u64(bytes, offset + 12),
            width = u16(bytes, offset + 20),
            height = u16(bytes, offset + 22),
            payloadLen = payloadLen,
        )
    }

    /** Encode a header. Exists so the tests round-trip rather than hand-craft. */
    fun encodeHeader(
        ordinal: Long,
        captureNs: Long,
        width: Int,
        height: Int,
        payloadLen: Int,
        codec: Int = CODEC_JPEG,
        keyframe: Boolean = true,
    ): ByteArray {
        val out = ByteArray(HEADER_SIZE)
        MAGIC.copyInto(out, 0)
        out[4] = VERSION.toByte()
        out[5] = codec.toByte()
        putU16(out, 6, if (keyframe) FLAG_KEYFRAME else 0)
        putU32(out, 8, ordinal.toInt())
        putU64(out, 12, captureNs)
        putU16(out, 20, width)
        putU16(out, 22, height)
        putU32(out, 24, payloadLen)
        return out
    }

    /**
     * Read exactly [count] bytes, or null if the stream ends first.
     *
     * `InputStream.read` is allowed to return fewer bytes than asked for, and a
     * receiver that treats one short read as a whole frame produces a truncated
     * image and then reads the next header from the middle of a payload. Every
     * frame after that is garbage, and the symptom looks like a broken encoder.
     */
    fun readFully(input: InputStream, count: Int): ByteArray? {
        val buffer = ByteArray(count)
        var read = 0
        while (read < count) {
            val n = input.read(buffer, read, count - read)
            if (n < 0) return null
            read += n
        }
        return buffer
    }

    // --------------------------------------------------------------- endian

    private fun u16(b: ByteArray, at: Int): Int =
        (b[at].toInt() and 0xFF) or ((b[at + 1].toInt() and 0xFF) shl 8)

    private fun u32(b: ByteArray, at: Int): Int =
        (b[at].toInt() and 0xFF) or
            ((b[at + 1].toInt() and 0xFF) shl 8) or
            ((b[at + 2].toInt() and 0xFF) shl 16) or
            ((b[at + 3].toInt() and 0xFF) shl 24)

    private fun u64(b: ByteArray, at: Int): Long {
        var value = 0L
        for (i in 7 downTo 0) {
            value = (value shl 8) or (b[at + i].toLong() and 0xFF)
        }
        return value
    }

    private fun putU16(b: ByteArray, at: Int, value: Int) {
        b[at] = (value and 0xFF).toByte()
        b[at + 1] = ((value shr 8) and 0xFF).toByte()
    }

    private fun putU32(b: ByteArray, at: Int, value: Int) {
        for (i in 0..3) b[at + i] = ((value shr (8 * i)) and 0xFF).toByte()
    }

    private fun putU64(b: ByteArray, at: Int, value: Long) {
        for (i in 0..7) b[at + i] = ((value shr (8 * i)) and 0xFF).toByte()
    }
}
