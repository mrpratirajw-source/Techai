// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

/** Hysteretic 6DOF acquisition state carried in POSE flags. */
enum class TrackingQuality(val wireCode: Int, val wireName: String) {
    UNKNOWN(0, "unknown"),
    WARMING(1, "warming"),
    GOOD(2, "good"),
    DEGRADED(3, "degraded"),
    LOST(4, "lost"),
    RECOVERING(5, "recovering");

    companion object {
        fun fromWireCode(code: Int): TrackingQuality = entries.firstOrNull {
            it.wireCode == code
        } ?: UNKNOWN

        fun fromWireName(name: String?): TrackingQuality = entries.firstOrNull {
            it.wireName == name?.trim()?.lowercase()
        } ?: UNKNOWN
    }
}

/** Concise reason for a non-GOOD quality state. */
enum class TrackingIssue(val wireCode: Int, val wireName: String) {
    NONE(0, "none"),
    INITIALIZING(1, "initializing"),
    INSUFFICIENT_FEATURES(2, "insufficient_features"),
    INSUFFICIENT_LIGHT(3, "insufficient_light"),
    EXCESSIVE_MOTION(4, "excessive_motion"),
    BAD_STATE(5, "bad_state"),
    CAMERA_UNAVAILABLE(6, "camera_unavailable"),
    UNKNOWN(7, "unknown");

    companion object {
        fun fromWireCode(code: Int): TrackingIssue = entries.firstOrNull {
            it.wireCode == code
        } ?: UNKNOWN

        fun fromWireName(name: String?): TrackingIssue = entries.firstOrNull {
            it.wireName == name?.trim()?.lowercase()
        } ?: UNKNOWN

        fun fromArCoreName(name: String?): TrackingIssue = when (name?.trim()?.uppercase()) {
            null, "", "NONE" -> NONE
            "INSUFFICIENT_FEATURES" -> INSUFFICIENT_FEATURES
            "INSUFFICIENT_LIGHT" -> INSUFFICIENT_LIGHT
            "EXCESSIVE_MOTION" -> EXCESSIVE_MOTION
            "BAD_STATE" -> BAD_STATE
            "CAMERA_UNAVAILABLE" -> CAMERA_UNAVAILABLE
            else -> UNKNOWN
        }
    }
}

data class TrackingStatus(
    val quality: TrackingQuality,
    val issue: TrackingIssue = TrackingIssue.NONE,
) {
    /** Position is emitted only after stable tracked frames. */
    val positionValid: Boolean get() = quality == TrackingQuality.GOOD

    companion object {
        val UNKNOWN = TrackingStatus(TrackingQuality.UNKNOWN)
        val WARMING = TrackingStatus(TrackingQuality.WARMING, TrackingIssue.INITIALIZING)
    }
}

/**
 * Conservative ARCore quality state machine. It reacts immediately to hard
 * tracking evidence, but requires a short stable run before position is
 * trusted initially or after a loss/gap. Times use elapsed-realtime nanoseconds.
 */
// Dwell defaults are the spec section 4.2 SHOULDs and are pinned to
// fixtures/motion_gates.json by MotionGatesTest; internal rather than private
// so that assertion can read them.
class TrackingQualityEstimator(
    internal val warmupNs: Long = 200_000_000L,
    internal val lostAfterNs: Long = 500_000_000L,
    internal val recoveryNs: Long = 300_000_000L,
    internal val frameGapNs: Long = 250_000_000L,
) {
    private var current = TrackingStatus.WARMING
    private var stateSinceNs = 0L
    private var lastSourceNs = 0L
    private var everGood = false

    val status: TrackingStatus get() = current

    fun reset(): TrackingStatus {
        current = TrackingStatus.WARMING
        stateSinceNs = 0L
        lastSourceNs = 0L
        everGood = false
        return current
    }

    fun update(
        tracking: Boolean,
        failureReason: String?,
        observedNs: Long,
        sourceTimestampNs: Long = observedNs,
    ): TrackingStatus {
        val gap = lastSourceNs > 0L && sourceTimestampNs - lastSourceNs > frameGapNs
        val stale = sourceTimestampNs > 0L && observedNs >= sourceTimestampNs &&
            observedNs - sourceTimestampNs > frameGapNs
        lastSourceNs = sourceTimestampNs

        if (!tracking || stale) {
            val issue = TrackingIssue.fromArCoreName(failureReason).let {
                if (it == TrackingIssue.NONE) TrackingIssue.UNKNOWN else it
            }
            if (current.quality != TrackingQuality.DEGRADED &&
                current.quality != TrackingQuality.LOST
            ) {
                current = TrackingStatus(TrackingQuality.DEGRADED, issue)
                stateSinceNs = observedNs
            } else if (current.issue != issue) {
                current = TrackingStatus(current.quality, issue)
            }
            if (current.quality == TrackingQuality.DEGRADED &&
                observedNs - stateSinceNs >= lostAfterNs
            ) {
                current = TrackingStatus(TrackingQuality.LOST, issue)
            }
            return current
        }

        when {
            !everGood && current.quality == TrackingQuality.WARMING && stateSinceNs == 0L -> {
                stateSinceNs = observedNs
            }
            !everGood && current.quality != TrackingQuality.WARMING -> {
                current = TrackingStatus.WARMING
                stateSinceNs = observedNs
            }
            !everGood && observedNs - stateSinceNs >= warmupNs -> {
                everGood = true
                current = TrackingStatus(TrackingQuality.GOOD)
                stateSinceNs = observedNs
            }
            everGood && (gap || current.quality == TrackingQuality.DEGRADED ||
                current.quality == TrackingQuality.LOST) -> {
                current = TrackingStatus(TrackingQuality.RECOVERING)
                stateSinceNs = observedNs
            }
            current.quality == TrackingQuality.RECOVERING &&
                observedNs - stateSinceNs >= recoveryNs -> {
                current = TrackingStatus(TrackingQuality.GOOD)
                stateSinceNs = observedNs
            }
        }
        return current
    }
}
