// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

/** A 3-vector in the protocol world frame (right-handed Z-up), meters. */
data class Vec3(val x: Float, val y: Float, val z: Float)
