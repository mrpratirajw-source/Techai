// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
package dev.pocketrig.protocol

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.add
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray

/** One take in the library (spec §5.11). */
data class TakeInfo(
    val id: String,
    val name: String,
    val durationS: Double,
    val source: String,
    val samples: Int,
    val sent: Boolean,
    /** Rows with position usable by the conservative baker; -1 when an older
     * peer did not advertise the capability. */
    val positionSamples: Int = -1,
)

/**
 * pocketrig wire protocol v1 messages (`spec/protocol.md`).
 *
 * Every message starts with a 16-byte little-endian header:
 * magic `0x50 0x52` ("PR"), u8 version (=1), u8 msg_type, u32 seq
 * (per-sender, monotonic from 1), u64 timestamp_ns (sender's monotonic
 * clock — for POSE it is the sensor sample time, not the send time).
 *
 * [seq] and [timestampNs] are held as [Long]; both are non-negative
 * unsigned values on the wire (u32 / u64) and monotonic clocks never
 * exceed Long range in practice.
 */
sealed class Message {
    abstract val seq: Long
    abstract val timestampNs: Long
    abstract val msgType: Int

    /** POSE (0x01), phone → host, unreliable. 40 bytes rotation-only, 52
     * bytes when [pos] is present (6DOF, spec §4.1 — the position_valid flag
     * tracks [pos] automatically on encode). */
    data class Pose(
        override val seq: Long,
        override val timestampNs: Long,
        /** Unit quaternion (w, x, y, z), Hamilton, protocol camera frame. */
        val q: Quaternion,
        /** Offset 32; send 0.0 (future: focal length mm). */
        /**
         * Lens focal length in millimetres (§4.5), or 0 for "not driving the
         * lens". Occupies the f32 v1.0 reserved at offset 32, so every older
         * sender's 0.0 already means exactly the right thing.
         */
        val focalLengthMm: Float = 0f,
        /** Flags bit 0: sender believes recording is active. */
        val recording: Boolean = false,
        /** Camera position, meters, protocol world frame; null = rotation-only. */
        val pos: Vec3? = null,
        /** Optional v1.2 tracking state; UNKNOWN preserves old-sender behavior. */
        val trackingQuality: TrackingQuality = TrackingQuality.UNKNOWN,
        val trackingIssue: TrackingIssue = TrackingIssue.NONE,
    ) : Message() {
        override val msgType get() = Packets.TYPE_POSE
    }

    /** HELLO (0x10), phone → host, reliable, JSON body. */
    data class Hello(
        override val seq: Long,
        override val timestampNs: Long,
        val deviceName: String,
        val appVersion: String,
        val protocolVersion: Int,
        val token: String,
    ) : Message() {
        override val msgType get() = Packets.TYPE_HELLO
    }

    /** WELCOME (0x11), host → phone, reliable, JSON body. */
    data class Welcome(
        override val seq: Long,
        override val timestampNs: Long,
        val serverName: String,
        val hostApp: String,
        val hostVersion: String,
        val addonVersion: String,
        val protocolVersion: Int,
        val sceneFps: Double,
        /** TCP port for offline-take upload (§5.10); null = live-only host. */
        val takePort: Int? = null,
        /**
         * Viewport channel advertisement (viewport-channel.md §3). Null port
         * means the host cannot stream and we MUST NOT connect.
         */
        val viewportPort: Int? = null,
        val viewportModes: List<String> = emptyList(),
        val viewportCodecs: List<String> = emptyList(),
        /**
         * Sizes the host can actually produce. We choose from these rather than
         * requesting one: its capture path can only decimate the framebuffer it
         * was handed, so any other number is a size it cannot make.
         */
        val viewportSizes: List<Pair<Int, Int>> = emptyList(),
        /**
         * Sizes the CAMERA path offers — real resolutions, not decimations.
         *
         * A separate list because the two paths are constrained differently:
         * the video path can only divide the operator's viewport by whole
         * numbers, while an offscreen camera draw can pick any size and barely
         * cares which. Merging them would lose that.
         */
        val viewportCameraSizes: List<Pair<Int, Int>> = emptyList(),
        val viewportMaxFps: Int = 30,
    ) : Message() {
        override val msgType get() = Packets.TYPE_WELCOME
    }

    /** PING (0x12), phone → host, unreliable, no body; header timestamp is t1. */
    data class Ping(
        override val seq: Long,
        override val timestampNs: Long,
    ) : Message() {
        override val msgType get() = Packets.TYPE_PING
    }

    /** PONG (0x13), host → phone, unreliable, JSON body `{t1, t2}`. */
    data class Pong(
        override val seq: Long,
        override val timestampNs: Long,
        /** Echo of the PING header timestamp (client clock). */
        val t1: Long,
        /** Host receive time (host clock). */
        val t2: Long,
    ) : Message() {
        override val msgType get() = Packets.TYPE_PONG
    }

    /** RECORD_START (0x20), phone → host, reliable, JSON body. */
    data class RecordStart(
        override val seq: Long,
        override val timestampNs: Long,
        /** Client POSE timestamp domain. */
        val startTimestampNs: Long,
        /** Stable identity for this record/save/upload/bake transaction. */
        val takeId: String? = null,
    ) : Message() {
        override val msgType get() = Packets.TYPE_RECORD_START
    }

    /** RECORD_STOP (0x21), either direction, reliable, JSON body. */
    data class RecordStop(
        override val seq: Long,
        override val timestampNs: Long,
        val endTimestampNs: Long,
        /** POSE count the client sent inside the record window. */
        val sampleCount: Int,
        /** An offline-take upload follows (spec §5.10). */
        val offline: Boolean = false,
        /** Must match RECORD_START when present. */
        val takeId: String? = null,
    ) : Message() {
        override val msgType get() = Packets.TYPE_RECORD_STOP
    }

    /** RECORD_BAKED (0x22), host → phone, reliable, JSON body. */
    data class RecordBaked(
        override val seq: Long,
        override val timestampNs: Long,
        val frames: Int,
        val fps: Double,
        val received: Int,
        val sent: Int,
        /** "offline" | "live" — which take the host baked (§5.10). */
        val source: String = "live",
        /** Transaction completed by this result; absent for legacy peers. */
        val takeId: String? = null,
    ) : Message() {
        override val msgType get() = Packets.TYPE_RECORD_BAKED
    }

    /** RECENTER (0x23), phone → host, reliable, JSON body `{}`. */
    data class Recenter(
        override val seq: Long,
        override val timestampNs: Long,
    ) : Message() {
        override val msgType get() = Packets.TYPE_RECENTER
    }

    /** PARAMS (0x24), either direction, reliable, JSON body (spec §5.7).
     * Session tuning mirrored on both UIs; the host owns the values. */
    /** Start, reconfigure or stop the viewport stream (viewport-channel.md §5.1). */
    data class ViewportControl(
        override val seq: Long,
        override val timestampNs: Long,
        /** "camera" or "off". */
        val mode: String,
        val codec: String? = null,
        val size: Pair<Int, Int>? = null,
        val fps: Double? = null,
        val quality: Int? = null,
        /**
         * Whether the host draws its own viewport overlays -- 3D cursor, grid,
         * relationship lines -- into our picture (viewport-channel.md §5.1).
         *
         * Null means "leave it as it is", not "off": a client that omits it must
         * not silently change a preference the operator set.
         */
        val overlays: Boolean? = null,
        /**
         * Hand size selection to the host: "light", "balanced" or "smooth"
         * (viewport-channel.md §5.1). Null leaves it with us.
         *
         * Only the host can see what a capture costs on its machine and its
         * scene, and both move under the operator's hands, so a phone choosing
         * a resolution is guessing at something it cannot measure.
         */
        val profile: String? = null,
    ) : Message() {
        override val msgType get() = Packets.TYPE_VIEWPORT_CONTROL
    }

    /**
     * A frame reached the screen (viewport-channel.md §5.2).
     *
     * Unreliable on purpose: telemetry about a preview is not worth a resend
     * layer. The timestamps are in OUR clock domain, so only their difference
     * means anything to the host.
     */
    data class ViewportStat(
        override val seq: Long,
        override val timestampNs: Long,
        val ordinal: Long,
        val decodedNs: Long,
        val presentedNs: Long,
    ) : Message() {
        override val msgType get() = Packets.TYPE_VIEWPORT_STAT
    }

    data class Params(
        override val seq: Long,
        override val timestampNs: Long,
        val liveSmoothing: Double,
        val recordSmoothing: Double,
        val moveScale: Double,
        /** Legacy/deprecated mirrored layout key (spec §5.7). */
        val layout: String? = null,
        /** "offline" | "live" | null (spec §5.7, what a take bakes from). */
        val takeSource: String? = null,
        /**
         * The host's own focal length in mm, host → phone only (spec §5.7).
         *
         * Null when the host did not report one — it omits it while we are
         * driving the lens and while its lens is animated. It says what the
         * lens rail should *open on*; it is never permission to drive.
         */
        val lensMm: Double? = null,
        /**
         * Angular speed above which the host holds 6DOF position (spec §5.7),
         * or 0.0 for "gate off". Null means the peer did not state one.
         *
         * Mirrored, and it has to be: a cue drawn from our own default while the
         * host uses another number describes something that is not happening.
         */
        val shakeHoldDps: Double? = null,
        /**
         * The viewport rate the host has MEASURED itself reaching, host -> phone
         * only (spec viewport-channel.md 5.3), or null if it has not measured
         * one yet.
         *
         * Not the same thing as [ViewportOffer.maxFps], which is what the host
         * is willing to be asked for. This is what its event loop can actually
         * deliver, and the two differ because the loop runs at the operator's
         * viewport redraw rate -- which is unknowable at pairing time, when
         * nothing is redrawing.
         */
        val viewportMaxFps: Double? = null,
    ) : Message() {
        override val msgType get() = Packets.TYPE_PARAMS
    }

    /** SEEK (0x26), phone → host, reliable, JSON body (spec §5.9).
     * null [frame] = the scene's start (the retake button). */
    data class Seek(
        override val seq: Long,
        override val timestampNs: Long,
        val frame: Long? = null,
    ) : Message() {
        override val msgType get() = Packets.TYPE_SEEK
    }

    /** PAUSE (0x25), either direction, reliable, JSON body (spec §5.8).
     * Suspends/resumes the host's live drive; host owns the state. */
    data class Pause(
        override val seq: Long,
        override val timestampNs: Long,
        val paused: Boolean,
    ) : Message() {
        override val msgType get() = Packets.TYPE_PAUSE
    }

    /** TAKE_LIST (0x27), either direction, reliable (spec §5.11). Host sends
     * it with [takes] = null (a request); the phone replies with the list. */
    data class TakeList(
        override val seq: Long,
        override val timestampNs: Long,
        val takes: List<TakeInfo>?,
    ) : Message() {
        override val msgType get() = Packets.TYPE_TAKE_LIST
    }

    /** TAKE_PULL (0x28), host → phone, reliable: upload this take (spec §5.11). */
    data class TakePull(
        override val seq: Long,
        override val timestampNs: Long,
        val id: String,
    ) : Message() {
        override val msgType get() = Packets.TYPE_TAKE_PULL
    }

    /** FRAME_RESET (0x29), phone -> host, reliable. The next POSE uses a new
     * raw display/source/world reference; the host rebases without changing
     * pause/review or the user's Home framing. */
    data class FrameReset(
        override val seq: Long,
        override val timestampNs: Long,
        val reason: String,
    ) : Message() {
        override val msgType get() = Packets.TYPE_FRAME_RESET
    }

    /** ACK (0x30), either direction, unreliable. Binary body: u32 acked_seq. */
    data class Ack(
        override val seq: Long,
        override val timestampNs: Long,
        /** The seq (from the other side) being acknowledged. */
        val ackedSeq: Long,
    ) : Message() {
        override val msgType get() = Packets.TYPE_ACK
    }

    /** BYE (0x0F), either direction, reliable, no body. */
    data class Bye(
        override val seq: Long,
        override val timestampNs: Long,
    ) : Message() {
        override val msgType get() = Packets.TYPE_BYE
    }

    /** ERROR (0x1F), host → phone, reliable, JSON body `{code, message}`. */
    data class ErrorMsg(
        override val seq: Long,
        override val timestampNs: Long,
        val code: String,
        val message: String = "",
    ) : Message() {
        override val msgType get() = Packets.TYPE_ERROR
    }
}

/**
 * Encoder/decoder for all v1 messages. Everything is little-endian.
 *
 * Decoding is tolerant per the spec's forward-compatibility rules:
 * - bad magic or version ≠ 1 → `null` (silently dropped by callers)
 * - unknown msg_type → `null`
 * - POSE longer than 40 bytes → accepted, extra bytes ignored
 * - unknown JSON keys → ignored
 */
object Packets {
    const val HEADER_SIZE = 16
    const val POSE_SIZE = 40
    const val POSE_6DOF_SIZE = 52
    const val ACK_SIZE = 20

    /** POSE flags (spec §4). */
    const val FLAG_RECORDING = 0x0001
    const val FLAG_HAS_POSITION = 0x0002
    const val FLAG_QUALITY_SHIFT = 2
    const val FLAG_QUALITY_MASK = 0x001C
    const val FLAG_ISSUE_SHIFT = 5
    const val FLAG_ISSUE_MASK = 0x00E0

    const val PROTOCOL_VERSION = 1

    const val TYPE_POSE = 0x01
    const val TYPE_BYE = 0x0F
    const val TYPE_HELLO = 0x10
    const val TYPE_WELCOME = 0x11
    const val TYPE_PING = 0x12
    const val TYPE_PONG = 0x13
    const val TYPE_ERROR = 0x1F
    const val TYPE_RECORD_START = 0x20
    const val TYPE_RECORD_STOP = 0x21
    const val TYPE_RECORD_BAKED = 0x22
    const val TYPE_RECENTER = 0x23
    const val TYPE_PARAMS = 0x24
    const val TYPE_PAUSE = 0x25
    const val TYPE_SEEK = 0x26
    const val TYPE_TAKE_LIST = 0x27
    const val TYPE_TAKE_PULL = 0x28
    const val TYPE_FRAME_RESET = 0x29
    const val TYPE_VIEWPORT_CONTROL = 0x2A
    const val TYPE_VIEWPORT_STAT = 0x2B
    const val TYPE_ACK = 0x30

    private const val MAGIC_0 = 0x50 // 'P'
    private const val MAGIC_1 = 0x52 // 'R'

    private val json = Json { ignoreUnknownKeys = true }

    /** Encodes [message] to its exact wire bytes. */
    fun encode(message: Message): ByteArray {
        val body: ByteArray = when (message) {
            is Message.Pose -> {
                val size = (if (message.pos != null) POSE_6DOF_SIZE else POSE_SIZE) - HEADER_SIZE
                var flags = if (message.recording) FLAG_RECORDING else 0
                if (message.pos != null) flags = flags or FLAG_HAS_POSITION
                flags = flags or (
                    (message.trackingQuality.wireCode shl FLAG_QUALITY_SHIFT) and
                        FLAG_QUALITY_MASK
                    )
                flags = flags or (
                    (message.trackingIssue.wireCode shl FLAG_ISSUE_SHIFT) and
                        FLAG_ISSUE_MASK
                    )
                val buf = ByteBuffer.allocate(size)
                    .order(ByteOrder.LITTLE_ENDIAN)
                    .putFloat(message.q.w.toFloat())
                    .putFloat(message.q.x.toFloat())
                    .putFloat(message.q.y.toFloat())
                    .putFloat(message.q.z.toFloat())
                    .putFloat(message.focalLengthMm)
                    .putShort(flags.toShort())
                    .putShort(0)
                message.pos?.let { buf.putFloat(it.x).putFloat(it.y).putFloat(it.z) }
                buf.array()
            }

            is Message.Ack -> ByteBuffer.allocate(ACK_SIZE - HEADER_SIZE)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putInt(message.ackedSeq.toInt())
                .array()

            is Message.Bye, is Message.Ping -> ByteArray(0)

            is Message.Hello -> jsonBody {
                put("device_name", message.deviceName)
                put("app_version", message.appVersion)
                put("protocol_version", message.protocolVersion)
                put("token", message.token)
            }

            is Message.Welcome -> jsonBody {
                put("server_name", message.serverName)
                put("host_app", message.hostApp)
                put("host_version", message.hostVersion)
                put("addon_version", message.addonVersion)
                put("protocol_version", message.protocolVersion)
                put("scene_fps", message.sceneFps)
                message.takePort?.let { put("take_port", it) }
            }

            is Message.Pong -> jsonBody {
                put("t1", message.t1)
                put("t2", message.t2)
            }

            is Message.RecordStart -> jsonBody {
                put("start_timestamp_ns", message.startTimestampNs)
                message.takeId?.let { put("take_id", it) }
            }

            is Message.RecordStop -> jsonBody {
                put("end_timestamp_ns", message.endTimestampNs)
                put("sample_count", message.sampleCount)
                if (message.offline) put("offline", true)
                message.takeId?.let { put("take_id", it) }
            }

            is Message.RecordBaked -> jsonBody {
                put("frames", message.frames)
                put("fps", message.fps)
                put("received", message.received)
                put("sent", message.sent)
                put("source", message.source)
                message.takeId?.let { put("take_id", it) }
            }

            is Message.Recenter -> jsonBody { /* empty object {} */ }

            is Message.Params -> jsonBody {
                put("live_smoothing", message.liveSmoothing)
                put("record_smoothing", message.recordSmoothing)
                put("move_scale", message.moveScale)
                message.layout?.let { put("layout", it) }
                message.takeSource?.let { put("take_source", it) }
                // Encoded for symmetry with the decoder -- a codec that can read
                // a field but not write it makes every round-trip test a lie.
                // The phone never sets it (spec §5.7 is host → phone), so this
                // stays absent on the wire from this side; a Kotlin *host* would
                // need it, and a host receiving one ignores it either way.
                message.lensMm?.let { put("lens_mm", it) }
                // Sent even when 0.0: absent means "unchanged", off is a value.
                message.shakeHoldDps?.let { put("shake_hold_dps", it) }
                // Same symmetry rule as lens_mm: host -> phone on the wire, so a
                // phone never writes it, but a codec that reads what it cannot
                // write makes every round-trip test a lie.
                message.viewportMaxFps?.let { put("viewport_max_fps", it) }
            }

            is Message.ViewportControl -> jsonBody {
                put("mode", message.mode)
                message.codec?.let { put("codec", it) }
                message.size?.let {
                    put("size", buildJsonArray { add(it.first); add(it.second) })
                }
                message.fps?.let { put("fps", it) }
                message.quality?.let { put("quality", it) }
                message.overlays?.let { put("overlays", it) }
                message.profile?.let { put("profile", it) }
            }

            is Message.ViewportStat -> jsonBody {
                put("ordinal", message.ordinal)
                put("decoded_ns", message.decodedNs)
                put("presented_ns", message.presentedNs)
            }

            is Message.Pause -> jsonBody {
                put("paused", message.paused)
            }

            is Message.Seek -> jsonBody {
                val f = message.frame
                if (f != null) put("frame", f) else put("to", "start")
            }

            is Message.TakeList -> jsonBody {
                message.takes?.let { list ->
                    putJsonArray("takes") {
                        for (t in list) add(
                            buildJsonObject {
                                put("id", t.id)
                                put("name", t.name)
                                put("duration_s", t.durationS)
                                put("source", t.source)
                                put("samples", t.samples)
                                put("sent", t.sent)
                                if (t.positionSamples >= 0) {
                                    put("position_samples", t.positionSamples)
                                }
                            },
                        )
                    }
                }
            }

            is Message.TakePull -> jsonBody { put("id", message.id) }

            is Message.FrameReset -> jsonBody { put("reason", message.reason) }

            is Message.ErrorMsg -> jsonBody {
                put("code", message.code)
                put("message", message.message)
            }
        }

        return ByteBuffer.allocate(HEADER_SIZE + body.size)
            .order(ByteOrder.LITTLE_ENDIAN)
            .put(MAGIC_0.toByte())
            .put(MAGIC_1.toByte())
            .put(PROTOCOL_VERSION.toByte())
            .put(message.msgType.toByte())
            .putInt(message.seq.toInt())
            .putLong(message.timestampNs)
            .put(body)
            .array()
    }

    /**
     * Decodes the first [length] bytes of [bytes] into a [Message], or `null`
     * if the datagram should be dropped (bad magic/version, unknown type,
     * truncated, or malformed JSON).
     */
    fun decode(bytes: ByteArray, length: Int = bytes.size): Message? {
        if (length < HEADER_SIZE || length > bytes.size) return null
        val buf = ByteBuffer.wrap(bytes, 0, length).order(ByteOrder.LITTLE_ENDIAN)
        if (buf.get().toInt() and 0xFF != MAGIC_0) return null
        if (buf.get().toInt() and 0xFF != MAGIC_1) return null
        if (buf.get().toInt() and 0xFF != PROTOCOL_VERSION) return null
        val msgType = buf.get().toInt() and 0xFF
        val seq = buf.getInt().toLong() and 0xFFFF_FFFFL
        val timestampNs = buf.getLong()

        return when (msgType) {
            TYPE_POSE -> {
                // Append-only rule: accept longer POSE, ignore unknown bytes.
                if (length < POSE_SIZE) return null
                val w = buf.getFloat()
                val x = buf.getFloat()
                val y = buf.getFloat()
                val z = buf.getFloat()
                val focalLengthMm = buf.getFloat()
                val flags = buf.getShort().toInt() and 0xFFFF
                buf.getShort() // reserved
                // Position needs BOTH the flag and the bytes (spec §4.1).
                val pos = if (flags and FLAG_HAS_POSITION != 0 && length >= POSE_6DOF_SIZE) {
                    Vec3(buf.getFloat(), buf.getFloat(), buf.getFloat())
                } else {
                    null
                }
                Message.Pose(
                    seq = seq,
                    timestampNs = timestampNs,
                    q = Quaternion(w, x, y, z),
                    focalLengthMm = focalLengthMm,
                    recording = flags and FLAG_RECORDING != 0,
                    pos = pos,
                    trackingQuality = TrackingQuality.fromWireCode(
                        (flags and FLAG_QUALITY_MASK) ushr FLAG_QUALITY_SHIFT,
                    ),
                    trackingIssue = TrackingIssue.fromWireCode(
                        (flags and FLAG_ISSUE_MASK) ushr FLAG_ISSUE_SHIFT,
                    ),
                )
            }

            TYPE_ACK -> {
                if (length < ACK_SIZE) return null
                Message.Ack(seq, timestampNs, buf.getInt().toLong() and 0xFFFF_FFFFL)
            }

            TYPE_BYE -> Message.Bye(seq, timestampNs)
            TYPE_PING -> Message.Ping(seq, timestampNs)

            TYPE_HELLO -> jsonObject(bytes, length)?.let { o ->
                Message.Hello(
                    seq, timestampNs,
                    deviceName = o.string("device_name") ?: "",
                    appVersion = o.string("app_version") ?: "",
                    protocolVersion = o.int("protocol_version") ?: PROTOCOL_VERSION,
                    token = o.string("token") ?: return null,
                )
            }

            TYPE_WELCOME -> jsonObject(bytes, length)?.let { o ->
                Message.Welcome(
                    seq, timestampNs,
                    serverName = o.string("server_name") ?: "",
                    hostApp = o.string("host_app") ?: "",
                    hostVersion = o.string("host_version") ?: "",
                    addonVersion = o.string("addon_version") ?: "",
                    protocolVersion = o.int("protocol_version") ?: PROTOCOL_VERSION,
                    sceneFps = o.double("scene_fps") ?: 0.0,
                    takePort = o.int("take_port"),
                    viewportPort = o.int("viewport_port"),
                    viewportModes = (o["viewport_modes"] as? JsonArray)
                        ?.mapNotNull { it.jsonPrimitive.contentOrNull } ?: emptyList(),
                    viewportCodecs = (o["viewport_video"] as? JsonObject)
                        ?.get("codecs")?.let { it as? JsonArray }
                        ?.mapNotNull { it.jsonPrimitive.contentOrNull } ?: emptyList(),
                    viewportSizes = sizeList(o, "camera_sizes"),
                    viewportMaxFps = (o["viewport_video"] as? JsonObject)
                        ?.get("max_fps")?.let { (it as? JsonPrimitive)?.intOrNull } ?: 30,
                )
            }

            TYPE_PONG -> jsonObject(bytes, length)?.let { o ->
                Message.Pong(
                    seq, timestampNs,
                    t1 = o.long("t1") ?: return null,
                    t2 = o.long("t2") ?: return null,
                )
            }

            TYPE_RECORD_START -> jsonObject(bytes, length)?.let { o ->
                Message.RecordStart(
                    seq, timestampNs,
                    startTimestampNs = o.long("start_timestamp_ns") ?: return null,
                    takeId = o.string("take_id"),
                )
            }

            TYPE_RECORD_STOP -> jsonObject(bytes, length)?.let { o ->
                Message.RecordStop(
                    seq, timestampNs,
                    endTimestampNs = o.long("end_timestamp_ns") ?: return null,
                    sampleCount = o.int("sample_count") ?: 0,
                    offline = (o["offline"] as? JsonPrimitive)?.contentOrNull == "true",
                    takeId = o.string("take_id"),
                )
            }

            TYPE_RECORD_BAKED -> jsonObject(bytes, length)?.let { o ->
                Message.RecordBaked(
                    seq, timestampNs,
                    frames = o.int("frames") ?: 0,
                    fps = o.double("fps") ?: 0.0,
                    received = o.int("received") ?: 0,
                    sent = o.int("sent") ?: 0,
                    source = o.string("source") ?: "live",
                    takeId = o.string("take_id"),
                )
            }

            TYPE_RECENTER -> jsonObject(bytes, length)?.let {
                Message.Recenter(seq, timestampNs)
            }

            TYPE_PARAMS -> jsonObject(bytes, length)?.let { o ->
                Message.Params(
                    seq, timestampNs,
                    liveSmoothing = o.double("live_smoothing") ?: 0.0,
                    recordSmoothing = o.double("record_smoothing") ?: 0.0,
                    moveScale = o.double("move_scale") ?: 1.0,
                    layout = o.string("layout"),
                    takeSource = o.string("take_source"),
                    lensMm = o.double("lens_mm"),
                    shakeHoldDps = o.double("shake_hold_dps"),
                    viewportMaxFps = o.double("viewport_max_fps"),
                )
            }

            // Decoded for symmetry with the encoder, not because a phone
            // receives these -- both are phone -> host. A codec that can write a
            // field but not read it makes every round-trip test a lie, which is
            // the same reason lens_mm is encoded on this side.
            TYPE_VIEWPORT_CONTROL -> jsonObject(bytes, length)?.let { o ->
                val size = (o["size"] as? JsonArray)?.takeIf { it.size >= 2 }?.let {
                    val w = it[0].jsonPrimitive.intOrNull
                    val h = it[1].jsonPrimitive.intOrNull
                    if (w != null && h != null) w to h else null
                }
                Message.ViewportControl(
                    seq, timestampNs,
                    mode = o.string("mode") ?: "off",
                    codec = o.string("codec"),
                    size = size,
                    fps = o.double("fps"),
                    quality = o.int("quality"),
                    overlays = o.boolean("overlays"),
                    profile = o.string("profile"),
                )
            }

            TYPE_VIEWPORT_STAT -> jsonObject(bytes, length)?.let { o ->
                Message.ViewportStat(
                    seq, timestampNs,
                    ordinal = o.long("ordinal") ?: 0L,
                    decodedNs = o.long("decoded_ns") ?: 0L,
                    presentedNs = o.long("presented_ns") ?: 0L,
                )
            }

            TYPE_SEEK -> jsonObject(bytes, length)?.let { o ->
                Message.Seek(seq, timestampNs, frame = o.long("frame"))
            }

            TYPE_TAKE_LIST -> jsonObject(bytes, length)?.let { o ->
                val arr = o["takes"] as? JsonArray
                Message.TakeList(
                    seq, timestampNs,
                    takes = arr?.map { e ->
                        val t = e.jsonObject
                        TakeInfo(
                            id = t.string("id") ?: "",
                            name = t.string("name") ?: "",
                            durationS = t.double("duration_s") ?: 0.0,
                            source = t.string("source") ?: "sensor",
                            samples = t.int("samples") ?: 0,
                            sent = (t["sent"] as? JsonPrimitive)?.booleanOrNull ?: false,
                            positionSamples = t.int("position_samples") ?: -1,
                        )
                    },
                )
            }

            TYPE_TAKE_PULL -> jsonObject(bytes, length)?.let { o ->
                Message.TakePull(seq, timestampNs, id = o.string("id") ?: return null)
            }

            TYPE_FRAME_RESET -> jsonObject(bytes, length)?.let { o ->
                Message.FrameReset(
                    seq, timestampNs,
                    reason = o.string("reason") ?: "unknown",
                )
            }

            TYPE_PAUSE -> jsonObject(bytes, length)?.let { o ->
                Message.Pause(
                    seq, timestampNs,
                    paused = (o["paused"] as? JsonPrimitive)?.contentOrNull == "true",
                )
            }

            TYPE_ERROR -> jsonObject(bytes, length)?.let { o ->
                Message.ErrorMsg(
                    seq, timestampNs,
                    code = o.string("code") ?: "",
                    message = o.string("message") ?: "",
                )
            }

            else -> null // unknown msg_type: ignore (forward compatibility)
        }
    }

    /** True if [msgType] requires resend-until-ACK per §3/§6 of the spec. */
    fun isReliable(msgType: Int): Boolean = when (msgType) {
        TYPE_BYE, TYPE_HELLO, TYPE_WELCOME, TYPE_ERROR,
        TYPE_RECORD_START, TYPE_RECORD_STOP, TYPE_RECORD_BAKED, TYPE_RECENTER,
        TYPE_PARAMS, TYPE_PAUSE, TYPE_SEEK, TYPE_TAKE_LIST, TYPE_TAKE_PULL,
        TYPE_FRAME_RESET,
        -> true

        else -> false
    }

    private inline fun jsonBody(build: kotlinx.serialization.json.JsonObjectBuilder.() -> Unit): ByteArray =
        buildJsonObject(build).toString().encodeToByteArray()

    /** `{"viewport_video": {"<key>": [[w, h], ...]}}` as pairs. */
    private fun sizeList(o: JsonObject, key: String): List<Pair<Int, Int>> =
        (o["viewport_video"] as? JsonObject)
            ?.get(key)?.let { it as? JsonArray }
            ?.mapNotNull { entry ->
                val pair = entry as? JsonArray ?: return@mapNotNull null
                if (pair.size < 2) return@mapNotNull null
                val w = pair[0].jsonPrimitive.intOrNull ?: return@mapNotNull null
                val h = pair[1].jsonPrimitive.intOrNull ?: return@mapNotNull null
                w to h
            } ?: emptyList()

    private fun jsonObject(bytes: ByteArray, length: Int): JsonObject? = try {
        val text = String(bytes, HEADER_SIZE, length - HEADER_SIZE, Charsets.UTF_8)
        json.parseToJsonElement(text) as? JsonObject
    } catch (_: Exception) {
        null
    }

    private fun JsonObject.string(key: String): String? =
        (this[key] as? JsonPrimitive)?.contentOrNull

    private fun JsonObject.int(key: String): Int? =
        (this[key] as? JsonPrimitive)?.intOrNull

    private fun JsonObject.long(key: String): Long? =
        (this[key] as? JsonPrimitive)?.longOrNull

    private fun JsonObject.double(key: String): Double? =
        (this[key] as? JsonPrimitive)?.doubleOrNull

    private fun JsonObject.boolean(key: String): Boolean? =
        (this[key] as? JsonPrimitive)?.booleanOrNull
}
