// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.1.20" apply false
    id("org.jetbrains.kotlin.jvm") version "2.1.20" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.1.20" apply false
    id("org.jetbrains.kotlin.plugin.serialization") version "2.1.20" apply false
    // Renders real Compose screens to PNG on the JVM, no device or emulator, so
    // UI can be designed and reviewed on the desktop. Design-time only.
    id("io.github.takahirom.roborazzi") version "1.43.1" apply false
}
